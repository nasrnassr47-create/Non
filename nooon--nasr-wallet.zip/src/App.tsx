import React, { useState } from 'react';
import { 
  FolderTree, 
  Smartphone, 
  Database, 
  Server, 
  Terminal, 
  BookOpen, 
  Stethoscope, 
  Save, 
  Crown, 
  Layers, 
  ShieldCheck, 
  CheckCircle2, 
  AlertCircle, 
  Sparkles, 
  Sliders, 
  Users, 
  Briefcase, 
  Store, 
  Headphones, 
  FileText,
  Clock,
  ArrowRight,
  ExternalLink,
  ChevronLeft,
  Key,
  Download
} from 'lucide-react';
import { Logo } from './components/Logo';
import { SystemVisualizer } from './components/SystemVisualizer';
import { MobileFrame } from './components/MobileFrame';
import { UserApp } from './features/user/UserApp';
import { UserClientApp } from './components/apps/UserClientApp';
import { SubscriberApp } from './components/apps/SubscriberApp';
import { FamilyMiniApp } from './components/apps/FamilyMiniApp';
import { AgentApp } from './components/apps/AgentApp';
import { MerchantApp } from './components/apps/MerchantApp';
import { AdminPanel } from './components/apps/AdminPanel';
import { SovereignOwnerPanel } from './components/apps/SovereignOwnerPanel';
import { SupportApp } from './components/apps/SupportApp';
import { DiagnosticsView } from './components/modules/DiagnosticsView';
import { DocumentationEngineView } from './components/modules/DocumentationEngineView';
import { BackupAutoSaveView } from './components/modules/BackupAutoSaveView';
import { ApiExplorerView } from './components/modules/ApiExplorerView';
import { MicroservicesView } from './components/modules/MicroservicesView';
import { DatabaseERDView } from './components/modules/DatabaseERDView';
import { MasterControlPanel } from './features/control/MasterControlPanel';
import { EnterpriseCentralDashboard } from './components/central/EnterpriseCentralDashboard';
import { SecretVaultAndDbView } from './components/central/SecretVaultAndDbView';
import { DownloadCodeModal } from './components/central/DownloadCodeModal';
import { AppRole } from './types';

export default function App() {
  // Navigation State - Default to 'central' to show the enterprise central dashboard exactly matching user reference image
  const [activeTab, setActiveTab] = useState<
    'central' | 'portal' | 'apps' | 'control' | 'vault' | 'tree' | 'db' | 'services' | 'api' | 'docs' | 'diagnostics' | 'backup'
  >('central');

  // Selected Mobile/Role App
  const [selectedRole, setSelectedRole] = useState<AppRole>('client');
  const [viewInMobileFrame, setViewInMobileFrame] = useState(true);

  // Real-time Auto-Save notification feed
  const [lastAutoSaveAction, setLastAutoSaveAction] = useState('جاهزية المنظومة السيادية 100%');
  const [notificationMessage, setNotificationMessage] = useState<string | null>(null);
  const [isDownloadModalOpen, setIsDownloadModalOpen] = useState(false);

  const handleNotifyAutoSave = (action: string) => {
    setLastAutoSaveAction(action);
    setNotificationMessage(action);
    setTimeout(() => {
      setNotificationMessage(null);
    }, 4000);
  };

  const appRoleList = [
    { role: 'client' as AppRole, nameAr: 'تطبيق العميل (Client)', icon: Smartphone, color: 'text-emerald-400', badge: 'P2P & QR' },
    { role: 'subscriber' as AppRole, nameAr: 'تطبيق المشترك ورب الأسرة (Subscriber)', icon: Users, color: 'text-blue-400', badge: 'رواتب وعائلة' },
    { role: 'family_mini' as AppRole, nameAr: 'محفظة التابع / الابن (Family Mini)', icon: Users, color: 'text-teal-400', badge: 'إشراف أبوي' },
    { role: 'agent' as AppRole, nameAr: 'تطبيق الوكيل والصراف (Agent)', icon: Briefcase, color: 'text-amber-400', badge: 'إيداع وسحب' },
    { role: 'merchant' as AppRole, nameAr: 'تطبيق التاجر ونقاط البيع (Merchant POS)', icon: Store, color: 'text-cyan-400', badge: 'فواتير كاشير' },
    { role: 'admin' as AppRole, nameAr: 'لوحة إدارة العمليات (Admin Panel)', icon: ShieldCheck, color: 'text-indigo-400', badge: 'KYC & AML' },
    { role: 'sovereign' as AppRole, nameAr: 'لوحة التحكم السيادية للمالك (Sovereign God Mode)', icon: Crown, color: 'text-amber-300', badge: 'تحكم مطلق' },
    { role: 'support' as AppRole, nameAr: 'خدمة العملاء والدعم (Support 24/7)', icon: Headphones, color: 'text-emerald-300', badge: 'دعم حي' }
  ];

  const currentRoleInfo = appRoleList.find(r => r.role === selectedRole) || appRoleList[0];

  // If activeTab is 'central', render the complete Enterprise Central Dashboard matching the reference screenshot
  if (activeTab === 'central') {
    return (
      <div className="min-h-screen bg-[#F4F6F9] dark:bg-slate-950 font-sans relative">
        {/* Floating Quick Navigation Pill to access Phone Simulator, God Mode, or Developer Tools */}
        <div className="fixed bottom-4 left-4 z-50 flex items-center gap-2 bg-slate-900/95 text-white p-2 rounded-2xl border border-slate-700 shadow-2xl backdrop-blur-md text-xs">
          <button
            onClick={() => { setActiveTab('apps'); setSelectedRole('client'); }}
            className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl flex items-center gap-1.5 cursor-pointer shadow-md transition-all"
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span>محاكي الهاتف الميداني</span>
          </button>
          <button
            onClick={() => setActiveTab('control')}
            className="px-3 py-1.5 bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 font-bold rounded-xl flex items-center gap-1.5 cursor-pointer border border-amber-500/40 transition-all"
          >
            <Crown className="w-3.5 h-3.5" />
            <span>God Mode</span>
          </button>
          <button
            onClick={() => setActiveTab('vault')}
            className="px-3 py-1.5 bg-cyan-600/30 hover:bg-cyan-600/50 text-cyan-300 font-bold rounded-xl flex items-center gap-1.5 cursor-pointer border border-cyan-500/40 transition-all"
          >
            <Key className="w-3.5 h-3.5" />
            <span>خزنة الأكواد والبيانات السرية</span>
          </button>
          <button
            onClick={() => setActiveTab('portal')}
            className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold rounded-xl flex items-center gap-1.5 cursor-pointer transition-all"
          >
            <Layers className="w-3.5 h-3.5" />
            <span>الأدوات والشجرة</span>
          </button>
        </div>

        <EnterpriseCentralDashboard
          onOpenSimulator={() => {
            setActiveTab('apps');
            setSelectedRole('client');
          }}
          onOpenMobileApp={() => {
            setActiveTab('apps');
          }}
          onSelectRoleApp={(role) => {
            setSelectedRole(role as AppRole);
            setActiveTab('apps');
          }}
        />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-emerald-500 selection:text-white">
      {/* Sovereign Master Header */}
      <header className="bg-slate-900/90 backdrop-blur-md border-b border-slate-800 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3 flex flex-col md:flex-row items-center justify-between gap-3">
          {/* Logo & Slogan */}
          <div className="flex items-center gap-3 w-full md:w-auto justify-between md:justify-start">
            <div className="flex items-center gap-2.5">
              <Logo size="md" />
              <div>
                <div className="flex items-center gap-1.5">
                  <span className="font-extrabold text-base tracking-tight text-white">نصر والت</span>
                  <span className="text-[11px] font-mono text-emerald-400 font-bold">NASR WALLET V2</span>
                  <span className="bg-amber-500/20 text-amber-300 text-[10px] px-2 py-0.2 rounded-full border border-amber-500/30 font-semibold">
                    النظام السيادي الشامل
                  </span>
                </div>
                <p className="text-[11px] text-slate-400 -mt-0.5">محفظتك أنت.. المنظومة المالية السيادية متعددة الأدوار</p>
              </div>
            </div>

            {/* Live Auto-save WAL Indicator */}
            <div className="flex items-center gap-2 bg-slate-950 px-3 py-1.5 rounded-xl border border-slate-800 text-xs text-slate-300">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span className="hidden sm:inline text-slate-400 text-[11px]">حفظ فوري WAL:</span>
              <span className="text-emerald-300 font-mono text-[11px] truncate max-w-[160px]">
                {lastAutoSaveAction}
              </span>
            </div>
          </div>

          {/* Quick Stats & God Mode Indicator */}
          <div className="flex items-center gap-2 text-xs">
            <button
              onClick={() => setActiveTab('central')}
              className="px-3.5 py-1.5 bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-500 hover:to-cyan-500 text-white font-black rounded-xl text-xs flex items-center gap-1.5 shadow-md shadow-blue-900/40 transition-all cursor-pointer"
            >
              <Crown className="w-4 h-4" />
              <span>لوحة المنظومة المركزية Ω</span>
            </button>
            <button
              onClick={() => setActiveTab('control')}
              className="px-3.5 py-1.5 bg-gradient-to-r from-amber-500 via-amber-400 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-black rounded-xl text-xs flex items-center gap-1.5 shadow-md shadow-amber-950/40 transition-all cursor-pointer"
            >
              <Sliders className="w-4 h-4" />
              <span>God Mode</span>
            </button>
            <div className="px-2.5 py-1.5 bg-slate-800 text-slate-300 rounded-xl border border-slate-700 text-[11px] font-mono">
              42 فرعاً • 22 خدمة • 50+ جدول
            </div>
          </div>
        </div>

        {/* Global Navigation Bar */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 overflow-x-auto">
          <nav className="flex items-center gap-1 py-1.5 border-t border-slate-800/80 text-xs whitespace-nowrap">
            <button
              onClick={() => setActiveTab('central')}
              className="px-3 py-2 rounded-xl font-bold transition-all flex items-center gap-1.5 cursor-pointer text-blue-400 hover:text-white hover:bg-slate-800"
            >
              <Crown className="w-4 h-4" /> 0. المنظومة المركزية Ω (الرئيسية)
            </button>

            <button
              onClick={() => setActiveTab('apps')}
              className={`px-3 py-2 rounded-xl font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                activeTab === 'apps'
                  ? 'bg-emerald-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              <Smartphone className="w-4 h-4" /> 1. المحفظة والتطبيقات الميدانية
            </button>

            <button
              onClick={() => setActiveTab('control')}
              className={`px-3 py-2 rounded-xl font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                activeTab === 'control'
                  ? 'bg-amber-600 text-white shadow-md'
                  : 'text-amber-400/90 hover:text-amber-300 hover:bg-slate-800'
              }`}
            >
              <Sliders className="w-4 h-4" /> 2. الإعدادات والتحكم الكامل (Settings)
            </button>

            <button
              onClick={() => setActiveTab('portal')}
              className={`px-3 py-2 rounded-xl font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                activeTab === 'portal'
                  ? 'bg-emerald-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              <Layers className="w-4 h-4" /> 3. البوابة السيادية (Portal)
            </button>

            <button
              onClick={() => setActiveTab('tree')}
              className={`px-3 py-2 rounded-xl font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                activeTab === 'tree'
                  ? 'bg-emerald-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              <FolderTree className="w-4 h-4" /> 4. الشجرة الـ 42 والمراحل
            </button>

            <button
              onClick={() => setActiveTab('db')}
              className={`px-3 py-2 rounded-xl font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                activeTab === 'db'
                  ? 'bg-emerald-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              <Database className="w-4 h-4" /> 5. قاعدة البيانات (50+ جدول ERD)
            </button>

            <button
              onClick={() => setActiveTab('services')}
              className={`px-3 py-2 rounded-xl font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                activeTab === 'services'
                  ? 'bg-emerald-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              <Server className="w-4 h-4" /> 6. الخدمات المصغرة الـ 22
            </button>

            <button
              onClick={() => setActiveTab('api')}
              className={`px-3 py-2 rounded-xl font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                activeTab === 'api'
                  ? 'bg-emerald-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              <Terminal className="w-4 h-4" /> 7. مستكشف الواجهات (OpenAPI)
            </button>

            <button
              onClick={() => setActiveTab('docs')}
              className={`px-3 py-2 rounded-xl font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                activeTab === 'docs'
                  ? 'bg-emerald-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              <BookOpen className="w-4 h-4" /> 8. الأدلة الـ 12 والـ APK
            </button>

            <button
              onClick={() => setActiveTab('diagnostics')}
              className={`px-3 py-2 rounded-xl font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                activeTab === 'diagnostics'
                  ? 'bg-emerald-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              <Stethoscope className="w-4 h-4" /> 9. الفاحص الذكي (Diagnostics)
            </button>

            <button
              onClick={() => setActiveTab('backup')}
              className={`px-3 py-2 rounded-xl font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                activeTab === 'backup'
                  ? 'bg-emerald-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              <Save className="w-4 h-4" /> 10. الحفظ التلقائي WAL
            </button>

            <button
              onClick={() => setActiveTab('vault')}
              className={`px-3 py-2 rounded-xl font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                activeTab === 'vault'
                  ? 'bg-cyan-600 text-white shadow-md'
                  : 'text-cyan-400 hover:text-cyan-300 hover:bg-slate-800'
              }`}
            >
              <Key className="w-4 h-4" /> 11. قاعدة البيانات السرية ومخزن الأكواد (Secret Vault & DB)
            </button>
          </nav>
        </div>
      </header>

      {/* Real-time floating notification */}
      {notificationMessage && (
        <div className="fixed bottom-6 left-6 z-50 bg-emerald-950/90 text-emerald-200 px-4 py-2.5 rounded-2xl border border-emerald-500/50 shadow-2xl flex items-center gap-2.5 text-xs backdrop-blur">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span>تم الحفظ اللحظي في مخزن البيانات: {notificationMessage}</span>
        </div>
      )}

      {/* Main App Body */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-6">
        {/* Universal Top Back Bar for All Subpages */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-900/95 border border-slate-800 p-3.5 mb-6 rounded-2xl shadow-xl">
          <div className="flex items-center gap-2 flex-wrap">
            <button
              onClick={() => setActiveTab('central')}
              className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold flex items-center gap-2 transition-all cursor-pointer shadow-md w-fit"
              title="الرجوع إلى لوحة التحكم والعمليات المركزية"
            >
              <ArrowRight className="w-4 h-4" />
              <span>العودة للوحة المركزية (Back to Central)</span>
            </button>

            <button
              onClick={() => setIsDownloadModalOpen(true)}
              className="px-3.5 py-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer shadow-md w-fit"
              title="تنزيل الكود كاملاً بصيغة ZIP, APK, PDF, أو HTML"
            >
              <Download className="w-4 h-4" />
              <span>تحميل الكود (ZIP / APK / PDF)</span>
            </button>
          </div>

          <div className="flex items-center gap-2 text-xs text-slate-400 font-mono">
            <span>القسم المفتوح حالياً:</span>
            <span className="px-2.5 py-1 bg-slate-800/80 border border-slate-700/80 rounded-lg text-emerald-400 font-bold">
              {activeTab}
            </span>
          </div>
        </div>

        {/* TAB 1: MASTER SOVEREIGN PORTAL */}
        {activeTab === 'portal' && (
          <div className="space-y-6">
            {/* Hero Sovereign Overview Card */}
            <div className="p-6 rounded-3xl bg-gradient-to-br from-emerald-950 via-slate-900 to-black border border-emerald-500/40 shadow-2xl relative overflow-hidden">
              <div className="relative z-10 space-y-3">
                <div className="flex items-center gap-2">
                  <span className="p-2 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                    <Crown className="w-6 h-6" />
                  </span>
                  <div>
                    <h2 className="text-xl sm:text-2xl font-black text-white">
                      محفظة نصر والت الإلكترونية السيادية (Nasr Wallet V2)
                    </h2>
                    <p className="text-xs text-emerald-300 font-mono mt-0.5">
                      Sovereign Multi-Role E-Wallet Architecture & Engine
                    </p>
                  </div>
                </div>

                <p className="text-xs sm:text-sm text-slate-300 leading-relaxed max-w-3xl">
                  النظام المالي الإلكتروني المتكامل المبني وفق أمر البناء الشامل V2. يربط 7 تطبيقات ميدانية للهاتف، 22 خدمة مصغرة معزولة، قاعدة بيانات دفتر الأستاذ المزدوج غير القابل للتعديل، ومخزن الأسرار المشفر، مع تحكم سيادي مطلق للمالك.
                </p>

                {/* 4 Pillars Stats */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-3">
                  <div 
                    onClick={() => setActiveTab('tree')}
                    className="p-3 bg-slate-950/70 hover:bg-slate-900 border border-emerald-500/30 rounded-2xl cursor-pointer transition-all"
                  >
                    <div className="text-[11px] text-slate-400">الشجرة الشاملة</div>
                    <div className="text-lg font-black text-emerald-400 font-mono">42 فرعاً</div>
                    <div className="text-[10px] text-slate-500">من الجذر للأوراق مكتملة 100%</div>
                  </div>

                  <div 
                    onClick={() => setActiveTab('apps')}
                    className="p-3 bg-slate-950/70 hover:bg-slate-900 border border-emerald-500/30 rounded-2xl cursor-pointer transition-all"
                  >
                    <div className="text-[11px] text-slate-400">التطبيقات الميدانية</div>
                    <div className="text-lg font-black text-teal-300 font-mono">7 تطبيقات</div>
                    <div className="text-[10px] text-slate-500">Mobile-First لكل الأدوار</div>
                  </div>

                  <div 
                    onClick={() => setActiveTab('services')}
                    className="p-3 bg-slate-950/70 hover:bg-slate-900 border border-emerald-500/30 rounded-2xl cursor-pointer transition-all"
                  >
                    <div className="text-[11px] text-slate-400">الخدمات المصغرة</div>
                    <div className="text-lg font-black text-amber-300 font-mono">22 خدمة</div>
                    <div className="text-[10px] text-slate-500">gRPC, Kafka, REST</div>
                  </div>

                  <div 
                    onClick={() => setActiveTab('db')}
                    className="p-3 bg-slate-950/70 hover:bg-slate-900 border border-emerald-500/30 rounded-2xl cursor-pointer transition-all"
                  >
                    <div className="text-[11px] text-slate-400">جداول البيانات</div>
                    <div className="text-lg font-black text-blue-400 font-mono">50+ جدولاً</div>
                    <div className="text-[10px] text-slate-500">دفتر الأستاذ وقيد مزدوج</div>
                  </div>
                </div>
              </div>
            </div>

            {/* Quick Access to the 7 Role Apps */}
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <Smartphone className="w-5 h-5 text-emerald-400" />
                  التطبيقات الميدانية السبعة (اختر تطبيقاً للمعاينة الفورية):
                </h3>
                <span className="text-xs text-slate-400">تصميم Mobile-First بالكامل</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                {appRoleList.slice(0, 4).map((r) => {
                  const Icon = r.icon;
                  return (
                    <button
                      key={r.role}
                      onClick={() => {
                        setSelectedRole(r.role);
                        setActiveTab('apps');
                      }}
                      className="p-4 bg-slate-900 hover:bg-slate-850 border border-slate-800 hover:border-emerald-500/50 rounded-2xl text-right transition-all group flex flex-col justify-between min-h-[110px]"
                    >
                      <div className="flex justify-between items-start">
                        <Icon className={`w-6 h-6 ${r.color}`} />
                        <span className="text-[10px] bg-slate-800 text-slate-300 px-2 py-0.5 rounded-full border border-slate-700">
                          {r.badge}
                        </span>
                      </div>
                      <div>
                        <div className="text-xs font-bold text-white group-hover:text-emerald-300 transition-colors">
                          {r.nameAr}
                        </div>
                        <div className="text-[11px] text-slate-400 mt-0.5 flex items-center gap-1">
                          <span>فتح وتشغيل التطبيق</span>
                          <ChevronLeft className="w-3 h-3 group-hover:-translate-x-1 transition-transform" />
                        </div>
                      </div>
                    </button>
                  );
                })}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                {appRoleList.slice(4).map((r) => {
                  const Icon = r.icon;
                  return (
                    <button
                      key={r.role}
                      onClick={() => {
                        setSelectedRole(r.role);
                        setActiveTab('apps');
                      }}
                      className="p-4 bg-slate-900 hover:bg-slate-850 border border-slate-800 hover:border-emerald-500/50 rounded-2xl text-right transition-all group flex flex-col justify-between min-h-[110px]"
                    >
                      <div className="flex justify-between items-start">
                        <Icon className={`w-6 h-6 ${r.color}`} />
                        <span className="text-[10px] bg-slate-800 text-slate-300 px-2 py-0.5 rounded-full border border-slate-700">
                          {r.badge}
                        </span>
                      </div>
                      <div>
                        <div className="text-xs font-bold text-white group-hover:text-emerald-300 transition-colors">
                          {r.nameAr}
                        </div>
                        <div className="text-[11px] text-slate-400 mt-0.5 flex items-center gap-1">
                          <span>فتح وتشغيل التطبيق</span>
                          <ChevronLeft className="w-3 h-3 group-hover:-translate-x-1 transition-transform" />
                        </div>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Comprehensive Tree Preview */}
            <SystemVisualizer 
              onSelectBranch={() => setActiveTab('tree')}
              onSelectService={() => setActiveTab('services')}
            />
          </div>
        )}

        {/* TAB 2: THE 7 ROLE-BASED APPS */}
        {activeTab === 'apps' && (
          <div className="space-y-4">
            {/* Top Selector Ribbon */}
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 p-4 bg-slate-900 rounded-2xl border border-slate-800">
              <div>
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <Smartphone className="w-5 h-5 text-emerald-400" />
                  محاكي التطبيقات الميدانية للهواتف الذكية (Mobile Apps)
                </h3>
                <p className="text-xs text-slate-400">
                  التطبيق النشط حالياً: <span className="text-emerald-300 font-bold">{currentRoleInfo.nameAr}</span>
                </p>
              </div>

              {/* View mode toggle */}
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setViewInMobileFrame(!viewInMobileFrame)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold border transition-all ${
                    viewInMobileFrame
                      ? 'bg-emerald-950 text-emerald-300 border-emerald-700'
                      : 'bg-slate-800 text-slate-300 border-slate-700'
                  }`}
                >
                  {viewInMobileFrame ? 'وضع إطار الهاتف (Mobile View)' : 'وضع العرض الموسع (Full View)'}
                </button>
              </div>
            </div>

            {/* Roles Bar */}
            <div className="flex gap-2 overflow-x-auto pb-2 text-xs">
              {appRoleList.map((r) => {
                const Icon = r.icon;
                const isSelected = selectedRole === r.role;
                return (
                  <button
                    key={r.role}
                    onClick={() => setSelectedRole(r.role)}
                    className={`px-3 py-2 rounded-xl font-bold shrink-0 transition-all flex items-center gap-1.5 border ${
                      isSelected
                        ? 'bg-emerald-600 text-white border-emerald-500 shadow-md'
                        : 'bg-slate-900 text-slate-400 border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    <Icon className="w-4 h-4" />
                    <span>{r.nameAr}</span>
                  </button>
                );
              })}
            </div>

            {/* Active App Container */}
            <div className="mt-4">
              {selectedRole === 'client' ? (
                <UserApp
                  showFrame={viewInMobileFrame}
                  onRequestRoleApp={(role) => setSelectedRole(role as AppRole)}
                />
              ) : viewInMobileFrame && selectedRole !== 'sovereign' && selectedRole !== 'admin' ? (
                <MobileFrame activeAppName={currentRoleInfo.nameAr}>
                  {selectedRole === 'subscriber' && <SubscriberApp onNotifyAutoSave={handleNotifyAutoSave} />}
                  {selectedRole === 'family_mini' && <FamilyMiniApp onNotifyAutoSave={handleNotifyAutoSave} />}
                  {selectedRole === 'agent' && <AgentApp onNotifyAutoSave={handleNotifyAutoSave} />}
                  {selectedRole === 'merchant' && <MerchantApp onNotifyAutoSave={handleNotifyAutoSave} />}
                  {selectedRole === 'support' && <SupportApp onNotifyAutoSave={handleNotifyAutoSave} />}
                </MobileFrame>
              ) : (
                <div>
                  {selectedRole === 'subscriber' && <SubscriberApp onNotifyAutoSave={handleNotifyAutoSave} />}
                  {selectedRole === 'family_mini' && <FamilyMiniApp onNotifyAutoSave={handleNotifyAutoSave} />}
                  {selectedRole === 'agent' && <AgentApp onNotifyAutoSave={handleNotifyAutoSave} />}
                  {selectedRole === 'merchant' && <MerchantApp onNotifyAutoSave={handleNotifyAutoSave} />}
                  {selectedRole === 'admin' && <AdminPanel onNotifyAutoSave={handleNotifyAutoSave} />}
                  {selectedRole === 'sovereign' && <SovereignOwnerPanel onNotifyAutoSave={handleNotifyAutoSave} />}
                  {selectedRole === 'support' && <SupportApp onNotifyAutoSave={handleNotifyAutoSave} />}
                </div>
              )}
            </div>
          </div>
        )}

        {/* TAB 2: SOVEREIGN MASTER CONTROL PANEL & GOD MODE */}
        {activeTab === 'control' && (
          <MasterControlPanel 
            onRequestRoleApp={(role) => {
              setSelectedRole(role as AppRole);
              setActiveTab('apps');
            }} 
          />
        )}

        {/* TAB 3: 42-BRANCH HIERARCHY */}
        {activeTab === 'tree' && (
          <SystemVisualizer 
            onSelectService={() => setActiveTab('services')}
            onSelectBranch={() => {}}
          />
        )}

        {/* TAB 4: DATABASE SCHEMA & 50+ TABLES ERD */}
        {activeTab === 'db' && (
          <DatabaseERDView />
        )}

        {/* TAB 5: 22 MICROSERVICES MESH */}
        {activeTab === 'services' && (
          <MicroservicesView />
        )}

        {/* TAB 6: OPENAPI 3.0 EXPLORER */}
        {activeTab === 'api' && (
          <ApiExplorerView />
        )}

        {/* TAB 7: 12 MANUALS & APK BUILDER */}
        {activeTab === 'docs' && (
          <DocumentationEngineView onNotifyAutoSave={handleNotifyAutoSave} />
        )}

        {/* TAB 8: 24-POINT DIAGNOSTICS & REPAIR */}
        {activeTab === 'diagnostics' && (
          <DiagnosticsView onNotifyAutoSave={handleNotifyAutoSave} />
        )}

        {/* TAB 9: AUTO-SAVE & CONTINUOUS WAL */}
        {activeTab === 'backup' && (
          <BackupAutoSaveView lastAction={lastAutoSaveAction} onNotifyAutoSave={handleNotifyAutoSave} />
        )}

        {/* TAB 11: SECRET DATABASE & MASTER CODES VAULT */}
        {activeTab === 'vault' && (
          <div className="space-y-4">
            <SecretVaultAndDbView />
          </div>
        )}
      </main>

      {/* Sovereign Master Footer */}
      <footer className="bg-slate-900 border-t border-slate-800 text-slate-400 py-6 mt-12 text-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <Logo size="sm" />
            <div>
              <div className="font-bold text-white">منظومة محفظة نصر والت الإلكترونية السيادية V2</div>
              <div className="text-[11px] text-slate-500">
                شعار المنظومة: <span className="text-emerald-400 font-semibold">محفظتك أنت..</span> • تم البناء من الجذر إلى الأوراق وفق خطة الـ 42 فرعاً
              </div>
            </div>
          </div>

          <div className="flex items-center gap-4 text-[11px]">
            <span className="text-emerald-400 font-mono">Zero-Data-Loss WAL: Active</span>
            <span className="text-slate-600">|</span>
            <span className="text-teal-300 font-mono">Double-Spending Shield: Active</span>
            <span className="text-slate-600">|</span>
            <span className="text-amber-400 font-mono">Owner Sovereignty: Uncompromised</span>
          </div>
        </div>
      </footer>

      {/* Global Download Code Modal */}
      <DownloadCodeModal
        isOpen={isDownloadModalOpen}
        onClose={() => setIsDownloadModalOpen(false)}
        onNotify={(msg) => handleNotifyAutoSave(msg)}
      />
    </div>
  );
}
