// src/lib/format.ts
import { CurrencyCode } from '../types/wallet';

export const CURRENCY_SYMBOLS: Record<CurrencyCode, { ar: string; en: string }> = {
  YER: { ar: 'ر.ي', en: 'YER' },
  SAR: { ar: 'ر.س', en: 'SAR' },
  USD: { ar: '$', en: 'USD' },
  EUR: { ar: '€', en: 'EUR' },
};

export function formatCurrency(
  amount: number, 
  currency: CurrencyCode = 'YER', 
  lang: 'ar' | 'en' = 'ar'
): string {
  const formattedNumber = new Intl.NumberFormat(lang === 'ar' ? 'ar-YE' : 'en-US', {
    minimumFractionDigits: currency === 'USD' ? 2 : 0,
    maximumFractionDigits: 2,
  }).format(amount);

  const sym = lang === 'ar' ? CURRENCY_SYMBOLS[currency].ar : CURRENCY_SYMBOLS[currency].en;
  return lang === 'ar' ? `${formattedNumber} ${sym}` : `${sym} ${formattedNumber}`;
}

export function formatDate(dateString: string, lang: 'ar' | 'en' = 'ar'): string {
  try {
    const d = new Date(dateString);
    if (isNaN(d.getTime())) return dateString;
    return new Intl.DateTimeFormat(lang === 'ar' ? 'ar-YE' : 'en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    }).format(d);
  } catch {
    return dateString;
  }
}

export function formatRelativeTime(dateString: string, lang: 'ar' | 'en' = 'ar'): string {
  try {
    const d = new Date(dateString);
    const now = new Date();
    const diffSec = Math.floor((now.getTime() - d.getTime()) / 1000);

    if (diffSec < 60) return lang === 'ar' ? 'الآن' : 'just now';
    if (diffSec < 3600) {
      const min = Math.floor(diffSec / 60);
      return lang === 'ar' ? `منذ ${min} دقيقة` : `${min}m ago`;
    }
    if (diffSec < 86400) {
      const hours = Math.floor(diffSec / 3600);
      return lang === 'ar' ? `منذ ${hours} ساعة` : `${hours}h ago`;
    }
    const days = Math.floor(diffSec / 86400);
    return lang === 'ar' ? `منذ ${days} يوم` : `${days}d ago`;
  } catch {
    return dateString;
  }
}

export function formatPhone(phone: string): string {
  if (!phone) return '';
  const cleaned = phone.replace(/\D/g, '');
  if (cleaned.startsWith('967') && cleaned.length >= 12) {
    return `+${cleaned.substring(0, 3)} ${cleaned.substring(3, 5)} ${cleaned.substring(5, 8)} ${cleaned.substring(8)}`;
  }
  return phone;
}

export function formatCardNumber(cardNumber: string): string {
  return cardNumber.replace(/\s?/g, '').replace(/(\d{4})/g, '$1 ').trim();
}
