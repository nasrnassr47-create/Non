// src/lib/crypto.ts
/**
 * Simple client-side pseudo-cryptographic utilities for prototype simulation
 */

export function pseudoSha256(input: string): string {
  let hash = 0;
  for (let i = 0; i < input.length; i++) {
    const char = input.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash |= 0; // Convert to 32bit integer
  }
  const hexPart1 = Math.abs(hash).toString(16).padStart(8, '0');
  const hexPart2 = Math.abs(hash ^ 0x5a5a5a5a).toString(16).padStart(8, '0');
  const hexPart3 = Math.abs(hash ^ 0xa5a5a5a5).toString(16).padStart(8, '0');
  const hexPart4 = Math.abs(hash ^ 0x12345678).toString(16).padStart(8, '0');
  return `${hexPart1}${hexPart2}${hexPart3}${hexPart4}`.toLowerCase();
}

export function generateRefNo(prefix = 'TXN'): string {
  const rand = Math.floor(100000 + Math.random() * 900000);
  return `${prefix}-${rand}`;
}

export function generateToken(length = 32): string {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let token = '';
  for (let i = 0; i < length; i++) {
    token += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return token;
}

export function maskSecret(val: string): string {
  if (val.length <= 6) return '••••••••';
  return `${val.substring(0, 3)}••••••••${val.substring(val.length - 3)}`;
}
