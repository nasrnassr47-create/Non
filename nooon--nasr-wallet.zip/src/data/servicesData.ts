export interface Microservice {
  id: string;
  code: string;
  name: string;
  nameAr: string;
  port: number;
  status: 'healthy' | 'active' | 'synced';
  latencyMs: number;
  protocol: 'gRPC' | 'REST' | 'Kafka';
  description: string;
  endpoints: string[];
  keyFeatures: string[];
}

export const BACKEND_SERVICES: Microservice[] = [
  {
    id: 's-auth',
    code: '10.1',
    name: 'Auth & Identity Service',
    nameAr: 'خدمة الهوية والمصادقة والـ 2FA',
    port: 5001,
    status: 'healthy',
    latencyMs: 24,
    protocol: 'gRPC',
    description: 'تسجيل الدخول، التحقق من الهوية الوطنية KYC والقياسات الحيوية',
    endpoints: ['/v1/auth/login', '/v1/auth/otp', '/v1/auth/biometrics'],
    keyFeatures: ['JWT Token Rotation', 'Device Fingerprinting', 'Brute-force Shield']
  },
  {
    id: 's-wallet',
    code: '10.2',
    name: 'Wallet Core Engine',
    nameAr: 'محرك المحافظ ودفتر الأستاذ المزدوج',
    port: 5002,
    status: 'healthy',
    latencyMs: 18,
    protocol: 'gRPC',
    description: 'إدارة المحافظ متعددة العملات (YER, SAR, USD) وقيد اليومية المتوازن',
    endpoints: ['/v1/wallets/balance', '/v1/wallets/create', '/v1/wallets/lock'],
    keyFeatures: ['Strict Double-Entry Ledger', 'Multi-currency Vault', 'Balance Snapshotting']
  },
  {
    id: 's-txn',
    code: '10.3',
    name: 'Transaction Engine (Saga)',
    nameAr: 'محرك التحويلات والمعاملات السريعة',
    port: 5003,
    status: 'healthy',
    latencyMs: 32,
    protocol: 'Kafka',
    description: 'تنفيذ التحويلات P2P ومنع الصرف المزدوج عبر Saga Orchestration',
    endpoints: ['/v1/txn/send', '/v1/txn/status', '/v1/txn/rollback'],
    keyFeatures: ['Idempotency Guard', 'Compensating Transactions', 'Sub-second Finality']
  },
  {
    id: 's-payments',
    code: '10.4',
    name: 'Payment & Bill Service',
    nameAr: 'بوابة سداد الفواتير والشحن',
    port: 5004,
    status: 'healthy',
    latencyMs: 45,
    protocol: 'REST',
    description: 'سداد فواتير الاتصالات، باقات الإنترنت والمياه والكهرباء والبطاقات',
    endpoints: ['/v1/bills/inquire', '/v1/bills/pay', '/v1/telecom/recharge'],
    keyFeatures: ['Direct Telco APIs', 'Instant Receipt Generation', 'Auto-Retry Queue']
  },
  {
    id: 's-family',
    code: '10.5',
    name: 'Family Sub-Wallet Service',
    nameAr: 'خدمة المحافظ العائلية المصغرة',
    port: 5005,
    status: 'healthy',
    latencyMs: 22,
    protocol: 'REST',
    description: 'إدارة أفراد العائلة، حدود الصرف اليومية والشهرية وموافقة الوصي',
    endpoints: ['/v1/family/members', '/v1/family/limits', '/v1/family/approve'],
    keyFeatures: ['Guardian Approval Flow', 'Category Restrictions', 'Allowance Scheduler']
  },
  {
    id: 's-link',
    code: '10.6',
    name: 'Bank & Exchange Gateway',
    nameAr: 'بوابة ربط البنوك وشبكات الصرافة',
    port: 5006,
    status: 'healthy',
    latencyMs: 65,
    protocol: 'gRPC',
    description: 'الربط مع شبكات الصرافة اليمنية (النجم، الامتياز، يمن إكسبرس) والبنوك',
    endpoints: ['/v1/remit/send', '/v1/remit/receive', '/v1/banks/sync'],
    keyFeatures: ['Multi-network Routing', 'Real-time FX Rates', 'Settlement Reconciliation']
  },
  {
    id: 's-payroll',
    code: '10.7',
    name: 'Corporate Payroll Engine',
    nameAr: 'محرك الرواتب والكشوف الجماعية',
    port: 5007,
    status: 'healthy',
    latencyMs: 50,
    protocol: 'Kafka',
    description: 'معالجة صرف الرواتب لآلاف الموظفين دفعة واحدة مع كشوفات معتمدة',
    endpoints: ['/v1/payroll/batch', '/v1/payroll/slips', '/v1/payroll/validate'],
    keyFeatures: ['Bulk Batch Processing', 'Cryptographic Slip Signing', 'CSV/Excel Parser']
  },
  {
    id: 's-vault',
    code: '10.8',
    name: 'Secrets Vault Service',
    nameAr: 'مخزن الأسرار المشفر السيادي',
    port: 5008,
    status: 'healthy',
    latencyMs: 15,
    protocol: 'gRPC',
    description: 'تشفير وحفظ مفاتيح API، شهادات SSL وشظايا الأمان السيادية للمالك',
    endpoints: ['/v1/vault/get', '/v1/vault/rotate', '/v1/vault/shamir-split'],
    keyFeatures: ['Hardware Security Module (HSM)', 'AES-256-GCM', 'Zero-Knowledge Storage']
  },
  {
    id: 's-selfdev',
    code: '10.9',
    name: 'AI Self-Development Engine',
    nameAr: 'محرك التطوير البرمجي الذاتي',
    port: 5009,
    status: 'healthy',
    latencyMs: 90,
    protocol: 'REST',
    description: 'تحليل الأكواد واقتراح الميزات واختبارها وتجهيزها لاعتماد المالك',
    endpoints: ['/v1/ai-dev/analyze', '/v1/ai-dev/propose', '/v1/ai-dev/test'],
    keyFeatures: ['AST Code Parser', 'Security Flaw Scanner', 'Owner Sovereign Approval Wall']
  },
  {
    id: 's-autosave',
    code: '10.10',
    name: 'Auto-Save & WAL Engine',
    nameAr: 'محرك الحفظ اللحظي والنسخ 5 دقائق',
    port: 5010,
    status: 'healthy',
    latencyMs: 12,
    protocol: 'gRPC',
    description: 'كتابة سجل الأحداث فورياً وأخذ لقطات Snapshot احتياطية دورياً',
    endpoints: ['/v1/save/wal-append', '/v1/backup/create-snapshot', '/v1/backup/restore'],
    keyFeatures: ['Zero-Data-Loss WAL', '5-Minute Encrypted Snapshots', 'Instant Disaster Recovery']
  },
  {
    id: 's-structure',
    code: '10.11',
    name: 'System Structure Service',
    nameAr: 'خدمة الهياكل والشجرة الحية',
    port: 5011,
    status: 'healthy',
    latencyMs: 14,
    protocol: 'REST',
    description: 'توفير تمثيل الشجرة الـ 42 فرعاً للوحة عرض شكل النظام',
    endpoints: ['/v1/system/tree', '/v1/system/nodes', '/v1/system/export'],
    keyFeatures: ['5 Projection Modes', 'Dynamic Graph Traversal', 'Real-time State Sync']
  },
  {
    id: 's-docs',
    code: '10.12',
    name: 'Documentation & PDF Engine',
    nameAr: 'محرك توليد الدلائل ومستندات PDF',
    port: 5012,
    status: 'healthy',
    latencyMs: 110,
    protocol: 'REST',
    description: 'توليد الـ 12 دليلاً رقمياً للتشغيل والأمان والواجهات البرمجية',
    endpoints: ['/v1/docs/generate-pdf', '/v1/docs/manuals', '/v1/docs/export-spec'],
    keyFeatures: ['Headless Chromium PDF', 'Bilingual Generation (AR/EN)', 'Custom Watermarking']
  },
  {
    id: 's-cards',
    code: '10.13',
    name: 'Virtual Cards & Issuing',
    nameAr: 'محرك إصدار البطاقات الافتراضية',
    port: 5013,
    status: 'healthy',
    latencyMs: 38,
    protocol: 'gRPC',
    description: 'إصدار بطاقات فيزا وماستركارد افتراضية مع 3D Secure فوري',
    endpoints: ['/v1/cards/issue', '/v1/cards/freeze', '/v1/cards/limits'],
    keyFeatures: ['Dynamic CVV', 'Instant PAN Tokenization', 'Merchant Category Controls']
  },
  {
    id: 's-agent',
    code: '10.14',
    name: 'Agent Float & Cash Engine',
    nameAr: 'محرك الصناديق والوكلاء',
    port: 5014,
    status: 'healthy',
    latencyMs: 28,
    protocol: 'REST',
    description: 'إدارة سيولة الوكلاء، الإيداع، السحب النقدي وحساب العمولات الفورية',
    endpoints: ['/v1/agents/cash-in', '/v1/agents/cash-out', '/v1/agents/commissions'],
    keyFeatures: ['Float Pre-authorization', 'Geo-fence Agent Validation', 'Offline OTP Cash-out']
  },
  {
    id: 's-merchant',
    code: '10.15',
    name: 'Merchant & QR Terminal Service',
    nameAr: 'بوابة التجار ونقاط البيع POS',
    port: 5015,
    status: 'healthy',
    latencyMs: 25,
    protocol: 'REST',
    description: 'توليد رموز QR الديناميكية، فواتير المتجر وتسوية مبيعات التجار',
    endpoints: ['/v1/merchants/qr-generate', '/v1/merchants/settle', '/v1/merchants/sales'],
    keyFeatures: ['EMVCo Static/Dynamic QR', 'WhatsApp Payment Links', 'Instant Cashier Soundbox API']
  },
  {
    id: 's-aml',
    code: '10.16',
    name: 'AML & Fraud Shield Engine',
    nameAr: 'محرك مكافحة غسل الأموال والاحتيال',
    port: 5016,
    status: 'healthy',
    latencyMs: 35,
    protocol: 'Kafka',
    description: 'فحص فوري للأنماط غير الطبيعية والحدود المشبوهة وقوائم الحظر',
    endpoints: ['/v1/aml/screen-txn', '/v1/aml/watchlist', '/v1/aml/flagged'],
    keyFeatures: ['Heuristic Rule Engine', 'Velocity Anomaly Detector', 'Central Bank STR Reports']
  },
  {
    id: 's-audit',
    code: '10.17',
    name: 'Immutable Audit Ledger Service',
    nameAr: 'سجل التدقيق السيادي الموثق',
    port: 5017,
    status: 'healthy',
    latencyMs: 20,
    protocol: 'gRPC',
    description: 'سلسلة تجزئة SHA-256 مشفرة غير قابلة للتعديل لكل أمر إداري وسيادي',
    endpoints: ['/v1/audit/log-event', '/v1/audit/verify-chain', '/v1/audit/search'],
    keyFeatures: ['Hash-chained Integrity', 'Tamper Evident Proof', 'Owner Sovereign Traceability']
  },
  {
    id: 's-notif',
    code: '10.18',
    name: 'Notification & SMS Relay',
    nameAr: 'خدمة الإشعارات والرسائل النصية',
    port: 5018,
    status: 'healthy',
    latencyMs: 40,
    protocol: 'REST',
    description: 'إشعارات لحظية عبر Push Notifications و SMS و WhatsApp',
    endpoints: ['/v1/notify/send', '/v1/notify/push', '/v1/notify/template'],
    keyFeatures: ['Multi-channel Failover', 'SMS Gateway Aggregation', 'Localized Content']
  },
  {
    id: 's-files',
    code: '10.19',
    name: 'Encrypted File Storage Service',
    nameAr: 'مستودع الملفات والمرفقات المشفر',
    port: 5019,
    status: 'healthy',
    latencyMs: 60,
    protocol: 'REST',
    description: 'تخزين صور الهويات KYC، إيصالات السداد وكشوف الحساب المشفرة',
    endpoints: ['/v1/files/upload', '/v1/files/download', '/v1/files/verify'],
    keyFeatures: ['Chunked Upload', 'Client-side Encryption Keying', 'Anti-virus Scan on Ingest']
  },
  {
    id: 's-diag',
    code: '10.20',
    name: 'Diagnostics & Auto-Repair Service',
    nameAr: 'محرك الفحص والإصلاح الذاتي',
    port: 5020,
    status: 'healthy',
    latencyMs: 30,
    protocol: 'REST',
    description: 'فحص التناغم المالي وسلامة السيرفرات وإصلاح الفروقات آلياً',
    endpoints: ['/v1/diagnostics/run-health', '/v1/diagnostics/reconcile', '/v1/diagnostics/fix-hanging'],
    keyFeatures: ['Automated Ledger Balance Check', 'Hanging Txn Auto-unfreezer', 'DB Deadlock Breaker']
  },
  {
    id: 's-apk',
    code: '10.21',
    name: 'Build & Release Pipeline',
    nameAr: 'محرك تجهيز وبناء الـ APK',
    port: 5021,
    status: 'healthy',
    latencyMs: 85,
    protocol: 'REST',
    description: 'بناء وتوقيع حزم تطبيقات الموبايل وتجهيز روابط التحميل المباشرة',
    endpoints: ['/v1/builds/status', '/v1/builds/trigger', '/v1/builds/download-latest'],
    keyFeatures: ['Fastlane Integration', 'Sovereign Keystore Signer', 'OTA Delta Patching']
  },
  {
    id: 's-sovereign',
    code: '10.22',
    name: 'Sovereign Command & Override',
    nameAr: 'بوابة التحكم والسيادة المطلقة',
    port: 5022,
    status: 'healthy',
    latencyMs: 10,
    protocol: 'gRPC',
    description: 'أوامر المالك السيادية (God Mode)، القفل الشامل والتحكم المركزي',
    endpoints: ['/v1/sovereign/kill-switch', '/v1/sovereign/override', '/v1/sovereign/system-state'],
    keyFeatures: ['Unbypassable Owner Priority', 'Emergency Freeze Protocol', 'Master Cryptographic Key']
  }
];
