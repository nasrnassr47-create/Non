export interface DBTable {
  id: string;
  name: string;
  nameAr: string;
  category: 'core' | 'finance' | 'family' | 'merchants' | 'security' | 'dev_ops';
  description: string;
  columns: {
    name: string;
    type: string;
    isPrimary?: boolean;
    isForeign?: boolean;
    nullable?: boolean;
    ref?: string;
  }[];
}

export const DATABASE_TABLES: DBTable[] = [
  // Core Identity & Auth
  {
    id: 't-users',
    name: 'users',
    nameAr: 'المستخدمون',
    category: 'core',
    description: 'البيانات الأساسية لجميع مستخدمي المنظومة',
    columns: [
      { name: 'id', type: 'UUID', isPrimary: true },
      { name: 'phone', type: 'VARCHAR(20)' },
      { name: 'full_name', type: 'VARCHAR(150)' },
      { name: 'national_id', type: 'VARCHAR(50)' },
      { name: 'role', type: 'ENUM (client, subscriber, agent, merchant, admin, owner)' },
      { name: 'kyc_level', type: 'INT (Tier 1-3)' },
      { name: 'status', type: 'ENUM (active, suspended, locked)' },
      { name: 'created_at', type: 'TIMESTAMP WITH TIME ZONE' }
    ]
  },
  {
    id: 't-user-credentials',
    name: 'user_credentials',
    nameAr: 'بيانات المصادقة والتشفير',
    category: 'security',
    description: 'كلمات المرور المشفرة والأرقام السرية والرموز البيومترية',
    columns: [
      { name: 'id', type: 'UUID', isPrimary: true },
      { name: 'user_id', type: 'UUID', isForeign: true, ref: 'users.id' },
      { name: 'pin_hash', type: 'VARCHAR(255)' },
      { name: 'password_hash', type: 'VARCHAR(255)' },
      { name: 'biometric_pubkey', type: 'TEXT', nullable: true },
      { name: 'salt', type: 'VARCHAR(64)' }
    ]
  },
  {
    id: 't-wallets',
    name: 'wallets',
    nameAr: 'المحافظ المالية',
    category: 'finance',
    description: 'المحافظ التابعة للمستخدمين بمختلف العملات',
    columns: [
      { name: 'id', type: 'UUID', isPrimary: true },
      { name: 'user_id', type: 'UUID', isForeign: true, ref: 'users.id' },
      { name: 'account_no', type: 'VARCHAR(30)' },
      { name: 'currency', type: 'VARCHAR(5) (YER, SAR, USD)' },
      { name: 'balance', type: 'DECIMAL(18, 4)' },
      { name: 'hold_balance', type: 'DECIMAL(18, 4)' },
      { name: 'status', type: 'ENUM (active, frozen, closed)' },
      { name: 'is_primary', type: 'BOOLEAN' }
    ]
  },
  {
    id: 't-ledger-entries',
    name: 'ledger_entries',
    nameAr: 'دفتر الأستاذ المزدوج',
    category: 'finance',
    description: 'سجل القيد المزدوج الإلزامي لكل عملية بدون تعديل مباشر',
    columns: [
      { name: 'id', type: 'UUID', isPrimary: true },
      { name: 'transaction_id', type: 'UUID', isForeign: true, ref: 'transactions.id' },
      { name: 'wallet_id', type: 'UUID', isForeign: true, ref: 'wallets.id' },
      { name: 'account_code', type: 'VARCHAR(50)' },
      { name: 'entry_type', type: 'ENUM (DEBIT, CREDIT)' },
      { name: 'amount', type: 'DECIMAL(18, 4)' },
      { name: 'balance_after', type: 'DECIMAL(18, 4)' },
      { name: 'created_at', type: 'TIMESTAMP WITH TIME ZONE' }
    ]
  },
  {
    id: 't-transactions',
    name: 'transactions',
    nameAr: 'المعاملات والتحويلات',
    category: 'finance',
    description: 'رأس المعاملة المالية وسير حالتها وقفل الصرف المزدوج',
    columns: [
      { name: 'id', type: 'UUID', isPrimary: true },
      { name: 'reference_no', type: 'VARCHAR(64)' },
      { name: 'sender_wallet_id', type: 'UUID', isForeign: true, ref: 'wallets.id' },
      { name: 'receiver_wallet_id', type: 'UUID', isForeign: true, ref: 'wallets.id' },
      { name: 'amount', type: 'DECIMAL(18, 4)' },
      { name: 'fee', type: 'DECIMAL(18, 4)' },
      { name: 'currency', type: 'VARCHAR(5)' },
      { name: 'type', type: 'ENUM (P2P, QR_PAY, BILL, CASH_IN, CASH_OUT, PAYROLL)' },
      { name: 'status', type: 'ENUM (pending, completed, reversed, failed)' },
      { name: 'idempotency_key', type: 'VARCHAR(128)' },
      { name: 'created_at', type: 'TIMESTAMP' }
    ]
  },
  {
    id: 't-transaction-events',
    name: 'transaction_events',
    nameAr: 'أحداث تدفق المعاملات (Saga Events)',
    category: 'finance',
    description: 'سجل تدفق مراحل المعاملة لضمان استرجاع التعويض Compensating Txn',
    columns: [
      { name: 'id', type: 'UUID', isPrimary: true },
      { name: 'transaction_id', type: 'UUID', isForeign: true, ref: 'transactions.id' },
      { name: 'event_name', type: 'VARCHAR(100)' },
      { name: 'payload', type: 'JSONB' },
      { name: 'created_at', type: 'TIMESTAMP' }
    ]
  },
  {
    id: 't-families',
    name: 'families',
    nameAr: 'العائلات والمجموعات المصغرة',
    category: 'family',
    description: 'مجموعات العائلة التابعة للمشتركين',
    columns: [
      { name: 'id', type: 'UUID', isPrimary: true },
      { name: 'owner_user_id', type: 'UUID', isForeign: true, ref: 'users.id' },
      { name: 'family_name', type: 'VARCHAR(100)' },
      { name: 'monthly_budget_cap', type: 'DECIMAL(18, 4)' },
      { name: 'created_at', type: 'TIMESTAMP' }
    ]
  },
  {
    id: 't-family-members',
    name: 'family_members',
    nameAr: 'أعضاء العائلة والارتباطات',
    category: 'family',
    description: 'روابط الأبناء والزوجة والحدود والقيود المفروضة',
    columns: [
      { name: 'id', type: 'UUID', isPrimary: true },
      { name: 'family_id', type: 'UUID', isForeign: true, ref: 'families.id' },
      { name: 'user_id', type: 'UUID', isForeign: true, ref: 'users.id' },
      { name: 'relationship', type: 'ENUM (father, mother, son, daughter, spouse)' },
      { name: 'daily_limit', type: 'DECIMAL(18, 4)' },
      { name: 'monthly_limit', type: 'DECIMAL(18, 4)' },
      { name: 'require_guardian_approval', type: 'BOOLEAN' },
      { name: 'status', type: 'ENUM (active, suspended)' }
    ]
  },
  {
    id: 't-family-wallets',
    name: 'family_wallets',
    nameAr: 'محافظ العائلة الفرعية',
    category: 'family',
    description: 'المحافظ المقتطعة الخاضعة لرقابة رب الأسرة',
    columns: [
      { name: 'id', type: 'UUID', isPrimary: true },
      { name: 'family_member_id', type: 'UUID', isForeign: true, ref: 'family_members.id' },
      { name: 'wallet_id', type: 'UUID', isForeign: true, ref: 'wallets.id' },
      { name: 'allowed_categories', type: 'JSONB (food, education, games, etc.)' }
    ]
  },
  {
    id: 't-agents',
    name: 'agents',
    nameAr: 'الوكلاء الميدانيون والصرافون',
    category: 'merchants',
    description: 'بيانات الوكلاء ونقاط التغذية والصرافة وسقوف السيولة',
    columns: [
      { name: 'id', type: 'UUID', isPrimary: true },
      { name: 'user_id', type: 'UUID', isForeign: true, ref: 'users.id' },
      { name: 'business_name', type: 'VARCHAR(150)' },
      { name: 'agent_code', type: 'VARCHAR(20)' },
      { name: 'commercial_register', type: 'VARCHAR(50)' },
      { name: 'commission_rate', type: 'DECIMAL(5, 2)' },
      { name: 'float_balance', type: 'DECIMAL(18, 4)' },
      { name: 'daily_cash_limit', type: 'DECIMAL(18, 4)' },
      { name: 'latitude', type: 'DECIMAL(10, 8)' },
      { name: 'longitude', type: 'DECIMAL(11, 8)' }
    ]
  },
  {
    id: 't-merchants',
    name: 'merchants',
    nameAr: 'التجار ونقاط البيع POS',
    category: 'merchants',
    description: 'حسابات المتاجر، نسب الخصم، وبوابات الدفع ورموز الـ QR',
    columns: [
      { name: 'id', type: 'UUID', isPrimary: true },
      { name: 'user_id', type: 'UUID', isForeign: true, ref: 'users.id' },
      { name: 'store_name', type: 'VARCHAR(150)' },
      { name: 'category', type: 'VARCHAR(50)' },
      { name: 'qr_terminal_code', type: 'VARCHAR(64)' },
      { name: 'settlement_period', type: 'ENUM (instant, daily, weekly)' },
      { name: 'status', type: 'ENUM (verified, pending, paused)' }
    ]
  },
  {
    id: 't-bank-links',
    name: 'bank_links',
    nameAr: 'ربط الحسابات البنكية',
    category: 'finance',
    description: 'الحسابات المصرفية المربوطة بمحفظة نصر والت عبر IBAN/OpenBanking',
    columns: [
      { name: 'id', type: 'UUID', isPrimary: true },
      { name: 'user_id', type: 'UUID', isForeign: true, ref: 'users.id' },
      { name: 'bank_name', type: 'VARCHAR(100)' },
      { name: 'iban', type: 'VARCHAR(34)' },
      { name: 'swift_code', type: 'VARCHAR(11)' },
      { name: 'is_verified', type: 'BOOLEAN' },
      { name: 'verified_at', type: 'TIMESTAMP' }
    ]
  },
  {
    id: 't-exchange-links',
    name: 'exchange_links',
    nameAr: 'ربط شبكات الصرافة',
    category: 'finance',
    description: 'الربط المباشر مع شبكات التحويل والصرافة اليمنية',
    columns: [
      { name: 'id', type: 'UUID', isPrimary: true },
      { name: 'network_name', type: 'VARCHAR(100) (النجم، الامتياز، يمن إكسبرس)' },
      { name: 'api_endpoint', type: 'VARCHAR(255)' },
      { name: 'status', type: 'ENUM (online, maintenance)' }
    ]
  },
  {
    id: 't-payrolls',
    name: 'payrolls',
    nameAr: 'كشوفات الرواتب الجماعية',
    category: 'finance',
    description: 'دفعات الرواتب الصادرة للشركات والمؤسسات',
    columns: [
      { name: 'id', type: 'UUID', isPrimary: true },
      { name: 'subscriber_id', type: 'UUID', isForeign: true, ref: 'users.id' },
      { name: 'month_year', type: 'VARCHAR(10)' },
      { name: 'total_amount', type: 'DECIMAL(18, 4)' },
      { name: 'employees_count', type: 'INT' },
      { name: 'status', type: 'ENUM (draft, approved, executed, failed)' }
    ]
  },
  {
    id: 't-secrets-vault',
    name: 'secrets_vault',
    nameAr: 'مخزن الأسرار المشفر (AES-256)',
    category: 'security',
    description: 'مفاتيح التشفير، شظايا Shamir، وشهادات الأمان السيادية',
    columns: [
      { name: 'id', type: 'UUID', isPrimary: true },
      { name: 'secret_key_name', type: 'VARCHAR(100)' },
      { name: 'encrypted_payload', type: 'TEXT' },
      { name: 'algorithm', type: 'VARCHAR(50) (AES-256-GCM, RSA-4096)' },
      { name: 'version', type: 'INT' },
      { name: 'created_by_owner', type: 'BOOLEAN' },
      { name: 'updated_at', type: 'TIMESTAMP' }
    ]
  },
  {
    id: 't-audit-logs',
    name: 'audit_logs',
    nameAr: 'سجل التدقيق السيادي (Immutable)',
    category: 'security',
    description: 'سجل تسلسلي محمي بتشفير غير قابل للتعديل لكل حركة وإجراء سيادي',
    columns: [
      { name: 'id', type: 'UUID', isPrimary: true },
      { name: 'actor_id', type: 'UUID' },
      { name: 'action', type: 'VARCHAR(100)' },
      { name: 'target_entity', type: 'VARCHAR(100)' },
      { name: 'previous_hash', type: 'VARCHAR(64)' },
      { name: 'current_hash', type: 'VARCHAR(64)' },
      { name: 'created_at', type: 'TIMESTAMP WITH TIME ZONE' }
    ]
  },
  {
    id: 't-system-backups',
    name: 'system_backups',
    nameAr: 'النسخ الاحتياطي التلقائي (Auto-Save)',
    category: 'dev_ops',
    description: 'سجلات لقطات النسخ الاحتياطي المنفذة كل 5 دقائق',
    columns: [
      { name: 'id', type: 'UUID', isPrimary: true },
      { name: 'snapshot_hash', type: 'VARCHAR(64)' },
      { name: 'records_count', type: 'BIGINT' },
      { name: 'size_mb', type: 'DECIMAL(8, 2)' },
      { name: 'is_verified', type: 'BOOLEAN' },
      { name: 'created_at', type: 'TIMESTAMP' }
    ]
  },
  {
    id: 't-dev-requests',
    name: 'dev_requests',
    nameAr: 'محرك التطوير الذاتي (AI Requests)',
    category: 'dev_ops',
    description: 'أوامر وتحسينات الكود الصادرة من محرك الـ AI بانتظار موافقة المالك',
    columns: [
      { name: 'id', type: 'UUID', isPrimary: true },
      { name: 'module_name', type: 'VARCHAR(100)' },
      { name: 'proposal_summary', type: 'TEXT' },
      { name: 'code_diff', type: 'TEXT' },
      { name: 'test_coverage', type: 'DECIMAL(5, 2)' },
      { name: 'owner_approval_status', type: 'ENUM (pending, approved, rejected)' }
    ]
  }
];
