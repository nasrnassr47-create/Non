import { SecretCodeItem, SecretDbTable, SecretAuditLog } from '../types/central';

export const SECRET_CODES_VAULT: SecretCodeItem[] = [
  // 1. Master Cryptographic Keys
  {
    id: 'sec-mek-01',
    name: 'SOVEREIGN_MASTER_ENCRYPTION_KEY_MEK',
    nameAr: 'مفتاح التشفير الرئيسي للمنظومة السيادية (MEK)',
    category: 'master_key',
    codeValue: 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855f4a7c290a184e9128f7311',
    algorithm: 'AES-256-GCM / HSM FIPS 140-2 L3',
    environment: 'hsm_root',
    lastRotated: '2025-08-01 03:00 UTC',
    expiryDate: '2026-08-01',
    status: 'active',
    description: 'المفتاح الجذري المشفر في الـ Hardware Security Module لتشفير مفاتيح البيانات الدورية (DEK)'
  },
  {
    id: 'sec-rsa-02',
    name: 'ROOT_CA_RSA_4096_SIGNING_PRIVATE_KEY',
    nameAr: 'مفتاح التوقيع الجذري RSA-4096 المعتمد للشهادات',
    category: 'master_key',
    codeValue: 'MIIJKAIBAAKCAgEA0R8pL2w5K8gN8mO1kL9m4pQ3rT6vY8xZ1wB7cD5eF3aG2hI0jK4lM6nO8pQ0rS2tU4vW6xY8z...[PRIVATE_ROOT_PEM_PROTECTED]',
    algorithm: 'RSA-4096 PKCS#1 v2.2',
    environment: 'hsm_root',
    lastRotated: '2025-01-15 00:00 UTC',
    expiryDate: '2030-01-15',
    status: 'active',
    description: 'المفتاح الخاص بتوقيع شهادات SSL/mTLS لجميع خوادم وتطبيقات نصر والت المعتمدة'
  },
  {
    id: 'sec-hmac-03',
    name: 'LEDGER_INTEGRITY_HMAC_SHA512_SALT',
    nameAr: 'مفتاح حماية وسلامة دفتر الأستاذ (HMAC-SHA512)',
    category: 'master_key',
    codeValue: 'hmac_sha512_sov_9918274615243890a8f7c3e1b4d2a6c8e0f9b7d5a3c1e9f2a4b6c8d0e1f3a5b7c9d1e3f5a7b9c1d3',
    algorithm: 'HMAC-SHA512',
    environment: 'production',
    lastRotated: '2025-07-20 04:15 UTC',
    expiryDate: '2026-07-20',
    status: 'active',
    description: 'مفتاح البصمة الرقمية المتسلسلة لجميع قيود الحسابات والدفاتر المالية غير القابلة للتعديل'
  },
  {
    id: 'sec-ed25519-04',
    name: 'MOBILE_DEVICE_ATTESTATION_ED25519',
    nameAr: 'مفتاح مصادقة تطبيقات الهاتف المحمول (Ed25519)',
    category: 'master_key',
    codeValue: 'ed25519_sk_948f2c019a7e6b5d4c3b2a1f0e9d8c7b6a5f4e3d2c1b0a9f8e7d6c5b4a3f2e1d0c',
    algorithm: 'Curve25519 / EdDSA',
    environment: 'production',
    lastRotated: '2025-08-10 11:30 UTC',
    expiryDate: '2026-08-10',
    status: 'active',
    description: 'يضمن عدم تشغيل تطبيقات العملاء والوكلاء إلا على أجهزة موثوقة ذات عتاد Secure Enclave سليم'
  },

  // 2. Sovereign Emergency Break-Glass Codes
  {
    id: 'sec-bg-01',
    name: 'SOVEREIGN_BREAK_GLASS_CODE_OMEGA_01',
    nameAr: 'كود الطوارئ السيادي رقم 01 (فك القفل العام)',
    category: 'break_glass',
    codeValue: 'NASR-SOV-OMEGA-9921-ALPHA-7741',
    algorithm: 'BIP-39 Derived 256-bit Entropy',
    environment: 'hsm_root',
    lastRotated: '2025-09-01 08:00 UTC',
    expiryDate: '2026-09-01',
    status: 'active',
    description: 'كود استرداد فائق لحالات انقطاع الشبكة وفك القفل العام بإذن مالك المنظومة حصرياً'
  },
  {
    id: 'sec-bg-02',
    name: 'SOVEREIGN_BREAK_GLASS_CODE_SIGMA_02',
    nameAr: 'كود الطوارئ السيادي رقم 02 (إلغاء التجميد الشامل)',
    category: 'break_glass',
    codeValue: 'NASR-SOV-SIGMA-8842-DELTA-3319',
    algorithm: 'BIP-39 Derived 256-bit Entropy',
    environment: 'hsm_root',
    lastRotated: '2025-09-01 08:00 UTC',
    expiryDate: '2026-09-01',
    status: 'active',
    description: 'إلغاء التجميد الأمني الطارئ للعمليات المصرفية واستئناف التسويات مع البنك المركزي'
  },
  {
    id: 'sec-bg-03',
    name: 'SOVEREIGN_BREAK_GLASS_CODE_KAPPA_03',
    nameAr: 'كود الطوارئ السيادي رقم 03 (إعادة بناء القيود WAL)',
    category: 'break_glass',
    codeValue: 'NASR-SOV-KAPPA-4419-THETA-8820',
    algorithm: 'BIP-39 Derived 256-bit Entropy',
    environment: 'hsm_root',
    lastRotated: '2025-09-01 08:00 UTC',
    expiryDate: '2026-09-01',
    status: 'active',
    description: 'تطبيق سجلات التعديل المستمر وإعادة المزامنة عند استعادة قاعدة البيانات البديلة'
  },
  {
    id: 'sec-bg-04',
    name: 'SOVEREIGN_BREAK_GLASS_CODE_ZETA_04',
    nameAr: 'كود الطوارئ السيادي رقم 04 (التحكم بالسيولة والاحتياطي)',
    category: 'break_glass',
    codeValue: 'NASR-SOV-ZETA-1158-LAMBDA-6604',
    algorithm: 'BIP-39 Derived 256-bit Entropy',
    environment: 'hsm_root',
    lastRotated: '2025-09-01 08:00 UTC',
    expiryDate: '2026-09-01',
    status: 'active',
    description: 'تفعيل السحب الاحتياطي الطارئ من الخزائن السيادية المودعة لدى البنوك الشريكة'
  },

  // 3. Banking & Telecom API Gateways Secrets
  {
    id: 'sec-api-cby',
    name: 'CBY_CENTRAL_BANK_CLEARING_SECRET_PROD',
    nameAr: 'المفتاح السري لمقاصة البنك المركزي اليمني (CBY RTGS)',
    category: 'api_gateway',
    codeValue: 'cby_rtgs_sec_live_9a8b7c6d5e4f3a2b1c0d9e8f7a6b5c4d3e2f1a0',
    algorithm: 'mTLS + HMAC-SHA256 Token',
    environment: 'production',
    lastRotated: '2025-08-25 14:00 UTC',
    expiryDate: '2025-11-25',
    status: 'active',
    description: 'المفتاح المعتمد للتحويلات الفورية بين البنوك ومطابقة أرصدة المقاصة اللحظية'
  },
  {
    id: 'sec-api-swift',
    name: 'SWIFT_GPI_ALLIANCE_GATEWAY_SECRET',
    nameAr: 'مفتاح ربط شبكة سويفت الدولية (SWIFT GPI Alliance)',
    category: 'api_gateway',
    codeValue: 'swift_gpi_sec_prod_9941829471928471928371928471928374',
    algorithm: 'ISO-20022 XML Signature / RSA',
    environment: 'production',
    lastRotated: '2025-07-15 09:00 UTC',
    expiryDate: '2026-01-15',
    status: 'active',
    description: 'قناة الدفع الدولية للحوالات السريعة عبر البنوك المراسلة في الخليج وأوروبا'
  },
  {
    id: 'sec-api-ym',
    name: 'YEMEN_MOBILE_API_SECRET_B2B',
    nameAr: 'المفتاح السري لخدمات يمن موبايل (تسديد فواتير وباقات)',
    category: 'api_gateway',
    codeValue: 'ym_b2b_secret_live_83719284719283749182749182739481',
    algorithm: 'AES-128-CBC + Token Bearer',
    environment: 'production',
    lastRotated: '2025-09-05 16:30 UTC',
    expiryDate: '2025-12-05',
    status: 'active',
    description: 'الربط المباشر مع سيرفرات فوترة يمن موبايل لتغذية الرصيد الفوري وباقات مزايا'
  },
  {
    id: 'sec-api-sabafon',
    name: 'SABAFON_DIRECT_BILLING_SECRET',
    nameAr: 'المفتاح السري لفوترة سبأفون (شحن فوري وباقات)',
    category: 'api_gateway',
    codeValue: 'sbf_live_sec_77192847192837491827491827491827',
    algorithm: 'HMAC-SHA256',
    environment: 'production',
    lastRotated: '2025-08-18 12:00 UTC',
    expiryDate: '2025-11-18',
    status: 'active',
    description: 'شحن رصيد سبأفون ودفع الفواتير آلياً عبر بروتوكول SOAP الآمن'
  },
  {
    id: 'sec-api-you',
    name: 'YOU_TELECOM_GATEWAY_API_KEY',
    nameAr: 'المفتاح السري لخدمات يو للاتصالات (YOU Telecom)',
    category: 'api_gateway',
    codeValue: 'you_telco_sec_live_19284719283749182749182749182749',
    algorithm: 'OAuth 2.0 / SHA256',
    environment: 'production',
    lastRotated: '2025-08-30 10:00 UTC',
    expiryDate: '2025-11-30',
    status: 'active',
    description: 'خدمات الدفع والشحن المباشر لشبكة يو (MTN سابقاً)'
  },
  {
    id: 'sec-api-visa',
    name: 'VISA_DIRECT_MASTERCARD_SEND_MASTER_KEY',
    nameAr: 'مفتاح إصدار وتغذية بطاقات فيزا وماستركارد الدولية',
    category: 'api_gateway',
    codeValue: 'vd_mc_sec_live_99481729481729481729481729481729481729',
    algorithm: 'PCI-DSS Level 1 / HSM 3DES Key',
    environment: 'production',
    lastRotated: '2025-06-01 00:00 UTC',
    expiryDate: '2026-06-01',
    status: 'active',
    description: 'معالجة المدفوعات والبطاقات الافتراضية والفيزيائية للمحفظة عبر شبكات الدفع العالمية'
  },

  // 4. TOTP / 2FA Master Seeds
  {
    id: 'sec-totp-admin',
    name: 'SOVEREIGN_ADMIN_TOTP_MASTER_SEED',
    nameAr: 'بذرة المصادقة الثنائية (TOTP 2FA) للمشرفين والمالك',
    category: 'totp_seed',
    codeValue: 'JBSWY3DPEHPK3PXP4G7Q8M9N2V3W5X7Y',
    algorithm: 'RFC-6238 TOTP (SHA-1 / 30s step)',
    environment: 'production',
    lastRotated: '2025-08-01 02:00 UTC',
    expiryDate: '2026-08-01',
    status: 'active',
    description: 'البذرة المشفرة لتوليد أكواد المصادقة اللحظية لـ Google Authenticator و YubiKey للأدوار الحساسة'
  },
  {
    id: 'sec-totp-approvals',
    name: 'DUAL_CONTROL_APPROVALS_TOTP_SEED',
    nameAr: 'بذرة التوقيع الثنائي لاعتماد الحوالات الكبيرة',
    category: 'totp_seed',
    codeValue: 'KZXW4ZDPNVRW65LZMJ2XEZLBNRXW4ZDA',
    algorithm: 'RFC-6238 TOTP (SHA-256 / 60s step)',
    environment: 'production',
    lastRotated: '2025-07-10 15:00 UTC',
    expiryDate: '2026-07-10',
    status: 'active',
    description: 'تتطلب إدخال رمز ديناميكي لحظي عند الموافقة على أي حركة مالية تتجاوز $10,000'
  },

  // 5. POS & Agent Hardware Activation Codes
  {
    id: 'sec-pos-seed',
    name: 'AGENT_POS_HARDWARE_TERMINAL_MASTER_SECRET',
    nameAr: 'مفتاح تشفير ماكينات الصرافين ونقاط البيع (POS Enclave Key)',
    category: 'pos_activation',
    codeValue: 'pos_hw_sec_live_8849182749182749182749182749182749182749',
    algorithm: 'DUKPT (Derived Unique Key Per Transaction)',
    environment: 'production',
    lastRotated: '2025-08-15 06:00 UTC',
    expiryDate: '2026-08-15',
    status: 'active',
    description: 'يضمن توليد مفتاح تشفير مختلف وفريد لكل عملية مسح كود أو بطاقة على أجهزة الوكلاء الميدانية'
  },
  {
    id: 'sec-pos-qr',
    name: 'DYNAMIC_OFFLINE_QR_SIGNATURE_KEY',
    nameAr: 'مفتاح التوقيع الرقمي لأكواد QR غير المتصلة (Offline QR Pay)',
    category: 'pos_activation',
    codeValue: 'qr_offline_sign_sec_77192847192837491827491827491827',
    algorithm: 'ECDSA P-256',
    environment: 'production',
    lastRotated: '2025-08-20 09:30 UTC',
    expiryDate: '2026-08-20',
    status: 'active',
    description: 'يتيح إتمام عمليات الشراء والدفع حتى عند انقطاع الإنترنت عن الهاتف لمدة تصل إلى 48 ساعة'
  }
];

export const SECRET_DB_TABLES: SecretDbTable[] = [
  {
    id: 'sec-t-keys',
    tableName: 'sec_master_encryption_keys',
    nameAr: 'جدول مفاتيح التشفير الرئيسية وجذور HSM',
    category: 'keys',
    recordCount: 14,
    encryptionStandard: 'Envelope Encryption (AES-256-GCM + HSM Root)',
    hsmEnclave: 'Dedicated Hardware Security Module (Thales Luna HSM v7)',
    description: 'يحتوي على المفاتيح المشفرة والمحمية بطبقة الغلاف الرقمي، مع تدوير تلقائي وسجل تدقيق صارم',
    columns: [
      { name: 'key_id', type: 'UUID', isEncrypted: false, description: 'المعرف الفريد للمفتاح' },
      { name: 'key_alias', type: 'VARCHAR(100)', isEncrypted: false, description: 'الاسم الرمزي للمفتاح' },
      { name: 'encrypted_key_material', type: 'BYTEA (BLOB)', isEncrypted: true, description: 'المادة المشفرة للمفتاح بـ MEK' },
      { name: 'key_version', type: 'INT', isEncrypted: false, description: 'إصدار المفتاح الحالي' },
      { name: 'algorithm', type: 'VARCHAR(50)', isEncrypted: false, description: 'خوارزمية التشفير أو التوقيع' },
      { name: 'hsm_slot', type: 'VARCHAR(30)', isEncrypted: false, description: 'منفذ الـ HSM الفعلي' },
      { name: 'created_at', type: 'TIMESTAMPTZ', isEncrypted: false, description: 'تاريخ الإنشاء والتفعيل' }
    ],
    records: [
      {
        id: 'rec-k1',
        recordIdentifier: 'KEY-MEK-ROOT-001',
        cipherText: 'U2FsdGVkX1+9qK7w3eL4p1a2b3c4d5e6f7g8h9i0j1k2l3m4n5o6p7q8r9s0t1u2v3w4x5y6z7a8b9c0d1e2f3g4h5i6j7k8==',
        algorithm: 'AES-256-GCM',
        keyFingerprint: 'SHA256:4f:8a:12:9c:e1:8b:33:d4:aa:67:10:98:3f:55:bb:01',
        decryptedPreview: 'AES256_SOVEREIGN_SYSTEM_KEY_PAYMENT_CORE_9981',
        createdAt: '2025-08-01 03:00:00',
        lastAccessed: '2025-09-06 10:24:12'
      },
      {
        id: 'rec-k2',
        recordIdentifier: 'KEY-LEDGER-HMAC-002',
        cipherText: 'U2FsdGVkX18aB9cD0eF1g2h3i4j5k6l7m8n9o0p1q2r3s4t5u6v7w8x9y0z1a2b3c4d5e6f7g8h9i0j1k2l3m4n5o6p7q8==',
        algorithm: 'HMAC-SHA512',
        keyFingerprint: 'SHA256:99:a4:23:cc:d9:11:ee:02:44:88:99:aa:bb:cc:dd:ee',
        decryptedPreview: 'HMAC512_IMMUTABLE_DOUBLE_ENTRY_LEDGER_CHAIN_SALT',
        createdAt: '2025-07-20 04:15:00',
        lastAccessed: '2025-09-06 10:24:45'
      },
      {
        id: 'rec-k3',
        recordIdentifier: 'KEY-WALLET-DEK-USD-003',
        cipherText: 'U2FsdGVkX19zX8yW7vU6tS5rQ4pP3oN2mM1lL0kK9jI8hH7gG6fF5eE4dD3cC2bB1aA0zZ9yY8xX7wW6vV5uU4tT3sS2rR1==',
        algorithm: 'AES-256-GCM',
        keyFingerprint: 'SHA256:12:34:56:78:90:ab:cd:ef:fe:dc:ba:09:87:65:43:21',
        decryptedPreview: 'DEK_ENCRYPT_USD_RESERVES_VAULT_RECORDS_ACTIVE',
        createdAt: '2025-08-15 00:00:00',
        lastAccessed: '2025-09-06 10:23:50'
      }
    ]
  },
  {
    id: 'sec-t-credentials',
    tableName: 'sec_argon2_credentials',
    nameAr: 'جدول بيانات المصادقة وتجزئات كلمات المرور والـ PIN',
    category: 'credentials',
    recordCount: 8742,
    encryptionStandard: 'Argon2id (Memory: 64MB, Iterations: 4, Parallelism: 2)',
    hsmEnclave: 'Internal Secured Memory Enclave',
    description: 'يخزن الأرقام السرية المشفرة لمستخدمي المحفظة والمديرين مع أملاح تجزئة فريدة لكل مستخدم',
    columns: [
      { name: 'user_id', type: 'UUID', isEncrypted: false, description: 'معرف المستخدم المرجعي' },
      { name: 'pin_hash', type: 'VARCHAR(255)', isEncrypted: true, description: 'تجزئة الرقم السري بتنسيق Argon2id' },
      { name: 'salt', type: 'VARCHAR(64)', isEncrypted: true, description: 'الملح العشوائي المضاف للتجزئة' },
      { name: 'biometric_token_enc', type: 'TEXT', isEncrypted: true, description: 'رمز المصادقة البيومترية المشفر' },
      { name: 'failed_attempts', type: 'INT', isEncrypted: false, description: 'عدد المحاولات الفاشلة قبل القفل' },
      { name: 'locked_until', type: 'TIMESTAMPTZ', isEncrypted: false, description: 'وقت انتهاء القفل إن وجد' }
    ],
    records: [
      {
        id: 'rec-c1',
        recordIdentifier: 'USR-ROOT-NASR-001',
        cipherText: '$argon2id$v=19$m=65536,t=4,p=2$c292ZXJlaWduX3NhbHRfOTk0MQ$xQ7m9aK2vB8pL4wZ0rT6vY8xZ1wB7cD5eF3aG2hI0jK',
        algorithm: 'Argon2id',
        keyFingerprint: 'SALT:c292ZXJlaWduX3NhbHQ',
        decryptedPreview: 'HASHED_PIN_VERIFIED_MATCH [SALT_MATCH: VALID]',
        createdAt: '2025-01-01 00:00:00',
        lastAccessed: '2025-09-06 10:24:00'
      },
      {
        id: 'rec-c2',
        recordIdentifier: 'USR-CLIENT-777123456',
        cipherText: '$argon2id$v=19$m=65536,t=4,p=2$Y2xpZW50X3NhbHRfMTIzNDU2$b9cD0eF1g2h3i4j5k6l7m8n9o0p1q2r3s4t5u6v7w8x',
        algorithm: 'Argon2id',
        keyFingerprint: 'SALT:Y2xpZW50X3NhbHQ',
        decryptedPreview: 'PIN: •••••• [VERIFIED ACTIVE]',
        createdAt: '2025-06-12 11:20:00',
        lastAccessed: '2025-09-06 09:45:10'
      }
    ]
  },
  {
    id: 'sec-t-hsm',
    tableName: 'sec_hsm_root_certificates',
    nameAr: 'جدول شهادات الأجهزة والجذور المشفرة (HSM Root Certificates)',
    category: 'hsm',
    recordCount: 8,
    encryptionStandard: 'X.509 v3 mTLS / SHA384WithRSAEncryption',
    hsmEnclave: 'Thales Luna HSM Partition #1',
    description: 'يحتوي على الشهادات الجذرية وسلاسل الثقة التي تضمن عدم اختراق أي خادم أو بوابة فرعية',
    columns: [
      { name: 'cert_id', type: 'VARCHAR(64)', isEncrypted: false, description: 'معرف الشهادة والبصمة' },
      { name: 'subject_dn', type: 'TEXT', isEncrypted: false, description: 'اسم الكيان المعتمد (Distinguished Name)' },
      { name: 'certificate_pem', type: 'TEXT', isEncrypted: true, description: 'محتوى الشهادة المشفر' },
      { name: 'serial_number', type: 'VARCHAR(128)', isEncrypted: false, description: 'الرقم التسلسلي للشهادة' },
      { name: 'valid_to', type: 'TIMESTAMPTZ', isEncrypted: false, description: 'تاريخ انتهاء الصلاحية' }
    ],
    records: [
      {
        id: 'rec-h1',
        recordIdentifier: 'CERT-ROOT-CA-SOV-2025',
        cipherText: '-----BEGIN ENCRYPTED CERTIFICATE-----\nMIIDXTCCAkWgAwIBAgIUQ7m9aK2vB8pL4wZ0rT6vY8xZ1wB7cD5eF3aG2hI0jK4lM6nO\n...[ENCRYPTED_SOVEREIGN_CA_BLOB]...\n-----END ENCRYPTED CERTIFICATE-----',
        algorithm: 'RSA-4096 / SHA-384',
        keyFingerprint: 'SHA256:e3:b0:c4:42:98:fc:1c:14:9a:fb:f4:c8:99:6f:b9:24',
        decryptedPreview: 'CN=Nasr Wallet Sovereign Root CA 2025, O=Nasr FinTech, C=YE',
        createdAt: '2025-01-01 00:00:00',
        lastAccessed: '2025-09-06 10:24:00'
      }
    ]
  },
  {
    id: 'sec-t-m2m',
    tableName: 'sec_oauth_m2m_secrets',
    nameAr: 'جدول أسرار الربط البنكي وقنوات الـ mTLS والـ Webhooks',
    category: 'sessions',
    recordCount: 32,
    encryptionStandard: 'AES-256-GCM With Ephemeral Session Salts',
    hsmEnclave: 'Bank Gateway Isolated Pods',
    description: 'يخزن مفاتيح التوثيق الخاصة بالربط مع البنوك اليمنية وشبكات الصرافة والشركاء الماليين',
    columns: [
      { name: 'partner_code', type: 'VARCHAR(30)', isEncrypted: false, description: 'رمز الشريك البنكي (Tadhamon, Kuraimi, ...)' },
      { name: 'client_id', type: 'VARCHAR(100)', isEncrypted: false, description: 'معرف العميل' },
      { name: 'client_secret_enc', type: 'TEXT', isEncrypted: true, description: 'السر المشفر لقناة الربط' },
      { name: 'webhook_signing_secret', type: 'TEXT', isEncrypted: true, description: 'مفتاح التحقق من إشعارات الإيداع' },
      { name: 'allowed_ips', type: 'CIDR[]', isEncrypted: false, description: 'عناوين IP المسموح لها بالاتصال' }
    ],
    records: [
      {
        id: 'rec-m1',
        recordIdentifier: 'BANK-TADHAMON-API-M2M',
        cipherText: 'U2FsdGVkX1/qW3eR5tY7uI9oP1aS3dF5gH7jK9lZ1xC3vB5nN7mQ9wE1rT3yU5iO7pA9sD1fG3hJ5kL7zX9cV1bN3mQ5wE7rT==',
        algorithm: 'AES-256-GCM',
        keyFingerprint: 'SHA256:77:88:99:aa:bb:cc:dd:ee:ff:00:11:22:33:44:55:66',
        decryptedPreview: 'TADHAMON_PROD_SECRET_KEY_EXCHANGE_CLEARED',
        createdAt: '2025-08-01 10:00:00',
        lastAccessed: '2025-09-06 10:20:15'
      },
      {
        id: 'rec-m2',
        recordIdentifier: 'BANK-KURAIMI-API-M2M',
        cipherText: 'U2FsdGVkX1+kL9m4pQ3rT6vY8xZ1wB7cD5eF3aG2hI0jK4lM6nO8pQ0rS2tU4vW6xY8z0a1b2c3d4e5f6g7h8i9j0k1l2m3n==',
        algorithm: 'AES-256-GCM',
        keyFingerprint: 'SHA256:aa:bb:cc:dd:ee:ff:11:22:33:44:55:66:77:88:99:00',
        decryptedPreview: 'KURAIMI_EXPRESS_RESERVE_CHANNEL_SECRET_ACTIVE',
        createdAt: '2025-08-05 14:30:00',
        lastAccessed: '2025-09-06 10:19:40'
      }
    ]
  },
  {
    id: 'sec-t-wal',
    tableName: 'sec_disaster_recovery_wal',
    nameAr: 'جدول سجلات الاسترداد والتسجيل المستمر المشفر (Zero-Loss WAL)',
    category: 'disaster_recovery',
    recordCount: 145820,
    encryptionStandard: 'ChaCha20-Poly1305 Streaming Encrypted Append-Only',
    hsmEnclave: 'Geo-Redundant Encrypted Cold Storage Enclave',
    description: 'يخزن كل تعديل مالي بصيغة مشفرة غير قابلة للتلف أو التعديل لضمان عدم ضياع أي قرش حتى عند انقطاع التيار',
    columns: [
      { name: 'wal_lsn', type: 'BIGINT', isEncrypted: false, description: 'الرقم التسلسلي اللحظي للسجل (LSN)' },
      { name: 'tx_uuid', type: 'UUID', isEncrypted: false, description: 'معرف المعاملة' },
      { name: 'encrypted_payload', type: 'BYTEA', isEncrypted: true, description: 'حمولة العملية المشفرة' },
      { name: 'prev_hash', type: 'VARCHAR(128)', isEncrypted: false, description: 'بصمة السجل السابق (Chain Integrity)' },
      { name: 'signature', type: 'VARCHAR(256)', isEncrypted: false, description: 'توقيع العتاد الرقمي' }
    ],
    records: [
      {
        id: 'rec-w1',
        recordIdentifier: 'WAL-LSN-0000000004928172',
        cipherText: 'U2FsdGVkX19ChaCha20Poly1305StreamingPayloadPayloadPayloadEncryptedZeroDataLossLedgerDelta992198273618',
        algorithm: 'ChaCha20-Poly1305',
        keyFingerprint: 'PREV_HASH:0000000004928171_OK',
        decryptedPreview: 'TX_COMMIT: FROM=ACC-USD-001 TO=ACC-USD-002 AMT=150.00 CUR=USD [IMMUTABLE]',
        createdAt: '2025-09-06 10:24:00',
        lastAccessed: '2025-09-06 10:24:01'
      }
    ]
  }
];

export const SECRET_AUDIT_LOGS: SecretAuditLog[] = [
  {
    id: 'log-01',
    timestamp: '2025-09-06 10:24:12',
    actor: 'نصر النصر (مدير النظام السيادي)',
    action: 'view',
    targetSecret: 'SOVEREIGN_MASTER_ENCRYPTION_KEY_MEK',
    ipAddress: '10.0.0.1 (Internal Secured Console)',
    result: 'authorized'
  },
  {
    id: 'log-02',
    timestamp: '2025-09-06 10:15:30',
    actor: 'محرك التسوية الآلي (Settlement Engine)',
    action: 'decrypt',
    targetSecret: 'CBY_CENTRAL_BANK_CLEARING_SECRET_PROD',
    ipAddress: '10.150.4.12 (Banking Gateway Service)',
    result: 'authorized'
  },
  {
    id: 'log-03',
    timestamp: '2025-09-06 09:40:05',
    actor: 'نظام إدارة المفاتيح (Automated KMS Daemon)',
    action: 'rotate',
    targetSecret: 'MOBILE_DEVICE_ATTESTATION_ED25519',
    ipAddress: '127.0.0.1 (HSM Daemon)',
    result: 'authorized'
  },
  {
    id: 'log-04',
    timestamp: '2025-09-06 08:12:44',
    actor: 'نظام الدعم الفني (Support Agent #14)',
    action: 'view',
    targetSecret: 'SOVEREIGN_BREAK_GLASS_CODE_OMEGA_01',
    ipAddress: '192.168.1.55 (Unauthorized IP Attempt)',
    result: 'denied'
  },
  {
    id: 'log-05',
    timestamp: '2025-09-05 22:30:19',
    actor: 'نصر النصر (المالك السيادي)',
    action: 'export',
    targetSecret: 'EMERGENCY_DISASTER_RECOVERY_KEY_BUNDLE',
    ipAddress: '10.0.0.1 (Cold Storage Vault)',
    result: 'authorized'
  }
];
