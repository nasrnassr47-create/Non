// src/data/mockFamilies.ts
import { FamilyGroup, FamilyMember, FamilyAllowanceRequest } from '../types/family';

export const mockFamilyGroups: FamilyGroup[] = [
  {
    id: 'fam-1',
    ownerId: 'u-3', // Abdullah Yahya
    familyName: 'عائلة عبدالله يحيى',
    sharedBudget: 1500000,
    currency: 'YER',
    membersCount: 4,
    createdAt: '2025-01-15T10:00:00Z'
  },
  {
    id: 'fam-2',
    ownerId: 'u-1', // Mohammed Nasr
    familyName: 'أسرة نصر الكريمة',
    sharedBudget: 2500000,
    currency: 'YER',
    membersCount: 3,
    createdAt: '2025-02-01T12:00:00Z'
  },
  {
    id: 'fam-3',
    ownerId: 'u-13',
    familyName: 'عائلة الحاشدي',
    sharedBudget: 800000,
    currency: 'YER',
    membersCount: 5,
    createdAt: '2025-02-10T09:00:00Z'
  },
  {
    id: 'fam-4',
    ownerId: 'u-10',
    familyName: 'عائلة آل النهدي',
    sharedBudget: 12000,
    currency: 'SAR',
    membersCount: 4,
    createdAt: '2025-02-20T11:00:00Z'
  },
  {
    id: 'fam-5',
    ownerId: 'u-9',
    familyName: 'أسرة السقاف',
    sharedBudget: 5000,
    currency: 'USD',
    membersCount: 3,
    createdAt: '2025-03-01T14:00:00Z'
  }
];

export const mockFamilyMembers: FamilyMember[] = [
  {
    id: 'fm-1',
    familyId: 'fam-1',
    userId: 'u-3',
    name: 'عبدالله يحيى',
    phone: '+967771234567',
    relationship: 'father',
    allowanceDaily: 100000,
    allowanceMonthly: 1500000,
    spentThisMonth: 340000,
    balance: 18450000,
    currency: 'YER',
    canRequestMoney: true,
    canSendOutside: true,
    status: 'active',
    linkedWalletId: 'w-3-yer'
  },
  {
    id: 'fm-2',
    familyId: 'fam-1',
    userId: 'u-fam-mother',
    name: 'أم عمر (مريم صالح)',
    phone: '+967771234568',
    relationship: 'mother',
    allowanceDaily: 40000,
    allowanceMonthly: 400000,
    spentThisMonth: 125000,
    balance: 275000,
    currency: 'YER',
    canRequestMoney: true,
    canSendOutside: true,
    status: 'active',
    linkedWalletId: 'w-fam-mother'
  },
  {
    id: 'fm-3',
    familyId: 'fam-1',
    userId: 'u-4',
    name: 'عمر عبدالله (الابن الأكبر)',
    phone: '+967772345678',
    relationship: 'son',
    allowanceDaily: 5000,
    allowanceMonthly: 60000,
    spentThisMonth: 25000,
    balance: 35000,
    currency: 'YER',
    canRequestMoney: true,
    canSendOutside: false,
    status: 'active',
    linkedWalletId: 'w-4-yer'
  },
  {
    id: 'fm-4',
    familyId: 'fam-1',
    userId: 'u-fam-daughter',
    name: 'سارة عبدالله (الابنة)',
    phone: '+967772345679',
    relationship: 'daughter',
    allowanceDaily: 3000,
    allowanceMonthly: 45000,
    spentThisMonth: 18000,
    balance: 27000,
    currency: 'YER',
    canRequestMoney: true,
    canSendOutside: false,
    status: 'active',
    linkedWalletId: 'w-fam-daughter'
  }
];

export const mockFamilyAllowanceRequests: FamilyAllowanceRequest[] = [
  {
    id: 'req-1',
    familyId: 'fam-1',
    memberId: 'fm-3',
    memberName: 'عمر عبدالله',
    amount: 10000,
    currency: 'YER',
    reason: 'شراء مراجع جامعية ومستلزمات دراسية لمادة الهندسة',
    requestedAt: '2025-03-20T08:30:00Z',
    status: 'pending'
  },
  {
    id: 'req-2',
    familyId: 'fam-1',
    memberId: 'fm-4',
    memberName: 'سارة عبدالله',
    amount: 6000,
    currency: 'YER',
    reason: 'تجديد باقة إنترنت للدراسة عن بُعد',
    requestedAt: '2025-03-19T14:15:00Z',
    status: 'approved',
    resolvedAt: '2025-03-19T14:20:00Z',
    notes: 'تمت الموافقة الآلية من رصيد العائلة'
  }
];
