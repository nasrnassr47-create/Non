// src/data/mockSystemTree.ts
export * from './systemTree';
export { SYSTEM_BRANCHES as mockSystemTree } from './systemTree';
