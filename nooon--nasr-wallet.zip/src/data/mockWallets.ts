// src/data/mockWallets.ts
import { Wallet, BankCard, LinkedBankAccount } from '../types/wallet';

export const mockWallets: Wallet[] = [
  // User 1 (Mohammed Nasr - Main User)
  {
    id: 'w-1-yer',
    userId: 'u-1',
    currency: 'YER',
    balance: 4850000,
    holdBalance: 0,
    availableBalance: 4850000,
    symbol: 'ر.ي',
    accountNumber: '777-100-2491',
    iban: 'YE94NASR0000007771002491',
    isDefault: true,
    status: 'active',
    updatedAt: '2025-03-20T10:00:00Z'
  },
  {
    id: 'w-1-sar',
    userId: 'u-1',
    currency: 'SAR',
    balance: 14200,
    holdBalance: 0,
    availableBalance: 14200,
    symbol: 'ر.س',
    accountNumber: '777-100-2492',
    iban: 'YE94NASR0000007771002492',
    isDefault: false,
    status: 'active',
    updatedAt: '2025-03-20T10:00:00Z'
  },
  {
    id: 'w-1-usd',
    userId: 'u-1',
    currency: 'USD',
    balance: 3750,
    holdBalance: 0,
    availableBalance: 3750,
    symbol: '$',
    accountNumber: '777-100-2493',
    iban: 'YE94NASR0000007771002493',
    isDefault: false,
    status: 'active',
    updatedAt: '2025-03-20T10:00:00Z'
  },
  {
    id: 'w-1-eur',
    userId: 'u-1',
    currency: 'EUR',
    balance: 2400,
    holdBalance: 0,
    availableBalance: 2400,
    symbol: '€',
    accountNumber: '777-100-2494',
    iban: 'YE94NASR0000007771002494',
    isDefault: false,
    status: 'active',
    updatedAt: '2025-03-20T10:00:00Z'
  },

  // User 3 (Abdullah - Subscriber)
  {
    id: 'w-3-yer',
    userId: 'u-3',
    currency: 'YER',
    balance: 18450000,
    holdBalance: 500000,
    availableBalance: 17950000,
    symbol: 'ر.ي',
    accountNumber: '771-234-5671',
    isDefault: true,
    status: 'active',
    updatedAt: '2025-03-20T09:00:00Z'
  },

  // User 4 (Omar - Family Mini)
  {
    id: 'w-4-yer',
    userId: 'u-4',
    currency: 'YER',
    balance: 35000,
    holdBalance: 0,
    availableBalance: 35000,
    symbol: 'ر.ي',
    accountNumber: '772-345-6781',
    isDefault: true,
    status: 'active',
    updatedAt: '2025-03-20T09:30:00Z'
  },

  // User 5 (Al-Nasr Agent)
  {
    id: 'w-5-yer',
    userId: 'u-5',
    currency: 'YER',
    balance: 95000000,
    holdBalance: 2000000,
    availableBalance: 93000000,
    symbol: 'ر.ي',
    accountNumber: '773-456-7891',
    isDefault: true,
    status: 'active',
    updatedAt: '2025-03-20T08:00:00Z'
  },

  // User 6 (Consumer Hypermarket POS)
  {
    id: 'w-6-yer',
    userId: 'u-6',
    currency: 'YER',
    balance: 42300000,
    holdBalance: 0,
    availableBalance: 42300000,
    symbol: 'ر.ي',
    accountNumber: '774-567-8901',
    isDefault: true,
    status: 'active',
    updatedAt: '2025-03-20T11:00:00Z'
  }
];

export const mockBankCards: BankCard[] = [
  {
    id: 'card-1',
    userId: 'u-1',
    walletId: 'w-1-usd',
    cardNumber: '5399428199201482',
    cardHolder: 'MOHAMMED N AL-YAMANI',
    expiryMonth: '11',
    expiryYear: '29',
    cvv: '842',
    cardType: 'virtual_mastercard',
    isFrozen: false,
    dailyLimit: 2000,
    monthlyLimit: 15000,
    currency: 'USD',
    colorTheme: 'emerald'
  },
  {
    id: 'card-2',
    userId: 'u-1',
    walletId: 'w-1-sar',
    cardNumber: '4159820019483321',
    cardHolder: 'MOHAMMED N AL-YAMANI',
    expiryMonth: '06',
    expiryYear: '28',
    cvv: '391',
    cardType: 'virtual_visa',
    isFrozen: false,
    dailyLimit: 5000,
    monthlyLimit: 30000,
    currency: 'SAR',
    colorTheme: 'gold'
  },
  {
    id: 'card-3',
    userId: 'u-1',
    walletId: 'w-1-yer',
    cardNumber: '9670182944012948',
    cardHolder: 'MOHAMMED N AL-YAMANI',
    expiryMonth: '12',
    expiryYear: '30',
    cvv: '519',
    cardType: 'mada',
    isFrozen: false,
    dailyLimit: 1000000,
    monthlyLimit: 10000000,
    currency: 'YER',
    colorTheme: 'dark'
  }
];

export const mockLinkedBankAccounts: LinkedBankAccount[] = [
  {
    id: 'bank-1',
    userId: 'u-1',
    bankName: 'بنك اليمن والكويت (YKB)',
    bankCode: 'YKB-YE',
    iban: 'YE88YKB00019284910291',
    swift: 'YKBYESAA',
    accountNumber: '0102-948192',
    isVerified: true,
    status: 'active'
  },
  {
    id: 'bank-2',
    userId: 'u-1',
    bankName: 'بنك التضامن الإسلامي (TIIB)',
    bankCode: 'TADAMON-YE',
    iban: 'YE77TADB00028471920194',
    swift: 'TADBYESA',
    accountNumber: '1105-839201',
    isVerified: true,
    status: 'active'
  },
  {
    id: 'bank-3',
    userId: 'u-3',
    bankName: 'بنك القطيبي الإسلامي للتمويل الأصغر',
    bankCode: 'QUTAIBI-YE',
    iban: 'YE55QUTB00094829104821',
    swift: 'QUTBYESA',
    accountNumber: '3301-482910',
    isVerified: true,
    status: 'active'
  }
];
