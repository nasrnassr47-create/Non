// src/data/mockSubscriptions.ts
import { SubscriptionPlan, SubscriberAccount, PayrollBatch } from '../types/subscription';

export const mockSubscriptionPlans: SubscriptionPlan[] = [
  {
    id: 'plan-basic',
    tier: 'basic',
    nameAr: 'الباقة الأساسية (Free)',
    nameEn: 'Basic Tier',
    monthlyFeeYER: 0,
    monthlyFeeSAR: 0,
    maxFamilyMembers: 1,
    maxBankLinks: 1,
    hasPayrollSupport: false,
    hasFreeP2P: true,
    prioritySupport: false,
    badgeColor: 'bg-slate-700 text-slate-200',
    features: ['محفظة فردية', 'تحويلات P2P مجانية محدودة', 'سداد فواتير وشحن', 'بطاقة رقمية واحدة']
  },
  {
    id: 'plan-silver',
    tier: 'silver',
    nameAr: 'الباقة الفضية (عائلية خفيفة)',
    nameEn: 'Silver Family Tier',
    monthlyFeeYER: 2500,
    monthlyFeeSAR: 15,
    maxFamilyMembers: 3,
    maxBankLinks: 2,
    hasPayrollSupport: false,
    hasFreeP2P: true,
    prioritySupport: false,
    badgeColor: 'bg-slate-400 text-slate-950',
    features: ['إدارة حتى 3 أفراد من العائلة', 'تحديد ميزانية مصروف شهرية', 'ربط حسابين بنكيين', 'إشعارات سريعة']
  },
  {
    id: 'plan-gold',
    tier: 'gold',
    nameAr: 'الباقة الذهبية (العائلة والرواتب)',
    nameEn: 'Gold Family & Payroll',
    monthlyFeeYER: 6000,
    monthlyFeeSAR: 35,
    maxFamilyMembers: 7,
    maxBankLinks: 5,
    hasPayrollSupport: true,
    hasFreeP2P: true,
    prioritySupport: true,
    badgeColor: 'bg-amber-400 text-slate-950',
    features: ['إدارة حتى 7 أفراد من العائلة', 'نظام مسير رواتب مبسط (حتى 20 موظف)', 'ربط 5 حسابات بنكية وصرافة', 'دعم فني ذو أولوية']
  },
  {
    id: 'plan-platinum',
    tier: 'platinum',
    nameAr: 'الباقة البلاتينية السيادية (الشركات والمؤسسات)',
    nameEn: 'Platinum Corporate Tier',
    monthlyFeeYER: 15000,
    monthlyFeeSAR: 90,
    maxFamilyMembers: 20,
    maxBankLinks: 15,
    hasPayrollSupport: true,
    hasFreeP2P: true,
    prioritySupport: true,
    badgeColor: 'bg-gradient-to-r from-emerald-400 to-teal-200 text-slate-950 font-bold',
    features: ['أفراد عائلة وفروع غير محدود', 'صرف كشوفات رواتب ضخمة عبر CSV', 'ربط مباشر عبر API مع البنوك', 'مدير حساب مخصص 24/7']
  }
];

export const mockSubscribers: SubscriberAccount[] = Array.from({ length: 30 }, (_, i) => {
  const tiers: Array<'basic' | 'silver' | 'gold' | 'platinum'> = ['gold', 'silver', 'platinum', 'gold', 'basic'];
  const tier = tiers[i % tiers.length];
  const companyNames = [
    'مؤسسة النصر للخدمات اللوجستية',
    'مجموعة التلال التجارية',
    'شركة السعيد الهندسية',
    'مدارس الرواد النموذجية',
    'مستشفى الأمل التخصصي',
    'مكتب البرهان للمحاماة والاستشارات'
  ];
  return {
    id: `sub-${i + 1}`,
    userId: i === 0 ? 'u-3' : `u-sub-${i + 1}`,
    planId: `plan-${tier}`,
    tier,
    startDate: '2025-01-01T00:00:00Z',
    renewDate: '2025-04-01T00:00:00Z',
    autoRenew: true,
    familyMembersCount: tier === 'basic' ? 1 : tier === 'silver' ? 3 : tier === 'gold' ? 5 : 12,
    linkedBanksCount: tier === 'basic' ? 1 : tier === 'silver' ? 2 : 4,
    companyName: i % 2 === 0 ? companyNames[i % companyNames.length] : undefined,
    status: i === 19 ? 'grace_period' : 'active'
  };
});

export const mockPayrollBatches: PayrollBatch[] = [
  {
    id: 'pr-1',
    subscriberId: 'sub-1',
    batchTitle: 'رواتب موظفي الإدارة - مارس 2025',
    month: '2025-03',
    totalAmount: 3850000,
    currency: 'YER',
    employeesCount: 14,
    status: 'disbursed',
    disbursedAt: '2025-03-01T10:00:00Z'
  },
  {
    id: 'pr-2',
    subscriberId: 'sub-1',
    batchTitle: 'مكافآت الربع الأول وإكرامية رمضان',
    month: '2025-03',
    totalAmount: 1200000,
    currency: 'YER',
    employeesCount: 14,
    status: 'processing'
  }
];
