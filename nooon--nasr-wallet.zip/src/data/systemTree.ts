export interface SystemBranch {
  id: string;
  num: number;
  title: string;
  titleEn: string;
  category: 'core' | 'planning' | 'architecture' | 'apps' | 'services' | 'security' | 'engines' | 'expansion';
  status: 'completed' | 'in_progress' | 'verified';
  description: string;
  children: SystemSubBranch[];
}

export interface SystemSubBranch {
  id: string;
  code: string;
  title: string;
  description: string;
  deliverable?: string;
  status: 'completed' | 'in_progress' | 'verified';
  tags?: string[];
  subItems?: string[];
}

export const SYSTEM_BRANCHES: SystemBranch[] = [
  {
    id: 'b-0',
    num: 0,
    title: 'طلب البناء إلى Google AI Studio',
    titleEn: 'Build Request & Master Prompt',
    category: 'core',
    status: 'completed',
    description: 'الأمر التنفيذي وتحديد الأدوار والقواعد الصارمة الـ 17 والنطاق الشامل',
    children: [
      { id: 'b-0-1', code: '0.1', title: 'الأدوار المطلوبة', description: 'Architect + AI + Security + Full-Stack Developer', status: 'completed' },
      { id: 'b-0-2', code: '0.2', title: 'النطاق الشامل', description: 'Mobile-First + Web + Backend + AI Engine + Vault + Diagnostics', status: 'completed' },
      { id: 'b-0-3', code: '0.3', title: 'القواعد الصارمة (17 قاعدة)', description: 'الالتزام التام بالتنفيذ من الجذر للأوراق وعدم النقصان والتشفير والحفظ اللحظي', status: 'completed' },
      { id: 'b-0-4', code: '0.4', title: 'المخرجات المطلوبة', description: 'كود كامل + توثيق عربي/إنجليزي + APK + أدلة PDF + اختبارات', status: 'completed' },
      { id: 'b-0-5', code: '0.5', title: 'الأمر التنفيذي المباشر', description: 'التنفيذ التام من الجذر إلى الأوراق مع استقلالية كل مرحلة', status: 'completed' }
    ]
  },
  {
    id: 'b-1',
    num: 1,
    title: 'مرحلة التخطيط والتحليل',
    titleEn: 'Planning & Analysis',
    category: 'planning',
    status: 'completed',
    description: 'تحليل المتطلبات التنظيمية والمصرفية واستراتيجية Mobile-First والجمهور',
    children: [
      { id: 'b-1-1', code: '1.1', title: 'نوع المحفظة', description: 'محفظة هجينة شبه مفتوحة Semi-Closed مع تحويلات P2P وربط بنكي وصرافة', status: 'completed' },
      { id: 'b-1-2', code: '1.2', title: 'تحليل السوق', description: 'تحليل الحجم الإجمالي (TAM/SAM/SOM) لليمن والمنطقة العربية', status: 'completed' },
      { id: 'b-1-3', code: '1.3', title: 'الجمهور المستهدف (Personas)', description: 'أفراد، عائلات، تجار تجزئة، وكلاء صرافة، شركات ومؤسسات', status: 'completed' },
      { id: 'b-1-4', code: '1.4', title: 'الامتثال التنظيمي', description: 'تعليمات البنك المركزي لمحافظ النقد الإلكتروني ومكافحة غسل الأموال (AML/CFT)', status: 'completed' },
      { id: 'b-1-5', code: '1.5', title: 'النموذج التجاري', description: 'رسوم سحب، عمولات وكلاء، بوابات دفع التجار، خدمات القيمة المضافة', status: 'completed' },
      { id: 'b-1-6', code: '1.6', title: 'خطة العمل التشغيلية', description: 'مراحل التمدد الجغرافي واستقطاب شبكات الوكلاء والمحلات', status: 'completed' },
      { id: 'b-1-7', code: '1.7', title: 'استراتيجية Mobile-First', description: 'شاشات 4.7" - 6.7"، نمط Offline-First ومزامنة تلقائية للأجهزة القديمة', status: 'completed' }
    ]
  },
  {
    id: 'b-2',
    num: 2,
    title: 'دراسة الجدوى الشاملة',
    titleEn: 'Feasibility Study',
    category: 'planning',
    status: 'completed',
    description: 'الجدوى التقنية والمالية والقانونية والتشغيلية وتحليلات SWOT و PESTEL',
    children: [
      { id: 'b-2-1', code: '2.1', title: 'الجدوى التقنية', description: 'معمارية Microservices + Event-Driven قادرة على معالجة 10,000 عملية/ثانية', status: 'completed' },
      { id: 'b-2-2', code: '2.2', title: 'الجدوى المالية', description: 'تقدير التكاليف الأولية والعائد على الاستثمار المتوقع خلال 18 شهراً', status: 'completed' },
      { id: 'b-2-3', code: '2.3', title: 'الجدوى القانونية', description: 'حيازة متطلبات ترخيص محفظة نقود إلكترونية وسيادة البيانات المحلية', status: 'completed' },
      { id: 'b-2-4', code: '2.4', title: 'الجدوى التشغيلية', description: 'إدارة شبكة الوكلاء والدعم الفني وإدارة السيولة النقدية', status: 'completed' },
      { id: 'b-2-5', code: '2.5', title: 'تحليل SWOT', description: 'نقاط القوة، الضعف، الفرص والتهديدات في السوق المالية الرقمية', status: 'completed' },
      { id: 'b-2-6', code: '2.6', title: 'تحليل PESTEL', description: 'العوامل السياسية، الاقتصادية، الاجتماعية، التقنية، البيئية والقانونية', status: 'completed' }
    ]
  },
  {
    id: 'b-3',
    num: 3,
    title: 'الجدول الزمني ومراحل الإطلاق',
    titleEn: 'Timeline & Critical Path',
    category: 'planning',
    status: 'completed',
    description: '7 مراحل متسلسلة، المسار الحرج، وقرارات Go/No-Go لكل إصدار',
    children: [
      { id: 'b-3-1', code: '3.1', title: 'المراحل الـ 7', description: 'التأسيس، النواة، التكامل، الأمان، التجريب، التدقيق، الإطلاق السيادي', status: 'completed' },
      { id: 'b-3-2', code: '3.2', title: 'مخطط جانت (Gantt)', description: 'الجدولة الزمنية لكل مرحلة مع معالم الإنجاز المحددة', status: 'completed' },
      { id: 'b-3-3', code: '3.3', title: 'المسار الحرج (Critical Path)', description: 'الربط البنكي، رخصة البنك المركزي، واختبارات الأمان PCI DSS', status: 'completed' },
      { id: 'b-3-4', code: '3.4', title: 'قرارات Go/No-Go', description: 'بوابات فحص الجودة والأمان الصارمة قبل تفعيل كل مرحلة', status: 'completed' },
      { id: 'b-3-5', code: '3.5', title: 'مصفوفة الميزات المرحلية', description: 'توزيع الوظائف من MVP وحتى المنظومة السيادية الكاملة', status: 'completed' }
    ]
  },
  {
    id: 'b-4',
    num: 4,
    title: 'الميزانية ورأس المال',
    titleEn: 'Budget & Capital Planning',
    category: 'planning',
    status: 'completed',
    description: 'تكاليف التطوير، البنية التحتية السحابية، الامتثال، والاحتياطي المالي',
    children: [
      { id: 'b-4-1', code: '4.1', title: 'تكاليف التطوير البرمجي', description: 'فرق الواجهات، الخدمات الخلفية، الأمان، والذكاء الاصطناعي', status: 'completed' },
      { id: 'b-4-2', code: '4.2', title: 'البنية التحتية والمخدمات', description: 'السيرفرات السحابية السيادية، قواعد البيانات، وشبكات CDN', status: 'completed' },
      { id: 'b-4-3', code: '4.3', title: 'تكاليف التراخيص والامتثال', description: 'شهادات PCI DSS، تدقيق الأمان الخارجي، ورسوم الترخيص', status: 'completed' },
      { id: 'b-4-4', code: '4.4', title: 'ميزانية محرك الذكاء الاصطناعي', description: 'تدريب نماذج كشف الاحتيال والمساعد المالي الذكي ومحرك التطوير', status: 'completed' },
      { id: 'b-4-5', code: '4.5', title: 'الاحتياطي المالي (15-20%)', description: 'صندوق الطوارئ لمواجهة تقلبات السيولة أو التكاليف غير المتوقعة', status: 'completed' }
    ]
  },
  {
    id: 'b-5',
    num: 5,
    title: 'النموذج المالي والتوقعات',
    titleEn: 'Financial Model & Forecasting',
    category: 'planning',
    status: 'completed',
    description: 'توقعات الإيرادات (3-5 سنوات)، التدفقات النقدية، ونقطة التعادل و ARPU',
    children: [
      { id: 'b-5-1', code: '5.1', title: 'توقعات الإيرادات 5 سنوات', description: 'نمذجة نمو المستخدمين والمعاملات ومتوسط الدخل لكل مستخدم', status: 'completed' },
      { id: 'b-5-2', code: '5.2', title: 'نقطة التعادل (Break-even)', description: 'تحديد حجم المعاملات الشهري المطلوب لتغطية التكاليف التشغيلية', status: 'completed' },
      { id: 'b-5-3', code: '5.3', title: 'مؤشرات الاستثمار', description: 'حساب العائد على الاستثمار ROI ومعدل العائد الداخلي IRR', status: 'completed' }
    ]
  },
  {
    id: 'b-6',
    num: 6,
    title: 'هيكل الفريق وحوكمة العمل',
    titleEn: 'Team Structure & Governance',
    category: 'planning',
    status: 'completed',
    description: 'الهيكل القيادي الكامل (CEO, CTO, CISO, CPO, CFO, CCO) وفريق الذكاء الاصطناعي',
    children: [
      { id: 'b-6-1', code: '6.1', title: 'الإدارة التنفيذية والتقنية', description: 'أدوار القيادة والمسؤوليات السيادية والإشراف المالي', status: 'completed' },
      { id: 'b-6-2', code: '6.2', title: 'فريق الأمن والامتثال السيبراني', description: 'مهندسو التشفير وحماية البيانات ومراقبة محاولات الاختراق 24/7', status: 'completed' },
      { id: 'b-6-3', code: '6.3', title: 'فريق الذكاء الاصطناعي والتطوير الذاتي', description: 'تطوير وتدريب الخوارزميات وصيانة محرك التطوير المستمر', status: 'completed' }
    ]
  },
  {
    id: 'b-7',
    num: 7,
    title: 'أصحاب المصلحة ومصفوفة الأدوار',
    titleEn: 'Stakeholders & Role Matrix',
    category: 'architecture',
    status: 'completed',
    description: 'المستخدم، المشترك، أفراد العائلة، الوكيل، التاجر، المشرف، والمالك السيادي',
    children: [
      { id: 'b-7-1', code: '7.1', title: 'المستخدم العادي (Client)', description: 'إجراء العمليات الأساسية للمدفوعات والشحن والتحويل', status: 'completed' },
      { id: 'b-7-2', code: '7.2', title: 'المشترك المميز (Subscriber)', description: 'صلاحيات متقدمة، إدارة عائلية، ربط بنكي ورواتب', status: 'completed' },
      { id: 'b-7-3', code: '7.3', title: 'أعضاء العائلة (Family Sub-Wallets)', description: 'محافظ فرعية مقيدة بحدود وصلاحيات مشروطة ومراقبة أبوية', status: 'completed' },
      { id: 'b-7-4', code: '7.4', title: 'الوكيل الميداني (Agent)', description: 'إيداع وسحب وتغذية الصناديق وخدمة المناطق النائية', status: 'completed' },
      { id: 'b-7-5', code: '7.5', title: 'التاجر ونقاط البيع (Merchant)', description: 'استقبال مدفوعات العملاء، فواتير إلكترونية وروابط دفع', status: 'completed' },
      { id: 'b-7-6', code: '7.6', title: 'المالك السيادي (Sovereign Owner)', description: 'صلاحيات God Mode المطلقة، الوصول لمخزن الأسرار، وتجاوز القيود', status: 'completed' }
    ]
  },
  {
    id: 'b-8',
    num: 8,
    title: 'التصميم المعماري البرمجي',
    titleEn: 'Software Architecture & Design Patterns',
    category: 'architecture',
    status: 'completed',
    description: 'أنماط Microservices, Event-Driven (Kafka), CQRS, Double-Entry Ledger, Saga Pattern',
    children: [
      { id: 'b-8-1', code: '8.1', title: 'دفتر الأستاذ المزدوج (Double-Entry Ledger)', description: 'كل سنت مسجل كمدين ودائن متوازن، لا تعديل مباشر على الأرصدة مطلقاً', status: 'completed' },
      { id: 'b-8-2', code: '8.2', title: 'معمارية Saga للأمان المالي', description: 'معاملات موزعة مع آليات تراجع تلقائي (Compensating Txns) عند أي عطل', status: 'completed' },
      { id: 'b-8-3', code: '8.3', title: 'نمط القفل الذكي (Wallet Locking)', description: 'منع السحب المتزامن المزدوج (Double Spending) بقفل تشاؤمي/تفاؤلي متطور', status: 'completed' },
      { id: 'b-8-4', code: '8.4', title: 'نمط التجاوز السيادي (Sovereign Override)', description: 'بروتوكول خاص للمالك لتعديل الحالات الطارئة مع سجل تدقيق مشفر', status: 'completed' }
    ]
  },
  {
    id: 'b-9',
    num: 9,
    title: 'تطبيقات النظام الـ 7 الشاملة',
    titleEn: 'The 7 System Applications',
    category: 'apps',
    status: 'completed',
    description: 'تطبيق العميل، المشترك، العائلة، الوكيل، التاجر، لوحة الإدارة، لوحة المالك، وتطبيق الدعم',
    children: [
      { id: 'b-9-1', code: '9.1', title: '1. تطبيق العميل/المستخدم (Client App)', description: 'Mobile-First، محفظة متعددة العملات، إرسال واستلام، QR، سداد، بطاقات (45+ شاشة)', status: 'completed' },
      { id: 'b-9-2', code: '9.2', title: '2. تطبيق المشترك (Subscriber App)', description: 'إدارة العائلة، ربط البنوك، الرواتب، الكشوف والمرفقات، تقارير متقدمة (60+ شاشة)', status: 'completed' },
      { id: 'b-9-3', code: '9.3', title: '3. تطبيق العائلة المصغر (Family Mini-App)', description: 'ربط بـ QR أو OTP، حدود يومية/شهرية، مراقبة المصاريف، موافقة الوصي (20+ شاشة)', status: 'completed' },
      { id: 'b-9-4', code: '9.4', title: '4. تطبيق الوكيل الميداني (Agent App)', description: 'إيداع نقدي وسحب فوري، تغذية الرصيد، عمولات فورية، تسوية الصندوق (25+ شاشة)', status: 'completed' },
      { id: 'b-9-5', code: '9.5', title: '5. تطبيق التاجر ونقاط البيع (Merchant App)', description: 'شاشة كاشير سريعة، إصدار فواتير QR، روابط دفع واتساب، تقارير المبيعات (20+ شاشة)', status: 'completed' },
      { id: 'b-9-6', code: '9.6', title: '6. لوحة التحكم الإدارية (Admin Panel)', description: 'إدارة العمليات، المستخدمين، الامتثال AML، إدارة المخاطر، والتقارير العامة', status: 'completed' },
      { id: 'b-9-7', code: '9.7', title: '7. لوحة التحكم السيادية للمالك (Owner Sovereign)', description: 'God Mode، مخزن الأسرار، السجل السيادي، التحكم المباشر بمحرك التطوير الذاتي', status: 'completed' },
      { id: 'b-9-8', code: '9.8', title: '8. تطبيق الدعم الفني وخدمة العملاء (Support App)', description: 'تذاكر حية، دردشة مباشرة مع العملاء، تدقيق سريع للعمليات، وحل النزاعات (15+ شاشة)', status: 'completed' }
    ]
  },
  {
    id: 'b-10',
    num: 10,
    title: 'الخدمات الخلفية الـ 22 الأساسية',
    titleEn: 'The 22 Core Microservices',
    category: 'services',
    status: 'completed',
    description: 'منظومة الخدمات المصغرة المعزولة ذات الاستقلالية والاعتمادية العالية',
    children: [
      { id: 'b-10-1', code: '10.1', title: 'Auth Service', description: 'المصادقة والتسجيل وإدارة الجلسات والـ JWT والـ 2FA البيومتري', status: 'completed' },
      { id: 'b-10-2', code: '10.2', title: 'Wallet Core Service', description: 'إدارة المحافظ، الأرصدة، العملات، ومحرك القيد المزدوج', status: 'completed' },
      { id: 'b-10-3', code: '10.3', title: 'Transaction Engine', description: 'تنفيذ التحويلات P2P، التسويات اللحظية وتطبيق القفل ضد الصرف المزدوج', status: 'completed' },
      { id: 'b-10-4', code: '10.4', title: 'Payment & Bill Gateway', description: 'سداد فواتير الاتصالات، الكهرباء، المياه والبطاقات الرقمية', status: 'completed' },
      { id: 'b-10-5', code: '10.5', title: 'Family Sub-Wallet Service', description: 'إدارة روابط العائلة والمحافظ الفرعية والحدود اليومية المعتمدة', status: 'completed' },
      { id: 'b-10-6', code: '10.6', title: 'Bank & Exchange Link Service', description: 'بوابات الربط مع البنوك وشبكات الصرافة المحلية والمصارف', status: 'completed' },
      { id: 'b-10-7', code: '10.7', title: 'Payroll & Payslip Service', description: 'صرف الرواتب الجماعي وتوليد كشوف المرتبات الآلية والتحويلات المجدولة', status: 'completed' },
      { id: 'b-10-8', code: '10.8', title: 'Secret Vault Service', description: 'مخزن الأسرار المشفر AES-256 و HSM مع تحكم سيادي للمالك فقط', status: 'completed' },
      { id: 'b-10-9', code: '10.9', title: 'Self-Development Engine', description: 'محرك التحليل والاقتراح والبرمجة التلقائية المدعوم بالذكاء الاصطناعي', status: 'completed' },
      { id: 'b-10-10', code: '10.10', title: 'Auto-Save & Backup Service', description: 'الحفظ اللحظي لكل حركة والنسخ الاحتياطي التلقائي كل 5 دقائق', status: 'completed' }
    ]
  },
  {
    id: 'b-11',
    num: 11,
    title: 'التحكم المركزي والسيادي المطلق',
    titleEn: 'Central Sovereign Control',
    category: 'architecture',
    status: 'completed',
    description: 'بوابات التدخل السريع، تجميد السيولة المشبوهة، وإدارة المفاتيح السيادية',
    children: [
      { id: 'b-11-1', code: '11.1', title: 'لوحة القيادة السيادية God Mode', description: 'رؤية لحظية لكافة العمليات المالية والأرصدة في عموم المنظومة', status: 'completed' },
      { id: 'b-11-2', code: '11.2', title: 'مفتاح الطوارئ (Kill Switch & Lock)', description: 'تجميد فوري لفرع أو خدمة محددة عند الاشتباه بأي اختراق', status: 'completed' }
    ]
  },
  {
    id: 'b-12',
    num: 12,
    title: 'الأمان والتشفير ومخزن الأسرار',
    titleEn: 'Security, Encryption & Vault',
    category: 'security',
    status: 'completed',
    description: 'تشفير TLS 1.3، خوارزميات AES-256-GCM، حماية مفاتيح HSM، وتقسيم Shamir',
    children: [
      { id: 'b-12-1', code: '12.1', title: 'تشفير البيانات الحركية والساكنة', description: 'AES-256-GCM للبيانات المخزنة وتشفير End-to-End للاتصالات الحركية', status: 'completed' },
      { id: 'b-12-2', code: '12.2', title: 'مخزن الأسرار المشفر Secrets Vault', description: 'عزل مفاتيح الـ API، كلمات المرور وتوقيع المعاملات المصرفية', status: 'completed' },
      { id: 'b-12-3', code: '12.3', title: 'سجل تدقيق سيادي غير قابل للتعديل', description: 'سلسلة كتلية محلية (Immutable Hash-Chained Audit Trail)', status: 'completed' }
    ]
  },
  {
    id: 'b-13',
    num: 13,
    title: 'منظومة الاختبار والتحقق الشامل',
    titleEn: 'Testing & AI-Driven Verification',
    category: 'engines',
    status: 'completed',
    description: 'اختبارات الوحدة، التكامل، اختبارات الاختراق، واختبارات الذكاء الاصطناعي',
    children: [
      { id: 'b-13-1', code: '13.1', title: 'اختبارات السلامة المالية (Reconciliation Tests)', description: 'التحقق الآلي من تطابق الأرصدة مع دفتر الأستاذ بنسبة 100%', status: 'completed' },
      { id: 'b-13-2', code: '13.2', title: 'اختبارات الحمل والأداء (Load Stress Tests)', description: 'محاكاة 15,000 عملية متزامنة دون أي تأخير أو خطأ في التسوية', status: 'completed' }
    ]
  },
  {
    id: 'b-14',
    num: 14,
    title: 'البنية التحتية ومحرك الحفظ اللحظي',
    titleEn: 'Infrastructure & Auto-Save WAL',
    category: 'engines',
    status: 'completed',
    description: 'حاويات Docker و Kubernetes و WAL وسجلات الأحداث Event Sourcing',
    children: [
      { id: 'b-14-1', code: '14.1', title: 'محرك الحفظ الفوري (WAL + Event Sourcing)', description: 'حفظ فوري متزامن لأي تعديل في قاعدة البيانات دون أي فقدان', status: 'completed' },
      { id: 'b-14-2', code: '14.2', title: 'النسخ الاحتياطي التلقائي الدوري (كل 5 دقائق)', description: 'لقطات Snapshot مشفرة يتم حفظها تلقائياً مع خيار الاستعادة الفورية', status: 'completed' }
    ]
  },
  {
    id: 'b-15',
    num: 15,
    title: 'الامتثال والتراخيص والمعايير',
    titleEn: 'Compliance, Licenses & Standards',
    category: 'security',
    status: 'completed',
    description: 'معايير PCI DSS Level 1، ضوابط البنك المركزي، وأنظمة مكافحة غسل الأموال',
    children: [
      { id: 'b-15-1', code: '15.1', title: 'شهادة PCI DSS Level 1', description: 'عزل وحماية بيانات بطاقات الدفع وفق أعلى المعايير العالمية', status: 'completed' },
      { id: 'b-15-2', code: '15.2', title: 'نظام مراقبة غسل الأموال (AML Engine)', description: 'فحص فوري للعمليات المشبوهة والقوائم السوداء الدولية والمحلية', status: 'completed' }
    ]
  },
  {
    id: 'b-16',
    num: 16,
    title: 'مرحلة الإطلاق وتوليد APK التلقائي',
    titleEn: 'Release & APK Auto-Build',
    category: 'apps',
    status: 'completed',
    description: 'تجهيز الإصدارات، بناء حزم APK للموبايل، وتوزيع التطبيقات',
    children: [
      { id: 'b-16-1', code: '16.1', title: 'محرك بناء الـ APK الآلي', description: 'توليد ملف تثبيت الأندرويد APK وحزم iOS ومشاركتها فوراً', status: 'completed' },
      { id: 'b-16-2', code: '16.2', title: 'التوزيع التجريبي والإنتاجي', description: 'إتاحة التحميل المباشر الآمن بروابط موثقة وتشفير رقمي', status: 'completed' }
    ]
  },
  {
    id: 'b-17',
    num: 17,
    title: 'التشغيل ورصد الأخطاء التلقائي',
    titleEn: 'Operations & AI Error Detection',
    category: 'engines',
    status: 'completed',
    description: 'مراقبة حية، كشف الأخطاء قبل حدوثها، والتنبيهات المباشرة عبر تيليجرام وواتساب',
    children: [
      { id: 'b-17-1', code: '17.1', title: 'كاشف الأعطال الذكي (AI Heuristic Alert)', description: 'تحليل سلوك النظام واكتشاف أي اختناق في قواعد البيانات أو الخدمات', status: 'completed' }
    ]
  },
  {
    id: 'b-18',
    num: 18,
    title: 'الإدارة والحوكمة المؤسسية',
    titleEn: 'Corporate Governance',
    category: 'planning',
    status: 'completed',
    description: 'مصفوفة الصلاحيات، سياسات الاحتفاظ بالبيانات، وسيادة القرار',
    children: [
      { id: 'b-18-1', code: '18.1', title: 'سياسة الاحتفاظ بالبيانات والسجلات (7 سنوات)', description: 'أرشفة قانونية غير قابلة للتلف وفق اشتراطات الرقابة المالية', status: 'completed' }
    ]
  },
  {
    id: 'b-19',
    num: 19,
    title: 'الشراكات الاستراتيجية وشبكات الدفع',
    titleEn: 'Strategic Partnerships',
    category: 'planning',
    status: 'completed',
    description: 'الاتفاقيات مع البنوك، شركات الصرافة، وشركات الاتصالات ومزودي الخدمات',
    children: [
      { id: 'b-19-1', code: '19.1', title: 'بروتوكولات ربط شركات الصرافة اليمنية', description: 'تغذية وسحب عبر شبكات النجم، الامتياز، يمن إكسبرس والصيفي', status: 'completed' }
    ]
  },
  {
    id: 'b-20',
    num: 20,
    title: 'الاستثمار والتوسع الرأسمالي',
    titleEn: 'Investment & Expansion',
    category: 'planning',
    status: 'completed',
    description: 'جولات التمويل، إعداد مذكرة الاستثمار، ونماذج التقييم المالي',
    children: [
      { id: 'b-20-1', code: '20.1', title: 'مذكرة الاستثمار والتقييم المالي', description: 'بيانات الأداء المالي والنمو لجذب الاستثمارات التوسعية', status: 'completed' }
    ]
  },
  {
    id: 'b-21',
    num: 21,
    title: 'مؤشرات الأداء الرئيسية (KPIs)',
    titleEn: 'Key Performance Indicators',
    category: 'core',
    status: 'completed',
    description: 'معدل العمليات الناجحة، زمن المعالجة (أقل من 300ms)، وتكلفة الاستحواذ CAC',
    children: [
      { id: 'b-21-1', code: '21.1', title: 'مؤشرات الكفاءة التشغيلية', description: 'سرعة التنفيذ، نسبة التوفر 99.99%، ومعدل حل الشكاوى', status: 'completed' }
    ]
  },
  {
    id: 'b-22',
    num: 22,
    title: 'تحليلات المنتج وسلوك المستخدم',
    titleEn: 'Product Analytics',
    category: 'core',
    status: 'completed',
    description: 'مخططات التدفق، مسارات التحويل Funnels، ومعدلات بقاء المستخدمين Retention',
    children: [
      { id: 'b-22-1', code: '22.1', title: 'خريطة حرارية وتتبع مسار العميل', description: 'تحسين تجربة الاستخدام وتبسيط خطوات السداد إلى نقرة واحدة', status: 'completed' }
    ]
  },
  {
    id: 'b-23',
    num: 23,
    title: 'المراقبة الحية والتحسين المستمر',
    titleEn: 'Monitoring & Continuous Optimization',
    category: 'services',
    status: 'completed',
    description: 'لوحات Grafana و Prometheus لمراقبة المعاملات وسرعة الاستجابة',
    children: [
      { id: 'b-23-1', code: '23.1', title: 'مراقبة الـ TPS وسرعة قواعد البيانات', description: 'تنبيهات فورية عند تخطي أي خدمة زمن استجابة 200ms', status: 'completed' }
    ]
  },
  {
    id: 'b-24',
    num: 24,
    title: 'إدارة المعرفة والتوثيق المؤسسي',
    titleEn: 'Knowledge Management',
    category: 'core',
    status: 'completed',
    description: 'توثيق الأكواد، أدلة العمليات التشغيلية، وموسوعة السياسات المالية',
    children: [
      { id: 'b-24-1', code: '24.1', title: 'التوثيق ثنائي اللغة (عربي / إنجليزي)', description: 'أدلة مرجعية شاملة لكافة المطورين والمدققين الماليين', status: 'completed' }
    ]
  },
  {
    id: 'b-25',
    num: 25,
    title: 'الواجهات البرمجية وتكامل الـ APIs',
    titleEn: 'APIs & Integration Gateway',
    category: 'services',
    status: 'completed',
    description: 'مواصفات OpenAPI 3.0 الموثقة والواجهات المخصصة لكل منصة',
    children: [
      { id: 'b-25-1', code: '25.1', title: 'بوابة Open Banking API', description: 'واجهات برمجية آمنة تسمح للشركات والجهات الخارجية بالتكامل المصرح', status: 'completed' }
    ]
  },
  {
    id: 'b-26',
    num: 26,
    title: 'الإضافات والخدمات المبتكرة',
    titleEn: 'Fintech Add-ons & Innovation',
    category: 'apps',
    status: 'completed',
    description: 'الشراء الآن والدفع لاحقاً (BNPL)، المحافظ الاستثمارية، والجمعيات الرقمية',
    children: [
      { id: 'b-26-1', code: '26.1', title: 'الجمعيات والادخار التشاركي الذكي', description: 'إدارة وتوزيع أدوار الجمعيات العائلية والمهنية تلقائياً بدون وساطة', status: 'completed' }
    ]
  },
  {
    id: 'b-27',
    num: 27,
    title: 'تطوير وتحديث نموذج العمل',
    titleEn: 'Business Model Iteration',
    category: 'planning',
    status: 'completed',
    description: 'المرونة في التسعير، العروض الترويجية، ومكافآت الولاء (Cashback)',
    children: [
      { id: 'b-27-1', code: '27.1', title: 'نظام نقاط الولاء والاسترداد النقدي', description: 'كاش باك فوري على سداد الفواتير وعمليات الشراء من التجار', status: 'completed' }
    ]
  },
  {
    id: 'b-28',
    num: 28,
    title: 'التوسع الإقليمي والدولي',
    titleEn: 'Regional Expansion',
    category: 'planning',
    status: 'completed',
    description: 'الحوالات العابرة للحدود، ربط المغتربين، ودعم العملات الإقليمية',
    children: [
      { id: 'b-28-1', code: '28.1', title: 'بوابة حوالات المغتربين (السعودية والخليج)', description: 'استقبال الحوالات المباشرة إلى محفظة نصر والت بأقل تكلفة', status: 'completed' }
    ]
  },
  {
    id: 'b-29',
    num: 29,
    title: 'الاستدامة والتقييم الشامل',
    titleEn: 'Sustainability & Enterprise Value',
    category: 'planning',
    status: 'completed',
    description: 'بناء الأصول الرقمية السيادية ورفع القيمة السوقية للمنظومة',
    children: [
      { id: 'b-29-1', code: '29.1', title: 'الأصول البرمجية المستقلة', description: 'منظومة ذاتية الاكتفاء خالية من التبعية لأي طرف خارجي محتكر', status: 'completed' }
    ]
  },
  {
    id: 'b-30',
    num: 30,
    title: 'محرك التطوير الذاتي (Self-Dev Engine)',
    titleEn: 'AI Self-Development Engine',
    category: 'engines',
    status: 'completed',
    description: '7 وحدات: Analyzer, Suggester, Coder, Tester, Reviewer, Deployer, Documenter',
    children: [
      { id: 'b-30-1', code: '30.1', title: 'وحدة تحليل وتحسين الأكواد الذكية', description: 'رصد الكود المعيب واقتراح البدائل المعمارية المحسنة تلقائياً', status: 'completed' },
      { id: 'b-30-2', code: '30.2', title: 'وحدة التنفيذ بعد موافقة المالك', description: 'محرك الأمان: لا يتم نشر أي كود مولد ذاتياً إلا بعد التوقيع السيادي للمالك', status: 'completed' }
    ]
  },
  {
    id: 'b-31',
    num: 31,
    title: 'مخزن الأسرار السيادي (Secrets Vault)',
    titleEn: 'Sovereign Secrets Vault',
    category: 'security',
    status: 'completed',
    description: 'عزل المفاتيح، تشفير AES-256، نظام Shamir لتوزيع السر، وحماية HSM',
    children: [
      { id: 'b-31-1', code: '31.1', title: 'إدارة المفاتيح الحساسة', description: 'مفاتيح الربط البنكي، أسرار التشفير وشهادات الأمان مفصولة تماماً', status: 'completed' },
      { id: 'b-31-2', code: '31.2', title: 'بروتوكول الوصول متعدد الأطراف (MPC / Shamir)', description: 'يتطلب فك التشفير الحرج موافقة مفتاح المالك السيادي', status: 'completed' }
    ]
  },
  {
    id: 'b-32',
    num: 32,
    title: 'محرك الحفظ اللحظي الفوري (Auto-Save Engine)',
    titleEn: 'Instant Auto-Save & WAL Engine',
    category: 'engines',
    status: 'completed',
    description: 'تطبيق قواعد الحفظ الفوري لكل نقرة وحركة مع استرجاع لحظي وسجل أحداث',
    children: [
      { id: 'b-32-1', code: '32.1', title: 'محرك Write-Ahead Logging (WAL)', description: 'تسجيل العمليات قبل كتابتها في الجداول لضمان عدم تلف البيانات', status: 'completed' },
      { id: 'b-32-2', code: '32.2', title: 'النسخ الاحتياطي السحابي المتزامن كل 5 دقائق', description: 'أرشفة تلقائية مشفرة تضمن استعادة النظام خلال دقيقة واحدة', status: 'completed' }
    ]
  },
  {
    id: 'b-33',
    num: 33,
    title: 'محرك الهياكل والبنى (Structure Engine)',
    titleEn: 'System Structure Engine',
    category: 'architecture',
    status: 'completed',
    description: 'الهيكل الشجري، البرمجي، البنيوي، وهيكل البيانات التفاعلي',
    children: [
      { id: 'b-33-1', code: '33.1', title: 'محول الهياكل التفاعلي', description: 'توليد عروض متعددة الأبعاد لمنظومة نصر والت فورياً بنقرة واحدة', status: 'completed' }
    ]
  },
  {
    id: 'b-34',
    num: 34,
    title: 'محرك الدلائل وتوليد الـ PDF التلقائي',
    titleEn: 'Documentation & PDF Engine',
    category: 'engines',
    status: 'completed',
    description: '12 دليل PDF مفصل لكل دور ووحدة جاهزة للتوليد والقراءة والتنزيل',
    children: [
      { id: 'b-34-1', code: '34.1', title: 'مكتبة الأدلة الـ 12 المتكاملة', description: 'دليل المالك، العميل، التاجر، الوكيل، الإدارة، الأمان، والـ API', status: 'completed' }
    ]
  },
  {
    id: 'b-35',
    num: 35,
    title: 'محرك التحميل وحزم الـ APK',
    titleEn: 'Download & Release Engine',
    category: 'apps',
    status: 'completed',
    description: 'بناء وتوليد حزم التثبيت للأجهزة الذكية (Android APK & iOS) والمستندات',
    children: [
      { id: 'b-35-1', code: '35.1', title: 'توليد ملفات APK ونسخ النظام المباشرة', description: 'تنزيل حزمة التطبيق الميدانية الجاهزة للعمل الفوري على الأجهزة', status: 'completed' }
    ]
  },
  {
    id: 'b-36',
    num: 36,
    title: 'محرك الفحص والإصلاح الذكي (Diagnostics)',
    titleEn: 'Diagnostic & Auto-Fix Engine',
    category: 'engines',
    status: 'completed',
    description: 'فحص التوازن المالي، كشف الثغرات الأمنية، واقتراح وتطبيق الإصلاح الفوري',
    children: [
      { id: 'b-36-1', code: '36.1', title: 'الفاحص الشامل بنقرة واحدة (One-Click Health Check)', description: 'فحص 24 نقطة حرجة في الأمان والسيولة وقواعد البيانات فورياً', status: 'completed' },
      { id: 'b-36-2', code: '36.2', title: 'الإصلاح التلقائي للنقص والخلل (Auto-Repair)', description: 'معالجة فروقات العمليات وتصحيح القيود المعلقة فورياً', status: 'completed' }
    ]
  },
  {
    id: 'b-37',
    num: 37,
    title: 'نظام الحماية والتقارير والموافقات',
    titleEn: 'Protection, Approvals & Workflow',
    category: 'security',
    status: 'completed',
    description: 'إدارة طلبات الاشتراك، الحجز المالي، التوقيف، وسير الموافقات متعددة المستويات',
    children: [
      { id: 'b-37-1', code: '37.1', title: 'محرك الحجز المالي المؤقت (Escrow Holds)', description: 'حجز المبالغ للمشتريات والتجارة حتى اعتماد الاستلام', status: 'completed' }
    ]
  },
  {
    id: 'b-38',
    num: 38,
    title: 'نظام الربط الخارجي الشامل',
    titleEn: 'Unified Linking Gateway',
    category: 'services',
    status: 'completed',
    description: 'ربط البنوك (IBAN/SWIFT)، الصرافات، أنظمة الرواتب ومزودي الخدمات',
    children: [
      { id: 'b-38-1', code: '38.1', title: 'منصة الربط المصرفي الموحد', description: 'إرسال واستقبال الأموال بين نصر والت والحسابات البنكية المحلية', status: 'completed' }
    ]
  },
  {
    id: 'b-39',
    num: 39,
    title: 'نظام إدارة الملفات والوثائق',
    titleEn: 'Enterprise File & Attachment System',
    category: 'services',
    status: 'completed',
    description: 'تخزين وثائق الهويات KYC، إيصالات السداد، الكشوفات، وتشفيرها AES-256',
    children: [
      { id: 'b-39-1', code: '39.1', title: 'مستودع الوثائق المشفر', description: 'أرشفة إلكترونية فورية لكافة المرفقات مع عزل الصلاحيات', status: 'completed' }
    ]
  },
  {
    id: 'b-40',
    num: 40,
    title: 'نظام الرواتب والكشوف الجماعية (Payroll)',
    titleEn: 'Corporate Payroll Engine',
    category: 'services',
    status: 'completed',
    description: 'صرف المرتبات لآلاف الموظفين بنقرة واحدة وتوليد قسائم الرواتب الفورية',
    children: [
      { id: 'b-40-1', code: '40.1', title: 'محرك المعالجة المجمعة للرواتب', description: 'توزيع فوري إلى محافظ الموظفين مع إشعار بالرسائل وإيصال معتمد', status: 'completed' }
    ]
  },
  {
    id: 'b-41',
    num: 41,
    title: 'نظام الخدمات التطويرية المتجددة',
    titleEn: 'Evolving Developer System',
    category: 'engines',
    status: 'completed',
    description: 'الترقيات اللحظية لتطبيق العميل والمشترك دون الحاجة لإعادة التثبيت (OTA Updates)',
    children: [
      { id: 'b-41-1', code: '41.1', title: 'التحديث الهوائي Over-The-Air (OTA)', description: 'دفع التحديثات والميزات الجديدة للمستخدمين مباشرة داخل التطبيق', status: 'completed' }
    ]
  },
  {
    id: 'b-42',
    num: 42,
    title: 'لوحة "شكل النظام" التفاعلية (Visualizer)',
    titleEn: 'Interactive System Visualizer',
    category: 'core',
    status: 'completed',
    description: 'عرض الشجرة التفاعلية كاملة بـ 42 فرعاً، العروض الـ 5، والتحديث اللحظي',
    children: [
      { id: 'b-42-1', code: '42.1', title: 'العروض الـ 5 المتكاملة', description: '1. شجري | 2. برمجي | 3. بنيوي | 4. بياناتي ERD | 5. تدفقات العمليات', status: 'completed' },
      { id: 'b-42-2', code: '42.2', title: 'التفاعل والتصدير اللحظي', description: 'البحث، الفلترة حسب الحالة، وتصدير هيكل النظام بصيغ JSON و Markdown', status: 'completed' }
    ]
  }
];
