// src/data/centralData.ts
import { CustomerRecord, ApprovalItem, PayrollBatch, BankIntegration } from '../types/central';

export const initialCentralCustomers: CustomerRecord[] = [
  {
    id: 'cust-001',
    name: 'أحمد علي السعيد',
    phone: '777123456',
    email: 'ahmed.saeed@example.com',
    nationalId: '01010048192',
    tier: 'Tier 3 (VIP)',
    status: 'active',
    balanceYER: 2450000,
    balanceUSD: 1250,
    balanceSAR: 4800,
    joinedDate: '2024-03-12',
    kycDocType: 'بطاقة شخصية ذكية'
  },
  {
    id: 'cust-002',
    name: 'فاطمة محمد باوزير',
    phone: '733987654',
    email: 'fatima.bawazeer@example.com',
    nationalId: '02040059281',
    tier: 'Tier 2',
    status: 'active',
    balanceYER: 850000,
    balanceUSD: 340,
    balanceSAR: 1200,
    joinedDate: '2024-05-18',
    kycDocType: 'جواز سفر إلكتروني'
  },
  {
    id: 'cust-003',
    name: 'مكتب الإبداع للتجارة العامة',
    phone: '711554433',
    email: 'contact@ibdaa-trade.ye',
    nationalId: '04080091823',
    tier: 'Tier 3 (VIP)',
    status: 'active',
    balanceYER: 18900000,
    balanceUSD: 9400,
    balanceSAR: 18500,
    joinedDate: '2023-11-04',
    kycDocType: 'سجل تجاري موثق'
  },
  {
    id: 'cust-004',
    name: 'عبد الله صالح المفلحي',
    phone: '772991188',
    email: 'a.muflahi@example.com',
    nationalId: '01020083719',
    tier: 'Tier 1',
    status: 'pending_kyc',
    balanceYER: 120000,
    balanceUSD: 0,
    balanceSAR: 250,
    joinedDate: '2025-01-10',
    kycDocType: 'بطاقة شخصية قديمة'
  },
  {
    id: 'cust-005',
    name: 'طارق عبد الله الحميري',
    phone: '770443322',
    email: 'tareq.humaidi@example.com',
    nationalId: '03090018274',
    tier: 'Tier 2',
    status: 'frozen',
    balanceYER: 4200000,
    balanceUSD: 800,
    balanceSAR: 0,
    joinedDate: '2024-08-22',
    kycDocType: 'بطاقة شخصية ذكية'
  },
  {
    id: 'cust-006',
    name: 'مروة ياسين العدني',
    phone: '739887766',
    email: 'marwa.adani@example.com',
    nationalId: '02070034981',
    tier: 'Tier 2',
    status: 'active',
    balanceYER: 1450000,
    balanceUSD: 620,
    balanceSAR: 1800,
    joinedDate: '2024-09-01',
    kycDocType: 'جواز سفر'
  }
];

export const initialApprovals: ApprovalItem[] = [
  {
    id: 'appr-01',
    type: 'large_transfer',
    requesterName: 'مكتب الإبداع للتجارة',
    requesterPhone: '711554433',
    amount: '15,000,000 YER',
    details: 'حوالة مصرفية جماعية لحساب بنك التضامن',
    time: 'منذ 15 دقيقة',
    riskLevel: 'medium',
    status: 'pending'
  },
  {
    id: 'appr-02',
    type: 'kyc_upgrade',
    requesterName: 'عبد الله صالح المفلحي',
    requesterPhone: '772991188',
    amount: '-',
    details: 'طلب ترقية من Tier 1 إلى Tier 2 مع إرفاق البطاقة الذكية',
    time: 'منذ 35 دقيقة',
    riskLevel: 'low',
    status: 'pending'
  },
  {
    id: 'appr-03',
    type: 'limit_override',
    requesterName: 'شركة النجم للصرافة والتحويلات',
    requesterPhone: '771009988',
    amount: '50,000 USD',
    details: 'رفع سقف التغذية اليومية للوكالة لفرع حدة',
    time: 'منذ ساعتين',
    riskLevel: 'high',
    status: 'pending'
  },
  {
    id: 'appr-04',
    type: 'subscription_request',
    requesterName: 'مؤسسة البركة للخدمات اللوجستية',
    requesterPhone: '775223344',
    amount: '18,750,000 YER',
    details: 'طلب اشتراك جديد في باقة المشترك المؤسسي (إدارة رواتب + عائلة + ربط بنكي)',
    time: 'منذ 5 دقائق',
    riskLevel: 'medium',
    status: 'pending'
  },
  {
    id: 'appr-05',
    type: 'client_registration',
    requesterName: 'سامي حمود المقرمي',
    requesterPhone: '771889922',
    amount: '-',
    details: 'تسجيل حساب عميل مستقل جديد من التطبيق الميداني (طلب فتح محفظة واعتماد هوية)',
    time: 'الآن',
    riskLevel: 'low',
    status: 'pending'
  }
];

export const initialPayrollBatches: PayrollBatch[] = [
  {
    id: 'PAY-2025-09-A',
    companyName: 'مستشفى الأمل التخصصي',
    totalEmployees: 142,
    totalAmount: 28400000,
    currency: 'YER',
    status: 'completed',
    executionDate: '2025-09-01'
  },
  {
    id: 'PAY-2025-09-B',
    companyName: 'مجموعة التكنولوجيا الذكية',
    totalEmployees: 48,
    totalAmount: 18500,
    currency: 'USD',
    status: 'completed',
    executionDate: '2025-09-02'
  },
  {
    id: 'PAY-2025-09-C',
    companyName: 'جامعة العلوم الحديثة',
    totalEmployees: 320,
    totalAmount: 64000000,
    currency: 'YER',
    status: 'scheduled',
    executionDate: '2025-09-25'
  }
];

export const initialBanks: BankIntegration[] = [
  {
    id: 'bank-1',
    bankName: 'بنك التضامن الإسلامي',
    code: 'TIIB',
    connectionType: 'API_DIRECT',
    status: 'online',
    dailyVolume: '$ 480,000',
    latencyMs: 42
  },
  {
    id: 'bank-2',
    bankName: 'بنك الكريمي للتمويل الأصغر الإسلامي',
    code: 'KREMI',
    connectionType: 'API_DIRECT',
    status: 'online',
    dailyVolume: '$ 720,000',
    latencyMs: 38
  },
  {
    id: 'bank-3',
    bankName: 'البنك الأهلي اليمني',
    code: 'NBY',
    connectionType: 'LOCAL_CLEARING',
    status: 'online',
    dailyVolume: '$ 190,000',
    latencyMs: 95
  },
  {
    id: 'bank-4',
    bankName: 'بنك اليمن والكويت',
    code: 'YKB',
    connectionType: 'API_DIRECT',
    status: 'online',
    dailyVolume: '$ 240,000',
    latencyMs: 51
  },
  {
    id: 'bank-5',
    bankName: 'شبكة سويفت الدولية SWIFT GPI',
    code: 'SWIFT-GPI',
    connectionType: 'SWIFT',
    status: 'online',
    dailyVolume: '$ 950,000',
    latencyMs: 120
  }
];
