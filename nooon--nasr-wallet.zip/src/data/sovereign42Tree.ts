// src/data/sovereign42Tree.ts
// نصر والت - النظام السيادي V2 - 42 فرع كامل 100%

export interface SovereignLevel {
  levelNumber: number;
  levelTitle: string;
  levelTitleEn: string;
  badge: string;
  color: string;
  branches: SovereignBranch[];
}

export interface SovereignBranch {
  number: number;
  title: string;
  titleEn: string;
  category: 'root' | 'app' | 'service' | 'infrastructure';
  icon: string;
  description: string;
  status: 'active' | 'sovereign_locked' | 'online_ready';
  details: string[];
  actionTarget?: string;
  badge?: string;
}

export const SOVEREIGN_42_BRANCHES: SovereignLevel[] = [
  {
    levelNumber: 0,
    levelTitle: "الجذر السيادي الأساسي (The Root)",
    levelTitleEn: "Level 0: The Sovereign Core",
    badge: "النواة السيادية",
    color: "from-blue-600 to-indigo-700",
    branches: [
      {
        number: 1,
        title: "Nasr Wallet Sovereign System (الجذر السيادي)",
        titleEn: "Nasr Wallet Sovereign System Root Engine",
        category: "root",
        icon: "Crown",
        description: "النواة السيادية المركزية العليا المشغلة لكافة الصلاحيات والمعايير والتحكم المطلق",
        status: "active",
        details: [
          "تحكم مطلق وسيادي لمالك النظام (Owner Full Authority)",
          "مفتاح الطوارئ والتعطيل المركزي (Master Sovereign Kill-Switch)",
          "تنسيق العمليات المتبادلة بين الـ 42 فرعاً لحظياً",
          "توافق بنسبة 100% مع أنظمة الصرافة والبنوك والعملات المتعددة (YER, SAR, USD)"
        ],
        actionTarget: "home",
        badge: "الجذر 1"
      }
    ]
  },
  {
    levelNumber: 1,
    levelTitle: "المستوى 1: 7 تطبيقات ميدانية وإدارية",
    levelTitleEn: "Level 1: The 7 Field & Administrative Applications",
    badge: "7 تطبيقات",
    color: "from-emerald-600 to-teal-700",
    branches: [
      {
        number: 2,
        title: "User App - تطبيق المستخدم",
        titleEn: "Client User Application (P2P / QR / Cards)",
        category: "app",
        icon: "Smartphone",
        description: "تطبيق العميل الشامل للتحويل الفوري P2P، مسح QR، سداد الفواتير والبطاقات الرقمية",
        status: "active",
        details: [
          "واجهة مستخدم فائقة الاستجابة متوافقة مع شاشات الجوال 4.7\" حتى 6.8\"",
          "تحويل فوري برقم الهاتف أو الحساب أو QR كود",
          "سداد فواتير الاتصالات (يمن موبايل، يو، سبأفون، عدن نت، الهاتف الثابت)",
          "بطاقات إلكترونية وتتبع لحظي لسجل الحركات"
        ],
        actionTarget: "apps:client",
        badge: "تطبيق 1"
      },
      {
        number: 3,
        title: "Subscriber App - تطبيق المشترك",
        titleEn: "Subscriber & Enterprise Client App",
        category: "app",
        icon: "Users",
        description: "تطبيق المشترك وأرباب الأعمال لإدارة أفراد العائلة، كشوف الرواتب، والربط المصرفي",
        status: "active",
        details: [
          "إدارة موازنة المنزل ومصروفات الأفراد والتابعين",
          "كشوفات حساب تفصيلية مع التصدير لـ PDF وإكسل",
          "طلب وتغذية محافظ الشركاء والرواتب المصغرة",
          "ربط الحسابات البنكية المعتمدة"
        ],
        actionTarget: "apps:subscriber",
        badge: "تطبيق 2"
      },
      {
        number: 4,
        title: "Family Mini-App - تطبيق العائلة المصغر ⭐",
        titleEn: "Family Group Mini-App & Allowance Guardian",
        category: "app",
        icon: "HeartHandshake",
        description: "تطبيق فرعي مخصص للأبناء والتابعين بربط QR فوري، حدود يومية، وإشراف أبوي كامل",
        status: "active",
        details: [
          "ربط فوري بالمحفظة الأبوية عبر مسح رمز QR العائلي",
          "حدود صرف يومية وأسبوعية ذكية تمنع التجاوز",
          "طلب مصروف فوري (Request Allowance) مع إشعار الولي للموافقة",
          "تقارير مشتريات واضحة تضمن الأمان المالي للأبناء"
        ],
        actionTarget: "apps:family_mini",
        badge: "تطبيق 3 ⭐"
      },
      {
        number: 5,
        title: "Agent App - تطبيق الوكيل (Float + عمولة)",
        titleEn: "Exchange & Cash-in / Cash-out Agent App",
        category: "app",
        icon: "Briefcase",
        description: "تطبيق الوكيل والصراف الميداني لعمليات الإيداع والسحب النقدي والعمولة الفورية",
        status: "active",
        details: [
          "إيداع نقدي فوري لحسابات العملاء (Cash-In)",
          "صرف واستلام حوافظ السحب عبر OTP والرمز السري (Cash-Out)",
          "إدارة رصيد السيولة العائم (Float Balance Management)",
          "حساب فوري وتوريد لحظي لعمولات الوكيل في محفظة مخصصة"
        ],
        actionTarget: "agents",
        badge: "تطبيق 4"
      },
      {
        number: 6,
        title: "Merchant App - تطبيق التاجر (QR + POS + تسوية)",
        titleEn: "Merchant POS & Instant QR Payment Terminal",
        category: "app",
        icon: "Store",
        description: "نقطة بيع سريعة (POS)، كاشير تجاري، توليد QR ديناميكي وتسويات T+1 التلقائية",
        status: "active",
        details: [
          "واجهة كاشير لمسية للمبيعات الفورية وإدخال المبالغ بنقرة واحدة",
          "رمز QR ديناميكي بالمبلغ والعملة لسرعة الدفع من جوال المشتري",
          "فواتير رقمية وإرسال الإيصالات الفورية عبر واتساب",
          "تسوية حسابات المبيعات وإرسالها للحساب البنكي يومياً T+1"
        ],
        actionTarget: "merchants",
        badge: "تطبيق 5"
      },
      {
        number: 7,
        title: "Admin App - لوحة المشرف",
        titleEn: "Operations & Compliance Admin Dashboard",
        category: "app",
        icon: "ShieldAlert",
        description: "لوحة العمليات الإدارية، التحقق من هويات KYC، تتبع العمليات المشبوهة AML والنزاعات",
        status: "active",
        details: [
          "مراجعة واعتماد طلبات التوثيق والهويات الشخصية KYC 1, 2, 3",
          "إدارة حدود المعاملات وسقوف العمليات والتحويلات",
          "إدارة وحل نزاعات العمليات وتذاكر الدعم الفني",
          "مراقبة تقارير التدقيق وسجلات النشاط اليومية"
        ],
        actionTarget: "approvals",
        badge: "تطبيق 6"
      },
      {
        number: 8,
        title: "Owner God Mode - لوحة المالك وضع الإله 👑",
        titleEn: "Sovereign Supreme Master Control Panel",
        category: "app",
        icon: "Crown",
        description: "لوحة التحكم السيادية الشاملة للمالك للتحكم في المعايير والأمان وخزنة الأسرار ومحرك الذكاء",
        status: "active",
        details: [
          "التحكم السيادي المطلق بنظام القفل والتشغيل لكافة الفروع",
          "إدارة وتدوير مفاتيح الخزنة السرية (Secrets Vault HSM & Shamir)",
          "تعديل رسوم المنظومة والنسب والعملات بضغطة زر واحدة",
          "إصدار الأوامر المباشرة لمحرك التطوير الذاتي للنظام"
        ],
        actionTarget: "dashboard_control",
        badge: "تطبيق 7 👑"
      }
    ]
  },
  {
    levelNumber: 2,
    levelTitle: "المستوى 2: 22 خدمة مصغرة - النواة التشغيلية",
    levelTitleEn: "Level 2: The 2 Core Microservices (Engine)",
    badge: "22 خدمة نواة",
    color: "from-amber-600 to-orange-700",
    branches: [
      {
        number: 9,
        title: "Wallet Service - المحفظة (Balance + Lock)",
        titleEn: "Multi-Currency Balance Engine & Concurrency Lock",
        category: "service",
        icon: "Wallet",
        description: "إدارة المحافظ متعددة العملات (USD, YER, SAR) مع القفل المتزامن لمنع الصرف المزدوج",
        status: "active",
        details: ["عزل الأرصدة", "قفل تشاؤمي/تفاؤلي متقدم", "دعم 3 عملات رئيسية"],
        actionTarget: "wallets"
      },
      {
        number: 10,
        title: "Ledger Service - القيد المزدوج Double-Entry (ما تضيع فلوس)",
        titleEn: "Double-Entry Financial Ledger (Zero-Discrepancy)",
        category: "service",
        icon: "Scale",
        description: "دفتر الأستاذ العام المالي الصارم: كل عملية تتكون من قيد مدين ودائن متطابق 100%",
        status: "active",
        details: ["لا تعديل مباشر للأرصدة إطلاقاً", "مطابقة محاسبية صفرية الخطأ", "سجل مالي غير قابل للحذف"],
        actionTarget: "settlements"
      },
      {
        number: 11,
        title: "Transaction Service - التحويلات + قفل Locking",
        titleEn: "High-Throughput P2P & Multi-Hop Transfer Engine",
        category: "service",
        icon: "ArrowLeftRight",
        description: "معالجة التحويلات السريعة بين المستخدمين والوكلاء مع التحقق من الرصيد والحدود",
        status: "active",
        details: ["تنفيذ في أقل من 120ms", "معرف فريد للعملية Idempotency Key", "تأكيد فوري بإشعار حي"],
        actionTarget: "transfers"
      },
      {
        number: 12,
        title: "Fees Service - الرسوم 1%",
        titleEn: "Dynamic Tariff & Fee Calculation Matrix",
        category: "service",
        icon: "Coins",
        description: "محرك حساب الرسوم المقتطعة آلياً بنسبة 1% أو شرائح ثابتة وتوزيعها بدقة",
        status: "active",
        details: ["حساب آلي فوري للعمولة", "إعفاءات ذكية للحسابات المميزة", "سجل إيرادات المنظومة"],
        actionTarget: "dashboard_control"
      },
      {
        number: 13,
        title: "Family Group Service - مجموعات عائلية",
        titleEn: "Family Hierarchy & Parent-Child Relationship Manager",
        category: "service",
        icon: "Users",
        description: "إنشاء وإدارة المجموعات العائلية وربط حسابات الأبناء بحساب الوالد أو المشترك",
        status: "active",
        details: ["شجرة العائلة المالية", "صلاحيات متعددة المستويات", "ربط عبر مسح QR فوري"],
        actionTarget: "customers"
      },
      {
        number: 14,
        title: "Members Service - أعضاء + Sub-Wallets بحدود",
        titleEn: "Sub-Wallet Provisions & Limit Enforcement",
        category: "service",
        icon: "FolderGit2",
        description: "تخصيص المحافظ الفرعية وسقوف المصروف اليومية والأسبوعية للتابعين",
        status: "active",
        details: ["سقف صرف أقصى", "منع فئات مشتريات محظورة", "تجميد مؤقت للحساب الفرعي"],
        actionTarget: "customers"
      },
      {
        number: 15,
        title: "Allowance Service - طلبات مصروف",
        titleEn: "Pocket Money Request & Instant Parent Approval",
        category: "service",
        icon: "HandCoins",
        description: "محرك استقبال طلبات المصروف من الأبناء والموافقة الفورية بضغطة زر مع الإشعار",
        status: "active",
        details: ["إشعار فوري للوالد", "تحويل تلقائي عند الموافقة", "تسجيل سبب الطلب والملاحظة"],
        actionTarget: "approvals"
      },
      {
        number: 16,
        title: "Agent Service - إيداع/سحب نقدي",
        titleEn: "Cash-In / Cash-Out Agent Operations Engine",
        category: "service",
        icon: "Building",
        description: "محرك عمليات الوكلاء الميدانيين لإيداع الكاش وسحب الأموال برمز التحقق OTP",
        status: "active",
        details: ["التحقق الثنائي للعميل", "تحديث فوري لسيولة الصندوق", "إيصال تسليم رقمي معتمد"],
        actionTarget: "agents"
      },
      {
        number: 17,
        title: "Commission Service - توزيع العمولات",
        titleEn: "Instant Commission Routing & Splitter",
        category: "service",
        icon: "Percent",
        description: "توزيع نسب الأرباح فورياً بين المنظومة والوكيل والتاجر عند إتمام أي حركة",
        status: "active",
        details: ["اقتطاع وتوريد لحظي", "كشف حساب دوري للعمولات", "دعم الحوافز والمكافآت الميدانية"],
        actionTarget: "agents"
      },
      {
        number: 18,
        title: "Merchant Service - QR + فواتير",
        titleEn: "Merchant Direct Invoicing & Dynamic QR",
        category: "service",
        icon: "QrCode",
        description: "إصدار وإدارة فواتير المبيعات التجارية وتوليد رموز QR مشفرة للدفع السريع",
        status: "active",
        details: ["باركود QR قياسي EMVCo", "ربط مع أجهزة الكاشير", "إشعارات صوتية ومرئية للدفع"],
        actionTarget: "merchants"
      },
      {
        number: 19,
        title: "Payout Service - تسوية T+1 للتجار",
        titleEn: "Automated Daily Merchant Payout & Settlement",
        category: "service",
        icon: "Banknote",
        description: "محرك الجدولة التلقائية لتسوية حسابات المبيعات وإرسالها لحسابات التجار المصرفية",
        status: "active",
        details: ["تصفية الحسابات في موعد T+1", "خصم عمولات التاجر المعتمدة", "سجلات ترحيل بنكية"],
        actionTarget: "settlements"
      },
      {
        number: 20,
        title: "BankLink Service - ربط IBAN/SWIFT + PSD2",
        titleEn: "Open Banking PSD2, IBAN & SWIFT Gateway",
        category: "service",
        icon: "Building2",
        description: "بوابة الربط البنكي الموحد والمقاصة الإلكترونية مع البنوك المحلية وشبكة سويفت",
        status: "active",
        details: ["تحقق تلقائي من صحة IBAN", "برقيات MT103 و SWIFT GPI", "واجهات Open Banking PSD2"],
        actionTarget: "banks"
      },
      {
        number: 21,
        title: "Payroll Service - رفع CSV رواتب جماعية",
        titleEn: "Bulk CSV Payroll Disbursement Engine",
        category: "service",
        icon: "FileSpreadsheet",
        description: "معالجة ملفات الرواتب الضخمة CSV/Excel وتوزيعها على آلاف الموظفين بضغطة زر",
        status: "active",
        details: ["فحص تلقائي للأخطاء والحسابات", "صرف متزامن لآلاف الحسابات", "توليد قسيمة راتب Payslip"],
        actionTarget: "payroll"
      },
      {
        number: 22,
        title: "File Service - رفع ملفات S3 + صور KYC",
        titleEn: "Encrypted Document & KYC Image Storage (S3/MinIO)",
        category: "service",
        icon: "FileUp",
        description: "محرك تخزين الوثائق والمستندات وصور الهويات وتشفيرها التام قبل التخزين",
        status: "active",
        details: ["ضغط وتحسين جودة المستندات", "تشفير AES-256 للملفات الساكنة", "روابط مؤقتة Presigned URLs"],
        actionTarget: "events"
      },
      {
        number: 23,
        title: "Notification Service - Push + SMS + واتساب",
        titleEn: "Multi-Channel Omni-Notification (Push, SMS, WhatsApp)",
        category: "service",
        icon: "BellRing",
        description: "إرسال الإشعارات اللحظية للحركات المالية ورموز OTP وتنبيهات الأمان",
        status: "active",
        details: ["قوالب واتساب معتمدة", "رسائل SMS فورية عبر بوابات الاتصالات", "تنبيهات Push على الهواتف"],
        actionTarget: "notifications"
      },
      {
        number: 24,
        title: "KYC Service - 3 مستويات + OCR",
        titleEn: "Tiered Identity Verification (KYC 1-3) & OCR Engine",
        category: "service",
        icon: "ScanFace",
        description: "التحقق من الهويات الشخصية (جواز سفر، بطاقة شخصية) على 3 مستويات واستخراج البيانات OCR",
        status: "active",
        details: ["مستوى 1: رقم الهاتف (سقف أساسي)", "مستوى 2: البطاقة الشخصية وصورة السيلفي", "مستوى 3: السجل التجاري وإثبات العنوان"],
        actionTarget: "approvals"
      },
      {
        number: 25,
        title: "Vault Service - تشفير AES-256-GCM + Shamir",
        titleEn: "Zero-Knowledge Secrets Vault & Shamir Secret Sharing",
        category: "service",
        icon: "KeyRound",
        description: "خزنة الأسرار المشفرة والمفاتيح السرية وتجزئة مفاتيح الوصول السيادية",
        status: "active",
        details: ["تشفير من طرف العميل Zero-Knowledge", "تقسيم المفاتيح السيادية Shamir M-of-N", "سجل كشف محاولات التلاعب"],
        actionTarget: "vault"
      },
      {
        number: 26,
        title: "Risk Engine - كشف احتيال + تجميد",
        titleEn: "AI Real-Time Fraud Detection & Velocity Engine",
        category: "service",
        icon: "ShieldAlert",
        description: "التحليل السلوكي اللحظي للحركات المالية ورصد العمليات المتطرفة وتجميد الحساب آلياً",
        status: "active",
        details: ["فحص تكرار العمليات Velocity Check", "رصد الحسابات والـ IPs المشبوهة", "تجميد وقائي فوري للحركة"],
        actionTarget: "risk"
      },
      {
        number: 27,
        title: "Audit Service - سجل لا يتمسح أبداً",
        titleEn: "Immutable Cryptographic Audit Trail (WORM Log)",
        category: "service",
        icon: "FileCheck2",
        description: "سجل تدقيق سيادي غير قابل للتعديل أو الحذف WORM موثق بهاش تشفيري لكل حركة",
        status: "active",
        details: ["سلسلة كتلية محلية Hash-Chained", "امتثال تام للمراجعة المصرفية والقانونية", "حفظ مستمر لمدة 7 سنوات"],
        actionTarget: "audit"
      },
      {
        number: 28,
        title: "Config Service - تحكم عن بعد Feature Flags",
        titleEn: "Dynamic Remote Configuration & Feature Toggles",
        category: "service",
        icon: "SlidersHorizontal",
        description: "التحكم عن بُعد في ميزات التطبيق، الحدود المالية وسعر الصرف دون الحاجة لتحديث الكود",
        status: "active",
        details: ["تفعيل وتعطيل الميزات لحظياً", "تحديث أسعار صرف العملات فوراً", "استهداف محدد حسب دور المستخدم"],
        actionTarget: "dashboard_control"
      },
      {
        number: 29,
        title: "QueueWorker Service - مهام ثقيلة BullMQ",
        titleEn: "Distributed Asynchronous Job Queue (BullMQ)",
        category: "service",
        icon: "Workflow",
        description: "معالجة المهام الخلفية الثقيلة، إرسال آلاف الرسائل، وتوليد ملفات PDF بشكل غير متزامن",
        status: "active",
        details: ["جدولة العمليات الضخمة", "إعادة المحاولة الذكية عند الفشل", "عزل تام يمنع بطء واجهة المستخدم"],
        actionTarget: "events"
      },
      {
        number: 30,
        title: "API Gateway - حارس البوابة + Rate Limit",
        titleEn: "API Gateway & Edge DDoS / Rate Limiting Shield",
        category: "service",
        icon: "DoorClosed",
        description: "البوابة المركزية الموحدة لاستقبال الطلبات، التحقق من التوقيع ومنع هجمات DDoS والفيضان",
        status: "active",
        details: ["تقييد معدل الطلبات Rate Limiting", "التحقق من التوقيع الرقمي HMAC", "توجيه ذكي للخدمات الخلفية"],
        actionTarget: "system_health"
      }
    ]
  },
  {
    levelNumber: 3,
    levelTitle: "المستوى 3: البنية الأساسية - 12 فرعاً سيادياً",
    levelTitleEn: "Level 3: The 12 Sovereign Infrastructure Branches",
    badge: "12 فرع بنية",
    color: "from-cyan-600 to-blue-800",
    branches: [
      {
        number: 31,
        title: "Database - PostgreSQL 50 جدول",
        titleEn: "PostgreSQL Database (50+ Sovereign Tables)",
        category: "infrastructure",
        icon: "Database",
        description: "قاعدة بيانات علائقية فائقة الأداء تشمل 50 جدولاً متكاملاً (users, wallets, ledger, families...)",
        status: "active",
        details: ["50 جدول مهيكلة بالكامل", "دعم القيود الصارمة والمفاتيح الأجنبية", "مؤشرات B-Tree لتسريع البحث اللحظي"],
        actionTarget: "secret_db"
      },
      {
        number: 32,
        title: "Cache Layer - Redis (أرصدة + جلسات + Pub/Sub)",
        titleEn: "In-Memory Redis Cache & Real-Time Pub/Sub",
        category: "infrastructure",
        icon: "Zap",
        description: "طبقة الذاكرة السريعة للتخزين المؤقت للأرصدة، الجلسات النشطة، والتوزيع اللحظي للبيانات",
        status: "active",
        details: ["استجابة للأرصدة في أقل من 2ms", "إدارة جلسات المستخدمين المشفرة", "قنوات بث لحظية Pub/Sub للعمليات"],
        actionTarget: "system_health"
      },
      {
        number: 33,
        title: "Storage Layer - MinIO (ملفات + صور بطاقات + PDF)",
        titleEn: "MinIO S3-Compatible Sovereign Object Storage",
        category: "infrastructure",
        icon: "HardDrive",
        description: "مستودع الكائنات السحابي السيادي لحفظ كافة الوثائق والملفات وإيصالات الدفع",
        status: "active",
        details: ["تخزين محلي معزول داخل الخوادم السيادية", "دعم كامل لبروتوكول S3 القياسي", "حماية البيانات بتشفير على مستوى البلوك"],
        actionTarget: "events"
      },
      {
        number: 34,
        title: "Search Layer - Elasticsearch (بحث معاملات + Logs)",
        titleEn: "Elasticsearch Real-Time Search & Telemetry Logs",
        category: "infrastructure",
        icon: "Search",
        description: "محرك البحث الفوري في ملايين المعاملات وسجلات النشاط وتحليلات الأمان",
        status: "active",
        details: ["بحث بنصوص كاملة في أقل من 50ms", "تصفية وفلترة متقدمة متعددة الأبعاد", "مراقبة سجلات التشغيل Logs"],
        actionTarget: "transactions"
      },
      {
        number: 35,
        title: "Auth Layer - JWT + OAuth 2.0 + 2FA + Biometric",
        titleEn: "Unified Identity & Biometric Auth Layer",
        category: "infrastructure",
        icon: "Fingerprint",
        description: "طبقة التوثيق والمصادقة الموحدة بالبصمة الحيوية والرموز المشفرة والتحقق الثنائي",
        status: "active",
        details: ["دعم WebAuthn وبصمة الإصبع والوجه", "رموز JWT مشفرة وموقعة برقم سري", "جلسات متعددة الأجهزة مع إمكانية الإنهاء الفوري"],
        actionTarget: "dashboard_control"
      },
      {
        number: 36,
        title: "Encryption Layer - AES-256 + HSM + PCI-DSS",
        titleEn: "Military-Grade Cryptography & HSM Integration",
        category: "infrastructure",
        icon: "Lock",
        description: "طبقة التشفير المتقدمة للبيانات الثابتة والمتحركة مع الامتثال لمعايير PCI-DSS المصرفية",
        status: "active",
        details: ["تشفير AES-256-GCM متقدم", "تكامل مع وحدات الأمان للأجهزة (HSM)", "حماية حقول البيانات الحساسة Tokenization"],
        actionTarget: "vault"
      },
      {
        number: 37,
        title: "Infrastructure - Kubernetes + Docker + Auto Scaling",
        titleEn: "Cloud-Native Kubernetes & Elastic Auto-Scaling",
        category: "infrastructure",
        icon: "Server",
        description: "البنية التحتية للحاويات والتشغيل السحابي ذات التوسع التلقائي لتحمل ضغط آلاف العمليات",
        status: "active",
        details: ["عزل الحاويات Docker Containers", "إدارة أوركسترا Kubernetes Clusters", "توسع تلقائي حسب الحمل Auto-Scaling"],
        actionTarget: "system_health"
      },
      {
        number: 38,
        title: "Backup Engine - نسخ WAL كل 5 دقائق + CDC + استعادة بنقرة ⭐",
        titleEn: "Continuous Zero-Loss WAL Backup Engine & CDC",
        category: "infrastructure",
        icon: "ArchiveRestore",
        description: "محرك النسخ الاحتياطي المستمر كل 5 دقائق مع خاصية الاسترجاع الفوري بنقرة واحدة",
        status: "active",
        details: ["كتابة متزامنة Write-Ahead Logging (WAL)", "التقاط فوري لتغيير البيانات (CDC)", "استعادة كاملة للنظام في ثوانٍ بنقرة زر"],
        actionTarget: "data_management"
      },
      {
        number: 39,
        title: "Self-Dev Engine - Analyzer + Coder + Tester (النظام يطور نفسه) ⭐",
        titleEn: "AI Autonomous Self-Development Engine",
        category: "infrastructure",
        icon: "Sparkles",
        description: "محرك الذكاء الاصطناعي الذاتي الذي يحلل الكود، يقترح التحسينات، ويجري الاختبارات تلقائياً",
        status: "active",
        details: ["تحليل مستمر لجودة الكود واكتشاف الثغرات", "اقتراح وتوليد حلول برمجية فورية", "إجراء اختبارات تلقائية مستمرة"],
        actionTarget: "dev_center"
      },
      {
        number: 40,
        title: "APK Builder - توليد APK تلقائياً CI/CD ⭐",
        titleEn: "Automated Android APK / Mobile App Generator",
        category: "infrastructure",
        icon: "SmartphoneNfc",
        description: "محرك البناء الآلي لحزم تطبيقات الأندرويد APK و AAB الجاهزة للتثبيت الميداني الفوري",
        status: "active",
        details: ["توليد ملفات Capacitor و AndroidManifest تلقائياً", "سكربت بناء فوري متكامل", "إمكانية تنزيل الحزمة الجاهزة بنقرة واحدة"],
        actionTarget: "download_modal"
      },
      {
        number: 41,
        title: "PDF Generator - توليد وثائق + فواتير + تقارير ⭐",
        titleEn: "Instant PDF Reports & Invoice Printing Engine",
        category: "infrastructure",
        icon: "FileDown",
        description: "محرك التوليد الآلي للوثائق والتقارير المالية، إيصالات الدفع، وتوثيق الكود البرمجي كاملاً",
        status: "active",
        details: ["توليد إيصالات وفواتير بصيغة PDF", "طباعة الكشوفات المالية التفصيلية", "تصدير المعمارية والكود البرمجي كاملاً"],
        actionTarget: "download_modal"
      },
      {
        number: 42,
        title: "System Visualizer - عارض الشجرة 42 فرع تفاعلي",
        titleEn: "Interactive 42-Branch System Architecture Visualizer",
        category: "infrastructure",
        icon: "GitFork",
        description: "المستكشف التفاعلي الكامل لشجرة الفروع الـ 42 مع كافة التفاصيل والبحث والتصدير المباشر",
        status: "active",
        details: ["تصفح وتفحص الـ 42 فرعاً بكامل تفاصيلها", "روابط تشغيل وتوجيه مباشر لكافة الخدمات", "خيارات تصدير الهيكل والبيانات"],
        actionTarget: "visualizer_tab"
      }
    ]
  }
];
