// src/data/mockTransactions.ts
import { Transaction } from '../types/transaction';
import { pseudoSha256 } from '../lib/crypto';

const transactionTitles = [
  { type: 'P2P', title: 'تحويل إلى أحمد ناصر', cat: 'transfer', amt: [15000, 50000, 100000], curr: 'YER' },
  { type: 'BILL', title: 'سداد باقة يمن موبايل مزايا', cat: 'telecom', amt: [4500, 6000, 9000], curr: 'YER' },
  { type: 'BILL', title: 'سداد فاتورة الإنترنت المنزلي ADSL', cat: 'telecom', amt: [6500, 12000], curr: 'YER' },
  { type: 'BILL', title: 'سداد كهرباء الطاقة الشمسية / تجاري', cat: 'electricity', amt: [18500, 32000], curr: 'YER' },
  { type: 'BILL', title: 'سداد فاتورة المؤسسة العامة للمياه', cat: 'water', amt: [3500, 5200], curr: 'YER' },
  { type: 'QR_PAY', title: 'مشتريات هايبر المستهلك', cat: 'retail', amt: [24000, 58000, 92000], curr: 'YER' },
  { type: 'QR_PAY', title: 'فاتورة صيدلية الشفاء', cat: 'retail', amt: [8500, 14200], curr: 'YER' },
  { type: 'QR_PAY', title: 'وجبة مطاعم الشيباني الملكي', cat: 'food', amt: [12500, 22000], curr: 'YER' },
  { type: 'CASH_IN', title: 'إيداع نقدي عبر وكيل النصر', cat: 'transfer', amt: [200000, 500000, 1000000], curr: 'YER' },
  { type: 'CASH_OUT', title: 'سحب نقدي عبر كود السحب OTP', cat: 'transfer', amt: [50000, 150000], curr: 'YER' },
  { type: 'PAYROLL', title: 'إيداع راتب موظفي شهر مارس 2025', cat: 'salary', amt: [350000, 480000], curr: 'YER' },
  { type: 'FAMILY_ALLOWANCE', title: 'صرف مصروف شهري - عمر', cat: 'transfer', amt: [25000, 35000], curr: 'YER' },
  { type: 'P2P', title: 'حوالة عبر الريال السعودي', cat: 'transfer', amt: [500, 1500, 3000], curr: 'SAR' },
  { type: 'P2P', title: 'تحويل عملة دولار أمريكي', cat: 'transfer', amt: [100, 250, 500], curr: 'USD' },
  { type: 'MERCHANT_PAY', title: 'دفع متجر إلكتروني بطاقة ماستركارد', cat: 'retail', amt: [45, 120, 280], curr: 'USD' },
] as const;

export const mockTransactions: Transaction[] = Array.from({ length: 200 }, (_, index) => {
  const template = transactionTitles[index % transactionTitles.length];
  const amtOptions = template.amt;
  const amount = amtOptions[index % amtOptions.length];
  const refNo = `TXN-${948200 - index}`;
  
  // Create dates spread over the last 180 days
  const date = new Date(2025, 2, 20, 12, 0, 0);
  date.setDate(date.getDate() - Math.floor(index * 0.9));
  date.setMinutes(date.getMinutes() - (index * 17) % 60);

  const hash = pseudoSha256(`${refNo}-${amount}-${date.toISOString()}`);
  
  return {
    id: `tx-${index + 1}`,
    refNo,
    type: template.type as any,
    title: template.title,
    amount,
    currency: template.curr as any,
    fee: template.type === 'P2P' ? 0 : template.type === 'CASH_OUT' ? Math.round(amount * 0.005) : 0,
    senderId: index % 4 === 0 ? 'u-5' : 'u-1',
    senderName: index % 4 === 0 ? 'صرافة النصر (وكيل)' : 'محمد ناصر اليماني',
    senderPhone: '+967777100249',
    receiverId: index % 3 === 0 ? 'u-6' : 'u-3',
    receiverName: template.title.includes('إلى') ? template.title.replace('تحويل إلى ', '') : 'الطرف المستلم',
    receiverPhone: `+96777${Math.floor(1000000 + (index * 29481) % 8999999)}`,
    timestamp: date.toISOString(),
    status: index === 33 ? 'pending' : index === 71 ? 'reversed' : 'completed',
    category: template.cat as any,
    hash: `sha256:${hash}`,
    notes: `قيد محاسبي مزدوج - نصر والت V2 مرجع #${refNo}`
  };
});
