// src/types/central.ts
export type CentralSidebarItem =
  | 'home'
  | 'sovereign_42'
  | 'events'
  | 'dashboard_control'
  | 'vault'
  | 'secret_db'
  | 'customers'
  | 'wallets'
  | 'transactions'
  | 'transfers'
  | 'services'
  | 'payroll'
  | 'merchants'
  | 'agents'
  | 'banks'
  | 'cards'
  | 'risk'
  | 'approvals'
  | 'settlements'
  | 'reports'
  | 'audit'
  | 'notifications'
  | 'data_management'
  | 'dev_center'
  | 'system_health';

export interface SecretCodeItem {
  id: string;
  name: string;
  nameAr: string;
  category: 'master_key' | 'break_glass' | 'api_gateway' | 'totp_seed' | 'pos_activation';
  codeValue: string;
  algorithm: string;
  environment: 'production' | 'staging' | 'hsm_root';
  lastRotated: string;
  expiryDate: string;
  status: 'active' | 'rotated' | 'locked';
  description: string;
}

export interface SecretDbTableRecord {
  id: string;
  recordIdentifier: string;
  cipherText: string;
  algorithm: string;
  keyFingerprint: string;
  decryptedPreview: string;
  createdAt: string;
  lastAccessed: string;
}

export interface SecretDbTable {
  id: string;
  tableName: string;
  nameAr: string;
  category: 'keys' | 'credentials' | 'hsm' | 'sessions' | 'disaster_recovery';
  recordCount: number;
  encryptionStandard: string;
  hsmEnclave: string;
  description: string;
  columns: { name: string; type: string; isEncrypted: boolean; description: string }[];
  records: SecretDbTableRecord[];
}

export interface SecretAuditLog {
  id: string;
  timestamp: string;
  actor: string;
  action: 'view' | 'decrypt' | 'rotate' | 'generate' | 'export';
  targetSecret: string;
  ipAddress: string;
  result: 'authorized' | 'denied';
}

export interface CustomerRecord {
  id: string;
  name: string;
  phone: string;
  email: string;
  nationalId: string;
  tier: 'Tier 1' | 'Tier 2' | 'Tier 3 (VIP)';
  status: 'active' | 'frozen' | 'pending_kyc';
  balanceYER: number;
  balanceUSD: number;
  balanceSAR: number;
  joinedDate: string;
  kycDocType: string;
}

export interface ApprovalItem {
  id: string;
  type: 'large_transfer' | 'kyc_upgrade' | 'merchant_payout' | 'limit_override' | 'subscription_request' | 'client_registration';
  requesterName: string;
  requesterPhone: string;
  amount?: string;
  details: string;
  time: string;
  riskLevel: 'low' | 'medium' | 'high';
  status: 'pending' | 'approved' | 'rejected';
}

export interface PayrollBatch {
  id: string;
  companyName: string;
  totalEmployees: number;
  totalAmount: number;
  currency: 'YER' | 'SAR' | 'USD';
  status: 'completed' | 'processing' | 'scheduled';
  executionDate: string;
}

export interface BankIntegration {
  id: string;
  bankName: string;
  code: string;
  connectionType: 'API_DIRECT' | 'SWIFT' | 'LOCAL_CLEARING';
  status: 'online' | 'degraded' | 'offline';
  dailyVolume: string;
  latencyMs: number;
}
