// src/types/agent.ts
import { CurrencyCode } from './wallet';

export interface Agent {
  id: string;
  userId: string;
  agentCode: string;
  tradeName: string;
  ownerName: string;
  phone: string;
  city: string;
  region: string;
  address: string;
  floatBalanceYER: number;
  floatBalanceSAR: number;
  floatBalanceUSD: number;
  accumulatedCommissionYER: number;
  dailyCashInLimit: number;
  dailyCashOutLimit: number;
  status: 'active' | 'suspended' | 'low_balance';
  rating: number;
  latitude?: number;
  longitude?: number;
}

export interface CashDeskOperation {
  id: string;
  agentId: string;
  type: 'cash_in' | 'cash_out';
  clientPhone: string;
  clientName?: string;
  amount: number;
  currency: CurrencyCode;
  commission: number;
  otpCode?: string;
  timestamp: string;
  status: 'completed' | 'pending_otp' | 'rejected';
}
