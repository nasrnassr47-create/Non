// src/types/wallet.ts
export type CurrencyCode = 'YER' | 'SAR' | 'USD' | 'EUR';

export interface SystemControlSettings {
  exchangeRates: {
    USD_YER: number;
    SAR_YER: number;
    EUR_USD: number;
  };
  limits: {
    dailyLimitYER: number;
    monthlyLimitYER: number;
    singleTxLimitYER: number;
  };
  fees: {
    isFeeFree: boolean;
    p2pFeePercent: number;
    billFeeFixed: number;
  };
  security: {
    masterPin: string;
    bypassPin: boolean;
    biometricAuth: boolean;
    emergencyLockdown: boolean;
    amlSensitivity: 'low' | 'medium' | 'strict';
  };
  appearance: {
    themePreset: 'emerald' | 'gold' | 'cyber' | 'light';
    viewMode: 'mobile' | 'desktop';
    hideBalances: boolean;
    density: 'comfortable' | 'compact';
  };
  network: {
    simulatedSpeed: '5g' | '3g' | 'offline';
    latencyMs: number;
  };
}

export interface Wallet {
  id: string;
  userId: string;
  currency: CurrencyCode;
  balance: number;
  holdBalance: number;
  availableBalance: number;
  symbol: string;
  accountNumber: string;
  iban?: string;
  isDefault: boolean;
  status: 'active' | 'frozen' | 'closed';
  updatedAt: string;
}

export interface BankCard {
  id: string;
  userId: string;
  walletId: string;
  cardNumber: string;
  cardHolder: string;
  cardholderName?: string;
  expiryMonth: string;
  expiryYear: string;
  expiryDate?: string;
  cvv: string;
  cardType: 'virtual_mastercard' | 'virtual_visa' | 'mada' | 'unionpay' | 'virtual' | 'physical';
  brand?: string;
  isFrozen: boolean;
  dailyLimit: number;
  monthlyLimit: number;
  currency: CurrencyCode;
  colorTheme?: 'emerald' | 'gold' | 'dark' | 'platinum';
}

export interface LinkedBankAccount {
  id: string;
  userId: string;
  bankName: string;
  bankCode: string;
  iban: string;
  swift: string;
  accountNumber: string;
  isVerified: boolean;
  status: 'active' | 'pending';
}
