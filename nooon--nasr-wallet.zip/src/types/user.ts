// src/types/user.ts
export type UserRole = 
  | 'client' 
  | 'subscriber' 
  | 'family' 
  | 'family_mini' 
  | 'agent' 
  | 'merchant' 
  | 'admin' 
  | 'sovereign' 
  | 'owner' 
  | 'support';

export type KYCStatus = 'none' | 'level_1' | 'level_2' | 'level_3' | 'rejected' | 'pending';
export type UserStatus = 'active' | 'suspended' | 'blocked' | 'pending_verification';

export interface User {
  id: string;
  name: string;
  nameEn: string;
  phone: string;
  email: string;
  nationalId: string;
  role: UserRole;
  status: UserStatus;
  kycLevel: KYCStatus;
  avatarUrl?: string;
  createdAt: string;
  lastLogin?: string;
  preferredCurrency: 'YER' | 'SAR' | 'USD';
  pinCode?: string;
  isBiometricEnabled?: boolean;
  twoFactorEnabled?: boolean;
  address?: {
    city: string;
    governorate: string;
    street: string;
  };
}
