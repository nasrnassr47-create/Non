// src/types/subscription.ts
export type SubscriptionTier = 'basic' | 'silver' | 'gold' | 'platinum';

export interface SubscriptionPlan {
  id: string;
  tier: SubscriptionTier;
  nameAr: string;
  nameEn: string;
  monthlyFeeYER: number;
  monthlyFeeSAR: number;
  maxFamilyMembers: number;
  maxBankLinks: number;
  hasPayrollSupport: boolean;
  hasFreeP2P: boolean;
  prioritySupport: boolean;
  badgeColor: string;
  features: string[];
}

export interface SubscriberAccount {
  id: string;
  userId: string;
  planId: string;
  tier: SubscriptionTier;
  startDate: string;
  renewDate: string;
  autoRenew: boolean;
  familyMembersCount: number;
  linkedBanksCount: number;
  companyName?: string;
  status: 'active' | 'grace_period' | 'cancelled';
}

export interface PayrollBatch {
  id: string;
  subscriberId: string;
  batchTitle: string;
  month: string;
  totalAmount: number;
  currency: 'YER' | 'SAR' | 'USD';
  employeesCount: number;
  status: 'draft' | 'processing' | 'disbursed' | 'failed';
  disbursedAt?: string;
}
