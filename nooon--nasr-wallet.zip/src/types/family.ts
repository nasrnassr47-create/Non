// src/types/family.ts
import { CurrencyCode } from './wallet';

export type FamilyRelationship = 'father' | 'mother' | 'son' | 'daughter' | 'spouse' | 'dependent';

export interface FamilyMember {
  id: string;
  familyId: string;
  userId: string;
  name: string;
  phone: string;
  relationship: FamilyRelationship;
  avatarUrl?: string;
  allowanceDaily: number;
  allowanceMonthly: number;
  spentThisMonth: number;
  balance: number;
  currency: CurrencyCode;
  canRequestMoney: boolean;
  canSendOutside: boolean;
  status: 'active' | 'paused' | 'invited';
  linkedWalletId: string;
}

export interface FamilyAllowanceRequest {
  id: string;
  familyId: string;
  memberId: string;
  memberName: string;
  amount: number;
  currency: CurrencyCode;
  reason: string;
  requestedAt: string;
  status: 'pending' | 'approved' | 'rejected';
  resolvedAt?: string;
  notes?: string;
}

export interface FamilyGroup {
  id: string;
  ownerId: string;
  familyName: string;
  sharedBudget: number;
  currency: CurrencyCode;
  membersCount: number;
  createdAt: string;
}
