// src/types/transaction.ts
import { CurrencyCode } from './wallet';

export type TransactionType = 
  | 'P2P' 
  | 'BILL' 
  | 'CASH_IN' 
  | 'CASH_OUT' 
  | 'QR_PAY' 
  | 'PAYROLL' 
  | 'MERCHANT_PAY' 
  | 'FAMILY_ALLOWANCE' 
  | 'REFUND' 
  | 'FEE';

export type TransactionStatus = 'completed' | 'pending' | 'failed' | 'reversed';

export interface Transaction {
  id: string;
  refNo: string;
  type: TransactionType;
  title: string;
  amount: number;
  currency: CurrencyCode;
  fee: number;
  senderId: string;
  senderName: string;
  senderPhone?: string;
  receiverId: string;
  receiverName: string;
  receiverPhone?: string;
  timestamp: string;
  status: TransactionStatus;
  notes?: string;
  hash: string;
  category?: 'telecom' | 'electricity' | 'water' | 'retail' | 'food' | 'entertainment' | 'transfer' | 'salary';
  metadata?: Record<string, unknown>;
}
