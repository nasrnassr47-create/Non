// src/types/merchant.ts
import { CurrencyCode } from './wallet';

export interface Merchant {
  id: string;
  userId: string;
  merchantCode: string;
  businessName: string;
  businessNameEn: string;
  category: 'restaurant' | 'supermarket' | 'pharmacy' | 'electronics' | 'fashion' | 'services' | 'food';
  ownerName: string;
  phone: string;
  commercialRegister: string;
  taxNumber: string;
  qrPayload: string;
  settlementAccount: string;
  balanceYER: number;
  balanceSAR: number;
  balanceUSD: number;
  totalSalesCount: number;
  status: 'active' | 'under_review' | 'paused';
}

export interface MerchantInvoice {
  id: string;
  invoiceNo: string;
  merchantId: string;
  customerPhone?: string;
  items: Array<{ name: string; qty: number; unitPrice: number; total: number }>;
  totalAmount: number;
  currency: CurrencyCode;
  createdAt: string;
  status: 'paid' | 'unpaid' | 'cancelled';
  qrString: string;
}

export interface MerchantStaff {
  id: string;
  merchantId: string;
  name: string;
  phone: string;
  role: 'cashier' | 'branch_manager' | 'accountant';
  permissions: string[];
  status: 'active' | 'inactive';
}
