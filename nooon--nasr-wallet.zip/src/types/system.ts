// src/types/system.ts
export interface SystemSecret {
  id: string;
  name: string;
  category: 'database' | 'hsm_master' | 'api_gateway' | 'encryption_key' | 'jwt_secret' | 'third_party';
  encryptedValue: string;
  maskedDisplay: string;
  lastRotated: string;
  accessPolicy: 'owner_only' | 'root_quorum';
  accessLogsCount: number;
}

export interface SelfDevRequest {
  id: string;
  userPrompt: string;
  category: 'feature' | 'fix' | 'ui_improvement' | 'security_patch';
  status: 'pending_approval' | 'processing' | 'implemented' | 'rejected';
  systemResponse: string;
  suggestedFiles: string[];
  createdAt: string;
  approvedByOwner: boolean;
}

export interface SystemAuditEntry {
  id: string;
  timestamp: string;
  actor: string;
  actorRole: string;
  action: string;
  ipAddress: string;
  resource: string;
  status: 'SUCCESS' | 'DENIED' | 'FLAGGED';
  hashChain: string;
}

export interface SystemDiagnosticIssue {
  id: string;
  code: string;
  title: string;
  description: string;
  severity: 'critical' | 'warning' | 'info';
  category: 'ledger' | 'security' | 'database' | 'latency' | 'backup';
  affectedService: string;
  suggestedFix: string;
  autoFixable: boolean;
  status: 'open' | 'resolved';
}

export interface SystemBackupRecord {
  id: string;
  timestamp: string;
  sizeBytes: number;
  sizeFormatted: string;
  recordsCount: number;
  type: 'manual' | 'scheduled_wal' | 'pre_update';
  checksum: string;
  notes: string;
}
