// src/context/LanguageContext.tsx
import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { storage } from '../lib/storage';

export type LanguageCode = 'ar' | 'en';
export type Direction = 'rtl' | 'ltr';

interface LanguageContextType {
  language: LanguageCode;
  direction: Direction;
  toggleLanguage: () => void;
  setLanguage: (lang: LanguageCode) => void;
  t: (key: string, fallback?: string) => string;
}

const translations: Record<string, { ar: string; en: string }> = {
  appName: { ar: 'نصر والت', en: 'Nasr Wallet' },
  slogan: { ar: 'محفظتك أنت..', en: 'Your Own Wallet..' },
  subSlogan: { ar: 'المنظومة المالية السيادية المتطورة', en: 'The Advanced Sovereign Financial System' },
  sendMoney: { ar: 'إرسال أموال', en: 'Send Money' },
  receiveMoney: { ar: 'استلام أموال', en: 'Receive Money' },
  scanQr: { ar: 'مسح QR', en: 'Scan QR' },
  billPayment: { ar: 'سداد فواتير', en: 'Pay Bills' },
  myCards: { ar: 'بطاقاتي', en: 'My Cards' },
  transactions: { ar: 'الحركات المالية', en: 'Transactions' },
  availableBalance: { ar: 'الرصيد المتاح', en: 'Available Balance' },
  doubleEntry: { ar: 'القيد المزدوج', en: 'Double Entry' },
  roleSwitcher: { ar: 'مبدّل الأدوار', en: 'Role Switcher' },
  logout: { ar: 'تسجيل الخروج', en: 'Logout' },
  login: { ar: 'تسجيل الدخول', en: 'Login' },
  register: { ar: 'إنشاء حساب جديد', en: 'Register' },
  settings: { ar: 'الإعدادات', en: 'Settings' },
  profile: { ar: 'الملف الشخصي', en: 'Profile' },
  security: { ar: 'الأمان والخصوصية', en: 'Security' },
  support: { ar: 'الدعم والمساعدة', en: 'Support' },
  notifications: { ar: 'الإشعارات', en: 'Notifications' },
  autoSaved: { ar: 'تم الحفظ الفوري', en: 'Auto-Saved' },
  godMode: { ar: 'الوضع السيادي الشامل', en: 'Sovereign God Mode' },
  backupNow: { ar: 'نسخ احتياطي الآن', en: 'Backup Now' },
  diagnostics: { ar: 'الفحص الذاتي', en: 'Diagnostics' },
  systemViewer: { ar: 'شكل النظام (42 فرعاً)', en: 'System Viewer (42 Branches)' },
};

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const LanguageProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [language, setLanguageState] = useState<LanguageCode>(() => {
    return storage.get<LanguageCode>('app_language', 'ar');
  });

  const direction: Direction = language === 'ar' ? 'rtl' : 'ltr';

  useEffect(() => {
    storage.set('app_language', language);
    document.documentElement.lang = language;
    document.documentElement.dir = direction;
  }, [language, direction]);

  const toggleLanguage = () => {
    setLanguageState(prev => (prev === 'ar' ? 'en' : 'ar'));
  };

  const setLanguage = (lang: LanguageCode) => {
    setLanguageState(lang);
  };

  const t = (key: string, fallback?: string): string => {
    if (translations[key]) {
      return translations[key][language];
    }
    return fallback || key;
  };

  return (
    <LanguageContext.Provider value={{ language, direction, toggleLanguage, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = (): LanguageContextType => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};
