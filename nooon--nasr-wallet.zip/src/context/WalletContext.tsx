// src/context/WalletContext.tsx
import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { Wallet, BankCard, CurrencyCode, SystemControlSettings } from '../types/wallet';
import { Transaction } from '../types/transaction';
import { mockWallets, mockBankCards } from '../data/mockWallets';
import { mockTransactions } from '../data/mockTransactions';
import { storage } from '../lib/storage';
import { pseudoSha256, generateRefNo } from '../lib/crypto';
import { useAuth } from './AuthContext';

export interface ToastNotification {
  id: string;
  message: string;
  type: 'success' | 'error' | 'info' | 'warning';
}

export const defaultSystemControl: SystemControlSettings = {
  exchangeRates: {
    USD_YER: 1650,
    SAR_YER: 435,
    EUR_USD: 1.08,
  },
  limits: {
    dailyLimitYER: 5000000,
    monthlyLimitYER: 30000000,
    singleTxLimitYER: 2000000,
  },
  fees: {
    isFeeFree: true,
    p2pFeePercent: 0,
    billFeeFixed: 0,
  },
  security: {
    masterPin: '1234',
    bypassPin: false,
    biometricAuth: true,
    emergencyLockdown: false,
    amlSensitivity: 'medium',
  },
  appearance: {
    themePreset: 'emerald',
    viewMode: 'desktop',
    hideBalances: false,
    density: 'comfortable',
  },
  network: {
    simulatedSpeed: '5g',
    latencyMs: 80,
  },
};

interface WalletContextType {
  wallets: Wallet[];
  activeCurrency: CurrencyCode;
  setActiveCurrency: (currency: CurrencyCode) => void;
  activeWallet: Wallet;
  cards: BankCard[];
  transactions: Transaction[];
  toasts: ToastNotification[];
  lastAutoSavedAction: string;
  systemControl: SystemControlSettings;
  updateWalletBalance: (currency: CurrencyCode, newBalance: number) => void;
  addQuickFunds: (currency: CurrencyCode, amount: number) => void;
  updateExchangeRate: (pair: 'USD_YER' | 'SAR_YER' | 'EUR_USD', rate: number) => void;
  updateLimits: (limits: Partial<SystemControlSettings['limits']>) => void;
  updateFees: (fees: Partial<SystemControlSettings['fees']>) => void;
  updateSecurity: (security: Partial<SystemControlSettings['security']>) => void;
  updateAppearance: (appearance: Partial<SystemControlSettings['appearance']>) => void;
  updateNetwork: (network: Partial<SystemControlSettings['network']>) => void;
  resetAllToFactoryDefaults: () => void;
  generateDemoTransactions: () => void;
  sendMoney: (params: { receiverPhone: string; amount: number; notes?: string; currency?: CurrencyCode }) => Promise<{ success: boolean; message: string }>;
  payBill: (params: { serviceName: string; amount: number; billNumber?: string; currency?: CurrencyCode }) => Promise<{ success: boolean; message: string }>;
  cashIn: (params: { clientPhone: string; amount: number; currency?: CurrencyCode }) => Promise<{ success: boolean; message: string }>;
  cashOut: (params: { clientPhone: string; amount: number; otpCode: string; currency?: CurrencyCode }) => Promise<{ success: boolean; message: string }>;
  addCard: (card: Omit<BankCard, 'id' | 'userId'>) => void;
  toggleFreezeCard: (cardId: string) => void;
  showToast: (message: string, type?: 'success' | 'error' | 'info' | 'warning') => void;
  dismissToast: (id: string) => void;
  createManualBackup: () => void;
  restoreFromData: (data: Record<string, unknown>) => boolean;
}

const WalletContext = createContext<WalletContextType | undefined>(undefined);

export const WalletProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const { currentUser } = useAuth();

  const [wallets, setWallets] = useState<Wallet[]>(() => {
    return storage.get<Wallet[]>('wallets_data', mockWallets);
  });

  const [cards, setCards] = useState<BankCard[]>(() => {
    return storage.get<BankCard[]>('cards_data', mockBankCards);
  });

  const [transactions, setTransactions] = useState<Transaction[]>(() => {
    return storage.get<Transaction[]>('transactions_data', mockTransactions);
  });

  const [activeCurrency, setActiveCurrency] = useState<CurrencyCode>('YER');
  const [toasts, setToasts] = useState<ToastNotification[]>([]);
  const [lastAutoSavedAction, setLastAutoSavedAction] = useState<string>('المنظومة جاهزة ومتصلة بالحفظ اللحظي');
  const [systemControl, setSystemControl] = useState<SystemControlSettings>(() => {
    return storage.get<SystemControlSettings>('system_control_settings', defaultSystemControl);
  });

  useEffect(() => {
    storage.set('system_control_settings', systemControl);
  }, [systemControl]);

  useEffect(() => {
    storage.set('wallets_data', wallets);
  }, [wallets]);

  useEffect(() => {
    storage.set('cards_data', cards);
  }, [cards]);

  useEffect(() => {
    storage.set('transactions_data', transactions);
  }, [transactions]);

  // Current active wallet for current user & currency
  const userWallets = wallets.filter(w => w.userId === currentUser.id);
  const activeWallet = userWallets.find(w => w.currency === activeCurrency) || 
    userWallets[0] || 
    wallets.find(w => w.currency === activeCurrency) || 
    wallets[0];

  const showToast = (message: string, type: 'success' | 'error' | 'info' | 'warning' = 'success') => {
    const id = `toast-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
    setToasts(prev => [...prev, { id, message, type }]);
    setLastAutoSavedAction(message);
    setTimeout(() => {
      dismissToast(id);
    }, 4500);
  };

  const dismissToast = (id: string) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  };

  const sendMoney = async (params: {
    receiverPhone: string;
    amount: number;
    notes?: string;
    currency?: CurrencyCode;
  }): Promise<{ success: boolean; message: string }> => {
    const curr = params.currency || activeCurrency;
    const currentW = userWallets.find(w => w.currency === curr) || activeWallet;

    if (params.amount <= 0) {
      showToast('يرجى إدخال مبلغ صحيح', 'error');
      return { success: false, message: 'مبلغ غير صالح' };
    }

    if (params.amount > currentW.balance) {
      showToast('عفواً، الرصيد المتاح غير كافٍ لإتمام العملية', 'error');
      return { success: false, message: 'الرصيد غير كافٍ' };
    }

    // Deduct balance from current wallet
    setWallets(prev => prev.map(w => {
      if (w.id === currentW.id) {
        const newBal = w.balance - params.amount;
        return { ...w, balance: newBal, availableBalance: newBal - w.holdBalance, updatedAt: new Date().toISOString() };
      }
      return w;
    }));

    const refNo = generateRefNo('TXN');
    const newTx: Transaction = {
      id: `tx-${Date.now()}`,
      refNo,
      type: 'P2P',
      title: `تحويل إلى ${params.receiverPhone}`,
      amount: params.amount,
      currency: curr,
      fee: 0,
      senderId: currentUser.id,
      senderName: currentUser.name,
      senderPhone: currentUser.phone,
      receiverId: 'u-target',
      receiverName: params.receiverPhone,
      receiverPhone: params.receiverPhone,
      timestamp: new Date().toISOString(),
      status: 'completed',
      notes: params.notes || 'تحويل مالي فوري عبر نصر والت',
      category: 'transfer',
      hash: `sha256:${pseudoSha256(`${refNo}-${params.amount}-${Date.now()}`)}`
    };

    setTransactions(prev => [newTx, ...prev]);
    showToast(`تم تحويل ${params.amount.toLocaleString()} ${currentW.symbol} بنجاح إلى ${params.receiverPhone}`, 'success');
    return { success: true, message: 'تم التحويل بنجاح' };
  };

  const payBill = async (params: {
    serviceName: string;
    amount: number;
    billNumber?: string;
    currency?: CurrencyCode;
  }): Promise<{ success: boolean; message: string }> => {
    const curr = params.currency || 'YER';
    const currentW = userWallets.find(w => w.currency === curr) || activeWallet;

    if (params.amount > currentW.balance) {
      showToast('الرصيد غير كافٍ لسداد الفاتورة', 'error');
      return { success: false, message: 'الرصيد غير كافٍ' };
    }

    setWallets(prev => prev.map(w => {
      if (w.id === currentW.id) {
        const newBal = w.balance - params.amount;
        return { ...w, balance: newBal, availableBalance: newBal - w.holdBalance, updatedAt: new Date().toISOString() };
      }
      return w;
    }));

    const refNo = generateRefNo('BILL');
    const newTx: Transaction = {
      id: `tx-${Date.now()}`,
      refNo,
      type: 'BILL',
      title: `سداد ${params.serviceName}`,
      amount: params.amount,
      currency: curr,
      fee: 0,
      senderId: currentUser.id,
      senderName: currentUser.name,
      senderPhone: currentUser.phone,
      receiverId: 'telecom-sys',
      receiverName: params.serviceName,
      timestamp: new Date().toISOString(),
      status: 'completed',
      category: 'telecom',
      notes: params.billNumber ? `رقم المشترك/العداد: ${params.billNumber}` : undefined,
      hash: `sha256:${pseudoSha256(`${refNo}-${params.amount}-${Date.now()}`)}`
    };

    setTransactions(prev => [newTx, ...prev]);
    showToast(`تم سداد ${params.serviceName} بمبلغ ${params.amount.toLocaleString()} ${currentW.symbol}`, 'success');
    return { success: true, message: 'تم سداد الفاتورة' };
  };

  const cashIn = async (params: {
    clientPhone: string;
    amount: number;
    currency?: CurrencyCode;
  }): Promise<{ success: boolean; message: string }> => {
    const curr = params.currency || 'YER';
    // Add to balance
    setWallets(prev => prev.map(w => {
      if (w.currency === curr && w.userId === currentUser.id) {
        const newBal = w.balance + params.amount;
        return { ...w, balance: newBal, availableBalance: newBal - w.holdBalance, updatedAt: new Date().toISOString() };
      }
      return w;
    }));

    const refNo = generateRefNo('CSH-IN');
    const newTx: Transaction = {
      id: `tx-${Date.now()}`,
      refNo,
      type: 'CASH_IN',
      title: `إيداع نقدي للعميل ${params.clientPhone}`,
      amount: params.amount,
      currency: curr,
      fee: 0,
      senderId: currentUser.id,
      senderName: currentUser.name,
      receiverId: 'client-dest',
      receiverName: params.clientPhone,
      receiverPhone: params.clientPhone,
      timestamp: new Date().toISOString(),
      status: 'completed',
      category: 'transfer',
      hash: `sha256:${pseudoSha256(`${refNo}-${params.amount}`)}`
    };

    setTransactions(prev => [newTx, ...prev]);
    showToast(`تم إيداع ${params.amount.toLocaleString()} ${curr} للعميل ${params.clientPhone}`, 'success');
    return { success: true, message: 'تم الإيداع بنجاح' };
  };

  const cashOut = async (params: {
    clientPhone: string;
    amount: number;
    otpCode: string;
    currency?: CurrencyCode;
  }): Promise<{ success: boolean; message: string }> => {
    const curr = params.currency || 'YER';
    if (!params.otpCode || params.otpCode.length < 4) {
      showToast('رمز التحقق OTP غير صحيح', 'error');
      return { success: false, message: 'OTP غير صالح' };
    }

    const refNo = generateRefNo('CSH-OUT');
    const newTx: Transaction = {
      id: `tx-${Date.now()}`,
      refNo,
      type: 'CASH_OUT',
      title: `سحب نقدي للعميل ${params.clientPhone}`,
      amount: params.amount,
      currency: curr,
      fee: Math.round(params.amount * 0.005),
      senderId: 'client-src',
      senderName: params.clientPhone,
      senderPhone: params.clientPhone,
      receiverId: currentUser.id,
      receiverName: currentUser.name,
      timestamp: new Date().toISOString(),
      status: 'completed',
      category: 'transfer',
      hash: `sha256:${pseudoSha256(`${refNo}-${params.amount}`)}`
    };

    setTransactions(prev => [newTx, ...prev]);
    showToast(`تم تسليم نقدية ${params.amount.toLocaleString()} ${curr} بنجاح`, 'success');
    return { success: true, message: 'تم السحب النقدي بنجاح' };
  };

  const addCard = (cardData: Omit<BankCard, 'id' | 'userId'>) => {
    const newCard: BankCard = {
      ...cardData,
      id: `card-${Date.now()}`,
      userId: currentUser.id,
    };
    setCards(prev => [newCard, ...prev]);
    showToast('تم إصدار وإضافة البطاقة الرقمية بنجاح', 'success');
  };

  const toggleFreezeCard = (cardId: string) => {
    setCards(prev => prev.map(c => {
      if (c.id === cardId) {
        const nextState = !c.isFrozen;
        showToast(nextState ? 'تم تجميد البطاقة مؤقتاً' : 'تم تنشيط وإلغاء تجميد البطاقة', 'info');
        return { ...c, isFrozen: nextState };
      }
      return c;
    }));
  };

  const createManualBackup = () => {
    const backup = storage.createBackup();
    showToast(`تم حفظ نسخة احتياطية محلية (${Math.round(backup.size / 1024)} KB)`, 'success');
  };

  const restoreFromData = (data: Record<string, unknown>): boolean => {
    const ok = storage.restoreBackup(data);
    if (ok) {
      if (data.wallets_data) setWallets(data.wallets_data as Wallet[]);
      if (data.cards_data) setCards(data.cards_data as BankCard[]);
      if (data.transactions_data) setTransactions(data.transactions_data as Transaction[]);
      showToast('تمت استعادة البيانات بنجاح من النسخة الاحتياطية', 'success');
    }
    return ok;
  };

  const updateWalletBalance = (currency: CurrencyCode, newBalance: number) => {
    setWallets(prev => prev.map(w => {
      if (w.currency === currency && w.userId === currentUser.id) {
        return {
          ...w,
          balance: Math.max(0, newBalance),
          availableBalance: Math.max(0, newBalance - w.holdBalance),
          updatedAt: new Date().toISOString()
        };
      }
      return w;
    }));
    showToast(`تم ضبط رصيد ${currency} إلى ${newBalance.toLocaleString()} فورياً`, 'success');
  };

  const addQuickFunds = (currency: CurrencyCode, amount: number) => {
    setWallets(prev => prev.map(w => {
      if (w.currency === currency && w.userId === currentUser.id) {
        const next = w.balance + amount;
        return {
          ...w,
          balance: next,
          availableBalance: next - w.holdBalance,
          updatedAt: new Date().toISOString()
        };
      }
      return w;
    }));
    showToast(`تم شحن المحفظة فورياً بمبلغ +${amount.toLocaleString()} ${currency}`, 'success');
  };

  const updateExchangeRate = (pair: 'USD_YER' | 'SAR_YER' | 'EUR_USD', rate: number) => {
    setSystemControl(prev => ({
      ...prev,
      exchangeRates: {
        ...prev.exchangeRates,
        [pair]: rate
      }
    }));
    showToast(`تم تحديث سعر صرف ${pair} إلى ${rate.toLocaleString()}`, 'info');
  };

  const updateLimits = (limits: Partial<SystemControlSettings['limits']>) => {
    setSystemControl(prev => ({
      ...prev,
      limits: { ...prev.limits, ...limits }
    }));
    showToast('تم تحديث سقوف وحدود العمليات المالية', 'success');
  };

  const updateFees = (fees: Partial<SystemControlSettings['fees']>) => {
    setSystemControl(prev => ({
      ...prev,
      fees: { ...prev.fees, ...fees }
    }));
    showToast('تم حفظ إعدادات العمولات والرسوم', 'info');
  };

  const updateSecurity = (sec: Partial<SystemControlSettings['security']>) => {
    setSystemControl(prev => ({
      ...prev,
      security: { ...prev.security, ...sec }
    }));
    if (sec.emergencyLockdown !== undefined) {
      showToast(sec.emergencyLockdown ? '⚠️ تم تفعيل قفل الطوارئ السيادي الشامل' : '✅ تم إلغاء قفل الطوارئ بنجاح', sec.emergencyLockdown ? 'error' : 'success');
    } else {
      showToast('تم تحديث السياسات الأمنية للسيادة المالية', 'success');
    }
  };

  const updateAppearance = (appr: Partial<SystemControlSettings['appearance']>) => {
    setSystemControl(prev => ({
      ...prev,
      appearance: { ...prev.appearance, ...appr }
    }));
    showToast('تم تحديث إعدادات المظهر وواجهة العرض', 'info');
  };

  const updateNetwork = (net: Partial<SystemControlSettings['network']>) => {
    setSystemControl(prev => ({
      ...prev,
      network: { ...prev.network, ...net }
    }));
    showToast(`تم تغيير محاكي الشبكة إلى: ${net.simulatedSpeed || 'متصل'}`, 'info');
  };

  const resetAllToFactoryDefaults = () => {
    setWallets(mockWallets);
    setCards(mockBankCards);
    setTransactions(mockTransactions);
    setSystemControl(defaultSystemControl);
    storage.set('wallets_data', mockWallets);
    storage.set('cards_data', mockBankCards);
    storage.set('transactions_data', mockTransactions);
    storage.set('system_control_settings', defaultSystemControl);
    showToast('تمت إعادة ضبط المنظومة والمحفظة إلى الحالة المصنعية الافتراضية', 'warning');
  };

  const generateDemoTransactions = () => {
    const demoItems: Transaction[] = [
      {
        id: `tx-demo-${Date.now()}-1`,
        refNo: generateRefNo('PAY-DEMO'),
        type: 'MERCHANT_PAY',
        title: 'شراء من سوبرماركت الهدى',
        amount: 32500,
        currency: 'YER',
        fee: 0,
        senderId: currentUser.id,
        senderName: currentUser.name,
        receiverId: 'm-1',
        receiverName: 'سوبرماركت الهدى',
        timestamp: new Date(Date.now() - 1000 * 60 * 15).toISOString(),
        status: 'completed',
        category: 'retail',
        hash: `sha256:${pseudoSha256(`demo-1-${Date.now()}`)}`
      },
      {
        id: `tx-demo-${Date.now()}-2`,
        refNo: generateRefNo('TRF-DEMO'),
        type: 'P2P',
        title: 'حوالة واردة من مكتب الصرافة',
        amount: 250,
        currency: 'SAR',
        fee: 0,
        senderId: 'ag-1',
        senderName: 'شركة النجم للصرافة',
        receiverId: currentUser.id,
        receiverName: currentUser.name,
        timestamp: new Date(Date.now() - 1000 * 60 * 120).toISOString(),
        status: 'completed',
        category: 'transfer',
        hash: `sha256:${pseudoSha256(`demo-2-${Date.now()}`)}`
      },
      {
        id: `tx-demo-${Date.now()}-3`,
        refNo: generateRefNo('BIL-DEMO'),
        type: 'BILL',
        title: 'سداد باقة يمن موبايل 4G ماكس',
        amount: 7000,
        currency: 'YER',
        fee: 0,
        senderId: currentUser.id,
        senderName: currentUser.name,
        receiverId: 'srv-ym',
        receiverName: 'يمن موبايل',
        timestamp: new Date(Date.now() - 1000 * 60 * 360).toISOString(),
        status: 'completed',
        category: 'telecom',
        hash: `sha256:${pseudoSha256(`demo-3-${Date.now()}`)}`
      }
    ];

    setTransactions(prev => [...demoItems, ...prev]);
    showToast('تم توليد 3 عمليات مالية تجريبية فورياً', 'success');
  };

  return (
    <WalletContext.Provider
      value={{
        wallets,
        activeCurrency,
        setActiveCurrency,
        activeWallet,
        cards: cards.filter(c => c.userId === currentUser.id),
        transactions,
        toasts,
        lastAutoSavedAction,
        systemControl,
        updateWalletBalance,
        addQuickFunds,
        updateExchangeRate,
        updateLimits,
        updateFees,
        updateSecurity,
        updateAppearance,
        updateNetwork,
        resetAllToFactoryDefaults,
        generateDemoTransactions,
        sendMoney,
        payBill,
        cashIn,
        cashOut,
        addCard,
        toggleFreezeCard,
        showToast,
        dismissToast,
        createManualBackup,
        restoreFromData
      }}
    >
      {children}
    </WalletContext.Provider>
  );
};

export const useWallet = (): WalletContextType => {
  const context = useContext(WalletContext);
  if (!context) {
    throw new Error('useWallet must be used within a WalletProvider');
  }
  return context;
};
