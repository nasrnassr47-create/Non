// src/context/AuthContext.tsx
import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { User, UserRole, UserStatus, KYCStatus } from '../types/user';
import { mockUsers } from '../data/mockUsers';
import { storage } from '../lib/storage';
import { initialApprovals } from '../data/centralData';
import { ApprovalItem } from '../types/central';

interface AuthContextType {
  currentUser: User;
  isAuthenticated: boolean;
  activeRole: UserRole;
  allUsers: User[];
  login: (phone: string, pinOrPass: string) => Promise<{ success: boolean; message: string }>;
  register: (data: { name: string; phone: string; email: string; pin: string }) => Promise<{ success: boolean; message: string }>;
  logout: () => void;
  verifyOtp: (code: string) => boolean;
  setPin: (newPin: string) => void;
  switchRole: (role: UserRole) => void;
  switchUser: (userId: string) => void;
  updateKyc: (level: KYCStatus) => void;
  updateUserStatus: (userId: string, status: UserStatus) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [allUsers, setAllUsers] = useState<User[]>(() => {
    return storage.get<User[]>('users_list', mockUsers);
  });

  const [currentUserId, setCurrentUserId] = useState<string>(() => {
    return storage.get<string>('active_user_id', mockUsers[0].id);
  });

  const [activeRole, setActiveRole] = useState<UserRole>(() => {
    return storage.get<UserRole>('active_role', 'client');
  });

  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    return storage.get<boolean>('is_authenticated', true);
  });

  const currentUser = allUsers.find(u => u.id === currentUserId) || allUsers[0] || mockUsers[0];

  useEffect(() => {
    storage.set('users_list', allUsers);
  }, [allUsers]);

  useEffect(() => {
    storage.set('active_user_id', currentUserId);
  }, [currentUserId]);

  useEffect(() => {
    storage.set('active_role', activeRole);
  }, [activeRole]);

  useEffect(() => {
    storage.set('is_authenticated', isAuthenticated);
  }, [isAuthenticated]);

  const login = async (phone: string, _pinOrPass: string): Promise<{ success: boolean; message: string }> => {
    const cleaned = phone.replace(/\s+/g, '');
    const matched = allUsers.find(u => u.phone.includes(cleaned) || cleaned.includes(u.phone.replace(/\D/g, '')));
    
    if (matched) {
      setCurrentUserId(matched.id);
      setActiveRole(matched.role);
      setIsAuthenticated(true);
      storage.set('active_user_id', matched.id);
      storage.set('active_role', matched.role);
      storage.set('is_authenticated', true);
      return { success: true, message: `مرحباً بك مجدداً، ${matched.name}` };
    }

    // Default fallback: login as main user
    setCurrentUserId(mockUsers[0].id);
    setActiveRole(mockUsers[0].role);
    setIsAuthenticated(true);
    return { success: true, message: `تم الدخول بنجاح بحساب ${mockUsers[0].name}` };
  };

  const register = async (data: { name: string; phone: string; email: string; pin: string }): Promise<{ success: boolean; message: string }> => {
    const formattedPhone = data.phone.startsWith('+') ? data.phone : `+967${data.phone.replace(/^0+/, '')}`;
    const newUser: User = {
      id: `u-${Date.now()}`,
      name: data.name,
      nameEn: data.name,
      phone: formattedPhone,
      email: data.email || `${data.phone}@nasrwallet.ye`,
      nationalId: `0101${Math.floor(1000000 + Math.random() * 9000000)}`,
      role: 'client',
      status: 'pending_verification',
      kycLevel: 'pending',
      createdAt: new Date().toISOString(),
      preferredCurrency: 'YER',
      pinCode: data.pin || '1234',
      isBiometricEnabled: false,
      twoFactorEnabled: false,
      address: { city: 'صنعاء', governorate: 'أمانة العاصمة', street: 'شارع حدة' }
    };

    // Push approval request to Central System Approvals Queue
    const approvalReq: ApprovalItem = {
      id: `appr-reg-${Date.now()}`,
      type: 'client_registration',
      requesterName: data.name,
      requesterPhone: formattedPhone,
      amount: '-',
      details: `طلب تسجيل حساب محفظة عميل جديد مع التحقق من الهوية (KYC).`,
      time: 'الآن',
      riskLevel: 'low',
      status: 'pending'
    };

    const currentApprovals = storage.get<ApprovalItem[]>('central_approvals_list', initialApprovals);
    storage.set('central_approvals_list', [approvalReq, ...currentApprovals]);

    setAllUsers(prev => [newUser, ...prev]);
    setCurrentUserId(newUser.id);
    setActiveRole('client');
    setIsAuthenticated(true);
    return { 
      success: true, 
      message: `أهلاً بك يا ${newUser.name}! تم استلام طلب التسجيل ورفعه إلى النظام المركزي للاعتماد والموافقة الفورية.` 
    };
  };

  const logout = () => {
    setIsAuthenticated(false);
    storage.set('is_authenticated', false);
  };

  const verifyOtp = (code: string): boolean => {
    // Prototype: any 6-digit code or default 123456
    return code.length === 6 || code === '123456';
  };

  const setPin = (newPin: string) => {
    setAllUsers(prev => prev.map(u => u.id === currentUserId ? { ...u, pinCode: newPin } : u));
  };

  const switchRole = (role: UserRole) => {
    setActiveRole(role);
    // Find suitable user for this role if any
    const userWithRole = allUsers.find(u => u.role === role);
    if (userWithRole) {
      setCurrentUserId(userWithRole.id);
    }
  };

  const switchUser = (userId: string) => {
    const target = allUsers.find(u => u.id === userId);
    if (target) {
      setCurrentUserId(target.id);
      setActiveRole(target.role);
    }
  };

  const updateKyc = (level: KYCStatus) => {
    setAllUsers(prev => prev.map(u => u.id === currentUserId ? { ...u, kycLevel: level } : u));
  };

  const updateUserStatus = (userId: string, status: UserStatus) => {
    setAllUsers(prev => prev.map(u => u.id === userId ? { ...u, status } : u));
  };

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        isAuthenticated,
        activeRole,
        allUsers,
        login,
        register,
        logout,
        verifyOtp,
        setPin,
        switchRole,
        switchUser,
        updateKyc,
        updateUserStatus
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
