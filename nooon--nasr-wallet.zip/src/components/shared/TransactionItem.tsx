// src/components/shared/TransactionItem.tsx
import React from 'react';
import { 
  ArrowUpRight, 
  ArrowDownLeft, 
  Receipt, 
  QrCode, 
  Users, 
  Store, 
  Sparkles,
  ChevronLeft
} from 'lucide-react';
import { Transaction } from '../../types/transaction';
import { formatDate, formatRelativeTime } from '../../lib/format';
import { cn } from '../../lib/utils';

interface TransactionItemProps {
  transaction: Transaction;
  onClick?: () => void;
  compact?: boolean;
}

export const TransactionItem: React.FC<TransactionItemProps> = ({
  transaction,
  onClick,
  compact = false
}) => {
  const isIncoming = transaction.type === 'CASH_IN' || transaction.type === 'REFUND';

  const getTypeIcon = () => {
    switch (transaction.type) {
      case 'CASH_IN':
        return <ArrowDownLeft className="w-4 h-4 text-emerald-400" />;
      case 'BILL':
        return <Receipt className="w-4 h-4 text-amber-400" />;
      case 'QR_PAY':
        return <QrCode className="w-4 h-4 text-teal-400" />;
      case 'PAYROLL':
        return <Users className="w-4 h-4 text-blue-400" />;
      case 'MERCHANT_PAY':
        return <Store className="w-4 h-4 text-cyan-400" />;
      default:
        return <ArrowUpRight className="w-4 h-4 text-slate-300" />;
    }
  };

  const getTypeBadgeColor = () => {
    switch (transaction.type) {
      case 'CASH_IN':
        return 'bg-emerald-500/10 border-emerald-500/30';
      case 'BILL':
        return 'bg-amber-500/10 border-amber-500/30';
      case 'QR_PAY':
        return 'bg-teal-500/10 border-teal-500/30';
      default:
        return 'bg-slate-800 border-slate-700';
    }
  };

  return (
    <div
      onClick={onClick}
      className={cn(
        'p-3 rounded-2xl bg-slate-900/90 border border-slate-800/90 hover:border-slate-700 flex items-center justify-between transition-all select-none',
        onClick ? 'cursor-pointer hover:bg-slate-800/60' : ''
      )}
    >
      <div className="flex items-center gap-3">
        <div className={cn('p-2.5 rounded-xl border shrink-0', getTypeBadgeColor())}>
          {getTypeIcon()}
        </div>

        <div>
          <div className="text-xs sm:text-sm font-semibold text-slate-100 line-clamp-1">
            {transaction.title}
          </div>
          <div className="text-[10px] text-slate-400 flex items-center gap-1.5 mt-0.5 font-mono">
            <span>{formatRelativeTime(transaction.timestamp)}</span>
            <span>•</span>
            <span className="text-slate-500">{transaction.refNo}</span>
          </div>
        </div>
      </div>

      <div className="text-left flex items-center gap-2">
        <div>
          <div
            className={cn(
              'text-xs sm:text-sm font-bold font-mono',
              isIncoming ? 'text-emerald-400' : 'text-slate-100'
            )}
          >
            {isIncoming ? '+' : '-'}
            {transaction.amount.toLocaleString()} {transaction.currency}
          </div>
          <div className="text-[10px] text-emerald-500 font-mono text-left">مكتمل</div>
        </div>
        {onClick && <ChevronLeft className="w-4 h-4 text-slate-500" />}
      </div>
    </div>
  );
};
