// src/components/shared/MerchantCard.tsx
import React from 'react';
import { Store, QrCode, ArrowRight, Phone, Receipt } from 'lucide-react';
import { Merchant } from '../../types/merchant';
import { Badge } from '../ui/Badge';
import { Button } from '../ui/Button';

interface MerchantCardProps {
  merchant: Merchant;
  onPay?: (merchant: Merchant) => void;
  onViewInvoices?: (merchant: Merchant) => void;
}

export const MerchantCard: React.FC<MerchantCardProps> = ({
  merchant,
  onPay,
  onViewInvoices
}) => {
  const categoryLabels: Record<string, string> = {
    supermarket: 'هايبر ماركت',
    pharmacy: 'صيدلية ومستلزمات',
    food: 'مخبز ومأكولات',
    restaurant: 'مطعم وكافيه',
    electronics: 'إلكترونيات وهواتف',
    fashion: 'أزياء وملابس',
    services: 'خدمات وصيانة'
  };

  return (
    <div className="p-4 rounded-3xl bg-slate-900 border border-slate-800 space-y-3 shadow-md">
      <div className="flex items-start justify-between">
        <div className="flex items-start gap-3">
          <div className="p-3 rounded-2xl bg-cyan-500/10 border border-cyan-500/20 text-cyan-400">
            <Store className="w-5 h-5" />
          </div>
          <div>
            <div className="text-sm font-bold text-slate-100">{merchant.businessName}</div>
            <div className="text-xs text-slate-400 mt-0.5 flex items-center gap-2">
              <span>{categoryLabels[merchant.category] || merchant.category}</span>
              <span>•</span>
              <span className="font-mono text-emerald-400">{merchant.merchantCode}</span>
            </div>
          </div>
        </div>

        <Badge variant={merchant.status === 'active' ? 'success' : 'warning'}>
          {merchant.status === 'active' ? 'نقطة بيع نشطة' : 'تحت المراجعة'}
        </Badge>
      </div>

      <div className="p-3 bg-slate-950/80 rounded-2xl border border-slate-800 flex justify-between items-center text-xs">
        <div>
          <span className="text-slate-400 block text-[10px]">إجمالي المبيعات:</span>
          <span className="font-bold text-white font-mono">{merchant.totalSalesCount} عملية ناجحة</span>
        </div>
        <div className="text-left">
          <span className="text-slate-400 block text-[10px]">رصيد المبيعات:</span>
          <span className="font-bold text-cyan-400 font-mono">{merchant.balanceYER.toLocaleString()} ر.ي</span>
        </div>
      </div>

      <div className="flex gap-2 pt-1">
        {onPay && (
          <Button
            size="sm"
            variant="primary"
            className="flex-1"
            icon={<QrCode className="w-3.5 h-3.5" />}
            onClick={() => onPay(merchant)}
          >
            دفع QR
          </Button>
        )}
        {onViewInvoices && (
          <Button
            size="sm"
            variant="secondary"
            className="flex-1"
            icon={<Receipt className="w-3.5 h-3.5" />}
            onClick={() => onViewInvoices(merchant)}
          >
            الفواتير
          </Button>
        )}
      </div>
    </div>
  );
};
