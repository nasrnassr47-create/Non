// src/components/shared/WalletCard.tsx
import React, { useState } from 'react';
import { Lock, Copy, Check, Eye, EyeOff, Sparkles, CreditCard, Wifi, PlusCircle } from 'lucide-react';
import { Wallet } from '../../types/wallet';
import { copyToClipboard } from '../../lib/utils';
import { useWallet } from '../../context/WalletContext';

interface WalletCardProps {
  wallet?: Wallet;
  onSelect?: () => void;
  showDetails?: boolean;
  onQuickTopUp?: () => void;
}

export const WalletCard: React.FC<WalletCardProps> = ({
  wallet,
  onSelect,
  showDetails = true,
  onQuickTopUp
}) => {
  const { activeWallet, showToast, systemControl, addQuickFunds } = useWallet();
  const currentWallet = wallet || activeWallet;
  const [copied, setCopied] = useState(false);
  const [localShowBalance, setLocalShowBalance] = useState(!systemControl.appearance.hideBalances);

  const handleCopyAccount = async () => {
    const ok = await copyToClipboard(currentWallet.accountNumber);
    if (ok) {
      setCopied(true);
      showToast('تم نسخ رقم الحساب للمحفظة', 'info');
      setTimeout(() => setCopied(false), 2000);
    }
  };

  // Theme presets
  const themeGradients = {
    emerald: 'from-emerald-900 via-teal-950 to-slate-950 border-emerald-500/40 shadow-emerald-950/60',
    gold: 'from-amber-900 via-yellow-950 to-slate-950 border-amber-500/40 shadow-amber-950/60',
    cyber: 'from-indigo-950 via-slate-900 to-black border-cyan-500/40 shadow-cyan-950/60',
    light: 'from-slate-800 via-slate-900 to-emerald-950 border-slate-700 shadow-slate-950/50'
  };

  const currentThemeGradient = themeGradients[systemControl.appearance.themePreset] || themeGradients.emerald;

  return (
    <div
      onClick={onSelect}
      className={`relative overflow-hidden rounded-3xl p-5 sm:p-6 bg-gradient-to-br ${currentThemeGradient} border shadow-2xl text-white select-none transition-all hover:scale-[1.01]`}
    >
      {/* Background ambient lighting effects */}
      <div className="absolute -left-12 -bottom-12 w-52 h-52 rounded-full bg-emerald-500/15 blur-3xl pointer-events-none" />
      <div className="absolute -right-12 -top-12 w-52 h-52 rounded-full bg-amber-400/10 blur-3xl pointer-events-none" />
      
      {/* Subtle geometric pattern lines */}
      <div className="absolute inset-0 bg-[radial-gradient(#ffffff0a_1px,transparent_1px)] [background-size:16px_16px] pointer-events-none" />

      {/* Top Header Row on Card */}
      <div className="flex justify-between items-start relative z-10">
        <div className="flex items-center gap-2">
          {/* EMV Gold Chip */}
          <div className="w-10 h-8 rounded-lg bg-gradient-to-br from-amber-300 via-yellow-400 to-amber-500 p-1 border border-amber-200/60 shadow-md flex items-center justify-center">
            <div className="w-7 h-5 border border-amber-700/40 rounded-sm grid grid-cols-2 grid-rows-2" />
          </div>
          {/* Contactless Wave */}
          <Wifi className="w-4 h-4 text-emerald-300/80 rotate-90" />
          <span className="text-[10px] font-mono tracking-wider px-2 py-0.5 rounded-full bg-black/40 border border-white/10 text-emerald-300 font-semibold uppercase">
            SOVEREIGN TIER
          </span>
        </div>

        <div className="flex items-center gap-2">
          <span className="px-3 py-1 rounded-full bg-black/50 border border-white/10 text-xs font-mono font-extrabold text-amber-300">
            {currentWallet.currency}
          </span>
          <div className="p-2 rounded-xl bg-black/40 border border-white/10 text-emerald-400">
            <Lock className="w-3.5 h-3.5" />
          </div>
        </div>
      </div>

      {/* Balance Section */}
      <div className="mt-4 relative z-10">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-300 font-medium">الرصيد المتاح (القيد المزدوج)</span>
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                setLocalShowBalance(!localShowBalance);
              }}
              className="text-emerald-300 hover:text-white transition-colors p-1"
            >
              {localShowBalance ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
            </button>
          </div>

          {/* Quick Balance Inject Button */}
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              if (onQuickTopUp) {
                onQuickTopUp();
              } else {
                addQuickFunds(currentWallet.currency, currentWallet.currency === 'YER' ? 50000 : 100);
              }
            }}
            className="flex items-center gap-1 text-[11px] font-bold text-amber-300 hover:text-amber-200 bg-amber-500/20 px-2.5 py-1 rounded-xl border border-amber-500/30 transition-all active:scale-95"
          >
            <PlusCircle className="w-3.5 h-3.5" />
            <span>شحن سريع</span>
          </button>
        </div>

        <div className="text-2xl sm:text-4xl font-black text-white tracking-tight mt-1 font-mono flex items-baseline gap-2">
          {localShowBalance ? (
            <>
              <span>{currentWallet.balance.toLocaleString()}</span>
              <span className="text-emerald-400 text-sm font-semibold">{currentWallet.symbol}</span>
            </>
          ) : (
            <span className="tracking-widest text-emerald-300">••••••••••</span>
          )}
        </div>
      </div>

      {/* Bottom row: Account Number & Copy */}
      {showDetails && (
        <div className="flex items-center justify-between mt-5 pt-3.5 border-t border-white/10 text-xs relative z-10">
          <div className="flex items-center gap-2">
            <CreditCard className="w-4 h-4 text-emerald-400" />
            <span className="text-slate-300 font-mono text-[11px]">
              رقم الحساب: <strong className="text-white font-bold tracking-wider">{currentWallet.accountNumber}</strong>
            </span>
          </div>

          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              handleCopyAccount();
            }}
            className="flex items-center gap-1 text-[11px] text-emerald-300 hover:text-white bg-black/40 px-2.5 py-1 rounded-xl border border-white/10 transition-colors"
          >
            {copied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
            <span>{copied ? 'تم النسخ' : 'نسخ'}</span>
          </button>
        </div>
      )}
    </div>
  );
};

