// src/components/shared/AgentCard.tsx
import React from 'react';
import { MapPin, Phone, Star, ShieldCheck, ArrowDownLeft, ArrowUpRight } from 'lucide-react';
import { Agent } from '../../types/agent';
import { Badge } from '../ui/Badge';
import { Button } from '../ui/Button';

interface AgentCardProps {
  agent: Agent;
  onCashIn?: (agent: Agent) => void;
  onCashOut?: (agent: Agent) => void;
}

export const AgentCard: React.FC<AgentCardProps> = ({
  agent,
  onCashIn,
  onCashOut
}) => {
  return (
    <div className="p-4 rounded-3xl bg-slate-900 border border-slate-800 space-y-3 shadow-md">
      <div className="flex items-start justify-between">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-sm font-bold text-slate-100">{agent.tradeName}</span>
            <Badge variant="gold">
              <Star className="w-3 h-3 fill-amber-400 text-amber-400 inline ml-1" />
              {agent.rating}
            </Badge>
          </div>
          <div className="text-xs text-slate-400 mt-1 flex items-center gap-1.5">
            <MapPin className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
            <span>{agent.city} - {agent.address}</span>
          </div>
          <div className="text-[11px] text-slate-500 font-mono mt-0.5 flex items-center gap-1">
            <Phone className="w-3 h-3 text-slate-400" />
            <span>{agent.phone} • كود: {agent.agentCode}</span>
          </div>
        </div>

        <div className="text-left">
          <Badge variant={agent.status === 'active' ? 'success' : 'warning'}>
            {agent.status === 'active' ? 'وكيل معتمد' : 'غير متصل'}
          </Badge>
        </div>
      </div>

      <div className="p-3 bg-slate-950/80 rounded-2xl border border-slate-800/80 flex justify-between items-center text-xs">
        <div>
          <span className="text-slate-400 block text-[10px]">الرصيد التشغيلي (Float):</span>
          <span className="font-bold text-white font-mono">{agent.floatBalanceYER.toLocaleString()} ر.ي</span>
        </div>
        <div className="text-left">
          <span className="text-slate-400 block text-[10px]">العمولات المحققة:</span>
          <span className="font-bold text-emerald-400 font-mono">{agent.accumulatedCommissionYER.toLocaleString()} ر.ي</span>
        </div>
      </div>

      {(onCashIn || onCashOut) && (
        <div className="flex gap-2 pt-1">
          {onCashIn && (
            <Button
              size="sm"
              variant="primary"
              className="flex-1"
              icon={<ArrowDownLeft className="w-3.5 h-3.5" />}
              onClick={() => onCashIn(agent)}
            >
              إيداع نقدي
            </Button>
          )}
          {onCashOut && (
            <Button
              size="sm"
              variant="secondary"
              className="flex-1"
              icon={<ArrowUpRight className="w-3.5 h-3.5" />}
              onClick={() => onCashOut(agent)}
            >
              سحب نقدي
            </Button>
          )}
        </div>
      )}
    </div>
  );
};
