// src/components/shared/SystemTreeViewer.tsx
import React from 'react';
import { SystemVisualizer } from '../SystemVisualizer';
import { SystemBranch } from '../../data/systemTree';

interface Props {
  onSelectBranch?: (branch: SystemBranch) => void;
  onRequestRoleApp?: (role: string) => void;
  onSelectService?: (serviceName: string) => void;
}

export const SystemTreeViewer: React.FC<Props> = (props) => {
  return <SystemVisualizer {...props} />;
};
