// src/components/shared/FamilyMemberCard.tsx
import React from 'react';
import { Shield, Send, PauseCircle, PlayCircle, MoreVertical } from 'lucide-react';
import { FamilyMember } from '../../types/family';
import { Avatar } from '../ui/Avatar';
import { Badge } from '../ui/Badge';
import { Button } from '../ui/Button';

interface FamilyMemberCardProps {
  member: FamilyMember;
  onSendAllowance?: (member: FamilyMember) => void;
  onToggleStatus?: (member: FamilyMember) => void;
  onEditLimits?: (member: FamilyMember) => void;
}

export const FamilyMemberCard: React.FC<FamilyMemberCardProps> = ({
  member,
  onSendAllowance,
  onToggleStatus,
  onEditLimits
}) => {
  const relationLabels: Record<string, string> = {
    father: 'رب الأسرة (الأب)',
    mother: 'الأم',
    son: 'ابن',
    daughter: 'ابنة',
    spouse: 'الزوجة / الزوج',
    dependent: 'تابع'
  };

  const percentSpent = Math.min(100, Math.round((member.spentThisMonth / (member.allowanceMonthly || 1)) * 100));

  return (
    <div className="p-4 rounded-3xl bg-slate-900 border border-slate-800 space-y-3 shadow-md">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Avatar name={member.name} size="md" />
          <div>
            <div className="text-sm font-bold text-slate-100 flex items-center gap-2">
              <span>{member.name}</span>
              <Badge variant={member.status === 'active' ? 'success' : 'warning'}>
                {relationLabels[member.relationship] || member.relationship}
              </Badge>
            </div>
            <div className="text-xs text-slate-400 font-mono mt-0.5">{member.phone}</div>
          </div>
        </div>

        <div className="text-left">
          <div className="text-xs text-slate-400">الرصيد الحالي</div>
          <div className="text-sm font-bold text-emerald-400 font-mono">
            {member.balance.toLocaleString()} {member.currency}
          </div>
        </div>
      </div>

      {/* Allowance Progress Bar */}
      <div className="space-y-1">
        <div className="flex justify-between text-[11px] text-slate-400">
          <span>المصروف الشهري: {member.spentThisMonth.toLocaleString()} ر.ي مستهلك</span>
          <span className="font-mono">{member.allowanceMonthly.toLocaleString()} ر.ي الحد الأقصى</span>
        </div>
        <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
          <div
            className={`h-full rounded-full transition-all ${
              percentSpent > 85 ? 'bg-red-500' : percentSpent > 60 ? 'bg-amber-500' : 'bg-emerald-500'
            }`}
            style={{ width: `${percentSpent}%` }}
          />
        </div>
      </div>

      {/* Actions */}
      <div className="flex items-center gap-2 pt-1">
        {onSendAllowance && (
          <Button
            size="sm"
            variant="primary"
            className="flex-1"
            icon={<Send className="w-3.5 h-3.5" />}
            onClick={() => onSendAllowance(member)}
          >
            صرف مصروف
          </Button>
        )}
        {onEditLimits && (
          <Button
            size="sm"
            variant="secondary"
            onClick={() => onEditLimits(member)}
          >
            تعديل الحدود
          </Button>
        )}
      </div>
    </div>
  );
};
