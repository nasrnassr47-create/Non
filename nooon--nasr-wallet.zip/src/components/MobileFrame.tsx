import React, { ReactNode } from 'react';
import { Wifi, Battery, Signal } from 'lucide-react';

interface Props {
  children: ReactNode;
  activeAppName: string;
}

export const MobileFrame: React.FC<Props> = ({ children, activeAppName }) => {
  return (
    <div className="flex justify-center my-2">
      <div className="w-full max-w-[420px] bg-slate-900 rounded-[44px] p-3 shadow-2xl border-4 border-slate-700/80 relative">
        {/* Device Notch / Dynamic Island */}
        <div className="w-28 h-4 bg-black rounded-full mx-auto mb-2 flex items-center justify-center gap-2">
          <div className="w-2 h-2 rounded-full bg-slate-800" />
          <div className="w-2 h-2 rounded-full bg-emerald-500/80 animate-pulse" />
        </div>

        {/* Status Bar */}
        <div className="flex justify-between items-center px-4 py-1 text-[11px] text-slate-400 font-mono mb-1">
          <span>9:41</span>
          <span className="text-[10px] text-emerald-400 font-semibold">{activeAppName}</span>
          <div className="flex items-center gap-1.5">
            <Signal className="w-3 h-3 text-slate-300" />
            <Wifi className="w-3 h-3 text-slate-300" />
            <Battery className="w-3.5 h-3.5 text-emerald-400" />
          </div>
        </div>

        {/* Screen Container */}
        <div className="rounded-[32px] overflow-hidden bg-slate-950 min-h-[580px] shadow-inner">
          {children}
        </div>

        {/* Home Indicator Bar */}
        <div className="w-32 h-1 bg-slate-600/80 rounded-full mx-auto mt-3" />
      </div>
    </div>
  );
};
