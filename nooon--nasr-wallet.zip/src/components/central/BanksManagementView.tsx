// src/components/central/BanksManagementView.tsx
import React, { useState } from 'react';
import { 
  Building2, 
  Globe, 
  CheckCircle2, 
  AlertTriangle, 
  RefreshCw, 
  ArrowUpRight, 
  ShieldCheck, 
  Plus,
  Activity,
  Layers
} from 'lucide-react';
import { BankIntegration } from '../../types/central';
import { initialBanks } from '../../data/centralData';
import { ArrowRight } from 'lucide-react';

interface Props {
  onNotify?: (msg: string) => void;
  onBackToHome?: () => void;
}

export const BanksManagementView: React.FC<Props> = ({ onNotify, onBackToHome }) => {
  const [banks, setBanks] = useState<BankIntegration[]>(initialBanks);

  const testConnection = (id: string, name: string) => {
    if (onNotify) onNotify(`تم اختبار الاتصال مع ${name}: الاستجابة ممتازة (Ping: 34ms)`);
  };

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          {onBackToHome && (
            <button
              onClick={onBackToHome}
              className="p-2 sm:px-3 sm:py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-xl flex items-center gap-1.5 text-xs font-bold transition-all cursor-pointer shadow-xs shrink-0"
              title="رجوع للرئيسية"
            >
              <ArrowRight className="w-4 h-4" />
              <span className="hidden sm:inline">رجوع للرئيسية</span>
            </button>
          )}
          <div>
            <h2 className="text-lg font-black text-slate-900 dark:text-white flex items-center gap-2">
              <Building2 className="w-5 h-5 text-blue-600" />
              <span>بوابات الربط البنكي والمقاصة المصرفية (Bank Gateways)</span>
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              إدارة اتصالات البنوك المحلية اليمنية وشبكة SWIFT GPI الدولية لتسوية السيولة الفورية
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <div className="px-3 py-1.5 bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-300 dark:border-emerald-800 text-emerald-700 dark:text-emerald-300 rounded-xl text-xs font-bold flex items-center gap-1.5">
            <CheckCircle2 className="w-4 h-4" />
            <span>5 بوابات نشطة 100%</span>
          </div>
        </div>
      </div>

      {/* Banks Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
        {banks.map(bank => (
          <div 
            key={bank.id}
            className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between space-y-4 hover:border-blue-400 transition-all"
          >
            <div>
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="p-2.5 rounded-xl bg-blue-50 dark:bg-blue-950 text-blue-600 dark:text-blue-400 border border-blue-200 dark:border-blue-800">
                    <Building2 className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-bold text-xs text-slate-900 dark:text-white">{bank.bankName}</h3>
                    <span className="text-[10px] font-mono text-slate-400 font-bold">CODE: {bank.code}</span>
                  </div>
                </div>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-50 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-800 flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                  <span>متصل</span>
                </span>
              </div>

              <div className="mt-4 grid grid-cols-2 gap-2 text-center text-xs">
                <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-100 dark:border-slate-800">
                  <span className="text-[10px] text-slate-400 block">حجم التداول اليومي</span>
                  <span className="font-bold font-mono text-slate-900 dark:text-slate-100">{bank.dailyVolume}</span>
                </div>
                <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-100 dark:border-slate-800">
                  <span className="text-[10px] text-slate-400 block">زمن الاستجابة (Latency)</span>
                  <span className="font-bold font-mono text-emerald-600 dark:text-emerald-400">{bank.latencyMs} ms</span>
                </div>
              </div>

              <div className="mt-2 text-[11px] text-slate-500 dark:text-slate-400 flex items-center justify-between">
                <span>نوع البروتوكول:</span>
                <span className="font-mono font-bold text-blue-600 dark:text-blue-400">{bank.connectionType}</span>
              </div>
            </div>

            <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
              <button
                onClick={() => testConnection(bank.id, bank.bankName)}
                className="px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-bold flex items-center gap-1.5 cursor-pointer transition-all"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>فحص الربط الحي</span>
              </button>
              <span className="text-[10px] text-emerald-500 font-bold">256-bit TLS</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
