// src/components/central/PayrollManagementView.tsx
import React, { useState } from 'react';
import { 
  Calendar, 
  Users, 
  DollarSign, 
  CheckCircle2, 
  Clock, 
  Plus, 
  Send, 
  Building,
  FileSpreadsheet
} from 'lucide-react';
import { PayrollBatch } from '../../types/central';
import { initialPayrollBatches } from '../../data/centralData';
import { ArrowRight } from 'lucide-react';

interface Props {
  onNotify?: (msg: string) => void;
  onBackToHome?: () => void;
}

export const PayrollManagementView: React.FC<Props> = ({ onNotify, onBackToHome }) => {
  const [batches, setBatches] = useState<PayrollBatch[]>(initialPayrollBatches);

  const executeScheduledBatch = (id: string, name: string) => {
    setBatches(prev => prev.map(b => {
      if (b.id === id) {
        if (onNotify) onNotify(`تم صرف دفعة رواتب ${name} وتغذية محافظ الموظفين بنجاح`);
        return { ...b, status: 'completed' };
      }
      return b;
    }));
  };

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          {onBackToHome && (
            <button
              onClick={onBackToHome}
              className="p-2 sm:px-3 sm:py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-xl flex items-center gap-1.5 text-xs font-bold transition-all cursor-pointer shadow-xs shrink-0"
              title="رجوع للرئيسية"
            >
              <ArrowRight className="w-4 h-4" />
              <span className="hidden sm:inline">رجوع للرئيسية</span>
            </button>
          )}
          <div>
            <h2 className="text-lg font-black text-slate-900 dark:text-white flex items-center gap-2">
              <Calendar className="w-5 h-5 text-blue-600" />
              <span>نظام مسيرات الرواتب والمستحقات الجماعية (Corporate Payroll)</span>
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              توزيع الرواتب آلياً للشركات والمؤسسات وإيداع المبالغ في محافظ الموظفين في ثوانٍ معدودة
            </p>
          </div>
        </div>

        <button 
          onClick={() => {
            if (onNotify) onNotify('تم فتح نافذة تحميل ملف Excel لمسير رواتب جديد');
          }}
          className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold flex items-center gap-2 shadow-md cursor-pointer shrink-0"
        >
          <FileSpreadsheet className="w-4 h-4" />
          <span>استيراد مسير رواتب Excel</span>
        </button>
      </div>

      {/* Batches Table */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-sm">
        <table className="w-full text-right text-xs text-slate-700 dark:text-slate-300">
          <thead className="bg-slate-50 dark:bg-slate-950/80 text-slate-500 dark:text-slate-400 border-b border-slate-200 dark:border-slate-800 text-[11px] font-semibold">
            <tr>
              <th className="p-3.5">رقم الدفعة</th>
              <th className="p-3.5">الجهة / الشركة</th>
              <th className="p-3.5">عدد الموظفين</th>
              <th className="p-3.5">المبلغ الإجمالي</th>
              <th className="p-3.5">تاريخ الصرف</th>
              <th className="p-3.5">الحالة</th>
              <th className="p-3.5 text-center">الإجراء</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
            {batches.map(b => (
              <tr key={b.id} className="hover:bg-slate-50/70 dark:hover:bg-slate-800/50 transition-colors">
                <td className="p-3.5 font-mono font-bold text-slate-900 dark:text-white">{b.id}</td>
                <td className="p-3.5 font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
                  <Building className="w-4 h-4 text-blue-500" />
                  <span>{b.companyName}</span>
                </td>
                <td className="p-3.5 font-mono">{b.totalEmployees} موظف</td>
                <td className="p-3.5 font-mono font-bold text-emerald-600 dark:text-emerald-400">
                  {b.totalAmount.toLocaleString()} {b.currency}
                </td>
                <td className="p-3.5 font-mono text-slate-400">{b.executionDate}</td>
                <td className="p-3.5">
                  {b.status === 'completed' ? (
                    <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-50 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400 border border-emerald-300 dark:border-emerald-800 flex items-center gap-1 w-fit">
                      <CheckCircle2 className="w-3 h-3" />
                      <span>تم الصرف بالكامل</span>
                    </span>
                  ) : (
                    <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-50 dark:bg-amber-950 text-amber-600 dark:text-amber-400 border border-amber-300 dark:border-amber-800 flex items-center gap-1 w-fit">
                      <Clock className="w-3 h-3" />
                      <span>مجدول للشهر</span>
                    </span>
                  )}
                </td>
                <td className="p-3.5 text-center">
                  {b.status === 'scheduled' ? (
                    <button
                      onClick={() => executeScheduledBatch(b.id, b.companyName)}
                      className="px-3 py-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold transition-all cursor-pointer shadow-sm flex items-center gap-1 mx-auto"
                    >
                      <Send className="w-3 h-3" />
                      <span>صرف فوري</span>
                    </button>
                  ) : (
                    <span className="text-slate-400 text-[11px]">مكتمل</span>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
