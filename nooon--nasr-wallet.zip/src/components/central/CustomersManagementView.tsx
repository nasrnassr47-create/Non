// src/components/central/CustomersManagementView.tsx
import React, { useState } from 'react';
import { 
  Users, 
  Search, 
  Plus, 
  Lock, 
  Unlock, 
  ShieldCheck, 
  CheckCircle2, 
  AlertCircle,
  FileText,
  Filter,
  ArrowUpDown,
  MoreVertical,
  X
} from 'lucide-react';
import { CustomerRecord } from '../../types/central';
import { initialCentralCustomers } from '../../data/centralData';
import { ArrowRight } from 'lucide-react';

interface Props {
  onNotify?: (msg: string) => void;
  onBackToHome?: () => void;
}

export const CustomersManagementView: React.FC<Props> = ({ onNotify, onBackToHome }) => {
  const [customers, setCustomers] = useState<CustomerRecord[]>(initialCentralCustomers);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'frozen' | 'pending_kyc'>('all');
  const [showAddModal, setShowAddModal] = useState(false);
  const [selectedCustomer, setSelectedCustomer] = useState<CustomerRecord | null>(null);

  // New customer form state
  const [newCustomer, setNewCustomer] = useState({
    name: '',
    phone: '',
    email: '',
    nationalId: '',
    tier: 'Tier 2' as CustomerRecord['tier'],
    initialBalanceYER: '500000',
    kycDocType: 'بطاقة شخصية ذكية'
  });

  const filteredCustomers = customers.filter(c => {
    const matchesSearch = 
      c.name.includes(searchQuery) || 
      c.phone.includes(searchQuery) || 
      c.nationalId.includes(searchQuery) ||
      c.email.includes(searchQuery);
    const matchesStatus = statusFilter === 'all' || c.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const toggleCustomerFreeze = (id: string) => {
    setCustomers(prev => prev.map(c => {
      if (c.id === id) {
        const nextStatus = c.status === 'frozen' ? 'active' : 'frozen';
        if (onNotify) onNotify(`${nextStatus === 'frozen' ? 'تم تجميد' : 'تم تنشيط'} حساب العميل ${c.name}`);
        return { ...c, status: nextStatus };
      }
      return c;
    }));
  };

  const approveCustomerKyc = (id: string) => {
    setCustomers(prev => prev.map(c => {
      if (c.id === id) {
        if (onNotify) onNotify(`تم اعتماد توثيق KYC للعميل ${c.name}`);
        return { ...c, status: 'active', tier: 'Tier 3 (VIP)' };
      }
      return c;
    }));
  };

  const handleCreateCustomer = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCustomer.name || !newCustomer.phone) return;

    const created: CustomerRecord = {
      id: `cust-${Date.now().toString().slice(-4)}`,
      name: newCustomer.name,
      phone: newCustomer.phone,
      email: newCustomer.email || `${newCustomer.phone}@nasrwallet.ye`,
      nationalId: newCustomer.nationalId || '010100' + Math.floor(10000 + Math.random() * 90000),
      tier: newCustomer.tier,
      status: 'active',
      balanceYER: Number(newCustomer.initialBalanceYER) || 0,
      balanceUSD: 0,
      balanceSAR: 0,
      joinedDate: new Date().toISOString().split('T')[0],
      kycDocType: newCustomer.kycDocType
    };

    setCustomers([created, ...customers]);
    setShowAddModal(false);
    if (onNotify) onNotify(`تم تسجيل العميل الجديد ${created.name} بنجاح`);
    setNewCustomer({
      name: '',
      phone: '',
      email: '',
      nationalId: '',
      tier: 'Tier 2',
      initialBalanceYER: '500000',
      kycDocType: 'بطاقة شخصية ذكية'
    });
  };

  return (
    <div className="space-y-4">
      {/* Header & Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm">
        <div className="flex items-center gap-3">
          {onBackToHome && (
            <button
              onClick={onBackToHome}
              className="p-2 sm:px-3 sm:py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-xl flex items-center gap-1.5 text-xs font-bold transition-all cursor-pointer shadow-xs shrink-0"
              title="رجوع للرئيسية"
            >
              <ArrowRight className="w-4 h-4" />
              <span className="hidden sm:inline">رجوع للرئيسية</span>
            </button>
          )}
          <div>
            <h2 className="text-lg font-black text-slate-900 dark:text-white flex items-center gap-2">
              <Users className="w-5 h-5 text-blue-600" />
              <span>إدارة العملاء والمشتركين ({customers.length})</span>
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              التحكم الشامل في حسابات العملاء، مستويات التوثيق KYC، والأرصدة والتجميد
            </p>
          </div>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold rounded-xl flex items-center gap-2 shadow-md cursor-pointer transition-all shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>إضافة عميل جديد</span>
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="sm:col-span-2 relative">
          <Search className="w-4 h-4 absolute right-3.5 top-3 text-slate-400" />
          <input
            type="text"
            placeholder="بحث بالاسم، رقم الهاتف، أو الرقم الوطني..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-4 pr-10 py-2.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl text-xs text-slate-800 dark:text-slate-200 placeholder-slate-400 focus:outline-none focus:border-blue-500 shadow-sm"
          />
        </div>

        <div className="flex items-center gap-2">
          {(['all', 'active', 'pending_kyc', 'frozen'] as const).map(st => (
            <button
              key={st}
              onClick={() => setStatusFilter(st)}
              className={`flex-1 py-2 text-xs font-bold rounded-xl border transition-all cursor-pointer ${
                statusFilter === st
                  ? 'bg-blue-600 text-white border-blue-600 shadow-sm'
                  : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300 border-slate-200 dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              {st === 'all' && 'الكل'}
              {st === 'active' && 'نشط'}
              {st === 'pending_kyc' && 'قيد التوثيق'}
              {st === 'frozen' && 'مجمد'}
            </button>
          ))}
        </div>
      </div>

      {/* Customers Table */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-right text-xs text-slate-700 dark:text-slate-300">
            <thead className="bg-slate-50 dark:bg-slate-950/80 text-slate-500 dark:text-slate-400 border-b border-slate-200 dark:border-slate-800 text-[11px] font-semibold">
              <tr>
                <th className="p-3.5">العميل</th>
                <th className="p-3.5">رقم الهاتف / الوطني</th>
                <th className="p-3.5">المستوى</th>
                <th className="p-3.5">الرصيد بالريال اليمني</th>
                <th className="p-3.5">الرصيد بالدولار</th>
                <th className="p-3.5">الحالة</th>
                <th className="p-3.5 text-center">الإجراءات والتحكم</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800/80">
              {filteredCustomers.map(cust => (
                <tr key={cust.id} className="hover:bg-slate-50/70 dark:hover:bg-slate-800/50 transition-colors">
                  <td className="p-3.5">
                    <div className="font-bold text-slate-900 dark:text-white">{cust.name}</div>
                    <div className="text-[10px] text-slate-400">{cust.email}</div>
                  </td>
                  <td className="p-3.5 font-mono">
                    <div className="text-slate-900 dark:text-slate-200">{cust.phone}</div>
                    <div className="text-[10px] text-slate-400">ID: {cust.nationalId}</div>
                  </td>
                  <td className="p-3.5">
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-blue-50 dark:bg-blue-950 text-blue-600 dark:text-blue-300 border border-blue-200 dark:border-blue-800">
                      {cust.tier}
                    </span>
                  </td>
                  <td className="p-3.5 font-mono font-bold text-emerald-600 dark:text-emerald-400">
                    {cust.balanceYER.toLocaleString()} YER
                  </td>
                  <td className="p-3.5 font-mono font-bold text-cyan-600 dark:text-cyan-400">
                    ${cust.balanceUSD.toLocaleString()}
                  </td>
                  <td className="p-3.5">
                    {cust.status === 'active' && (
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-50 dark:bg-emerald-950/80 text-emerald-600 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800">
                        نشط وموثق
                      </span>
                    )}
                    {cust.status === 'pending_kyc' && (
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-50 dark:bg-amber-950/80 text-amber-600 dark:text-amber-400 border border-amber-200 dark:border-amber-800">
                        قيد مراجعة KYC
                      </span>
                    )}
                    {cust.status === 'frozen' && (
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-red-50 dark:bg-red-950/80 text-red-600 dark:text-red-400 border border-red-200 dark:border-red-800">
                        حساب مجمد
                      </span>
                    )}
                  </td>
                  <td className="p-3.5 text-center">
                    <div className="flex items-center justify-center gap-1.5">
                      {cust.status === 'pending_kyc' && (
                        <button
                          onClick={() => approveCustomerKyc(cust.id)}
                          title="اعتماد توثيق KYC"
                          className="px-2 py-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-[10px] font-bold transition-all cursor-pointer flex items-center gap-1"
                        >
                          <ShieldCheck className="w-3.5 h-3.5" />
                          <span>توثيق</span>
                        </button>
                      )}

                      <button
                        onClick={() => toggleCustomerFreeze(cust.id)}
                        title={cust.status === 'frozen' ? 'إلغاء التجميد' : 'تجميد الحساب'}
                        className={`p-1.5 rounded-lg text-xs transition-all cursor-pointer border ${
                          cust.status === 'frozen'
                            ? 'bg-emerald-50 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400 border-emerald-300 dark:border-emerald-800'
                            : 'bg-red-50 dark:bg-red-950 text-red-600 dark:text-red-400 border-red-300 dark:border-red-800'
                        }`}
                      >
                        {cust.status === 'frozen' ? <Unlock className="w-3.5 h-3.5" /> : <Lock className="w-3.5 h-3.5" />}
                      </button>

                      <button
                        onClick={() => setSelectedCustomer(cust)}
                        title="تفاصيل الحساب"
                        className="p-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:text-blue-500 transition-all cursor-pointer border border-slate-200 dark:border-slate-700"
                      >
                        <FileText className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Customer Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl max-w-md w-full p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <h3 className="font-bold text-base text-slate-900 dark:text-white flex items-center gap-2">
                <Plus className="w-4 h-4 text-blue-600" />
                <span>إضافة عميل / مشترك جديد</span>
              </h3>
              <button 
                onClick={() => setShowAddModal(false)}
                className="text-slate-400 hover:text-slate-600 dark:hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateCustomer} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-600 dark:text-slate-300 mb-1 font-semibold">الاسم الثلاثي أو التجاري *</label>
                <input
                  type="text"
                  required
                  placeholder="مثال: ناصر عبد الرحمن الشامي"
                  value={newCustomer.name}
                  onChange={e => setNewCustomer({ ...newCustomer, name: e.target.value })}
                  className="w-full p-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:border-blue-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-slate-600 dark:text-slate-300 mb-1 font-semibold">رقم الهاتف (اليمن) *</label>
                  <input
                    type="tel"
                    required
                    placeholder="77XXXXXXX"
                    value={newCustomer.phone}
                    onChange={e => setNewCustomer({ ...newCustomer, phone: e.target.value })}
                    className="w-full p-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:border-blue-500 font-mono"
                  />
                </div>
                <div>
                  <label className="block text-slate-600 dark:text-slate-300 mb-1 font-semibold">الرقم الوطني</label>
                  <input
                    type="text"
                    placeholder="01010XXXXXX"
                    value={newCustomer.nationalId}
                    onChange={e => setNewCustomer({ ...newCustomer, nationalId: e.target.value })}
                    className="w-full p-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:border-blue-500 font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-slate-600 dark:text-slate-300 mb-1 font-semibold">مستوى الحساب (Tier)</label>
                  <select
                    value={newCustomer.tier}
                    onChange={e => setNewCustomer({ ...newCustomer, tier: e.target.value as CustomerRecord['tier'] })}
                    className="w-full p-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:border-blue-500"
                  >
                    <option value="Tier 1">Tier 1 (مبتدئ)</option>
                    <option value="Tier 2">Tier 2 (موثق أساسي)</option>
                    <option value="Tier 3 (VIP)">Tier 3 (VIP شركات)</option>
                  </select>
                </div>
                <div>
                  <label className="block text-slate-600 dark:text-slate-300 mb-1 font-semibold">الرصيد الافتتاحي (YER)</label>
                  <input
                    type="number"
                    value={newCustomer.initialBalanceYER}
                    onChange={e => setNewCustomer({ ...newCustomer, initialBalanceYER: e.target.value })}
                    className="w-full p-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:border-blue-500 font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-600 dark:text-slate-300 mb-1 font-semibold">نوع وثيقة الإثبات</label>
                <select
                  value={newCustomer.kycDocType}
                  onChange={e => setNewCustomer({ ...newCustomer, kycDocType: e.target.value })}
                  className="w-full p-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:border-blue-500"
                >
                  <option value="بطاقة شخصية ذكية">بطاقة شخصية ذكية</option>
                  <option value="جواز سفر إلكتروني">جواز سفر إلكتروني</option>
                  <option value="سجل تجاري موثق">سجل تجاري موثق</option>
                </select>
              </div>

              <div className="flex gap-2 pt-3">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="flex-1 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 font-bold hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold shadow-md cursor-pointer"
                >
                  حفظ وتسجيل العميل
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Customer Details Modal */}
      {selectedCustomer && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl max-w-lg w-full p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <div>
                <h3 className="font-bold text-base text-slate-900 dark:text-white">{selectedCustomer.name}</h3>
                <div className="text-xs text-slate-400 font-mono">ID: {selectedCustomer.id}</div>
              </div>
              <button 
                onClick={() => setSelectedCustomer(null)}
                className="text-slate-400 hover:text-slate-600 dark:hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="grid grid-cols-3 gap-2 text-center text-xs">
              <div className="p-3 bg-slate-50 dark:bg-slate-950 rounded-2xl border border-slate-100 dark:border-slate-800">
                <div className="text-[10px] text-slate-400">الرصيد اليمني</div>
                <div className="font-bold font-mono text-emerald-600 dark:text-emerald-400 mt-1">
                  {selectedCustomer.balanceYER.toLocaleString()} YER
                </div>
              </div>
              <div className="p-3 bg-slate-50 dark:bg-slate-950 rounded-2xl border border-slate-100 dark:border-slate-800">
                <div className="text-[10px] text-slate-400">الرصيد الأمريكي</div>
                <div className="font-bold font-mono text-cyan-600 dark:text-cyan-400 mt-1">
                  ${selectedCustomer.balanceUSD.toLocaleString()}
                </div>
              </div>
              <div className="p-3 bg-slate-50 dark:bg-slate-950 rounded-2xl border border-slate-100 dark:border-slate-800">
                <div className="text-[10px] text-slate-400">الرصيد السعودي</div>
                <div className="font-bold font-mono text-amber-600 dark:text-amber-400 mt-1">
                  {selectedCustomer.balanceSAR.toLocaleString()} SAR
                </div>
              </div>
            </div>

            <div className="space-y-2 text-xs text-slate-600 dark:text-slate-300">
              <div className="flex justify-between p-2 rounded-xl bg-slate-50 dark:bg-slate-950">
                <span>رقم الهاتف:</span>
                <span className="font-mono font-bold text-slate-900 dark:text-white">{selectedCustomer.phone}</span>
              </div>
              <div className="flex justify-between p-2 rounded-xl bg-slate-50 dark:bg-slate-950">
                <span>البريد الإلكتروني:</span>
                <span className="font-mono text-slate-900 dark:text-white">{selectedCustomer.email}</span>
              </div>
              <div className="flex justify-between p-2 rounded-xl bg-slate-50 dark:bg-slate-950">
                <span>الرقم الوطني المعتمد:</span>
                <span className="font-mono text-slate-900 dark:text-white">{selectedCustomer.nationalId}</span>
              </div>
              <div className="flex justify-between p-2 rounded-xl bg-slate-50 dark:bg-slate-950">
                <span>وثيقة التحقق:</span>
                <span className="font-bold text-blue-600 dark:text-blue-400">{selectedCustomer.kycDocType}</span>
              </div>
              <div className="flex justify-between p-2 rounded-xl bg-slate-50 dark:bg-slate-950">
                <span>تاريخ الانضمام:</span>
                <span className="font-mono text-slate-900 dark:text-white">{selectedCustomer.joinedDate}</span>
              </div>
            </div>

            <div className="flex justify-end pt-3">
              <button
                onClick={() => setSelectedCustomer(null)}
                className="px-6 py-2 rounded-xl bg-blue-600 text-white font-bold text-xs cursor-pointer"
              >
                إغلاق النافذة
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
