import React, { useState, useEffect, useMemo, useRef } from 'react';
import {
  Calendar,
  Clock,
  CheckCircle2,
  AlertTriangle,
  Wifi,
  WifiOff,
  RefreshCw,
  Plus,
  Edit3,
  Trash2,
  Download,
  Upload,
  FileText,
  Paperclip,
  Search,
  ArrowRight,
  ShieldCheck,
  Database,
  HardDrive,
  Eye,
  Check,
  X,
  Filter,
  Zap,
  Save,
  Cloud,
  CloudOff,
  FileSpreadsheet,
  FileCode,
  Image,
  Layers,
  ChevronDown
} from 'lucide-react';

export interface HubEventItem {
  id: string;
  title: string;
  category: 'transaction' | 'file' | 'system_dev' | 'audit_risk' | 'agent_operation' | 'emergency';
  status: 'synced' | 'pending_sync' | 'draft' | 'archived';
  priority: 'high' | 'medium' | 'low';
  amount?: number;
  currency?: string;
  notes: string;
  timestamp: string;
  isOfflineCreated: boolean;
  fileAttachment?: {
    name: string;
    size: string;
    type: string;
    dataUrl?: string;
  };
  lastModified?: string;
  version: number;
}

interface EventsAndOperationsHubProps {
  onBackToHome?: () => void;
  onNotify?: (msg: string, type?: 'success' | 'info' | 'error') => void;
}

const STORAGE_KEY = 'nasr_wallet_events_hub_v1';

export const EventsAndOperationsHub: React.FC<EventsAndOperationsHubProps> = ({
  onBackToHome,
  onNotify
}) => {
  // Network detection and manual simulation toggle
  const [isBrowserOnline, setIsBrowserOnline] = useState<boolean>(
    typeof window !== 'undefined' ? window.navigator.onLine : true
  );
  const [simulateOffline, setSimulateOffline] = useState<boolean>(false);

  // Computed effective online status
  const isOnline = isBrowserOnline && !simulateOffline;

  // Listen to browser network changes
  useEffect(() => {
    const handleOnline = () => setIsBrowserOnline(true);
    const handleOffline = () => setIsBrowserOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Initial demo seed data
  const defaultEvents: HubEventItem[] = [
    {
      id: 'EVT-9001',
      title: 'تسوية المقاصة اللحظية RTGS للبنك المركزي',
      category: 'transaction',
      status: 'synced',
      priority: 'high',
      amount: 450000,
      currency: 'USD',
      notes: 'تمت مطابقة وتأكيد إشعار الإيداع السيادي وتمريرها عبر الدفتر المحاسبي المركزي.',
      timestamp: new Date(Date.now() - 3600000).toISOString(),
      isOfflineCreated: false,
      fileAttachment: {
        name: 'RTGS_CBY_Settlement_Receipt_9001.pdf',
        size: '1.4 MB',
        type: 'application/pdf'
      },
      version: 1
    },
    {
      id: 'EVT-9002',
      title: 'تحديث قواعد التشفير ومفاتيح DUKPT لماكينات الوكلاء',
      category: 'system_dev',
      status: 'synced',
      priority: 'high',
      notes: 'تم تدوير المفاتيح الجزئية لجميع ماكينات POS الميدانية بنجاح مع تفعيل الـ Keepalive.',
      timestamp: new Date(Date.now() - 7200000).toISOString(),
      isOfflineCreated: false,
      fileAttachment: {
        name: 'DUKPT_Security_Patch_v15.json',
        size: '240 KB',
        type: 'application/json'
      },
      version: 2
    },
    {
      id: 'EVT-9003',
      title: 'عقد اعتماد فرع صرافة وكيل معتمد - فرع صنعاء',
      category: 'file',
      status: 'synced',
      priority: 'medium',
      notes: 'تم استلام وتوثيق السجل التجاري والضمانة البنكية لفرع الوكيل رقم 104.',
      timestamp: new Date(Date.now() - 14400000).toISOString(),
      isOfflineCreated: false,
      fileAttachment: {
        name: 'Agent_104_Commercial_License.pdf',
        size: '3.8 MB',
        type: 'application/pdf'
      },
      version: 1
    },
    {
      id: 'EVT-9004',
      title: 'مسودة عملية تحويل نقدي ميدانية غير متزامنة (Offline)',
      category: 'agent_operation',
      status: 'pending_sync',
      priority: 'high',
      amount: 1200,
      currency: 'USD',
      notes: 'تم تسجيل العملية أثناء انقطاع تغطية الشبكة، في انتظار أول اتصال بالمخدم لمزامنة الرصيد.',
      timestamp: new Date(Date.now() - 1800000).toISOString(),
      isOfflineCreated: true,
      version: 1
    }
  ];

  // State
  const [events, setEvents] = useState<HubEventItem[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        return JSON.parse(saved);
      }
    } catch {
      // ignore
    }
    return defaultEvents;
  });

  // Save immediately to local storage on any change (Offline-first persistence)
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(events));
    } catch {
      // quota handling
    }
  }, [events]);

  // Filters & Search
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedStatus, setSelectedStatus] = useState<string>('all');

  // Modal / Form state
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingEvent, setEditingEvent] = useState<HubEventItem | null>(null);

  // Form fields
  const [formTitle, setFormTitle] = useState('');
  const [formCategory, setFormCategory] = useState<HubEventItem['category']>('transaction');
  const [formPriority, setFormPriority] = useState<HubEventItem['priority']>('medium');
  const [formAmount, setFormAmount] = useState<string>('');
  const [formCurrency, setFormCurrency] = useState('USD');
  const [formNotes, setFormNotes] = useState('');
  const [formFile, setFormFile] = useState<HubEventItem['fileAttachment'] | undefined>(undefined);

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Handle open add modal
  const handleOpenAddModal = () => {
    setEditingEvent(null);
    setFormTitle('');
    setFormCategory('transaction');
    setFormPriority('medium');
    setFormAmount('');
    setFormCurrency('USD');
    setFormNotes('');
    setFormFile(undefined);
    setIsAddModalOpen(true);
  };

  // Handle open edit modal
  const handleOpenEditModal = (evt: HubEventItem) => {
    setEditingEvent(evt);
    setFormTitle(evt.title);
    setFormCategory(evt.category);
    setFormPriority(evt.priority);
    setFormAmount(evt.amount ? String(evt.amount) : '');
    setFormCurrency(evt.currency || 'USD');
    setFormNotes(evt.notes);
    setFormFile(evt.fileAttachment);
    setIsAddModalOpen(true);
  };

  // Handle file selection
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const sizeStr = file.size > 1024 * 1024
      ? `${(file.size / (1024 * 1024)).toFixed(1)} MB`
      : `${Math.round(file.size / 1024)} KB`;

    const reader = new FileReader();
    reader.onload = (uploadEvent) => {
      setFormFile({
        name: file.name,
        size: sizeStr,
        type: file.type || 'application/octet-stream',
        dataUrl: uploadEvent.target?.result as string
      });
      onNotify?.(`تم إرفاق الملف: ${file.name} بنجاح`, 'info');
    };
    reader.readAsDataURL(file);
  };

  // Save or Update Event (Instant Save)
  const handleSaveEvent = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formTitle.trim()) {
      alert('يرجى إدخال اسم أو عنوان الحدث/العملية');
      return;
    }

    const amtNum = formAmount ? parseFloat(formAmount) : undefined;

    if (editingEvent) {
      // Update existing
      const updated: HubEventItem = {
        ...editingEvent,
        title: formTitle.trim(),
        category: formCategory,
        priority: formPriority,
        amount: amtNum,
        currency: amtNum ? formCurrency : undefined,
        notes: formNotes.trim(),
        fileAttachment: formFile,
        lastModified: new Date().toISOString(),
        version: (editingEvent.version || 1) + 1,
        // if updated while offline, set pending sync
        status: isOnline ? (editingEvent.status === 'pending_sync' ? 'synced' : editingEvent.status) : 'pending_sync'
      };

      setEvents(prev => prev.map(item => item.id === editingEvent.id ? updated : item));
      onNotify?.(`تم تحديث وتطوير الحدث: ${updated.title} وحفظه فورياً`, 'success');
    } else {
      // Create new
      const newId = `EVT-${Math.floor(1000 + Math.random() * 9000)}`;
      const newEvent: HubEventItem = {
        id: newId,
        title: formTitle.trim(),
        category: formCategory,
        status: isOnline ? 'synced' : 'pending_sync',
        priority: formPriority,
        amount: amtNum,
        currency: amtNum ? formCurrency : undefined,
        notes: formNotes.trim(),
        timestamp: new Date().toISOString(),
        isOfflineCreated: !isOnline,
        fileAttachment: formFile,
        version: 1
      };

      setEvents(prev => [newEvent, ...prev]);
      onNotify?.(
        isOnline
          ? `تم حفظ الحدث [${newId}] مباشرة وتزامنه مع المخدم المركزي`
          : `تم الحفظ الفوري للحدث [${newId}] محلياً في الخزنة (وضع عدم الاتصال)`,
        'success'
      );
    }

    setIsAddModalOpen(false);
  };

  // Delete event
  const handleDeleteEvent = (id: string, title: string) => {
    if (confirm(`هل أنت متأكد من حذف هذا السجل: "${title}"؟`)) {
      setEvents(prev => prev.filter(item => item.id !== id));
      onNotify?.(`تم حذف السجل بنجاح`, 'info');
    }
  };

  // Sync Pending items
  const [isSyncing, setIsSyncing] = useState(false);
  const handleSyncPending = () => {
    if (!isOnline) {
      alert('لا يمكن المزامنة حالياً لعدم وجود اتصال بالإنترنت. يرجى تفعيل وضع الاتصال أولاً.');
      return;
    }

    setIsSyncing(true);
    setTimeout(() => {
      setEvents(prev =>
        prev.map(item =>
          item.status === 'pending_sync' ? { ...item, status: 'synced' as const } : item
        )
      );
      setIsSyncing(false);
      onNotify?.('تمت مزامنة جميع العمليات والملفات المعلقة مع الدفتر المركزي بنجاح 100%', 'success');
    }, 1200);
  };

  // Export all events to JSON
  const handleExportData = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(events, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `Nasr_Wallet_Events_Backup_${new Date().toISOString().slice(0, 10)}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
    onNotify?.('تم تصدير ملف النسخة الاحتياطية للأحداث بنجاح', 'info');
  };

  // Statistics
  const pendingCount = events.filter(e => e.status === 'pending_sync').length;
  const syncedCount = events.filter(e => e.status === 'synced').length;
  const filesCount = events.filter(e => !!e.fileAttachment).length;

  // Filtered list
  const filteredEvents = useMemo(() => {
    return events.filter(item => {
      const matchSearch =
        searchQuery === '' ||
        item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.notes.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (item.fileAttachment && item.fileAttachment.name.toLowerCase().includes(searchQuery.toLowerCase()));

      const matchCategory = selectedCategory === 'all' || item.category === selectedCategory;
      const matchStatus = selectedStatus === 'all' || item.status === selectedStatus;

      return matchSearch && matchCategory && matchStatus;
    });
  }, [events, searchQuery, selectedCategory, selectedStatus]);

  // Helper for category badge
  const renderCategoryBadge = (cat: HubEventItem['category']) => {
    switch (cat) {
      case 'transaction':
        return <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-blue-100 dark:bg-blue-950 text-blue-700 dark:text-blue-300">معاملة مالية</span>;
      case 'file':
        return <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-purple-100 dark:bg-purple-950 text-purple-700 dark:text-purple-300">مستند / ملف</span>;
      case 'system_dev':
        return <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300">تطوير وترقية</span>;
      case 'audit_risk':
        return <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 dark:bg-amber-950 text-amber-700 dark:text-amber-300">تدقيق ومخاطر</span>;
      case 'agent_operation':
        return <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-cyan-100 dark:bg-cyan-950 text-cyan-700 dark:text-cyan-300">عملية وكيل</span>;
      case 'emergency':
        return <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-red-100 dark:bg-red-950 text-red-700 dark:text-red-300">طوارئ سيادية</span>;
      default:
        return null;
    }
  };

  return (
    <div className="space-y-4 text-right" dir="rtl">
      {/* Top Header with Back Button & Connectivity Status */}
      <div className="bg-white dark:bg-slate-900 p-4 sm:p-5 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          {onBackToHome && (
            <button
              onClick={onBackToHome}
              className="p-2 sm:px-3 sm:py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-2xl flex items-center gap-1.5 text-xs font-bold transition-all cursor-pointer shadow-xs active:scale-95"
              title="رجوع للواجهة الرئيسية"
            >
              <ArrowRight className="w-4 h-4" />
              <span className="hidden sm:inline">رجوع للرئيسية</span>
            </button>
          )}

          <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-blue-600 via-indigo-600 to-cyan-500 text-white flex items-center justify-center shadow-md">
            <Zap className="w-5 h-5" />
          </div>

          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-base sm:text-lg font-black text-slate-900 dark:text-white">
                مركز الأحداث والعمليات والملفات (Events & Offline/Online Hub)
              </h1>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-blue-50 dark:bg-blue-950/70 text-blue-600 dark:text-blue-400 font-bold border border-blue-200 dark:border-blue-900">
                الحفظ المباشر اللحظي
              </span>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              إضافة وتطوير وحفظ العمليات والملفات والمستندات فورياً بإنترنت أو بدون إنترنت مع المزامنة التلقائية.
            </p>
          </div>
        </div>

        {/* Connectivity Status & Simulation Controls */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Online / Offline Status Badge */}
          <div
            className={`px-3 py-1.5 rounded-2xl border flex items-center gap-2 text-xs font-bold shadow-xs ${
              isOnline
                ? 'bg-emerald-50 dark:bg-emerald-950/60 border-emerald-300 dark:border-emerald-800 text-emerald-700 dark:text-emerald-300'
                : 'bg-amber-50 dark:bg-amber-950/60 border-amber-300 dark:border-amber-800 text-amber-700 dark:text-amber-300'
            }`}
          >
            {isOnline ? (
              <>
                <Wifi className="w-4 h-4 text-emerald-500 animate-pulse" />
                <span>متصل بالإنترنت (Online)</span>
              </>
            ) : (
              <>
                <WifiOff className="w-4 h-4 text-amber-500" />
                <span>وضع عدم الاتصال (Offline)</span>
              </>
            )}
          </div>

          {/* Toggle Offline Simulation Button */}
          <button
            onClick={() => {
              setSimulateOffline(prev => !prev);
              onNotify?.(!simulateOffline ? 'تم تفعيل محاكاة وضع عدم الاتصال (Offline Mode)' : 'تم العودة لوضع الاتصال الطبيعي (Online Mode)', 'info');
            }}
            className="px-3 py-1.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5"
            title="تبديل محاكاة انقطاع الإنترنت لاختبار الحفظ المحلي بدون إنترنت"
          >
            {simulateOffline ? <Cloud className="w-3.5 h-3.5 text-blue-500" /> : <CloudOff className="w-3.5 h-3.5 text-amber-500" />}
            <span>{simulateOffline ? 'إنهاء محاكاة الأوفلاين' : 'محاكاة انقطاع النت'}</span>
          </button>

          {/* Sync Button */}
          {pendingCount > 0 && (
            <button
              onClick={handleSyncPending}
              disabled={isSyncing || !isOnline}
              className={`px-3 py-1.5 bg-amber-500 hover:bg-amber-600 text-white rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer shadow-sm ${
                !isOnline ? 'opacity-50 cursor-not-allowed' : ''
              }`}
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin' : ''}`} />
              <span>مزامنة ({pendingCount})</span>
            </button>
          )}

          {/* New Event Button */}
          <button
            onClick={handleOpenAddModal}
            className="px-4 py-2 bg-blue-600 hover:bg-blue-500 active:scale-95 text-white rounded-2xl text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-md transition-all"
          >
            <Plus className="w-4 h-4" />
            <span>إضافة عملية / ملف جديد</span>
          </button>
        </div>
      </div>

      {/* 4 Stats Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs flex items-center justify-between">
          <div>
            <div className="text-[11px] text-slate-400 font-medium">إجمالي السجلات والأحداث</div>
            <div className="text-xl font-black font-mono text-slate-900 dark:text-white mt-1">
              {events.length}
            </div>
            <div className="text-[10px] text-emerald-500 font-bold flex items-center gap-1 mt-0.5">
              <Check className="w-3 h-3" />
              <span>محفوظة ومؤمنة محلياً</span>
            </div>
          </div>
          <div className="w-10 h-10 rounded-xl bg-blue-50 dark:bg-blue-950 text-blue-600 dark:text-blue-400 flex items-center justify-center">
            <Layers className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs flex items-center justify-between">
          <div>
            <div className="text-[11px] text-slate-400 font-medium">سجلات متزامنة بالكامل</div>
            <div className="text-xl font-black font-mono text-emerald-600 dark:text-emerald-400 mt-1">
              {syncedCount}
            </div>
            <div className="text-[10px] text-slate-400 mt-0.5">مع المخدم السحابي</div>
          </div>
          <div className="w-10 h-10 rounded-xl bg-emerald-50 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
            <Cloud className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs flex items-center justify-between">
          <div>
            <div className="text-[11px] text-slate-400 font-medium">سجلات بانتظار المزامنة (Offline)</div>
            <div className="text-xl font-black font-mono text-amber-600 dark:text-amber-400 mt-1">
              {pendingCount}
            </div>
            <div className="text-[10px] text-amber-500 font-bold mt-0.5">
              {pendingCount > 0 ? 'محفوظة بأمان محلياً' : 'لا توجد معلقات'}
            </div>
          </div>
          <div className="w-10 h-10 rounded-xl bg-amber-50 dark:bg-amber-950 text-amber-600 dark:text-amber-400 flex items-center justify-center">
            <HardDrive className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs flex items-center justify-between">
          <div>
            <div className="text-[11px] text-slate-400 font-medium">الملفات والمرفقات المحفوظة</div>
            <div className="text-xl font-black font-mono text-purple-600 dark:text-purple-400 mt-1">
              {filesCount}
            </div>
            <div className="text-[10px] text-purple-500 font-bold mt-0.5">PDF، عقود، إيصالات</div>
          </div>
          <div className="w-10 h-10 rounded-xl bg-purple-50 dark:bg-purple-950 text-purple-600 dark:text-purple-400 flex items-center justify-center">
            <Paperclip className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* Search, Filters & Quick Actions Bar */}
      <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
        {/* Search Input */}
        <div className="relative flex-1">
          <Search className="w-4 h-4 absolute right-3.5 top-3 text-slate-400" />
          <input
            type="text"
            placeholder="ابحث في الأحداث، العمليات، الملفات، أرقام المراجع..."
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            className="w-full pl-4 pr-10 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-800 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:border-blue-500 transition-colors"
          />
        </div>

        {/* Category Filter */}
        <div className="flex flex-wrap items-center gap-2">
          <div className="flex items-center gap-1 text-xs">
            <Filter className="w-3.5 h-3.5 text-slate-400" />
            <span className="text-slate-400">التصنيف:</span>
            <select
              value={selectedCategory}
              onChange={e => setSelectedCategory(e.target.value)}
              className="bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs rounded-xl px-2.5 py-1.5 text-slate-800 dark:text-slate-200 focus:outline-none"
            >
              <option value="all">كافة التصنيفات</option>
              <option value="transaction">عمليات مالية</option>
              <option value="file">ملفات ومستندات</option>
              <option value="system_dev">تطوير وترقيات</option>
              <option value="audit_risk">تدقيق ومخاطر</option>
              <option value="agent_operation">عمليات الوكلاء</option>
              <option value="emergency">طوارئ سيادية</option>
            </select>
          </div>

          {/* Status Filter */}
          <select
            value={selectedStatus}
            onChange={e => setSelectedStatus(e.target.value)}
            className="bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs rounded-xl px-2.5 py-1.5 text-slate-800 dark:text-slate-200 focus:outline-none"
          >
            <option value="all">كافة الحالات</option>
            <option value="synced">متزامنة سحابياً (Synced)</option>
            <option value="pending_sync">معلقة للأوفلاين (Pending Offline)</option>
          </select>

          {/* Export JSON Button */}
          <button
            onClick={handleExportData}
            className="px-3 py-1.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer shadow-xs"
            title="تصدير نسخة احتياطية من كافة الأحداث والملفات بصيغة JSON"
          >
            <Download className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">تصدير النسخة الاحتياطية</span>
          </button>
        </div>
      </div>

      {/* Events List / Cards Grid */}
      <div className="space-y-3">
        {filteredEvents.length === 0 ? (
          <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl border border-slate-200 dark:border-slate-800 text-center space-y-3">
            <div className="w-12 h-12 rounded-2xl bg-slate-100 dark:bg-slate-800 text-slate-400 mx-auto flex items-center justify-center">
              <FileText className="w-6 h-6" />
            </div>
            <div className="text-sm font-bold text-slate-700 dark:text-slate-300">
              لا توجد أحداث أو عمليات مطابقة للبحث
            </div>
            <p className="text-xs text-slate-400 max-w-sm mx-auto">
              يمكنك إضافة عملية جديدة أو مستند لحفظه فورياً سواء كنت متصلاً بالإنترنت أو في وضع الأوفلاين.
            </p>
            <button
              onClick={handleOpenAddModal}
              className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold inline-flex items-center gap-1.5 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>إضافة أول عملية / ملف الآن</span>
            </button>
          </div>
        ) : (
          filteredEvents.map(evt => (
            <div
              key={evt.id}
              className="bg-white dark:bg-slate-900 p-4 sm:p-5 rounded-2xl border border-slate-200 dark:border-slate-800 hover:border-blue-400/40 dark:hover:border-blue-500/40 shadow-xs hover:shadow-md transition-all space-y-3"
            >
              {/* Event Header */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 dark:border-slate-800 pb-3">
                <div className="flex items-center gap-2.5">
                  <span className="font-mono text-xs font-black text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-950/80 px-2 py-0.5 rounded-lg border border-blue-200 dark:border-blue-900">
                    {evt.id}
                  </span>
                  <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                    {evt.title}
                  </h3>
                  {renderCategoryBadge(evt.category)}
                  {evt.priority === 'high' && (
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-red-100 dark:bg-red-950 text-red-600 dark:text-red-400">
                      عاجل
                    </span>
                  )}
                </div>

                {/* Status & Timestamp */}
                <div className="flex items-center gap-2 text-xs">
                  {evt.status === 'synced' ? (
                    <span className="flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-emerald-50 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400 font-medium text-[11px]">
                      <Cloud className="w-3.5 h-3.5" />
                      <span>متزامن سحابياً</span>
                    </span>
                  ) : (
                    <span className="flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-amber-50 dark:bg-amber-950 text-amber-600 dark:text-amber-400 font-medium text-[11px]">
                      <HardDrive className="w-3.5 h-3.5" />
                      <span>محفوظ محلياً (Offline)</span>
                    </span>
                  )}

                  <span className="text-slate-400 text-[11px] font-mono flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    <span>{new Date(evt.timestamp).toLocaleString('ar-EG', { dateStyle: 'short', timeStyle: 'short' })}</span>
                  </span>

                  {/* Actions: Edit, Delete */}
                  <div className="flex items-center gap-1 mr-2">
                    <button
                      onClick={() => handleOpenEditModal(evt)}
                      className="p-1.5 rounded-lg text-slate-400 hover:text-blue-600 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                      title="تعديل وتطوير السجل"
                    >
                      <Edit3 className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => handleDeleteEvent(evt.id, evt.title)}
                      className="p-1.5 rounded-lg text-slate-400 hover:text-red-600 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                      title="حذف السجل"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>

              {/* Event Content & Amount */}
              <div className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed flex flex-col md:flex-row md:items-center justify-between gap-3">
                <p className="flex-1">{evt.notes}</p>
                {evt.amount !== undefined && (
                  <div className="shrink-0 p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700/80 font-mono text-left">
                    <div className="text-[10px] text-slate-400">قيمة العملية</div>
                    <div className="text-sm font-black text-emerald-600 dark:text-emerald-400">
                      {evt.amount.toLocaleString()} {evt.currency || 'USD'}
                    </div>
                  </div>
                )}
              </div>

              {/* File Attachment Pill (if exists) */}
              {evt.fileAttachment && (
                <div className="pt-1 flex items-center justify-between p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-800 text-xs">
                  <div className="flex items-center gap-2">
                    <div className="p-1.5 rounded-lg bg-blue-100 dark:bg-blue-950 text-blue-600 dark:text-blue-400">
                      <Paperclip className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="font-bold text-slate-800 dark:text-slate-200">
                        {evt.fileAttachment.name}
                      </div>
                      <div className="text-[10px] text-slate-400 font-mono">
                        الحجم: {evt.fileAttachment.size} • النوع: {evt.fileAttachment.type}
                      </div>
                    </div>
                  </div>

                  {evt.fileAttachment.dataUrl && (
                    <a
                      href={evt.fileAttachment.dataUrl}
                      download={evt.fileAttachment.name}
                      className="px-2.5 py-1 bg-white dark:bg-slate-700 hover:bg-slate-100 text-blue-600 dark:text-blue-300 rounded-lg font-bold text-[11px] flex items-center gap-1 border border-slate-200 dark:border-slate-600 shadow-xs cursor-pointer transition-colors"
                    >
                      <Download className="w-3 h-3" />
                      <span>تنزيل الملف</span>
                    </a>
                  )}
                </div>
              )}

              {/* Version & Sync History Badge */}
              <div className="text-[10px] text-slate-400 font-mono flex items-center justify-between pt-1">
                <span>الإصدار v{evt.version || 1} {evt.lastModified ? `(تم التحديث: ${new Date(evt.lastModified).toLocaleTimeString('ar-EG')})` : ''}</span>
                <span>الحفظ المحلي: FIPS-140-2 Level 3 Secure Encrypted Store</span>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Modal: Add or Edit Operation / File Event */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl max-w-xl w-full p-5 sm:p-6 shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto">
            {/* Modal Header */}
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-blue-600 text-white flex items-center justify-center">
                  {editingEvent ? <Edit3 className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
                </div>
                <div>
                  <h3 className="text-base font-black text-slate-900 dark:text-white">
                    {editingEvent ? 'تعديل وتطوير العملية / الملف' : 'إضافة وحفظ عملية أو حدث جديد'}
                  </h3>
                  <p className="text-[11px] text-slate-400">
                    يحفظ فورياً داخل قاعدة البيانات سواء بوجود إنترنت أو بدون إنترنت
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsAddModalOpen(false)}
                className="p-1.5 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Modal Form */}
            <form onSubmit={handleSaveEvent} className="space-y-4 text-xs">
              {/* Title */}
              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-bold mb-1">
                  عنوان العملية أو الحدث <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="مثال: تسوية تحويل بنكي، إرفاق رخصة تاجر، ترقية نظام..."
                  value={formTitle}
                  onChange={e => setFormTitle(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:outline-none focus:border-blue-500"
                />
              </div>

              {/* Category & Priority */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-bold mb-1">
                    تصنيف العملية
                  </label>
                  <select
                    value={formCategory}
                    onChange={e => setFormCategory(e.target.value as any)}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:outline-none focus:border-blue-500"
                  >
                    <option value="transaction">معاملة مالية</option>
                    <option value="file">مستند / ملف مرفق</option>
                    <option value="system_dev">تطوير وترقية نظام</option>
                    <option value="audit_risk">تدقيق ومخاطر</option>
                    <option value="agent_operation">عملية وكيل ميداني</option>
                    <option value="emergency">طوارئ سيادية</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-bold mb-1">
                    مستوى الأولوية
                  </label>
                  <select
                    value={formPriority}
                    onChange={e => setFormPriority(e.target.value as any)}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:outline-none focus:border-blue-500"
                  >
                    <option value="medium">متوسطة</option>
                    <option value="high">عاجلة وقصوى</option>
                    <option value="low">عادية / أرشفة</option>
                  </select>
                </div>
              </div>

              {/* Optional Amount & Currency (if financial) */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="sm:col-span-2">
                  <label className="block text-slate-700 dark:text-slate-300 font-bold mb-1">
                    المبلغ المالي (اختياري)
                  </label>
                  <input
                    type="number"
                    step="any"
                    placeholder="0.00"
                    value={formAmount}
                    onChange={e => setFormAmount(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:outline-none focus:border-blue-500 font-mono"
                  />
                </div>
                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-bold mb-1">
                    العملة
                  </label>
                  <select
                    value={formCurrency}
                    onChange={e => setFormCurrency(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:outline-none focus:border-blue-500 font-bold"
                  >
                    <option value="USD">USD (دولار)</option>
                    <option value="YER">YER (ريال يمني)</option>
                    <option value="SAR">SAR (ريال سعودي)</option>
                  </select>
                </div>
              </div>

              {/* Notes / Details */}
              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-bold mb-1">
                  الملاحظات والتفاصيل
                </label>
                <textarea
                  rows={3}
                  placeholder="اكتب تفاصيل العملية أو الحدث هنا..."
                  value={formNotes}
                  onChange={e => setFormNotes(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:outline-none focus:border-blue-500"
                />
              </div>

              {/* File Attachment Input */}
              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-bold mb-1">
                  إرفاق ملف أو مستند (يحفظ محلياً فورياً)
                </label>
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleFileChange}
                  className="hidden"
                />

                {formFile ? (
                  <div className="flex items-center justify-between p-3 rounded-xl bg-blue-50 dark:bg-blue-950/50 border border-blue-200 dark:border-blue-900">
                    <div className="flex items-center gap-2">
                      <Paperclip className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                      <div>
                        <div className="font-bold text-slate-800 dark:text-slate-200">{formFile.name}</div>
                        <div className="text-[10px] text-slate-400">{formFile.size}</div>
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => setFormFile(undefined)}
                      className="p-1 rounded text-red-500 hover:bg-red-50 dark:hover:bg-red-950/50 cursor-pointer"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ) : (
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="w-full p-4 border-2 border-dashed border-slate-300 dark:border-slate-700 hover:border-blue-500 rounded-2xl flex flex-col items-center justify-center gap-1.5 text-slate-500 dark:text-slate-400 cursor-pointer transition-colors"
                  >
                    <Upload className="w-5 h-5 text-blue-500" />
                    <span className="font-bold">انقر لاختيار ملف من جهازك</span>
                    <span className="text-[10px]">يدعم PDF, صور، مستندات، JSON</span>
                  </button>
                )}
              </div>

              {/* Submit Buttons */}
              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-300 font-bold cursor-pointer"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold flex items-center gap-1.5 cursor-pointer shadow-md"
                >
                  <Save className="w-4 h-4" />
                  <span>{editingEvent ? 'تحديث وتطوير السجل' : 'حفظ فوري مباشر (Instant Save)'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
