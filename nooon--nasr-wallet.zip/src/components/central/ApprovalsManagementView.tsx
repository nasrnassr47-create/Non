// src/components/central/ApprovalsManagementView.tsx
import React, { useState, useEffect } from 'react';
import { 
  FileCheck2, 
  CheckCircle2, 
  XCircle, 
  AlertTriangle, 
  Clock, 
  User, 
  DollarSign, 
  ShieldAlert,
  Search,
  Check,
  Building2,
  Sparkles,
  ArrowRight
} from 'lucide-react';
import { ApprovalItem } from '../../types/central';
import { initialApprovals } from '../../data/centralData';
import { storage } from '../../lib/storage';
import { useAuth } from '../../context/AuthContext';

interface Props {
  onNotify?: (msg: string) => void;
  onBackToHome?: () => void;
}

export const ApprovalsManagementView: React.FC<Props> = ({ onNotify, onBackToHome }) => {
  const { updateUserStatus, allUsers } = useAuth();
  const [approvals, setApprovals] = useState<ApprovalItem[]>(() => {
    return storage.get<ApprovalItem[]>('central_approvals_list', initialApprovals);
  });

  // Sync with persistent storage
  useEffect(() => {
    storage.set('central_approvals_list', approvals);
  }, [approvals]);

  const handleDecision = (id: string, decision: 'approved' | 'rejected') => {
    setApprovals(prev => prev.map(a => {
      if (a.id === id) {
        const text = decision === 'approved' ? 'تمت الموافقة والاعتماد للطلب' : 'تم رفض الطلب';
        if (onNotify) onNotify(`${text}: ${a.details}`);

        // If client registration or subscription, activate user status in AuthContext
        if (decision === 'approved') {
          if (a.type === 'client_registration' || a.type === 'subscription_request') {
            const rawPhone = a.requesterPhone.replace(/\D/g, '');
            const matchedUser = allUsers.find(u => 
              (rawPhone && u.phone.replace(/\D/g, '').includes(rawPhone)) || 
              u.name === a.requesterName
            );
            if (matchedUser) {
              updateUserStatus(matchedUser.id, 'active');
            }
          }
        }

        return { ...a, status: decision };
      }
      return a;
    }));
  };

  const pendingList = approvals.filter(a => a.status === 'pending');
  const historyList = approvals.filter(a => a.status !== 'pending');

  return (
    <div className="space-y-4">
      {/* Header Banner */}
      <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          {onBackToHome && (
            <button
              onClick={onBackToHome}
              className="p-2 sm:px-3 sm:py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-xl flex items-center gap-1.5 text-xs font-bold transition-all cursor-pointer shadow-xs shrink-0"
              title="رجوع للرئيسية"
            >
              <ArrowRight className="w-4 h-4" />
              <span className="hidden sm:inline">رجوع للرئيسية</span>
            </button>
          )}
          <div>
            <h2 className="text-lg font-black text-slate-900 dark:text-white flex items-center gap-2">
              <FileCheck2 className="w-5 h-5 text-blue-600" />
              <span>طابور الموافقات والتحقق الثنائي (Approvals Queue)</span>
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              مراجعة الحوالات الكبيرة، ترقيات السقف المالي، وتوثيق الحسابات قبل التنفيذ النهائي
            </p>
          </div>
        </div>

        <div className="px-3 py-1.5 bg-amber-50 dark:bg-amber-950/60 border border-amber-300 dark:border-amber-800 text-amber-700 dark:text-amber-300 rounded-xl text-xs font-bold flex items-center gap-1.5">
          <Clock className="w-4 h-4" />
          <span>{pendingList.length} طلبات قيد الانتظار</span>
        </div>
      </div>

      {/* Pending Approvals Cards */}
      <div className="space-y-3">
        {pendingList.length === 0 ? (
          <div className="p-8 text-center bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 text-slate-400 text-xs">
            <CheckCircle2 className="w-8 h-8 text-emerald-500 mx-auto mb-2" />
            <span>لا توجد طلبات معلقة حالياً. تم اعتماد ومراجعة كافة العمليات!</span>
          </div>
        ) : (
          pendingList.map(item => (
            <div 
              key={item.id}
              className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4"
            >
              <div className="flex items-start gap-3">
                <div className={`p-2.5 rounded-xl shrink-0 mt-1 ${
                  item.riskLevel === 'high' 
                    ? 'bg-red-50 dark:bg-red-950 text-red-600 border border-red-300 dark:border-red-800' 
                    : item.riskLevel === 'medium'
                    ? 'bg-amber-50 dark:bg-amber-950 text-amber-600 border border-amber-300 dark:border-amber-800'
                    : 'bg-blue-50 dark:bg-blue-950 text-blue-600 border border-blue-300 dark:border-blue-800'
                }`}>
                  <ShieldAlert className="w-5 h-5" />
                </div>
                <div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-bold text-slate-900 dark:text-white text-xs">{item.requesterName}</span>
                    <span className="text-[10px] text-slate-400 font-mono">({item.requesterPhone})</span>
                    
                    {item.type === 'subscription_request' && (
                      <span className="text-[10px] px-2 py-0.5 rounded-full font-bold bg-purple-100 dark:bg-purple-900/60 text-purple-700 dark:text-purple-200 border border-purple-300 dark:border-purple-700 flex items-center gap-1">
                        <Sparkles className="w-3 h-3 text-purple-500" />
                        <span>طلب اشتراك مؤسسي</span>
                      </span>
                    )}

                    {item.type === 'client_registration' && (
                      <span className="text-[10px] px-2 py-0.5 rounded-full font-bold bg-blue-100 dark:bg-blue-900/60 text-blue-700 dark:text-blue-200 border border-blue-300 dark:border-blue-700 flex items-center gap-1">
                        <User className="w-3 h-3 text-blue-500" />
                        <span>تسجيل عميل جديد</span>
                      </span>
                    )}

                    <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${
                      item.riskLevel === 'high' ? 'bg-red-100 dark:bg-red-900 text-red-700 dark:text-red-200' :
                      item.riskLevel === 'medium' ? 'bg-amber-100 dark:bg-amber-900 text-amber-700 dark:text-amber-200' :
                      'bg-emerald-100 dark:bg-emerald-900 text-emerald-700 dark:text-emerald-200'
                    }`}>
                      مستوى المخاطرة: {item.riskLevel === 'high' ? 'مرتفع' : item.riskLevel === 'medium' ? 'متوسط' : 'منخفض'}
                    </span>
                  </div>
                  <div className="text-xs text-slate-600 dark:text-slate-300 mt-1 font-semibold">{item.details}</div>
                  <div className="flex items-center gap-4 text-[11px] text-slate-400 mt-1 font-mono">
                    {item.amount !== '-' && <span>المبلغ: <strong className="text-blue-600 dark:text-blue-400">{item.amount}</strong></span>}
                    <span>الوقت: {item.time}</span>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center gap-2 self-end md:self-center shrink-0">
                <button
                  onClick={() => handleDecision(item.id, 'rejected')}
                  className="px-3 py-1.5 rounded-xl border border-red-200 dark:border-red-900 text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-950 text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5"
                >
                  <XCircle className="w-4 h-4" />
                  <span>رفض الطلب</span>
                </button>
                <button
                  onClick={() => handleDecision(item.id, 'approved')}
                  className="px-4 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 shadow-md"
                >
                  <Check className="w-4 h-4" />
                  <span>اعتماد وتمرير</span>
                </button>
              </div>
            </div>
          ))
        )}
      </div>

      {/* History List */}
      {historyList.length > 0 && (
        <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-2">
          <h3 className="text-xs font-bold text-slate-400">سجل القرارات الأخيرة</h3>
          <div className="divide-y divide-slate-100 dark:divide-slate-800">
            {historyList.map(item => (
              <div key={item.id} className="py-2.5 flex items-center justify-between text-xs">
                <div>
                  <span className="font-bold text-slate-800 dark:text-slate-200">{item.requesterName}</span>
                  <span className="text-slate-400 mr-2">- {item.details}</span>
                </div>
                <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                  item.status === 'approved' 
                    ? 'bg-emerald-50 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400 border border-emerald-300 dark:border-emerald-800'
                    : 'bg-red-50 dark:bg-red-950 text-red-600 dark:text-red-400 border border-red-300 dark:border-red-800'
                }`}>
                  {item.status === 'approved' ? 'تم الاعتماد' : 'تم الرفض'}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
