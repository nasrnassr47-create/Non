// src/components/central/Sovereign42BranchesViewer.tsx
// مستعرض شجرة الـ 42 فرع السيادية الكاملة 100% لنصر والت V2

import React, { useState, useMemo } from 'react';
import {
  Crown,
  Smartphone,
  Users,
  Briefcase,
  Store,
  ShieldAlert,
  Wallet,
  Scale,
  ArrowLeftRight,
  Coins,
  HandCoins,
  Building,
  Percent,
  QrCode,
  Banknote,
  Building2,
  FileSpreadsheet,
  FileUp,
  BellRing,
  ScanFace,
  KeyRound,
  FileCheck2,
  SlidersHorizontal,
  Workflow,
  DoorClosed,
  Database,
  Zap,
  HardDrive,
  Search,
  Fingerprint,
  Lock,
  Server,
  ArchiveRestore,
  Sparkles,
  SmartphoneNfc,
  FileDown,
  GitFork,
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  ExternalLink,
  Filter,
  Layers,
  ArrowRight,
  ShieldCheck,
  FolderGit2,
  HeartHandshake
} from 'lucide-react';
import { SOVEREIGN_42_BRANCHES, SovereignBranch } from '../../data/sovereign42Tree';
import { CentralSidebarItem } from '../../types/central';

interface Props {
  onNavigateToModule?: (target: string) => void;
  onOpenDownloadModal?: () => void;
  onRequestRoleApp?: (role: string) => void;
}

export const Sovereign42BranchesViewer: React.FC<Props> = ({
  onNavigateToModule,
  onOpenDownloadModal,
  onRequestRoleApp
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedLevel, setSelectedLevel] = useState<number | 'all'>('all');
  const [expandedBranch, setExpandedBranch] = useState<number | null>(null);

  // Icon mapping helper
  const renderBranchIcon = (iconName: string, className = "w-5 h-5") => {
    switch (iconName) {
      case 'Crown': return <Crown className={className} />;
      case 'Smartphone': return <Smartphone className={className} />;
      case 'Users': return <Users className={className} />;
      case 'HeartHandshake': return <HeartHandshake className={className} />;
      case 'Briefcase': return <Briefcase className={className} />;
      case 'Store': return <Store className={className} />;
      case 'ShieldAlert': return <ShieldAlert className={className} />;
      case 'Wallet': return <Wallet className={className} />;
      case 'Scale': return <Scale className={className} />;
      case 'ArrowLeftRight': return <ArrowLeftRight className={className} />;
      case 'Coins': return <Coins className={className} />;
      case 'FolderGit2': return <FolderGit2 className={className} />;
      case 'HandCoins': return <HandCoins className={className} />;
      case 'Building': return <Building className={className} />;
      case 'Percent': return <Percent className={className} />;
      case 'QrCode': return <QrCode className={className} />;
      case 'Banknote': return <Banknote className={className} />;
      case 'Building2': return <Building2 className={className} />;
      case 'FileSpreadsheet': return <FileSpreadsheet className={className} />;
      case 'FileUp': return <FileUp className={className} />;
      case 'BellRing': return <BellRing className={className} />;
      case 'ScanFace': return <ScanFace className={className} />;
      case 'KeyRound': return <KeyRound className={className} />;
      case 'FileCheck2': return <FileCheck2 className={className} />;
      case 'SlidersHorizontal': return <SlidersHorizontal className={className} />;
      case 'Workflow': return <Workflow className={className} />;
      case 'DoorClosed': return <DoorClosed className={className} />;
      case 'Database': return <Database className={className} />;
      case 'Zap': return <Zap className={className} />;
      case 'HardDrive': return <HardDrive className={className} />;
      case 'Search': return <Search className={className} />;
      case 'Fingerprint': return <Fingerprint className={className} />;
      case 'Lock': return <Lock className={className} />;
      case 'Server': return <Server className={className} />;
      case 'ArchiveRestore': return <ArchiveRestore className={className} />;
      case 'Sparkles': return <Sparkles className={className} />;
      case 'SmartphoneNfc': return <SmartphoneNfc className={className} />;
      case 'FileDown': return <FileDown className={className} />;
      case 'GitFork': return <GitFork className={className} />;
      default: return <Layers className={className} />;
    }
  };

  // Flattened branches for filtering & searching
  const allBranches = useMemo(() => {
    return SOVEREIGN_42_BRANCHES.flatMap(lvl => lvl.branches);
  }, []);

  const filteredLevels = useMemo(() => {
    return SOVEREIGN_42_BRANCHES.map(lvl => {
      if (selectedLevel !== 'all' && lvl.levelNumber !== selectedLevel) {
        return null;
      }
      const matchedBranches = lvl.branches.filter(b => {
        const query = searchQuery.trim().toLowerCase();
        if (!query) return true;
        return (
          b.number.toString().includes(query) ||
          b.title.toLowerCase().includes(query) ||
          b.titleEn.toLowerCase().includes(query) ||
          b.description.toLowerCase().includes(query) ||
          b.details.some(d => d.toLowerCase().includes(query))
        );
      });
      if (matchedBranches.length === 0) return null;
      return {
        ...lvl,
        branches: matchedBranches
      };
    }).filter(Boolean) as typeof SOVEREIGN_42_BRANCHES;
  }, [searchQuery, selectedLevel]);

  const handleActionClick = (branch: SovereignBranch) => {
    if (!branch.actionTarget) return;

    if (branch.actionTarget === 'download_modal' && onOpenDownloadModal) {
      onOpenDownloadModal();
    } else if (branch.actionTarget.startsWith('apps:') && onRequestRoleApp) {
      const role = branch.actionTarget.split(':')[1];
      onRequestRoleApp(role);
    } else if (onNavigateToModule) {
      onNavigateToModule(branch.actionTarget);
    }
  };

  return (
    <div className="space-y-6 text-right" dir="rtl">
      {/* Top Banner: Sovereign Header */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-slate-900 via-blue-950 to-slate-900 border border-blue-500/30 p-6 md:p-8 text-white shadow-xl">
        <div className="absolute top-0 left-0 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 right-0 w-80 h-80 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/20 border border-blue-400/40 text-blue-300 text-xs font-bold">
              <Crown className="w-3.5 h-3.5 text-amber-400" />
              <span>منظومة نصر والت - النظام السيادي V2</span>
              <span className="bg-emerald-500/20 text-emerald-400 px-2 py-0.5 rounded-full text-[10px]">
                42 فرعاً مكتملاً 100%
              </span>
            </div>
            <h1 className="text-2xl md:text-3xl font-black text-white tracking-tight">
              خارطة الفروع الـ 42 السيادية الكاملة
            </h1>
            <p className="text-xs md:text-sm text-slate-300 max-w-2xl leading-relaxed">
              من الجذر السيادي حتى المستوى الثالث للبنية التحتية. كل فرع وخدمة وتطبيق موثق ومربوط بروابط تنفيذية لحظية مباشرة.
            </p>
          </div>

          {/* Quick Metrics Bar */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 shrink-0">
            <div className="bg-white/5 border border-white/10 rounded-2xl p-3 text-center">
              <div className="text-[11px] text-slate-400 font-medium">الجذر</div>
              <div className="text-lg font-black text-white">1</div>
              <div className="text-[10px] text-blue-400 font-mono">السيادي</div>
            </div>
            <div className="bg-white/5 border border-white/10 rounded-2xl p-3 text-center">
              <div className="text-[11px] text-slate-400 font-medium">التطبيقات</div>
              <div className="text-lg font-black text-emerald-400">7</div>
              <div className="text-[10px] text-emerald-300 font-mono">ميدانية وإدارية</div>
            </div>
            <div className="bg-white/5 border border-white/10 rounded-2xl p-3 text-center">
              <div className="text-[11px] text-slate-400 font-medium">الخدمات</div>
              <div className="text-lg font-black text-amber-400">22</div>
              <div className="text-[10px] text-amber-300 font-mono">نواة مصغرة</div>
            </div>
            <div className="bg-white/5 border border-white/10 rounded-2xl p-3 text-center">
              <div className="text-[11px] text-slate-400 font-medium">البنية التحتية</div>
              <div className="text-lg font-black text-cyan-400">12</div>
              <div className="text-[10px] text-cyan-300 font-mono">أفرع سيادية</div>
            </div>
          </div>
        </div>

        {/* Quick Search & Filter Controls */}
        <div className="mt-6 pt-6 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="relative w-full sm:w-80">
            <Search className="w-4 h-4 absolute right-3.5 top-3 text-slate-400" />
            <input
              type="text"
              placeholder="ابحث برقم الفرع أو الاسم (مثلاً: 4 أو Family أو 31)..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-4 pr-10 py-2 bg-slate-800/80 border border-slate-700/80 rounded-xl text-xs text-white placeholder-slate-400 focus:outline-none focus:border-blue-400 transition-colors shadow-inner"
            />
          </div>

          <div className="flex items-center gap-1.5 overflow-x-auto w-full sm:w-auto pb-1 sm:pb-0">
            <button
              onClick={() => setSelectedLevel('all')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
                selectedLevel === 'all'
                  ? 'bg-blue-600 text-white shadow'
                  : 'bg-slate-800/80 text-slate-300 hover:bg-slate-700'
              }`}
            >
              الكل (42 فرعاً)
            </button>
            <button
              onClick={() => setSelectedLevel(0)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
                selectedLevel === 0
                  ? 'bg-blue-600 text-white shadow'
                  : 'bg-slate-800/80 text-slate-300 hover:bg-slate-700'
              }`}
            >
              الجذر (1)
            </button>
            <button
              onClick={() => setSelectedLevel(1)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
                selectedLevel === 1
                  ? 'bg-emerald-600 text-white shadow'
                  : 'bg-slate-800/80 text-slate-300 hover:bg-slate-700'
              }`}
            >
              التطبيقات (7)
            </button>
            <button
              onClick={() => setSelectedLevel(2)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
                selectedLevel === 2
                  ? 'bg-amber-600 text-white shadow'
                  : 'bg-slate-800/80 text-slate-300 hover:bg-slate-700'
              }`}
            >
              الخدمات الـ 22
            </button>
            <button
              onClick={() => setSelectedLevel(3)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
                selectedLevel === 3
                  ? 'bg-cyan-600 text-white shadow'
                  : 'bg-slate-800/80 text-slate-300 hover:bg-slate-700'
              }`}
            >
              البنية التحتية (12)
            </button>
          </div>
        </div>
      </div>

      {/* Levels and Branches Rendering */}
      <div className="space-y-8">
        {filteredLevels.map((lvl) => (
          <div key={lvl.levelNumber} className="space-y-4">
            {/* Level Title Bar */}
            <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-2">
              <div className="flex items-center gap-2.5">
                <span className={`w-3 h-3 rounded-full bg-gradient-to-r ${lvl.color}`} />
                <h2 className="text-base sm:text-lg font-black text-slate-900 dark:text-white">
                  {lvl.levelTitle}
                </h2>
                <span className="text-[11px] font-mono text-slate-500 hidden sm:inline">
                  ({lvl.levelTitleEn})
                </span>
              </div>
              <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700">
                {lvl.branches.length} فروع
              </span>
            </div>

            {/* Branches Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {lvl.branches.map((b) => {
                const isExpanded = expandedBranch === b.number;
                return (
                  <div
                    key={b.number}
                    className={`rounded-2xl border transition-all duration-200 flex flex-col justify-between ${
                      isExpanded
                        ? 'bg-slate-50 dark:bg-slate-800/90 border-blue-500 shadow-md ring-1 ring-blue-500/30'
                        : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 shadow-xs'
                    }`}
                  >
                    {/* Card Header */}
                    <div className="p-4 space-y-3">
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex items-center gap-2.5">
                          <div className="w-9 h-9 rounded-xl bg-blue-50 dark:bg-blue-950/80 border border-blue-200 dark:border-blue-800/80 text-blue-600 dark:text-blue-400 flex items-center justify-center shrink-0 shadow-xs">
                            {renderBranchIcon(b.icon, "w-4 h-4")}
                          </div>
                          <div>
                            <div className="flex items-center gap-1.5">
                              <span className="text-xs font-black font-mono px-1.5 py-0.2 rounded bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700">
                                #{b.number}
                              </span>
                              {b.badge && (
                                <span className="text-[10px] font-bold px-1.5 py-0.2 rounded bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/20">
                                  {b.badge}
                                </span>
                              )}
                            </div>
                            <h3 className="text-sm font-bold text-slate-900 dark:text-white mt-1 line-clamp-1">
                              {b.title}
                            </h3>
                          </div>
                        </div>

                        <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 shrink-0 mt-1" title="نشط ومكتمل 100%" />
                      </div>

                      <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-2 leading-relaxed">
                        {b.description}
                      </p>

                      {/* Expandable Details */}
                      {isExpanded && (
                        <div className="pt-2 border-t border-slate-200/80 dark:border-slate-800/80 space-y-2 animate-in fade-in duration-150">
                          <div className="text-[11px] font-bold text-slate-700 dark:text-slate-300">
                            مكونات الفرع البرمجية والتشغيلية:
                          </div>
                          <ul className="space-y-1.5">
                            {b.details.map((detail, idx) => (
                              <li key={idx} className="flex items-start gap-1.5 text-xs text-slate-600 dark:text-slate-300">
                                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 shrink-0 mt-0.5" />
                                <span>{detail}</span>
                              </li>
                            ))}
                          </ul>
                          <div className="text-[10px] text-slate-400 font-mono pt-1">
                            الاسم التقني: {b.titleEn}
                          </div>
                        </div>
                      )}
                    </div>

                    {/* Card Actions Footer */}
                    <div className="p-3 bg-slate-50/60 dark:bg-slate-950/40 border-t border-slate-100 dark:border-slate-800/80 rounded-b-2xl flex items-center justify-between gap-2">
                      <button
                        onClick={() => setExpandedBranch(isExpanded ? null : b.number)}
                        className="text-xs text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 font-semibold flex items-center gap-1 cursor-pointer transition-colors"
                      >
                        {isExpanded ? (
                          <>
                            <span>إخفاء التفاصيل</span>
                            <ChevronUp className="w-3.5 h-3.5" />
                          </>
                        ) : (
                          <>
                            <span>عرض التفاصيل</span>
                            <ChevronDown className="w-3.5 h-3.5" />
                          </>
                        )}
                      </button>

                      {b.actionTarget && (
                        <button
                          onClick={() => handleActionClick(b)}
                          className="px-2.5 py-1 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold flex items-center gap-1 transition-all cursor-pointer shadow-xs active:scale-95"
                          title="فتح الفرع مباشرة في المنظومة"
                        >
                          <span>فتح وتشغيل</span>
                          <ExternalLink className="w-3 h-3" />
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
