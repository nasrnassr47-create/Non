// src/components/central/EnterpriseCentralDashboard.tsx
import React, { useState } from 'react';
import {
  Home,
  LayoutDashboard,
  Users,
  Wallet,
  Receipt,
  ArrowLeftRight,
  Briefcase,
  Calendar,
  Store,
  Building,
  Building2,
  CreditCard,
  ShieldAlert,
  FileCheck2,
  Scale,
  FileText,
  FileSearch,
  Bell,
  Database,
  Terminal,
  Activity,
  Beaker,
  Search,
  Settings,
  Moon,
  Sun,
  ChevronDown,
  ChevronLeft,
  Calendar as CalendarIcon,
  Clock,
  Plus,
  Send,
  QrCode,
  Globe,
  MoreHorizontal,
  TrendingUp,
  Zap,
  ShieldCheck,
  CheckCircle2,
  AlertTriangle,
  Eye,
  EyeOff,
  PhoneCall,
  Smartphone,
  Check,
  X,
  Lock,
  Unlock,
  Key,
  Sliders,
  DollarSign,
  Menu,
  ArrowRight,
  Download,
  GitFork
} from 'lucide-react';
import { useWallet } from '../../context/WalletContext';
import { useAuth } from '../../context/AuthContext';
import { CentralSidebarItem } from '../../types/central';
import { CustomersManagementView } from './CustomersManagementView';
import { ApprovalsManagementView } from './ApprovalsManagementView';
import { BanksManagementView } from './BanksManagementView';
import { PayrollManagementView } from './PayrollManagementView';
import { MasterControlPanel } from '../../features/control/MasterControlPanel';
import { SecretVaultAndDbView } from './SecretVaultAndDbView';
import { EventsAndOperationsHub } from './EventsAndOperationsHub';
import { DownloadCodeModal } from './DownloadCodeModal';
import { Sovereign42BranchesViewer } from './Sovereign42BranchesViewer';
import { InstallStandaloneModal } from '../common/InstallStandaloneModal';
import { storage } from '../../lib/storage';
import { initialApprovals } from '../../data/centralData';
import { ApprovalItem } from '../../types/central';

interface Props {
  onOpenSimulator?: () => void;
  onOpenMobileApp?: () => void;
  onOpenMobileSimulator?: () => void;
  onSelectRoleApp?: (role: string) => void;
}

export const EnterpriseCentralDashboard: React.FC<Props> = ({
  onOpenSimulator,
  onOpenMobileApp,
  onOpenMobileSimulator,
  onSelectRoleApp,
}) => {
  const handleOpenSim = () => {
    if (onOpenSimulator) onOpenSimulator();
    else if (onOpenMobileSimulator) onOpenMobileSimulator();
  };
  const { 
    wallets, 
    transactions, 
    systemControl, 
    updateWalletBalance, 
    addQuickFunds, 
    showToast,
    sendMoney,
    payBill,
    cashIn
  } = useWallet();
  const { currentUser } = useAuth();

  // Navigation State
  const [activeMenu, setActiveMenu] = useState<CentralSidebarItem>('home');
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);
  const [showBalance, setShowBalance] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedLanguage, setSelectedLanguage] = useState<'ar' | 'en'>('ar');
  const [isDarkMode, setIsDarkMode] = useState(false);

  // Active Modals for Action Strip
  const [activeActionModal, setActiveActionModal] = useState<
    'deposit' | 'transfer' | 'bill' | 'cashout' | 'qr' | 'remittance' | 'more' | 'notifications' | 'settings' | null
  >(null);
  const [isDownloadModalOpen, setIsDownloadModalOpen] = useState(false);
  const [isInstallModalOpen, setIsInstallModalOpen] = useState(false);

  // Form States for Modals
  const [actionAmount, setActionAmount] = useState('100');
  const [actionPhone, setActionPhone] = useState('');
  const [actionService, setActionService] = useState('يمن موبايل - باقات مزايا');
  const [actionNotes, setActionNotes] = useState('');

  // Total balance computation across wallets in USD equivalent
  const usdWallet = wallets.find(w => w.currency === 'USD')?.balance || 1248.65;
  const yerWallet = wallets.find(w => w.currency === 'YER')?.balance || 2450000;
  const sarWallet = wallets.find(w => w.currency === 'SAR')?.balance || 4800;

  // Sidebar navigation items matching the screenshot
  const sidebarItems: { id: CentralSidebarItem; label: string; icon: React.FC<{ className?: string }> }[] = [
    { id: 'home', label: 'الرئيسية', icon: Home },
    { id: 'sovereign_42', label: 'خارطة الفروع الـ 42 السيادية 👑', icon: GitFork },
    { id: 'events', label: 'الأحداث والعمليات (Offline/Online)', icon: Zap },
    { id: 'dashboard_control', label: 'لوحة التحكم والإعدادات', icon: LayoutDashboard },
    { id: 'vault', label: 'مخزن الأكواد والأسرار', icon: Key },
    { id: 'secret_db', label: 'قاعدة البيانات المشفرة', icon: Database },
    { id: 'customers', label: 'العملاء', icon: Users },
    { id: 'wallets', label: 'المحافظ', icon: Wallet },
    { id: 'transactions', label: 'المعاملات', icon: Receipt },
    { id: 'transfers', label: 'التحويلات', icon: ArrowLeftRight },
    { id: 'services', label: 'الخدمات المالية', icon: Briefcase },
    { id: 'payroll', label: 'الرواتب', icon: Calendar },
    { id: 'merchants', label: 'التجار', icon: Store },
    { id: 'agents', label: 'الوكلاء، والفروع', icon: Building },
    { id: 'banks', label: 'البنوك', icon: Building2 },
    { id: 'cards', label: 'البطاقات', icon: CreditCard },
    { id: 'risk', label: 'المخاطر والامتثال', icon: ShieldAlert },
    { id: 'approvals', label: 'الموافقات', icon: FileCheck2 },
    { id: 'settlements', label: 'التسويات والمطابقة', icon: Scale },
    { id: 'reports', label: 'التقارير', icon: FileText },
    { id: 'audit', label: 'التدقيق', icon: FileSearch },
    { id: 'notifications', label: 'الإشعارات', icon: Bell },
    { id: 'data_management', label: 'إدارة البيانات', icon: Database },
    { id: 'dev_center', label: 'مركز التطوير', icon: Terminal },
    { id: 'system_health', label: 'صحة النظام', icon: Activity },
  ];

  // Handler for quick actions
  const handleExecuteAction = async (e: React.FormEvent) => {
    e.preventDefault();
    const amt = Number(actionAmount);
    if (!amt || amt <= 0) return;

    if (activeActionModal === 'deposit') {
      addQuickFunds('USD', amt);
      showToast(`تم إيداع $${amt.toLocaleString()} في المحفظة المركزية بنجاح`, 'success');
      setActiveActionModal(null);
    } else if (activeActionModal === 'transfer') {
      const res = await sendMoney({
        receiverPhone: actionPhone || '777123456',
        amount: amt,
        currency: 'USD',
        notes: actionNotes || 'تحويل مركزي من لوحة الإدارة'
      });
      showToast(res.message, res.success ? 'success' : 'error');
      setActiveActionModal(null);
    } else if (activeActionModal === 'bill') {
      const res = await payBill({
        serviceName: actionService,
        amount: amt,
        currency: 'USD'
      });
      showToast(res.message, res.success ? 'success' : 'error');
      setActiveActionModal(null);
    } else if (activeActionModal === 'cashout') {
      addQuickFunds('USD', -Math.min(amt, usdWallet));
      showToast(`تم سحب $${amt.toLocaleString()} نقداً من الخزينة`, 'info');
      setActiveActionModal(null);
    }
  };

  return (
    <div className={`min-h-screen ${isDarkMode ? 'dark bg-slate-950 text-slate-100' : 'bg-[#F4F7FB] text-slate-900'} flex font-sans antialiased relative`}>
      {/* Mobile Drawer Backdrop */}
      {isMobileSidebarOpen && (
        <div 
          className="fixed inset-0 bg-black/60 backdrop-blur-xs z-40 lg:hidden"
          onClick={() => setIsMobileSidebarOpen(false)}
        />
      )}

      {/* 1. RIGHT SIDEBAR (Matching the screenshot pixel-by-pixel in RTL) */}
      <aside 
        className={`fixed lg:sticky top-0 right-0 h-screen h-[100dvh] max-h-screen z-50 bg-[#09152A] text-slate-300 flex flex-col shrink-0 border-l border-slate-800/80 shadow-2xl transition-transform duration-300 w-64 sm:w-72 overflow-hidden overscroll-contain ${
          isMobileSidebarOpen ? 'translate-x-0' : 'translate-x-full lg:translate-x-0'
        }`}
      >
        {/* Sidebar Header: Logo & Slogan & Close Button (Pinned at Top) */}
        <div className="p-4 shrink-0 border-b border-slate-800/60 bg-[#09152A]">
          <div className="flex items-center justify-between px-1">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-600 via-indigo-500 to-cyan-400 flex items-center justify-center text-white font-black text-xl shadow-lg shadow-blue-900/50 shrink-0">
                Ω
              </div>
              <div>
                <div className="font-extrabold text-white text-base tracking-tight flex items-center gap-1">
                  <span>NASR WALLET</span>
                  <span className="text-blue-400">Ω</span>
                </div>
                <div className="text-[10px] text-slate-400 font-mono tracking-wider">
                  Secure • Fast • Global
                </div>
              </div>
            </div>
            <button
              onClick={() => setIsMobileSidebarOpen(false)}
              className="lg:hidden p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 cursor-pointer transition-colors"
              title="إغلاق القائمة"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Scrollable Navigation Links (Smooth Finger Touch Scrolling Enabled) */}
        <div 
          className="flex-1 min-h-0 overflow-y-auto overscroll-contain px-3 py-3 space-y-1 touch-scroll-container"
          style={{ WebkitOverflowScrolling: 'touch', touchAction: 'pan-y' }}
        >
          <nav className="space-y-1 text-xs font-medium" style={{ touchAction: 'pan-y' }}>
            {sidebarItems.map(item => {
              const Icon = item.icon;
              const isActive = activeMenu === item.id;
              // Check if item is approvals to show pending count badge
              const pendingApprovalsCount = item.id === 'approvals' 
                ? (storage.get<ApprovalItem[]>('central_approvals_list', initialApprovals).filter(a => a.status === 'pending').length)
                : 0;

              return (
                <button
                  key={item.id}
                  style={{ touchAction: 'pan-y' }}
                  onClick={() => {
                    setActiveMenu(item.id);
                    setIsMobileSidebarOpen(false);
                  }}
                  className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl transition-all cursor-pointer select-none touch-pan-y ${
                    isActive
                      ? 'bg-blue-600 text-white font-bold shadow-md shadow-blue-900/40'
                      : 'text-slate-400 hover:text-white hover:bg-slate-800/60 active:bg-slate-800'
                  }`}
                >
                  <div className="flex items-center gap-3 pointer-events-none">
                    <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-white' : 'text-slate-400'}`} />
                    <span>{item.label}</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    {pendingApprovalsCount > 0 && (
                      <span className="px-1.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-500 text-slate-950 animate-pulse font-mono">
                        {pendingApprovalsCount}
                      </span>
                    )}
                    <ChevronLeft className={`w-3.5 h-3.5 shrink-0 pointer-events-none ${isActive ? 'text-white' : 'text-slate-600'}`} />
                  </div>
                </button>
              );
            })}
          </nav>
        </div>

        {/* Sidebar Footer Area (Pinned at Bottom) */}
        <div className="p-4 space-y-2.5 border-t border-slate-800/80 bg-[#071123] shrink-0">
          {/* Download Code Button in Sidebar */}
          <button
            onClick={() => {
              setIsMobileSidebarOpen(false);
              setIsDownloadModalOpen(true);
            }}
            className="w-full py-2.5 px-3 rounded-2xl border border-emerald-500/40 bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-300 font-bold text-xs flex items-center justify-center gap-2 transition-all cursor-pointer shadow-sm active:scale-95"
            title="تحميل الكود كاملاً (ZIP, APK, PDF, HTML)"
          >
            <Download className="w-4 h-4 text-emerald-400" />
            <span>تحميل الكود (ZIP / APK / PDF)</span>
          </button>

          {/* Golden Simulator Mode Button (Matching Screenshot) */}
          <button
            onClick={() => {
              setIsMobileSidebarOpen(false);
              if (onOpenSimulator) {
                onOpenSimulator();
              } else if (onOpenMobileSimulator) {
                onOpenMobileSimulator();
              } else {
                setActiveMenu('dashboard_control');
              }
            }}
            className="w-full py-2.5 px-3 rounded-2xl border border-amber-500/60 bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 font-bold text-xs flex items-center justify-center gap-2 transition-all cursor-pointer shadow-sm active:scale-95"
          >
            <Beaker className="w-4 h-4 text-amber-400" />
            <span>وضع المحاكي المالي</span>
          </button>

          {/* Copyright & Version */}
          <div className="text-center text-[10px] text-slate-500 font-mono space-y-0.5">
            <div className="flex items-center justify-center gap-1 text-slate-400">
              <ShieldCheck className="w-3 h-3 text-blue-400" />
              <span>NASR WALLET Ω</span>
              <span className="text-[9px] bg-slate-800 text-slate-300 px-1 rounded">v15.0.0</span>
            </div>
            <div>جميع الحقوق محفوظة 2025 ©</div>
          </div>
        </div>
      </aside>

      {/* 2. MAIN WORKSPACE */}
      <div className="flex-1 flex flex-col min-w-0 overflow-y-auto">
        {/* Top Header Bar */}
        <header className="bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 px-3 sm:px-6 py-3 flex items-center justify-between gap-2 sm:gap-4 sticky top-0 z-30 shadow-xs">
          {/* Right: Sidebar Toggle & Events Hub Quick Button */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsMobileSidebarOpen(prev => !prev)}
              className="p-2 sm:px-3 sm:py-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-bold flex items-center gap-1.5 cursor-pointer transition-all shadow-xs shrink-0"
              title="إظهار / إخفاء القائمة الجانبية"
            >
              {isMobileSidebarOpen ? <X className="w-4 h-4 text-red-500" /> : <Menu className="w-4 h-4 text-blue-600 dark:text-blue-400" />}
              <span className="hidden sm:inline">القائمة</span>
            </button>

            <button
              onClick={() => setActiveMenu('events')}
              className={`px-2.5 sm:px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer shadow-xs shrink-0 ${
                activeMenu === 'events'
                  ? 'bg-blue-600 text-white'
                  : 'bg-blue-50 dark:bg-blue-950/70 text-blue-600 dark:text-blue-300 hover:bg-blue-100 dark:hover:bg-blue-900 border border-blue-200 dark:border-blue-800'
              }`}
              title="مركز الأحداث والعمليات والملفات (حفظ فوري - أوفلاين/أونلاين)"
            >
              <Zap className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
              <span className="hidden md:inline">الأحداث والعمليات</span>
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            </button>

            {/* Quick Button for 42 Sovereign Branches */}
            <button
              onClick={() => setActiveMenu('sovereign_42')}
              className={`px-2.5 sm:px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer shadow-xs shrink-0 ${
                activeMenu === 'sovereign_42'
                  ? 'bg-gradient-to-r from-amber-600 to-yellow-600 text-white shadow-md'
                  : 'bg-amber-50 dark:bg-amber-950/40 text-amber-700 dark:text-amber-300 hover:bg-amber-100 dark:hover:bg-amber-900/60 border border-amber-300 dark:border-amber-700/60'
              }`}
              title="خارطة الفروع الـ 42 السيادية كاملة 100%"
            >
              <GitFork className="w-3.5 h-3.5 text-amber-500" />
              <span className="hidden sm:inline">الـ 42 فرعاً</span>
              <span className="text-[10px] font-mono bg-amber-500/20 text-amber-700 dark:text-amber-300 px-1 rounded font-bold">100%</span>
            </button>
          </div>

          {/* Center: Global Search */}
          <div className="relative flex-1 max-w-xs sm:max-w-md">
            <Search className="w-4 h-4 absolute right-3.5 top-3 text-slate-400" />
            <input
              type="text"
              placeholder="بحث في النظام، العملاء، الأحداث..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="w-full pl-3 sm:pl-4 pr-9 sm:pr-10 py-2 bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700/80 rounded-xl text-xs text-slate-800 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:border-blue-500 transition-colors shadow-inner"
            />
          </div>

          {/* Left: Actions, Language, Theme, Download Code, User Avatar */}
          <div className="flex items-center gap-1.5 sm:gap-2.5">
            {/* Download Code Button (Prominent on Mobile & Desktop) */}
            <button
              onClick={() => setIsDownloadModalOpen(true)}
              className="px-2.5 sm:px-3 py-1.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer shadow-md shadow-emerald-900/30 active:scale-95 shrink-0"
              title="تحميل الكود كاملاً بصيغة ZIP, PDF, APK, أو HTML"
            >
              <Download className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">تحميل الكود</span>
              <span className="text-[10px] font-mono bg-white/20 px-1 py-0.2 rounded hidden md:inline">ZIP/APK/PDF</span>
            </button>

            {/* Quick Install App on Mobile */}
            <button
              onClick={() => setIsInstallModalOpen(true)}
              className="px-2.5 sm:px-3 py-1.5 rounded-xl bg-blue-600/20 hover:bg-blue-600/30 border border-blue-500/40 text-blue-300 text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer shadow-xs active:scale-95 shrink-0"
              title="تثبيت التطبيق على الجوال بنقرة واحدة كالمتجر"
            >
              <Smartphone className="w-3.5 h-3.5 text-blue-400" />
              <span className="hidden lg:inline">تثبيت بالجوال</span>
            </button>

            {/* Language Selector */}
            <div className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs font-medium cursor-pointer">
              <Globe className="w-3.5 h-3.5 text-slate-500" />
              <span>العربية</span>
              <ChevronDown className="w-3 h-3 text-slate-400" />
            </div>

            {/* Dark / Light Toggle */}
            <button
              onClick={() => setIsDarkMode(!isDarkMode)}
              className="p-2 rounded-xl text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition-all cursor-pointer"
              title="تبديل المظهر (داكن / فاتح)"
            >
              {isDarkMode ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4" />}
            </button>

            {/* Settings Gear */}
            <button
              onClick={() => setActiveActionModal('settings')}
              className="p-2 rounded-xl text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition-all cursor-pointer"
              title="إعدادات النظام"
            >
              <Settings className="w-4 h-4" />
            </button>

            {/* Notification Bell with red counter badge 3 */}
            <button
              onClick={() => setActiveActionModal('notifications')}
              className="relative p-2 rounded-xl text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition-all cursor-pointer"
              title="الإشعارات"
            >
              <Bell className="w-4 h-4" />
              <span className="absolute -top-0.5 -left-0.5 w-4 h-4 rounded-full bg-red-500 text-white text-[10px] font-bold flex items-center justify-center shadow-xs">
                3
              </span>
            </button>

            {/* User Profile Badge */}
            <div className="flex items-center gap-2.5 pr-2 border-r border-slate-200 dark:border-slate-800">
              <div className="w-8 h-8 rounded-full bg-blue-600 text-white flex items-center justify-center font-bold text-xs shadow-sm">
                ن
              </div>
              <div className="hidden sm:block text-right">
                <div className="text-xs font-bold text-slate-900 dark:text-white leading-tight">
                  {currentUser.name || 'نصر النصر'}
                </div>
                <div className="text-[10px] text-slate-400 flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                  <span>مدير النظام</span>
                </div>
              </div>
            </div>
          </div>
        </header>

        {/* Dynamic Content Views based on activeMenu */}
        <main className="p-4 sm:p-6 space-y-5 max-w-[1400px] w-full mx-auto">
          {/* VIEW: MAIN HOME DASHBOARD (Matching Screenshot) */}
          {activeMenu === 'home' && (
            <>
              {/* 42 Sovereign Branches Quick Status Banner */}
              <div 
                onClick={() => setActiveMenu('sovereign_42')}
                className="p-4 rounded-2xl bg-gradient-to-r from-slate-900 via-blue-950 to-slate-900 border border-blue-500/40 text-white flex flex-col sm:flex-row items-center justify-between gap-3 cursor-pointer hover:border-blue-400 transition-all shadow-md group"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-500/40 text-amber-400 flex items-center justify-center shrink-0 shadow-inner group-hover:scale-105 transition-transform">
                    <GitFork className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-black text-sm text-white">نصر والت - النظام السيادي V2</span>
                      <span className="text-[10px] font-mono bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 px-2 py-0.2 rounded-full font-bold">
                        42 فرع كامل 100%
                      </span>
                    </div>
                    <p className="text-xs text-slate-300 mt-0.5">
                      الجذر (1) • 7 تطبيقات ميدانية • 22 خدمة نواة • 12 فرعاً للبنية التحتية
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2 text-xs font-bold text-blue-300 group-hover:text-blue-200 shrink-0">
                  <span>استعراض خارطة الـ 42 فرعاً</span>
                  <ChevronLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" />
                </div>
              </div>

              {/* Greeting & Date Header */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div>
                  <h1 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white tracking-tight">
                    مرحباً بك، {currentUser.name || 'نصر النصر'}
                  </h1>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    لوحة التحكم الرئيسية للمنظومة
                  </p>
                </div>

                <div className="flex items-center gap-2 px-3 py-1.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl text-xs text-slate-600 dark:text-slate-300 font-medium shadow-xs w-fit">
                  <CalendarIcon className="w-3.5 h-3.5 text-slate-400" />
                  <span>السبت، 6 سبتمبر 2025</span>
                  <span className="text-slate-300 dark:text-slate-600">|</span>
                  <Clock className="w-3.5 h-3.5 text-slate-400" />
                  <span className="font-mono">10:24 ص</span>
                </div>
              </div>

              {/* Hero Promotional Banner (Matching Navy Gradient & Card Visual) */}
              <div className="rounded-3xl bg-gradient-to-r from-[#071E42] via-[#0E3570] to-[#144794] text-white p-6 sm:p-7 shadow-xl relative overflow-hidden flex flex-col md:flex-row items-center justify-between gap-6 border border-blue-400/20">
                <div className="space-y-3 z-10 max-w-xl text-right">
                  <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-500/20 border border-blue-400/30 text-blue-200 text-xs font-bold font-mono">
                    <span>NASR WALLET Ω</span>
                  </div>
                  <h2 className="text-2xl sm:text-3xl font-black tracking-tight leading-snug">
                    حلول مالية رقمية .. لعالم بلا حدود
                  </h2>
                  <div className="flex items-center gap-3 text-xs text-blue-200 font-semibold">
                    <span className="flex items-center gap-1">
                      <ShieldCheck className="w-4 h-4 text-emerald-400" /> آمن
                    </span>
                    <span>•</span>
                    <span className="flex items-center gap-1">
                      <Zap className="w-4 h-4 text-amber-300" /> سريع
                    </span>
                    <span>•</span>
                    <span className="flex items-center gap-1">
                      <Globe className="w-4 h-4 text-cyan-300" /> عالمي
                    </span>
                  </div>
                </div>

                {/* Simulated 3D Card & Phone Mockup graphic */}
                <div className="relative shrink-0 flex items-center justify-center">
                  <div className="w-48 h-28 rounded-2xl bg-gradient-to-tr from-slate-900 to-blue-950 border border-blue-400/40 shadow-2xl p-3 flex flex-col justify-between transform -rotate-6 hover:rotate-0 transition-transform">
                    <div className="flex justify-between items-center text-[10px] text-slate-400 font-mono">
                      <span>PREMIUM VIP</span>
                      <span>VISA</span>
                    </div>
                    <div>
                      <div className="text-[10px] text-slate-400">الرصيد المتاح</div>
                      <div className="text-base font-black font-mono text-emerald-400">$ 1,250.00</div>
                    </div>
                  </div>
                </div>
              </div>

              {/* 7 Quick Action Buttons Strip */}
              <div className="grid grid-cols-4 sm:grid-cols-7 gap-2.5">
                {[
                  { id: 'deposit', label: 'إيداع', icon: Plus, bg: 'bg-emerald-500', text: 'text-emerald-500' },
                  { id: 'transfer', label: 'تحويل', icon: ArrowLeftRight, bg: 'bg-blue-600', text: 'text-blue-600' },
                  { id: 'bill', label: 'دفع فاتورة', icon: Receipt, bg: 'bg-purple-600', text: 'text-purple-600' },
                  { id: 'cashout', label: 'سحب نقدي', icon: DollarSign, bg: 'bg-amber-500', text: 'text-amber-500' },
                  { id: 'qr', label: 'QR', icon: QrCode, bg: 'bg-cyan-600', text: 'text-cyan-600' },
                  { id: 'remittance', label: 'إرسال دولي', icon: Globe, bg: 'bg-indigo-600', text: 'text-indigo-600' },
                  { id: 'more', label: 'المزيد', icon: MoreHorizontal, bg: 'bg-slate-600', text: 'text-slate-600' },
                ].map(act => {
                  const Icon = act.icon;
                  return (
                    <button
                      key={act.id}
                      onClick={() => setActiveActionModal(act.id as any)}
                      className="flex flex-col items-center gap-2 p-3 bg-white dark:bg-slate-900 hover:bg-slate-50 dark:hover:bg-slate-850 border border-slate-200 dark:border-slate-800 rounded-2xl transition-all shadow-xs hover:shadow-md active:scale-95 cursor-pointer group"
                    >
                      <div className={`w-11 h-11 rounded-2xl ${act.bg} text-white flex items-center justify-center shadow-md group-hover:scale-110 transition-transform`}>
                        <Icon className="w-5 h-5" />
                      </div>
                      <span className="text-xs font-bold text-slate-800 dark:text-slate-200">
                        {act.label}
                      </span>
                    </button>
                  );
                })}
              </div>

              {/* 4 Key Metrics KPI Cards Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
                {/* 1. إجمالي الأرصدة */}
                <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs flex items-center justify-between">
                  <div className="space-y-1">
                    <div className="text-xs text-slate-500 dark:text-slate-400">إجمالي الأرصدة</div>
                    <div className="text-lg sm:text-xl font-black font-mono text-slate-900 dark:text-white">
                      {showBalance ? '$ 1,248,650' : '••••••••'}
                    </div>
                    <div className="text-[11px] font-bold text-emerald-600 dark:text-emerald-400 flex items-center gap-1">
                      <TrendingUp className="w-3 h-3" />
                      <span>+8.4% مقارنة بالأمس</span>
                    </div>
                  </div>
                  <div className="w-11 h-11 rounded-2xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 flex items-center justify-center border border-emerald-200 dark:border-emerald-800">
                    <Zap className="w-5 h-5" />
                  </div>
                </div>

                {/* 2. إجمالي المعاملات */}
                <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs flex items-center justify-between">
                  <div className="space-y-1">
                    <div className="text-xs text-slate-500 dark:text-slate-400">إجمالي المعاملات</div>
                    <div className="text-lg sm:text-xl font-black font-mono text-slate-900 dark:text-white">
                      458,230
                    </div>
                    <div className="text-[11px] font-bold text-emerald-600 dark:text-emerald-400 flex items-center gap-1">
                      <TrendingUp className="w-3 h-3" />
                      <span>+12.7% مقارنة بالأمس</span>
                    </div>
                  </div>
                  <div className="w-11 h-11 rounded-2xl bg-purple-50 dark:bg-purple-950/60 text-purple-600 dark:text-purple-400 flex items-center justify-center border border-purple-200 dark:border-purple-800">
                    <Receipt className="w-5 h-5" />
                  </div>
                </div>

                {/* 3. إجمالي العملاء */}
                <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs flex items-center justify-between">
                  <div className="space-y-1">
                    <div className="text-xs text-slate-500 dark:text-slate-400">إجمالي العملاء</div>
                    <div className="text-lg sm:text-xl font-black font-mono text-slate-900 dark:text-white">
                      8,742
                    </div>
                    <div className="text-[11px] font-bold text-emerald-600 dark:text-emerald-400 flex items-center gap-1">
                      <TrendingUp className="w-3 h-3" />
                      <span>+3.1% مقارنة بالأمس</span>
                    </div>
                  </div>
                  <div className="w-11 h-11 rounded-2xl bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 flex items-center justify-center border border-blue-200 dark:border-blue-800">
                    <Users className="w-5 h-5" />
                  </div>
                </div>

                {/* 4. إجمالي المحافظ */}
                <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs flex items-center justify-between">
                  <div className="space-y-1">
                    <div className="text-xs text-slate-500 dark:text-slate-400">إجمالي المحافظ</div>
                    <div className="text-lg sm:text-xl font-black font-mono text-slate-900 dark:text-white">
                      12,458
                    </div>
                    <div className="text-[11px] font-bold text-emerald-600 dark:text-emerald-400 flex items-center gap-1">
                      <TrendingUp className="w-3 h-3" />
                      <span>+2.5% مقارنة بالأمس</span>
                    </div>
                  </div>
                  <div className="w-11 h-11 rounded-2xl bg-cyan-50 dark:bg-cyan-950/60 text-cyan-600 dark:text-cyan-400 flex items-center justify-center border border-cyan-200 dark:border-cyan-800">
                    <Wallet className="w-5 h-5" />
                  </div>
                </div>
              </div>

              {/* Charts Section (Area Spline Chart + Donut Chart) */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
                {/* 1. Area Spline: حركة المعاملات الأخيرة */}
                <div className="lg:col-span-2 bg-white dark:bg-slate-900 p-5 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                        حركة المعاملات الأخيرة
                      </h3>
                      <p className="text-[11px] text-slate-400">نشاط المدفوعات والتحويلات الأسبوعي</p>
                    </div>
                    <button
                      onClick={() => setActiveMenu('transactions')}
                      className="text-xs text-blue-600 dark:text-blue-400 hover:underline font-bold flex items-center gap-1 cursor-pointer"
                    >
                      <span>عرض الكل</span>
                      <ChevronLeft className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  {/* SVG Area Spline Chart */}
                  <div className="h-52 w-full relative">
                    <svg viewBox="0 0 500 180" className="w-full h-full overflow-visible">
                      <defs>
                        <linearGradient id="chartGradient" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="0%" stopColor="#06B6D4" stopOpacity="0.4" />
                          <stop offset="100%" stopColor="#06B6D4" stopOpacity="0.0" />
                        </linearGradient>
                      </defs>

                      {/* Grid Horizontal Lines */}
                      <line x1="40" y1="20" x2="480" y2="20" stroke="#E2E8F0" strokeDasharray="3 3" className="dark:stroke-slate-800" />
                      <line x1="40" y1="60" x2="480" y2="60" stroke="#E2E8F0" strokeDasharray="3 3" className="dark:stroke-slate-800" />
                      <line x1="40" y1="100" x2="480" y2="100" stroke="#E2E8F0" strokeDasharray="3 3" className="dark:stroke-slate-800" />
                      <line x1="40" y1="140" x2="480" y2="140" stroke="#E2E8F0" strokeDasharray="3 3" className="dark:stroke-slate-800" />

                      {/* Y-Axis Labels */}
                      <text x="25" y="24" fontSize="9" fill="#94A3B8" textAnchor="end">40K</text>
                      <text x="25" y="64" fontSize="9" fill="#94A3B8" textAnchor="end">30K</text>
                      <text x="25" y="104" fontSize="9" fill="#94A3B8" textAnchor="end">20K</text>
                      <text x="25" y="144" fontSize="9" fill="#94A3B8" textAnchor="end">10K</text>

                      {/* Spline Path */}
                      <path
                        d="M 50 130 C 100 110, 130 135, 180 100 C 220 70, 260 110, 310 90 C 360 70, 400 80, 460 35 L 460 160 L 50 160 Z"
                        fill="url(#chartGradient)"
                      />
                      <path
                        d="M 50 130 C 100 110, 130 135, 180 100 C 220 70, 260 110, 310 90 C 360 70, 400 80, 460 35"
                        fill="none"
                        stroke="#06B6D4"
                        strokeWidth="3"
                        strokeLinecap="round"
                      />

                      {/* Points */}
                      <circle cx="50" cy="130" r="4" fill="#06B6D4" />
                      <circle cx="180" cy="100" r="4" fill="#06B6D4" />
                      <circle cx="310" cy="90" r="4" fill="#06B6D4" />
                      <circle cx="460" cy="35" r="5" fill="#0284C7" stroke="#FFFFFF" strokeWidth="2" />

                      {/* Active Tooltip matching Screenshot (6 Sep 32,450) */}
                      <g transform="translate(420, 5)">
                        <rect width="60" height="24" rx="6" fill="#0F172A" />
                        <text x="30" y="11" fontSize="8" fill="#94A3B8" textAnchor="middle">6 Sep</text>
                        <text x="30" y="21" fontSize="9" fontWeight="bold" fill="#FFFFFF" textAnchor="middle">32,450</text>
                      </g>

                      {/* X-Axis Dates */}
                      <text x="50" y="172" fontSize="9" fill="#94A3B8" textAnchor="middle">31 Aug</text>
                      <text x="120" y="172" fontSize="9" fill="#94A3B8" textAnchor="middle">1 Sep</text>
                      <text x="190" y="172" fontSize="9" fill="#94A3B8" textAnchor="middle">2 Sep</text>
                      <text x="260" y="172" fontSize="9" fill="#94A3B8" textAnchor="middle">3 Sep</text>
                      <text x="330" y="172" fontSize="9" fill="#94A3B8" textAnchor="middle">4 Sep</text>
                      <text x="400" y="172" fontSize="9" fill="#94A3B8" textAnchor="middle">5 Sep</text>
                      <text x="460" y="172" fontSize="9" fill="#0284C7" fontWeight="bold" textAnchor="middle">6 Sep</text>
                    </svg>
                  </div>
                </div>

                {/* 2. Donut Chart: توزيع المعاملات */}
                <div className="bg-white dark:bg-slate-900 p-5 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-4 flex flex-col justify-between">
                  <div>
                    <h3 className="text-sm font-bold text-slate-900 dark:text-white">توزيع المعاملات</h3>
                    <p className="text-[11px] text-slate-400">حسب تصنيف العمليات المصرفية</p>
                  </div>

                  {/* Donut Visualization */}
                  <div className="flex flex-col items-center justify-center my-2">
                    <div className="relative w-36 h-36 flex items-center justify-center">
                      <svg viewBox="0 0 36 36" className="w-full h-full -rotate-90">
                        {/* Segment 1: Local Transfers 45.2% (Blue) */}
                        <circle cx="18" cy="18" r="14" fill="none" stroke="#2563EB" strokeWidth="4.5" strokeDasharray="45.2 54.8" strokeDashoffset="0" />
                        {/* Segment 2: Bills 18.7% (Yellow) */}
                        <circle cx="18" cy="18" r="14" fill="none" stroke="#EAB308" strokeWidth="4.5" strokeDasharray="18.7 81.3" strokeDashoffset="-45.2" />
                        {/* Segment 3: Topup 12.5% (Purple) */}
                        <circle cx="18" cy="18" r="14" fill="none" stroke="#9333EA" strokeWidth="4.5" strokeDasharray="12.5 87.5" strokeDashoffset="-63.9" />
                        {/* Segment 4: Cashout 8.9% (Green) */}
                        <circle cx="18" cy="18" r="14" fill="none" stroke="#10B981" strokeWidth="4.5" strokeDasharray="8.9 91.1" strokeDashoffset="-76.4" />
                        {/* Segment 5: Others 14.7% (Orange) */}
                        <circle cx="18" cy="18" r="14" fill="none" stroke="#F97316" strokeWidth="4.5" strokeDasharray="14.7 85.3" strokeDashoffset="-85.3" />
                      </svg>
                      {/* Center Stats */}
                      <div className="absolute text-center">
                        <div className="text-sm font-black font-mono text-slate-900 dark:text-white">458,230</div>
                        <div className="text-[9px] text-slate-400">إجمالي المعاملات</div>
                      </div>
                    </div>
                  </div>

                  {/* Legend List */}
                  <div className="space-y-1.5 text-xs">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="w-2.5 h-2.5 rounded-full bg-blue-600" />
                        <span className="text-slate-600 dark:text-slate-300 text-[11px]">تحويلات محلية</span>
                      </div>
                      <span className="font-mono font-bold text-slate-900 dark:text-white text-[11px]">45.2%</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="w-2.5 h-2.5 rounded-full bg-yellow-500" />
                        <span className="text-slate-600 dark:text-slate-300 text-[11px]">دفع فواتير</span>
                      </div>
                      <span className="font-mono font-bold text-slate-900 dark:text-white text-[11px]">18.7%</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="w-2.5 h-2.5 rounded-full bg-purple-600" />
                        <span className="text-slate-600 dark:text-slate-300 text-[11px]">شحن رصيد</span>
                      </div>
                      <span className="font-mono font-bold text-slate-900 dark:text-white text-[11px]">12.5%</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
                        <span className="text-slate-600 dark:text-slate-300 text-[11px]">سحب نقدي</span>
                      </div>
                      <span className="font-mono font-bold text-slate-900 dark:text-white text-[11px]">8.9%</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="w-2.5 h-2.5 rounded-full bg-orange-500" />
                        <span className="text-slate-600 dark:text-slate-300 text-[11px]">خدمات أخرى</span>
                      </div>
                      <span className="font-mono font-bold text-slate-900 dark:text-white text-[11px]">14.7%</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Middle Row: أحدث المعاملات + مركز المحفظة */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
                {/* 1. أحدث المعاملات Table */}
                <div className="lg:col-span-2 bg-white dark:bg-slate-900 p-5 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-3">
                  <div className="flex items-center justify-between">
                    <h3 className="text-sm font-bold text-slate-900 dark:text-white">أحدث المعاملات</h3>
                    <button
                      onClick={() => setActiveMenu('transactions')}
                      className="text-xs text-blue-600 dark:text-blue-400 hover:underline font-bold flex items-center gap-1 cursor-pointer"
                    >
                      <span>عرض الكل</span>
                      <ChevronLeft className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  <div className="overflow-x-auto">
                    <table className="w-full text-right text-xs">
                      <thead className="text-slate-400 border-b border-slate-100 dark:border-slate-800 text-[11px]">
                        <tr>
                          <th className="py-2.5 pr-2">النوع</th>
                          <th className="py-2.5">المبلغ</th>
                          <th className="py-2.5">التاريخ</th>
                          <th className="py-2.5 text-center">الحالة</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60">
                        {[
                          { type: 'تحويل محفظة', icon: ArrowLeftRight, amount: '$ 45.00', date: '06/09 10:12', status: 'ناجحة' },
                          { type: 'دفع فاتورة', icon: Receipt, amount: '$ 15.00', date: '06/09 09:45', status: 'ناجحة' },
                          { type: 'شحن رصيد', icon: Smartphone, amount: '$ 20.00', date: '06/09 09:30', status: 'ناجحة' },
                          { type: 'سحب نقدي', icon: DollarSign, amount: '$ 100.00', date: '06/09 08:20', status: 'قيد المراجعة' },
                          { type: 'دفع للتاجر', icon: Store, amount: '$ 84.50', date: '06/09 07:50', status: 'ناجحة' },
                          { type: 'تحويل دولي', icon: Globe, amount: '$ 300.00', date: '06/09 06:15', status: 'ناجحة' },
                        ].map((tx, idx) => {
                          const TxIcon = tx.icon;
                          return (
                            <tr key={idx} className="hover:bg-slate-50 dark:hover:bg-slate-800/40 transition-colors">
                              <td className="py-2.5 pr-2 flex items-center gap-2">
                                <div className="p-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-blue-600 dark:text-blue-400">
                                  <TxIcon className="w-3.5 h-3.5" />
                                </div>
                                <span className="font-semibold text-slate-800 dark:text-slate-200">{tx.type}</span>
                              </td>
                              <td className="py-2.5 font-mono font-bold text-slate-900 dark:text-white">
                                {tx.amount}
                              </td>
                              <td className="py-2.5 font-mono text-slate-400 text-[11px]">
                                {tx.date}
                              </td>
                              <td className="py-2.5 text-center">
                                <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                                  tx.status === 'ناجحة'
                                    ? 'bg-emerald-50 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800'
                                    : 'bg-amber-50 dark:bg-amber-950 text-amber-600 dark:text-amber-400 border border-amber-200 dark:border-amber-800'
                                }`}>
                                  {tx.status}
                                </span>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* 2. مركز المحفظة (Wallet Center Card) */}
                <div className="bg-white dark:bg-slate-900 p-5 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-4 flex flex-col justify-between">
                  <div>
                    <div className="flex items-center justify-between">
                      <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                        <Wallet className="w-4 h-4 text-blue-600" />
                        <span>مركز المحفظة</span>
                      </h3>
                      <button
                        onClick={() => setShowBalance(!showBalance)}
                        className="text-slate-400 hover:text-slate-600 cursor-pointer"
                      >
                        {showBalance ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4 text-amber-500" />}
                      </button>
                    </div>

                    <div className="mt-4 text-center">
                      <div className="text-xs text-slate-400">الرصيد الكلي</div>
                      <div className="text-2xl font-black font-mono text-slate-900 dark:text-white mt-1">
                        {showBalance ? `$ 1,248.65` : '••••••••'}
                      </div>
                    </div>

                    {/* 3 Sub-Boxes: قيد التسوية / المحجوز / الرصيد المتاح */}
                    <div className="grid grid-cols-3 gap-2 mt-4 text-center">
                      <div className="p-2.5 rounded-2xl bg-blue-50/60 dark:bg-blue-950/40 border border-blue-100 dark:border-blue-900/60">
                        <span className="text-[10px] text-blue-600 dark:text-blue-400 block">قيد التسوية</span>
                        <span className="font-mono font-bold text-xs text-slate-800 dark:text-slate-200 block mt-0.5">$ 30.00</span>
                      </div>
                      <div className="p-2.5 rounded-2xl bg-amber-50/60 dark:bg-amber-950/40 border border-amber-100 dark:border-amber-900/60">
                        <span className="text-[10px] text-amber-600 dark:text-amber-400 block">المحجوز</span>
                        <span className="font-mono font-bold text-xs text-slate-800 dark:text-slate-200 block mt-0.5">$ 120.00</span>
                      </div>
                      <div className="p-2.5 rounded-2xl bg-emerald-50/60 dark:bg-emerald-950/40 border border-emerald-100 dark:border-emerald-900/60">
                        <span className="text-[10px] text-emerald-600 dark:text-emerald-400 block">الرصيد المتاح</span>
                        <span className="font-mono font-bold text-xs text-slate-800 dark:text-slate-200 block mt-0.5">$ 1,098.65</span>
                      </div>
                    </div>
                  </div>

                  {/* Actions Links */}
                  <div className="space-y-1.5 pt-2 border-t border-slate-100 dark:border-slate-800 text-xs">
                    <button
                      onClick={() => setActiveMenu('wallets')}
                      className="w-full flex items-center justify-between p-2 rounded-xl hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300 font-medium transition-colors cursor-pointer"
                    >
                      <span>تفاصيل المحفظة</span>
                      <ChevronLeft className="w-4 h-4 text-slate-400" />
                    </button>
                    <button
                      onClick={() => setActiveMenu('reports')}
                      className="w-full flex items-center justify-between p-2 rounded-xl hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300 font-medium transition-colors cursor-pointer"
                    >
                      <span>كشف الحساب</span>
                      <ChevronLeft className="w-4 h-4 text-slate-400" />
                    </button>
                    <button
                      onClick={() => setActiveMenu('dashboard_control')}
                      className="w-full flex items-center justify-between p-2 rounded-xl hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300 font-medium transition-colors cursor-pointer"
                    >
                      <span>إدارة الحسابات</span>
                      <ChevronLeft className="w-4 h-4 text-slate-400" />
                    </button>
                  </div>
                </div>
              </div>

              {/* Bottom Section: الخدمات السريعة + التنبيهات */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                {/* 1. الخدمات السريعة */}
                <div className="bg-white dark:bg-slate-900 p-5 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-3">
                  <h3 className="text-sm font-bold text-slate-900 dark:text-white">الخدمات السريعة</h3>
                  <div className="grid grid-cols-4 gap-3 text-center">
                    <button
                      onClick={() => setActiveActionModal('bill')}
                      className="flex flex-col items-center gap-1.5 p-3 rounded-2xl bg-slate-50 dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 transition-all cursor-pointer"
                    >
                      <div className="w-10 h-10 rounded-xl bg-cyan-100 dark:bg-cyan-950 text-cyan-600 dark:text-cyan-400 flex items-center justify-center">
                        <Smartphone className="w-5 h-5" />
                      </div>
                      <span className="text-[11px] font-bold text-slate-700 dark:text-slate-300">شحن رصيد</span>
                    </button>

                    <button
                      onClick={() => setActiveActionModal('bill')}
                      className="flex flex-col items-center gap-1.5 p-3 rounded-2xl bg-slate-50 dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 transition-all cursor-pointer"
                    >
                      <div className="w-10 h-10 rounded-xl bg-purple-100 dark:bg-purple-950 text-purple-600 dark:text-purple-400 flex items-center justify-center">
                        <Receipt className="w-5 h-5" />
                      </div>
                      <span className="text-[11px] font-bold text-slate-700 dark:text-slate-300">دفع فواتير</span>
                    </button>

                    <button
                      onClick={() => setActiveActionModal('remittance')}
                      className="flex flex-col items-center gap-1.5 p-3 rounded-2xl bg-slate-50 dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 transition-all cursor-pointer"
                    >
                      <div className="w-10 h-10 rounded-xl bg-blue-100 dark:bg-blue-950 text-blue-600 dark:text-blue-400 flex items-center justify-center">
                        <Globe className="w-5 h-5" />
                      </div>
                      <span className="text-[11px] font-bold text-slate-700 dark:text-slate-300">إرسال دولي</span>
                    </button>

                    <button
                      onClick={() => setActiveMenu('cards')}
                      className="flex flex-col items-center gap-1.5 p-3 rounded-2xl bg-slate-50 dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 transition-all cursor-pointer"
                    >
                      <div className="w-10 h-10 rounded-xl bg-amber-100 dark:bg-amber-950 text-amber-600 dark:text-amber-400 flex items-center justify-center">
                        <CreditCard className="w-5 h-5" />
                      </div>
                      <span className="text-[11px] font-bold text-slate-700 dark:text-slate-300">بطاقات</span>
                    </button>
                  </div>
                </div>

                {/* 2. التنبيهات (Alerts Feed matching screenshot) */}
                <div className="bg-white dark:bg-slate-900 p-5 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-3">
                  <div className="flex items-center justify-between">
                    <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                      <Bell className="w-4 h-4 text-blue-600" />
                      <span>التنبيهات</span>
                    </h3>
                    <button
                      onClick={() => setActiveMenu('notifications')}
                      className="text-xs text-blue-600 dark:text-blue-400 hover:underline font-bold flex items-center gap-1 cursor-pointer"
                    >
                      <span>عرض الكل</span>
                      <ChevronLeft className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  <div className="space-y-2 text-xs">
                    <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                        <span className="text-slate-800 dark:text-slate-200">تمت إضافة عميل جديد بنجاح</span>
                      </div>
                      <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-medium">منذ 10 دقائق</span>
                    </div>

                    <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <AlertTriangle className="w-4 h-4 text-amber-500" />
                        <span className="text-slate-800 dark:text-slate-200">معاملة مشبوهة في انتظار المراجعة</span>
                      </div>
                      <span className="text-[10px] text-amber-600 dark:text-amber-400 font-medium">منذ 25 دقيقة</span>
                    </div>

                    <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Zap className="w-4 h-4 text-blue-500" />
                        <span className="text-slate-800 dark:text-slate-200">تم إيداع مبلغ بقيمة $500.00</span>
                      </div>
                      <span className="text-[10px] text-blue-600 dark:text-blue-400 font-medium">منذ ساعة</span>
                    </div>

                    <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Clock className="w-4 h-4 text-purple-500" />
                        <span className="text-slate-800 dark:text-slate-200">تذكير: موعد التسوية اليومية</span>
                      </div>
                      <span className="text-[10px] text-purple-600 dark:text-purple-400 font-medium">منذ 3 ساعات</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Security & Payment Partners Footer Banner (Matching Screenshot) */}
              <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col sm:flex-row items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-xl bg-blue-50 dark:bg-blue-950 text-blue-600 dark:text-blue-400">
                    <ShieldCheck className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="text-xs font-bold text-slate-900 dark:text-white">
                      نظام أمن بمعايير عالمية
                    </div>
                    <div className="text-[11px] text-slate-400">
                      تشفير كامل • مراقبة مستمرة للسيولة • حماية البيانات PCI-DSS
                    </div>
                  </div>
                </div>

                {/* Partners Brand Badges */}
                <div className="flex items-center gap-3 text-xs font-black text-slate-500 dark:text-slate-400">
                  <span className="px-2 py-1 bg-slate-100 dark:bg-slate-800 rounded font-mono text-blue-600">VISA</span>
                  <span className="px-2 py-1 bg-slate-100 dark:bg-slate-800 rounded font-mono text-amber-600">Mastercard</span>
                  <span className="px-2 py-1 bg-slate-100 dark:bg-slate-800 rounded font-mono text-emerald-600">mada مدى</span>
                  <span className="px-2 py-1 bg-slate-100 dark:bg-slate-800 rounded font-mono text-indigo-600">PayPal</span>
                  <Globe className="w-4 h-4 text-slate-400" />
                </div>
              </div>
            </>
          )}

          {/* VIEW: 42 SOVEREIGN BRANCHES VIEWER (100% COMPLETE) */}
          {activeMenu === 'sovereign_42' && (
            <div className="space-y-4">
              <Sovereign42BranchesViewer
                onNavigateToModule={(mod) => {
                  if (mod === 'visualizer_tab') {
                    setActiveMenu('home');
                  } else {
                    setActiveMenu(mod as CentralSidebarItem);
                  }
                }}
                onOpenDownloadModal={() => setIsDownloadModalOpen(true)}
                onRequestRoleApp={onSelectRoleApp}
              />
            </div>
          )}

          {/* VIEW: EVENTS & OPERATIONS HUB (DIRECT SAVE OFFLINE / ONLINE) */}
          {activeMenu === 'events' && (
            <EventsAndOperationsHub 
              onBackToHome={() => setActiveMenu('home')}
              onNotify={(msg, type) => showToast(msg, type || 'info')}
            />
          )}

          {/* VIEW: CUSTOMERS MANAGEMENT */}
          {activeMenu === 'customers' && (
            <CustomersManagementView 
              onBackToHome={() => setActiveMenu('home')}
              onNotify={(msg) => showToast(msg, 'info')} 
            />
          )}

          {/* VIEW: APPROVALS QUEUE */}
          {activeMenu === 'approvals' && (
            <ApprovalsManagementView 
              onBackToHome={() => setActiveMenu('home')}
              onNotify={(msg) => showToast(msg, 'info')} 
            />
          )}

          {/* VIEW: BANKS & SWIFT */}
          {activeMenu === 'banks' && (
            <BanksManagementView 
              onBackToHome={() => setActiveMenu('home')}
              onNotify={(msg) => showToast(msg, 'info')} 
            />
          )}

          {/* VIEW: PAYROLL MANAGEMENT */}
          {activeMenu === 'payroll' && (
            <PayrollManagementView 
              onBackToHome={() => setActiveMenu('home')}
              onNotify={(msg) => showToast(msg, 'info')} 
            />
          )}

          {/* VIEW: SECRET VAULT & ENCRYPTED DATABASE */}
          {(activeMenu === 'vault' || activeMenu === 'secret_db') && (
            <div className="space-y-4">
              <div className="flex items-center justify-between bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800">
                <div>
                  <h2 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                    <Key className="w-5 h-5 text-cyan-500" />
                    <span>قاعدة البيانات السرية ومخزن الأكواد (Sovereign Secret Vault & DB)</span>
                  </h2>
                  <p className="text-xs text-slate-400">
                    مفاتيح التشفير MEK/RSA، أكواد الطوارئ Break-Glass، جداول التشفير، وأسرار الربط المصرفي
                  </p>
                </div>
                <button
                  onClick={() => setActiveMenu('home')}
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold transition-colors cursor-pointer flex items-center gap-1.5"
                >
                  <ArrowRight className="w-4 h-4" />
                  <span>العودة للواجهة الرئيسية</span>
                </button>
              </div>
              <SecretVaultAndDbView />
            </div>
          )}

          {/* VIEW: DASHBOARD & MASTER CONTROL (GOD MODE) */}
          {activeMenu === 'dashboard_control' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800">
                <div>
                  <h2 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                    <Sliders className="w-5 h-5 text-amber-500" />
                    <span>لوحة التحكم السيادية وضبط الأنظمة (Sovereign Control)</span>
                  </h2>
                  <p className="text-xs text-slate-400">
                    التحكم الفوري في الأرصدة، أسعار الصرف، الرسوم، وحدود السحب اليومية
                  </p>
                </div>
                <button
                  onClick={() => setActiveMenu('home')}
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer"
                >
                  <ArrowRight className="w-4 h-4" />
                  <span>العودة للواجهة الرئيسية</span>
                </button>
              </div>
              <MasterControlPanel onRequestRoleApp={onSelectRoleApp} />
            </div>
          )}

          {/* FALLBACK FOR OTHER SIDEBAR MODULES (RICH TAB WITH METRICS & SEARCH) */}
          {['wallets', 'transactions', 'transfers', 'services', 'merchants', 'agents', 'cards', 'risk', 'settlements', 'reports', 'audit', 'notifications', 'data_management', 'dev_center', 'system_health'].includes(activeMenu) && (
            <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
              <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-4">
                <div>
                  <h2 className="text-lg font-black text-slate-900 dark:text-white flex items-center gap-2">
                    <span>قسم: {sidebarItems.find(i => i.id === activeMenu)?.label}</span>
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-50 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400 font-mono">
                      جاهز ونشط 100%
                    </span>
                  </h2>
                  <p className="text-xs text-slate-400 mt-0.5">
                    البيانات متصلة بـ Ledger الدفتر المحاسبي وقاعدة بيانات نصر والت السيادية V2
                  </p>
                </div>
                <button
                  onClick={() => setActiveMenu('home')}
                  className="px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-bold cursor-pointer transition-colors flex items-center gap-1.5"
                >
                  <ArrowRight className="w-4 h-4" />
                  <span>رجوع للرئيسية</span>
                </button>
              </div>

              {/* Module Content Specifics */}
              {activeMenu === 'wallets' && (
                 <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                   {wallets.map(w => (
                     <div key={w.id} className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 space-y-2">
                       <div className="text-xs text-slate-400">
                         {w.currency === 'USD' ? 'المحفظة الدولارية' : w.currency === 'YER' ? 'المحفظة اليمنية' : 'المحفظة السعودية'} ({w.currency})
                       </div>
                       <div className="text-xl font-black font-mono text-emerald-600 dark:text-emerald-400">
                         {w.balance.toLocaleString()} {w.currency}
                       </div>
                       <div className="text-[10px] text-slate-400 font-mono">رقم المحفظة: {w.accountNumber}</div>
                     </div>
                   ))}
                 </div>
              )}

              {activeMenu === 'transactions' && (
                 <div className="overflow-x-auto">
                   <table className="w-full text-right text-xs">
                     <thead className="border-b border-slate-100 dark:border-slate-800 text-slate-400">
                       <tr>
                         <th className="p-2">المرجع</th>
                         <th className="p-2">الوصف</th>
                         <th className="p-2">المبلغ</th>
                         <th className="p-2">الحالة</th>
                       </tr>
                     </thead>
                     <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                       {transactions.slice(0, 8).map(tx => (
                         <tr key={tx.id}>
                           <td className="p-2 font-mono text-slate-500">{tx.refNo}</td>
                           <td className="p-2 font-bold text-slate-900 dark:text-white">{tx.title}</td>
                           <td className="p-2 font-mono font-bold text-blue-600">{tx.amount.toLocaleString()} {tx.currency}</td>
                           <td className="p-2">
                             <span className="px-2 py-0.5 rounded-full text-[10px] bg-emerald-50 text-emerald-600 font-bold">
                               {tx.status}
                             </span>
                           </td>
                         </tr>
                       ))}
                     </tbody>
                   </table>
                 </div>
              )}

              {activeMenu === 'risk' && (
                <div className="space-y-3 text-xs">
                  <div className="p-4 rounded-2xl bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900 text-red-700 dark:text-red-300">
                    <div className="font-bold flex items-center gap-2">
                      <ShieldAlert className="w-4 h-4" />
                      <span>قواعد الامتثال ومكافحة غسيل الأموال (AML Engine)</span>
                    </div>
                    <div className="text-[11px] mt-1">
                      حساسية الرصد: {systemControl.security.amlSensitivity} • فحص فوري للعمليات المشبوهة
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}
        </main>
      </div>

      {/* 3. INTERACTIVE MODAL SHEETS FOR QUICK ACTIONS */}
      {activeActionModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl max-w-md w-full p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <h3 className="font-bold text-base text-slate-900 dark:text-white flex items-center gap-2">
                {activeActionModal === 'deposit' && <Plus className="w-5 h-5 text-emerald-600" />}
                {activeActionModal === 'transfer' && <ArrowLeftRight className="w-5 h-5 text-blue-600" />}
                {activeActionModal === 'bill' && <Receipt className="w-5 h-5 text-purple-600" />}
                {activeActionModal === 'cashout' && <DollarSign className="w-5 h-5 text-amber-600" />}
                {activeActionModal === 'qr' && <QrCode className="w-5 h-5 text-cyan-600" />}
                {activeActionModal === 'remittance' && <Globe className="w-5 h-5 text-indigo-600" />}
                {activeActionModal === 'more' && <MoreHorizontal className="w-5 h-5 text-slate-600" />}
                {activeActionModal === 'notifications' && <Bell className="w-5 h-5 text-blue-600" />}
                {activeActionModal === 'settings' && <Settings className="w-5 h-5 text-blue-600" />}
                <span>
                  {activeActionModal === 'deposit' && 'إيداع نقدي / تغذية رصيد'}
                  {activeActionModal === 'transfer' && 'تحويل مالي فوري'}
                  {activeActionModal === 'bill' && 'سداد فواتير وخدمات'}
                  {activeActionModal === 'cashout' && 'سحب نقدي من الخزينة'}
                  {activeActionModal === 'qr' && 'رمز الاستجابة السريع QR'}
                  {activeActionModal === 'remittance' && 'حوالة دولية سريعة'}
                  {activeActionModal === 'more' && 'خيارات وإجراءات إضافية'}
                  {activeActionModal === 'notifications' && 'مركز الإشعارات والتنبيهات'}
                  {activeActionModal === 'settings' && 'إعدادات النظام السيادية'}
                </span>
              </h3>
              <button
                onClick={() => setActiveActionModal(null)}
                className="text-slate-400 hover:text-slate-600 dark:hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Form for Deposit, Transfer, Bill, Cashout */}
            {['deposit', 'transfer', 'bill', 'cashout', 'remittance'].includes(activeActionModal) && (
              <form onSubmit={handleExecuteAction} className="space-y-3 text-xs">
                <div>
                  <label className="block text-slate-600 dark:text-slate-400 mb-1 font-semibold">
                    المبلغ (USD)
                  </label>
                  <input
                    type="number"
                    required
                    min="1"
                    value={actionAmount}
                    onChange={e => setActionAmount(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl text-slate-900 dark:text-white font-mono text-base focus:outline-none focus:border-blue-500"
                  />
                </div>

                {activeActionModal === 'transfer' && (
                  <div>
                    <label className="block text-slate-600 dark:text-slate-400 mb-1 font-semibold">
                      رقم هاتف المستلم
                    </label>
                    <input
                      type="tel"
                      required
                      placeholder="77XXXXXXX"
                      value={actionPhone}
                      onChange={e => setActionPhone(e.target.value)}
                      className="w-full p-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl text-slate-900 dark:text-white font-mono focus:outline-none focus:border-blue-500"
                    />
                  </div>
                )}

                {activeActionModal === 'bill' && (
                  <div>
                    <label className="block text-slate-600 dark:text-slate-400 mb-1 font-semibold">
                      الخدمة أو الفاتورة
                    </label>
                    <select
                      value={actionService}
                      onChange={e => setActionService(e.target.value)}
                      className="w-full p-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:border-blue-500"
                    >
                      <option value="يمن موبايل - باقات مزايا">يمن موبايل - باقات مزايا</option>
                      <option value="سبأفون - شحن رصيد">سبأفون - شحن رصيد</option>
                      <option value="يو YOU - باقات سمارت">يو YOU - باقات سمارت</option>
                      <option value="فاتورة الكهرباء الوطنية">فاتورة الكهرباء الوطنية</option>
                      <option value="المؤسسة العامة للمياه والصرف">المؤسسة العامة للمياه والصرف</option>
                    </select>
                  </div>
                )}

                <div className="flex gap-2 pt-3">
                  <button
                    type="button"
                    onClick={() => setActiveActionModal(null)}
                    className="flex-1 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 font-bold hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                  >
                    إلغاء
                  </button>
                  <button
                    type="submit"
                    className="flex-1 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold shadow-md cursor-pointer"
                  >
                    تأكيد وتنفيذ العملية
                  </button>
                </div>
              </form>
            )}

            {activeActionModal === 'qr' && (
              <div className="text-center space-y-3 py-2">
                <div className="p-4 bg-slate-50 dark:bg-slate-950 rounded-2xl border border-slate-200 dark:border-slate-800 inline-block mx-auto">
                  <QrCode className="w-36 h-36 text-slate-900 dark:text-white mx-auto" />
                </div>
                <div className="text-xs text-slate-400 font-mono">NASR-WALLET-Ω-PAY-CENTRAL-QR</div>
                <button
                  onClick={() => setActiveActionModal(null)}
                  className="w-full py-2 bg-blue-600 text-white font-bold rounded-xl text-xs"
                >
                  إغلاق
                </button>
              </div>
            )}

            {activeActionModal === 'notifications' && (
              <div className="space-y-2 text-xs">
                <div className="p-3 bg-slate-50 dark:bg-slate-950 rounded-xl">
                  <div className="font-bold text-slate-900 dark:text-white">تم اعتماد توثيق KYC للعميل أحمد باوزير</div>
                  <div className="text-[10px] text-slate-400">منذ 15 دقيقة</div>
                </div>
                <div className="p-3 bg-slate-50 dark:bg-slate-950 rounded-xl">
                  <div className="font-bold text-slate-900 dark:text-white">تحديث سعر صرف الدولار اليوم: 1650 YER</div>
                  <div className="text-[10px] text-slate-400">اليوم 08:00 ص</div>
                </div>
                <button
                  onClick={() => setActiveActionModal(null)}
                  className="w-full py-2 bg-blue-600 text-white font-bold rounded-xl text-xs mt-2"
                >
                  إغلاق
                </button>
              </div>
            )}

            {activeActionModal === 'settings' && (
              <div className="space-y-3 text-xs">
                <div className="flex items-center justify-between p-3 bg-slate-50 dark:bg-slate-950 rounded-xl">
                  <span>وضع قفل الطوارئ السيادي:</span>
                  <span className="font-bold text-emerald-600">غير مفعل (النظام آمن)</span>
                </div>
                <button
                  onClick={() => {
                    setActiveActionModal(null);
                    setActiveMenu('dashboard_control');
                  }}
                  className="w-full py-2.5 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xl text-xs cursor-pointer shadow-md"
                >
                  فتح لوحة التحكم الكاملة (God Mode)
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* DOWNLOAD FULL SOURCE CODE / APK / PDF / HTML MODAL */}
      <DownloadCodeModal
        isOpen={isDownloadModalOpen}
        onClose={() => setIsDownloadModalOpen(false)}
        onNotify={(msg, type) => showToast(msg, type || 'info')}
      />

      {/* QUICK STANDALONE APP INSTALL MODAL */}
      <InstallStandaloneModal
        isOpen={isInstallModalOpen}
        onClose={() => setIsInstallModalOpen(false)}
        appName="نصر والت - المنظومة المالية السيادية (NASR WALLET Ω)"
      />
    </div>
  );
};
