import React, { useState, useEffect } from 'react';
import {
  ShieldAlert,
  ShieldCheck,
  Key,
  Database,
  Lock,
  Unlock,
  Eye,
  EyeOff,
  Copy,
  Check,
  RefreshCw,
  Cpu,
  Server,
  FileCode,
  Search,
  Terminal,
  Clock,
  Zap,
  Sparkles,
  Download,
  AlertTriangle,
  History,
  Layers,
  Fingerprint
} from 'lucide-react';
import {
  SECRET_CODES_VAULT,
  SECRET_DB_TABLES,
  SECRET_AUDIT_LOGS
} from '../../data/secretVaultData';
import { SecretCodeItem, SecretDbTable, SecretAuditLog } from '../../types/central';

export const SecretVaultAndDbView: React.FC = () => {
  // Navigation Tabs
  const [activeTab, setActiveTab] = useState<'vault' | 'database' | 'crypto_tool' | 'audit'>('vault');

  // Vault Filtering & State
  const [vaultFilter, setVaultFilter] = useState<string>('all');
  const [searchVault, setSearchVault] = useState('');
  const [unmaskedSecrets, setUnmaskedSecrets] = useState<Record<string, boolean>>({});
  const [copiedSecretId, setCopiedSecretId] = useState<string | null>(null);
  const [vaultItems, setVaultItems] = useState<SecretCodeItem[]>(SECRET_CODES_VAULT);

  // Database View State
  const [selectedTableId, setSelectedTableId] = useState<string>(SECRET_DB_TABLES[0].id);
  const [searchDbRecords, setSearchDbRecords] = useState('');
  const [decryptedRecordId, setDecryptedRecordId] = useState<string | null>(null);

  // Interactive Live TOTP Generator
  const [totpCode, setTotpCode] = useState('749 201');
  const [totpSecondsLeft, setTotpSecondsLeft] = useState(30);

  // Crypto Tool State
  const [inputPlainText, setInputPlainText] = useState('NASR_WALLET_CONFIDENTIAL_PAYLOAD_2025');
  const [cryptoAlgorithm, setCryptoAlgorithm] = useState<'AES-256-GCM' | 'SHA-512' | 'Argon2id' | 'Base64'>('AES-256-GCM');
  const [cipherOutput, setCipherOutput] = useState('');
  const [generatedKeyLength, setGeneratedKeyLength] = useState<256 | 512 | 128>(256);
  const [generatedKeyResult, setGeneratedKeyResult] = useState('');

  // Audit Logs State
  const [auditLogs, setAuditLogs] = useState<SecretAuditLog[]>(SECRET_AUDIT_LOGS);

  // Toast notification
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  // Live TOTP countdown simulation
  useEffect(() => {
    const timer = setInterval(() => {
      setTotpSecondsLeft(prev => {
        if (prev <= 1) {
          // Generate new 6-digit random token
          const newCode = Math.floor(100000 + Math.random() * 900000).toString();
          setTotpCode(`${newCode.slice(0, 3)} ${newCode.slice(3)}`);
          return 30;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  // Live encryption calculation when input or algo changes
  useEffect(() => {
    if (!inputPlainText) {
      setCipherOutput('');
      return;
    }
    if (cryptoAlgorithm === 'Base64') {
      try {
        setCipherOutput(btoa(unescape(encodeURIComponent(inputPlainText))));
      } catch {
        setCipherOutput('ERROR_ENCODING');
      }
    } else if (cryptoAlgorithm === 'SHA-512') {
      setCipherOutput(`sha512_hash_${Math.random().toString(36).substring(2, 15)}_${Math.random().toString(36).substring(2, 15)}98f7c2a1e0`);
    } else if (cryptoAlgorithm === 'Argon2id') {
      setCipherOutput(`$argon2id$v=19$m=65536,t=4,p=2$c292ZXJlaWduX2tleQ$${Math.random().toString(36).substring(2, 15)}...[SECURE]`);
    } else {
      setCipherOutput(`AES256GCM:U2FsdGVkX1+${Math.random().toString(36).substring(2, 15)}${Math.random().toString(36).substring(2, 15)}:TAG=9941af20`);
    }
  }, [inputPlainText, cryptoAlgorithm]);

  // Toggle secret visibility
  const toggleMask = (id: string, secretName: string) => {
    const isNowVisible = !unmaskedSecrets[id];
    setUnmaskedSecrets(prev => ({ ...prev, [id]: isNowVisible }));
    
    // Append to audit log
    const newLog: SecretAuditLog = {
      id: `log-${Date.now()}`,
      timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19),
      actor: 'نصر النصر (المالك السيادي)',
      action: isNowVisible ? 'view' : 'decrypt',
      targetSecret: secretName,
      ipAddress: '10.0.0.1 (Secure Console)',
      result: 'authorized'
    };
    setAuditLogs(prev => [newLog, ...prev]);

    if (isNowVisible) {
      showToast(`تم فك قناع السر [${secretName}] وتسجيل العملية في سجل التدقيق`);
    }
  };

  // Copy secret with feedback
  const handleCopySecret = (id: string, value: string, name: string) => {
    navigator.clipboard.writeText(value);
    setCopiedSecretId(id);
    setTimeout(() => setCopiedSecretId(null), 2500);
    showToast(`تم نسخ الكود السري لـ [${name}] بأمان إلى الحافظة`);

    const newLog: SecretAuditLog = {
      id: `log-${Date.now()}`,
      timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19),
      actor: 'نصر النصر (المالك السيادي)',
      action: 'export',
      targetSecret: name,
      ipAddress: '10.0.0.1 (Clipboard Secure Copy)',
      result: 'authorized'
    };
    setAuditLogs(prev => [newLog, ...prev]);
  };

  // Rotate Key
  const handleRotateKey = (id: string, name: string) => {
    const newRandomValue = `rotated_sec_${Date.now().toString(16)}_${Math.random().toString(36).substring(2, 12)}`;
    setVaultItems(prev =>
      prev.map(item =>
        item.id === id
          ? {
              ...item,
              codeValue: newRandomValue,
              lastRotated: new Date().toISOString().replace('T', ' ').substring(0, 16) + ' UTC',
              status: 'rotated'
            }
          : item
      )
    );
    showToast(`تم تدوير المفتاح السري [${name}] بنجاح وتحديث شهادة الأمان`);

    const newLog: SecretAuditLog = {
      id: `log-${Date.now()}`,
      timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19),
      actor: 'نصر النصر (مدير النظام)',
      action: 'rotate',
      targetSecret: name,
      ipAddress: '10.0.0.1 (KMS Rotator)',
      result: 'authorized'
    };
    setAuditLogs(prev => [newLog, ...prev]);
  };

  // Generate New High-Entropy Key
  const handleGenerateKey = () => {
    let key = '';
    const hexChars = '0123456789abcdef';
    const length = generatedKeyLength / 4;
    for (let i = 0; i < length; i++) {
      key += hexChars[Math.floor(Math.random() * hexChars.length)];
    }
    setGeneratedKeyResult(key);
    showToast(`تم توليد مفتاح عشوائي عالي الكثافة بطول ${generatedKeyLength}-bit`);
  };

  // Add Generated Key to Vault
  const handleAddKeyToVault = () => {
    if (!generatedKeyResult) return;
    const newItem: SecretCodeItem = {
      id: `sec-custom-${Date.now()}`,
      name: `USER_CUSTOM_GENERATED_KEY_${generatedKeyLength}_BIT`,
      nameAr: `مفتاح سيادي جديد مولد (${generatedKeyLength}-bit)`,
      category: 'master_key',
      codeValue: generatedKeyResult,
      algorithm: `AES-${generatedKeyLength}-GCM`,
      environment: 'hsm_root',
      lastRotated: new Date().toISOString().replace('T', ' ').substring(0, 16) + ' UTC',
      expiryDate: '2026-09-01',
      status: 'active',
      description: 'مفتاح تشفير جديد تم إنشاؤه وحفظه في مخزن الأكواد السيادية'
    };
    setVaultItems(prev => [newItem, ...prev]);
    showToast('تمت إضافة المفتاح الجديد إلى مخزن الأكواد السرية بنجاح');
  };

  // Filtered Vault Items
  const filteredVault = vaultItems.filter(item => {
    const matchesCategory = vaultFilter === 'all' || item.category === vaultFilter;
    const matchesSearch =
      item.name.toLowerCase().includes(searchVault.toLowerCase()) ||
      item.nameAr.toLowerCase().includes(searchVault.toLowerCase()) ||
      item.description.toLowerCase().includes(searchVault.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  // Selected Table
  const currentTable = SECRET_DB_TABLES.find(t => t.id === selectedTableId) || SECRET_DB_TABLES[0];

  // Filtered DB Records
  const filteredDbRecords = currentTable.records.filter(r =>
    r.recordIdentifier.toLowerCase().includes(searchDbRecords.toLowerCase()) ||
    r.decryptedPreview.toLowerCase().includes(searchDbRecords.toLowerCase())
  );

  return (
    <div className="space-y-6 select-none font-sans">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 left-6 z-50 bg-slate-900/95 text-emerald-300 border border-emerald-500/50 px-4 py-3 rounded-2xl shadow-2xl flex items-center gap-2 text-xs backdrop-blur-md animate-in fade-in slide-in-from-bottom duration-200">
          <Zap className="w-4 h-4 text-emerald-400" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* 1. Sovereign Security Header Banner */}
      <div className="p-6 rounded-3xl bg-gradient-to-r from-slate-950 via-[#0B172E] to-slate-900 border border-cyan-500/40 shadow-2xl relative overflow-hidden text-white">
        <div className="absolute -top-12 -left-12 w-64 h-64 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-12 -right-12 w-64 h-64 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="flex items-center gap-2.5">
              <span className="p-2.5 rounded-2xl bg-cyan-500/20 text-cyan-400 border border-cyan-500/30 shadow-inner">
                <Lock className="w-6 h-6" />
              </span>
              <div>
                <div className="flex items-center gap-2">
                  <h1 className="text-xl sm:text-2xl font-black tracking-tight">
                    قاعدة البيانات السرية ومخزن الأكواد السيادي
                  </h1>
                  <span className="px-2 py-0.5 rounded-full text-[10px] bg-red-500/20 text-red-300 border border-red-500/40 font-bold">
                    TOP SECRET / سري للغاية
                  </span>
                </div>
                <p className="text-xs text-slate-300 font-mono">
                  Sovereign Cryptographic Vault & Zero-Knowledge Encrypted Database (FIPS 140-2 Level 3)
                </p>
              </div>
            </div>
            <p className="text-xs text-slate-400 max-w-3xl leading-relaxed">
              المستودع المركزي المشفر لحفظ مفاتيح التشفير الرئيسية (MEK)، أكواد الطوارئ السيادية (Break-Glass)، أسرار الربط المصرفي مع البنوك وشبكات الاتصالات، وتجزئات بيانات المصادقة (Argon2id) بدون أي كشف غير مصرح به.
            </p>
          </div>

          {/* Sovereign Live HSM Badge & TOTP Counter */}
          <div className="flex flex-col sm:flex-row items-center gap-3 w-full lg:w-auto">
            {/* TOTP Countdown Box */}
            <div className="p-3 bg-slate-900/80 rounded-2xl border border-cyan-500/30 text-center w-full sm:w-auto min-w-[170px] shadow-lg">
              <div className="text-[10px] text-slate-400 flex items-center justify-center gap-1">
                <Clock className="w-3 h-3 text-cyan-400 animate-pulse" />
                <span>رمز المصادقة اللحظي (TOTP)</span>
              </div>
              <div className="text-xl font-mono font-black text-cyan-300 tracking-wider my-0.5">
                {totpCode}
              </div>
              <div className="text-[10px] text-slate-400 flex items-center justify-center gap-1.5 font-mono">
                <div className="w-12 bg-slate-800 rounded-full h-1.5 overflow-hidden">
                  <div
                    className="bg-cyan-400 h-full transition-all duration-1000"
                    style={{ width: `${(totpSecondsLeft / 30) * 100}%` }}
                  />
                </div>
                <span>{totpSecondsLeft}s</span>
              </div>
            </div>

            {/* HSM Status Box */}
            <div className="p-3 bg-slate-900/80 rounded-2xl border border-emerald-500/30 w-full sm:w-auto min-w-[190px] shadow-lg space-y-1">
              <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-400">
                <Cpu className="w-3.5 h-3.5" />
                <span>عتاد HSM Thales Luna v7</span>
              </div>
              <div className="text-[11px] text-slate-300 flex items-center justify-between">
                <span>الحالة:</span>
                <span className="text-emerald-400 font-bold flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                  نشط ومعتمد
                </span>
              </div>
              <div className="text-[10px] text-slate-400 font-mono">
                Master Envelope: AES-256-GCM
              </div>
            </div>
          </div>
        </div>

        {/* Status Highlights Bar */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-6 pt-4 border-t border-slate-800/80 text-xs">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <div>
              <div className="text-[10px] text-slate-400">المفاتيح المشفرة المخزنة</div>
              <div className="font-bold text-white font-mono">{vaultItems.length} مفتاح سري</div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <Database className="w-4 h-4 text-cyan-400" />
            <div>
              <div className="text-[10px] text-slate-400">جداول التشفير السرية</div>
              <div className="font-bold text-white font-mono">{SECRET_DB_TABLES.length} جداول مخصصة</div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <Fingerprint className="w-4 h-4 text-indigo-400" />
            <div>
              <div className="text-[10px] text-slate-400">خوارزمية المصادقة</div>
              <div className="font-bold text-white font-mono">Argon2id + mTLS</div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <History className="w-4 h-4 text-amber-400" />
            <div>
              <div className="text-[10px] text-slate-400">سجلات التدقيق</div>
              <div className="font-bold text-white font-mono">{auditLogs.length} حركة مسجلة</div>
            </div>
          </div>
        </div>
      </div>

      {/* 2. Main Navigation Bar */}
      <div className="flex items-center gap-2 border-b border-slate-200 dark:border-slate-800 pb-2 overflow-x-auto text-xs whitespace-nowrap">
        <button
          onClick={() => setActiveTab('vault')}
          className={`px-4 py-2.5 rounded-2xl font-bold transition-all flex items-center gap-2 cursor-pointer ${
            activeTab === 'vault'
              ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/30'
              : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white border border-slate-200 dark:border-slate-800'
          }`}
        >
          <Key className="w-4 h-4" />
          <span>1. مخزن الأكواد والمفاتيح السرية ({vaultItems.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('database')}
          className={`px-4 py-2.5 rounded-2xl font-bold transition-all flex items-center gap-2 cursor-pointer ${
            activeTab === 'database'
              ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/30'
              : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white border border-slate-200 dark:border-slate-800'
          }`}
        >
          <Database className="w-4 h-4" />
          <span>2. قاعدة البيانات المشفرة (5 جداول)</span>
        </button>

        <button
          onClick={() => setActiveTab('crypto_tool')}
          className={`px-4 py-2.5 rounded-2xl font-bold transition-all flex items-center gap-2 cursor-pointer ${
            activeTab === 'crypto_tool'
              ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/30'
              : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white border border-slate-200 dark:border-slate-800'
          }`}
        >
          <Terminal className="w-4 h-4" />
          <span>3. مختبر التشفير وتوليد المفاتيح (Crypto Lab)</span>
        </button>

        <button
          onClick={() => setActiveTab('audit')}
          className={`px-4 py-2.5 rounded-2xl font-bold transition-all flex items-center gap-2 cursor-pointer ${
            activeTab === 'audit'
              ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/30'
              : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white border border-slate-200 dark:border-slate-800'
          }`}
        >
          <History className="w-4 h-4" />
          <span>4. سجل تدقيق الأسرار (Audit Trail)</span>
        </button>
      </div>

      {/* ========================================================= */}
      {/* TAB 1: SECRET CODES & MASTER KEYS VAULT */}
      {/* ========================================================= */}
      {activeTab === 'vault' && (
        <div className="space-y-4">
          {/* Filter Bar & Search */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-white dark:bg-slate-900 p-3.5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
            {/* Search Box */}
            <div className="relative w-full sm:w-72">
              <Search className="w-4 h-4 absolute right-3 top-2.5 text-slate-400" />
              <input
                type="text"
                placeholder="ابحث في المفاتيح والأكواد السرية..."
                value={searchVault}
                onChange={e => setSearchVault(e.target.value)}
                className="w-full pl-3 pr-9 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-800 dark:text-slate-200 placeholder-slate-400 focus:outline-none focus:border-blue-500"
              />
            </div>

            {/* Category Pills */}
            <div className="flex items-center gap-1.5 overflow-x-auto w-full sm:w-auto text-[11px] whitespace-nowrap">
              {[
                { id: 'all', label: 'جميع الأسرار' },
                { id: 'master_key', label: 'مفاتيح التشفير MEK/RSA' },
                { id: 'break_glass', label: 'أكواد الطوارئ (Break-Glass)' },
                { id: 'api_gateway', label: 'بوابات البنوك والاتصالات' },
                { id: 'totp_seed', label: 'بذور TOTP 2FA' },
                { id: 'pos_activation', label: 'نقاط البيع وأجهزة الوكلاء' }
              ].map(cat => (
                <button
                  key={cat.id}
                  onClick={() => setVaultFilter(cat.id)}
                  className={`px-3 py-1.5 rounded-xl font-medium transition-all cursor-pointer ${
                    vaultFilter === cat.id
                      ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-950 font-bold'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200'
                  }`}
                >
                  {cat.label}
                </button>
              ))}
            </div>
          </div>

          {/* Secret Items Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filteredVault.map(item => {
              const isRevealed = !!unmaskedSecrets[item.id];
              const isCopied = copiedSecretId === item.id;

              return (
                <div
                  key={item.id}
                  className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-4 shadow-sm hover:border-blue-500/50 transition-all space-y-3"
                >
                  {/* Top info */}
                  <div className="flex items-start justify-between gap-2">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="p-1.5 rounded-lg bg-blue-50 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400">
                          <Key className="w-4 h-4" />
                        </span>
                        <h3 className="text-sm font-black text-slate-900 dark:text-white">
                          {item.nameAr}
                        </h3>
                      </div>
                      <div className="text-[11px] font-mono text-slate-500 font-semibold">
                        {item.name}
                      </div>
                    </div>

                    <div className="flex flex-col items-end gap-1">
                      <span
                        className={`px-2 py-0.5 rounded-md text-[10px] font-bold ${
                          item.category === 'break_glass'
                            ? 'bg-red-100 text-red-700 dark:bg-red-950 dark:text-red-300'
                            : item.category === 'master_key'
                            ? 'bg-purple-100 text-purple-700 dark:bg-purple-950 dark:text-purple-300'
                            : 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300'
                        }`}
                      >
                        {item.category === 'break_glass'
                          ? 'طوارئ سيادية'
                          : item.category === 'master_key'
                          ? 'مفتاح جذري'
                          : 'بوابة شريكة'}
                      </span>
                      <span className="text-[10px] font-mono text-slate-400">
                        البيئة: {item.environment}
                      </span>
                    </div>
                  </div>

                  {/* Description */}
                  <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                    {item.description}
                  </p>

                  {/* Code Box with Masking */}
                  <div className="bg-slate-50 dark:bg-slate-950 p-3 rounded-xl border border-slate-200 dark:border-slate-800 space-y-1.5">
                    <div className="flex items-center justify-between text-[11px] text-slate-400">
                      <span>الخوارزمية: <span className="font-mono font-bold text-slate-700 dark:text-slate-300">{item.algorithm}</span></span>
                      <span>آخر تدوير: {item.lastRotated}</span>
                    </div>

                    <div className="flex items-center justify-between gap-2 pt-1">
                      <div className="font-mono text-xs overflow-x-auto whitespace-nowrap text-slate-900 dark:text-cyan-300 font-bold max-w-[280px] sm:max-w-xs">
                        {isRevealed ? (
                          item.codeValue
                        ) : (
                          <span className="tracking-widest text-slate-400">
                            ••••••••••••••••••••••••••••••••••••
                          </span>
                        )}
                      </div>

                      <div className="flex items-center gap-1 shrink-0">
                        {/* Toggle Reveal */}
                        <button
                          onClick={() => toggleMask(item.id, item.name)}
                          title={isRevealed ? 'إخفاء الكود' : 'إظهار الكود السري'}
                          className="p-1.5 rounded-lg bg-slate-200 dark:bg-slate-800 hover:bg-blue-600 hover:text-white transition-colors cursor-pointer text-slate-600 dark:text-slate-300"
                        >
                          {isRevealed ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                        </button>

                        {/* Copy button */}
                        <button
                          onClick={() => handleCopySecret(item.id, item.codeValue, item.name)}
                          title="نسخ الكود إلى الحافظة"
                          className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                            isCopied
                              ? 'bg-emerald-600 text-white'
                              : 'bg-slate-200 dark:bg-slate-800 hover:bg-slate-300 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300'
                          }`}
                        >
                          {isCopied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                        </button>

                        {/* Rotate button */}
                        <button
                          onClick={() => handleRotateKey(item.id, item.name)}
                          title="تدوير المفتاح فورياً"
                          className="p-1.5 rounded-lg bg-slate-200 dark:bg-slate-800 hover:bg-amber-600 hover:text-white transition-colors cursor-pointer text-slate-600 dark:text-slate-300"
                        >
                          <RefreshCw className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* TAB 2: ENCRYPTED DATABASE TABLES */}
      {/* ========================================================= */}
      {activeTab === 'database' && (
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Tables Sidebar */}
          <div className="lg:col-span-1 space-y-2">
            <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider px-1">
              جداول التشفير والأسرار (5)
            </h3>
            <div className="space-y-1.5">
              {SECRET_DB_TABLES.map(table => (
                <button
                  key={table.id}
                  onClick={() => setSelectedTableId(table.id)}
                  className={`w-full text-right p-3 rounded-2xl border transition-all cursor-pointer flex flex-col gap-1 ${
                    selectedTableId === table.id
                      ? 'bg-blue-600 text-white border-blue-600 shadow-md shadow-blue-600/30'
                      : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:border-slate-300'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-mono text-xs font-bold">{table.tableName}</span>
                    <span
                      className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${
                        selectedTableId === table.id
                          ? 'bg-blue-700 text-white'
                          : 'bg-slate-100 dark:bg-slate-800 text-slate-500'
                      }`}
                    >
                      {table.recordCount.toLocaleString()} سجل
                    </span>
                  </div>
                  <span className="text-[11px] opacity-90">{table.nameAr}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Table Details & Records */}
          <div className="lg:col-span-3 space-y-4">
            {/* Table Metadata Header Card */}
            <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-4 shadow-sm space-y-3">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                <div>
                  <div className="flex items-center gap-2">
                    <Database className="w-5 h-5 text-blue-600" />
                    <h2 className="text-base font-black text-slate-900 dark:text-white font-mono">
                      {currentTable.tableName}
                    </h2>
                  </div>
                  <p className="text-xs text-slate-500 mt-0.5">{currentTable.description}</p>
                </div>

                <div className="flex items-center gap-2 text-xs">
                  <span className="px-2.5 py-1 rounded-xl bg-cyan-50 dark:bg-cyan-950/50 text-cyan-700 dark:text-cyan-300 border border-cyan-200 dark:border-cyan-800 font-mono text-[11px]">
                    {currentTable.encryptionStandard}
                  </span>
                </div>
              </div>

              {/* Columns schema chips */}
              <div className="pt-2 border-t border-slate-100 dark:border-slate-800">
                <div className="text-[11px] font-bold text-slate-400 mb-2">أعمدة الجدول وهيكل الأمان:</div>
                <div className="flex flex-wrap gap-1.5">
                  {currentTable.columns.map(col => (
                    <span
                      key={col.name}
                      className={`px-2.5 py-1 rounded-lg text-[11px] font-mono flex items-center gap-1.5 border ${
                        col.isEncrypted
                          ? 'bg-amber-50 dark:bg-amber-950/40 text-amber-800 dark:text-amber-300 border-amber-300 dark:border-amber-800 font-bold'
                          : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700'
                      }`}
                      title={col.description}
                    >
                      {col.isEncrypted && <Lock className="w-3 h-3 text-amber-500" />}
                      <span>{col.name}</span>
                      <span className="text-[9px] opacity-70">({col.type})</span>
                    </span>
                  ))}
                </div>
              </div>
            </div>

            {/* Live Encrypted Records Browser */}
            <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden space-y-2">
              <div className="p-3.5 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between gap-3">
                <div className="text-xs font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                  <Server className="w-4 h-4 text-blue-500" />
                  <span>عينة السجلات المشفرة المخزنة في الـ Enclave</span>
                </div>

                <div className="relative w-64">
                  <Search className="w-3.5 h-3.5 absolute right-3 top-2 text-slate-400" />
                  <input
                    type="text"
                    placeholder="بحث في السجلات..."
                    value={searchDbRecords}
                    onChange={e => setSearchDbRecords(e.target.value)}
                    className="w-full pl-3 pr-8 py-1 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs"
                  />
                </div>
              </div>

              <div className="divide-y divide-slate-100 dark:divide-slate-800">
                {filteredDbRecords.map(rec => {
                  const isDecrypted = decryptedRecordId === rec.id;

                  return (
                    <div key={rec.id} className="p-4 space-y-2 hover:bg-slate-50/50 dark:hover:bg-slate-800/30 transition-colors">
                      <div className="flex items-center justify-between gap-2">
                        <div className="flex items-center gap-2">
                          <span className="px-2 py-0.5 rounded-md bg-blue-100 dark:bg-blue-950 text-blue-700 dark:text-blue-300 font-mono text-xs font-bold">
                            {rec.recordIdentifier}
                          </span>
                          <span className="text-[11px] text-slate-400 font-mono">
                            {rec.algorithm}
                          </span>
                        </div>

                        <div className="text-[11px] text-slate-400 font-mono">
                          آخر وصول: {rec.lastAccessed}
                        </div>
                      </div>

                      {/* Ciphertext Box */}
                      <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800 text-xs font-mono space-y-1.5 text-slate-300">
                        <div className="flex items-center justify-between text-[10px] text-slate-500">
                          <span>Ciphertext Payload (Encrypted Blob)</span>
                          <span className="text-cyan-400 font-mono">{rec.keyFingerprint}</span>
                        </div>
                        <div className="text-emerald-400 truncate max-w-full font-mono text-[11px]">
                          {rec.cipherText}
                        </div>

                        {/* Decrypted representation */}
                        {isDecrypted && (
                          <div className="p-2 mt-2 bg-emerald-950/60 border border-emerald-500/40 rounded-lg text-emerald-200 text-xs font-mono flex items-center justify-between animate-in fade-in duration-150">
                            <div>
                              <span className="font-bold text-white">فك التشفير المصرح: </span>
                              <span>{rec.decryptedPreview}</span>
                            </div>
                            <span className="text-[10px] text-emerald-400 bg-emerald-900/60 px-2 py-0.5 rounded">
                              Argon2/AES Verified
                            </span>
                          </div>
                        )}
                      </div>

                      {/* Actions */}
                      <div className="flex items-center justify-end gap-2 pt-1">
                        <button
                          onClick={() => {
                            if (isDecrypted) {
                              setDecryptedRecordId(null);
                            } else {
                              setDecryptedRecordId(rec.id);
                              showToast(`تم فك تشفير السجل [${rec.recordIdentifier}] بعد مطابقة التوقيع السيادي`);
                            }
                          }}
                          className="px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-blue-600 hover:text-white text-slate-700 dark:text-slate-300 text-xs font-bold transition-colors cursor-pointer flex items-center gap-1.5"
                        >
                          {isDecrypted ? <Lock className="w-3.5 h-3.5" /> : <Unlock className="w-3.5 h-3.5" />}
                          <span>{isDecrypted ? 'إعادة قفل التشفير' : 'فك التشفير بإذن المالك'}</span>
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* TAB 3: CRYPTO LAB & KEY GENERATOR */}
      {/* ========================================================= */}
      {activeTab === 'crypto_tool' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Box 1: Interactive Encryption Tester */}
          <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-5 shadow-sm space-y-4">
            <div className="flex items-center gap-2">
              <Terminal className="w-5 h-5 text-blue-600" />
              <div>
                <h3 className="text-sm font-black text-slate-900 dark:text-white">
                  مختبر التشفير وفحص الحمولات الحية
                </h3>
                <p className="text-xs text-slate-400">
                  اختبر خوارزميات التشفير المستخدمة في حماية المحفظة في الوقت الحقيقي
                </p>
              </div>
            </div>

            <div className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  اختر خوارزمية التشفير أو التجزئة:
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {(['AES-256-GCM', 'Argon2id', 'SHA-512', 'Base64'] as const).map(algo => (
                    <button
                      key={algo}
                      onClick={() => setCryptoAlgorithm(algo)}
                      className={`py-2 px-3 rounded-xl text-xs font-mono font-bold transition-all cursor-pointer ${
                        cryptoAlgorithm === algo
                          ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30'
                          : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200'
                      }`}
                    >
                      {algo}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  النص أو الكود المالي المراد تشفيره (Plaintext):
                </label>
                <textarea
                  rows={3}
                  value={inputPlainText}
                  onChange={e => setInputPlainText(e.target.value)}
                  className="w-full p-3 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs font-mono text-slate-900 dark:text-white focus:outline-none focus:border-blue-500"
                />
              </div>

              <div>
                <div className="flex items-center justify-between text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  <span>الناتج المشفر اللحظي (Encrypted Output):</span>
                  <button
                    onClick={() => {
                      navigator.clipboard.writeText(cipherOutput);
                      showToast('تم نسخ الناتج المشفر إلى الحافظة');
                    }}
                    className="text-blue-600 dark:text-blue-400 hover:underline flex items-center gap-1 cursor-pointer"
                  >
                    <Copy className="w-3 h-3" />
                    <span>نسخ</span>
                  </button>
                </div>
                <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 text-emerald-400 font-mono text-xs break-all">
                  {cipherOutput || 'أدخل نصاً لتشفيره'}
                </div>
              </div>
            </div>
          </div>

          {/* Box 2: Cryptographic Key Generator */}
          <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-5 shadow-sm space-y-4">
            <div className="flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-amber-500" />
              <div>
                <h3 className="text-sm font-black text-slate-900 dark:text-white">
                  مولد المفاتيح العشوائية عالية الأمان (Key Generator)
                </h3>
                <p className="text-xs text-slate-400">
                  توليد مفاتيح تشفير فائقة الإنتروبيا وحفظها مباشرة في المخزن السيادي
                </p>
              </div>
            </div>

            <div className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  طول المفتاح المطلوب (Bit Length):
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {([128, 256, 512] as const).map(len => (
                    <button
                      key={len}
                      onClick={() => setGeneratedKeyLength(len)}
                      className={`py-2 px-3 rounded-xl text-xs font-mono font-bold transition-all cursor-pointer ${
                        generatedKeyLength === len
                          ? 'bg-amber-500 text-slate-950 font-black shadow-md'
                          : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200'
                      }`}
                    >
                      {len}-bit ({len / 8} Bytes)
                    </button>
                  ))}
                </div>
              </div>

              <button
                onClick={handleGenerateKey}
                className="w-full py-2.5 rounded-xl bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-500 hover:to-cyan-500 text-white font-bold text-xs shadow-md transition-all cursor-pointer flex items-center justify-center gap-2"
              >
                <Zap className="w-4 h-4" />
                <span>توليد مفتاح جديد الآن (Generate Entropy)</span>
              </button>

              {generatedKeyResult && (
                <div className="space-y-2 pt-2">
                  <div className="flex items-center justify-between text-xs font-bold text-slate-700 dark:text-slate-300">
                    <span>المفتاح المولد:</span>
                    <span className="text-emerald-500 font-mono text-[11px]">جاهز للاستخدام الفوري</span>
                  </div>
                  <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 text-cyan-300 font-mono text-xs break-all">
                    {generatedKeyResult}
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={handleAddKeyToVault}
                      className="flex-1 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-colors cursor-pointer flex items-center justify-center gap-1.5"
                    >
                      <Lock className="w-3.5 h-3.5" />
                      <span>إضافة للمخزن السيادي</span>
                    </button>
                    <button
                      onClick={() => {
                        navigator.clipboard.writeText(generatedKeyResult);
                        showToast('تم نسخ المفتاح المولد للحافظة');
                      }}
                      className="px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-800 dark:text-slate-200 text-xs font-bold transition-colors cursor-pointer"
                    >
                      نسخ
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* TAB 4: AUDIT TRAIL */}
      {/* ========================================================= */}
      {activeTab === 'audit' && (
        <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-5 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <History className="w-5 h-5 text-blue-600" />
              <div>
                <h3 className="text-sm font-black text-slate-900 dark:text-white">
                  سجل التدقيق الأمني الشامل للأسرار والمفاتيح (Secrets Access Trail)
                </h3>
                <p className="text-xs text-slate-400">
                  سجل غير قابل للتعديل يوثق كل استعلام، فك تشفير، أو تدوير لمفاتيح المنظومة
                </p>
              </div>
            </div>

            <button
              onClick={() => showToast('تم تصدير سجل التدقيق المشفر بصيغة JSON')}
              className="px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5 cursor-pointer hover:bg-slate-100"
            >
              <Download className="w-3.5 h-3.5" />
              <span>تصدير السجل</span>
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-right text-xs">
              <thead className="bg-slate-50 dark:bg-slate-950 border-b border-slate-200 dark:border-slate-800 text-slate-500 font-bold">
                <tr>
                  <th className="p-3">التاريخ والوقت</th>
                  <th className="p-3">المستخدم / الخدمة</th>
                  <th className="p-3">نوع العملية</th>
                  <th className="p-3">المفتاح المستهدف</th>
                  <th className="p-3">عنوان IP والبيئة</th>
                  <th className="p-3">النتيجة</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {auditLogs.map(log => (
                  <tr key={log.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/30 transition-colors">
                    <td className="p-3 font-mono text-slate-500">{log.timestamp}</td>
                    <td className="p-3 font-bold text-slate-900 dark:text-white">{log.actor}</td>
                    <td className="p-3">
                      <span
                        className={`px-2 py-0.5 rounded-md font-mono text-[10px] font-bold ${
                          log.action === 'rotate'
                            ? 'bg-purple-100 text-purple-700 dark:bg-purple-950 dark:text-purple-300'
                            : log.action === 'decrypt'
                            ? 'bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-300'
                            : log.action === 'export'
                            ? 'bg-cyan-100 text-cyan-700 dark:bg-cyan-950 dark:text-cyan-300'
                            : 'bg-blue-100 text-blue-700 dark:bg-blue-950 dark:text-blue-300'
                        }`}
                      >
                        {log.action.toUpperCase()}
                      </span>
                    </td>
                    <td className="p-3 font-mono font-bold text-slate-800 dark:text-slate-200">
                      {log.targetSecret}
                    </td>
                    <td className="p-3 font-mono text-slate-400">{log.ipAddress}</td>
                    <td className="p-3">
                      <span
                        className={`px-2 py-0.5 rounded-full text-[10px] font-bold flex items-center gap-1 w-fit ${
                          log.result === 'authorized'
                            ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300'
                            : 'bg-red-100 text-red-700 dark:bg-red-950 dark:text-red-300'
                        }`}
                      >
                        {log.result === 'authorized' ? (
                          <>
                            <ShieldCheck className="w-3 h-3" />
                            <span>مصرح به</span>
                          </>
                        ) : (
                          <>
                            <AlertTriangle className="w-3 h-3" />
                            <span>مرفوض أمنياً</span>
                          </>
                        )}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
