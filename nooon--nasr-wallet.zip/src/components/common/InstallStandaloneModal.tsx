import React, { useState, useEffect } from 'react';
import { 
  Smartphone, 
  Download, 
  X, 
  CheckCircle2, 
  Share, 
  PlusSquare, 
  MoreVertical, 
  ExternalLink,
  ShieldCheck,
  Sparkles
} from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  appName?: string;
}

export const InstallStandaloneModal: React.FC<Props> = ({ isOpen, onClose, appName = 'نصر والت (NASR WALLET)' }) => {
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [isInstalled, setIsInstalled] = useState(false);
  const [isAndroid, setIsAndroid] = useState(false);
  const [isIos, setIsIos] = useState(false);

  useEffect(() => {
    // Detect OS
    const ua = navigator.userAgent || '';
    setIsAndroid(/Android/i.test(ua));
    setIsIos(/iPhone|iPad|iPod/i.test(ua));

    // Capture beforeinstallprompt event if available
    const handleBeforeInstall = (e: any) => {
      e.preventDefault();
      setDeferredPrompt(e);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstall);

    // Detect if already running standalone
    if (window.matchMedia('(display-mode: standalone)').matches || (window.navigator as any).standalone) {
      setIsInstalled(true);
    }

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstall);
    };
  }, []);

  const handleInstallClick = async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const choiceResult = await deferredPrompt.userChoice;
      if (choiceResult.outcome === 'accepted') {
        setIsInstalled(true);
      }
      setDeferredPrompt(null);
    } else {
      // Fallback instructions alert or guide
      alert('لتثبيت التطبيق فورياً:\n1. اضغط على زر الخيارات (⋮) أعلى المتصفح.\n2. اختر "تثبيت التطبيق" أو "إضافة إلى الشاشة الرئيسية".');
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-xs">
      <div 
        className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl overflow-hidden flex flex-col my-auto"
        style={{ touchAction: 'pan-y' }}
      >
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-800 flex items-center justify-between bg-gradient-to-r from-emerald-950/80 to-slate-900 shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-2xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
              <Smartphone className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-black text-white flex items-center gap-1.5">
                <span>تثبيت التطبيق على الجوال</span>
                <span className="text-[10px] font-mono bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded-full border border-emerald-500/30">
                  مستقل كالمتجر
                </span>
              </h3>
              <p className="text-[11px] text-slate-400">
                يعمل كتطبيق هاتف حقيقي مستقل بدون شريط متصفح وبدون إنترنت
              </p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 sm:p-5 space-y-4 overflow-y-auto max-h-[75vh]">
          {/* App Preview Card */}
          <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 flex items-center gap-3.5">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-emerald-600 via-teal-600 to-cyan-500 flex items-center justify-center text-white font-black text-2xl shadow-lg shadow-emerald-900/30 shrink-0">
              Ω
            </div>
            <div>
              <div className="text-sm font-bold text-white">{appName}</div>
              <div className="text-xs text-emerald-400 font-mono">نظام نصر السيادي المستقل (PWA Standalone)</div>
              <div className="text-[10px] text-slate-400 mt-0.5 flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5 text-blue-400" />
                <span>حفظ محلي آمن + تشفير كامل</span>
              </div>
            </div>
          </div>

          {/* Native Install Prompt Button */}
          {deferredPrompt ? (
            <button
              onClick={handleInstallClick}
              className="w-full py-3 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold rounded-2xl text-xs flex items-center justify-center gap-2 shadow-lg shadow-emerald-900/40 cursor-pointer transition-all active:scale-95"
            >
              <Download className="w-4 h-4" />
              <span>تثبيت التطبيق الآن بنقرة واحدة (Install App)</span>
            </button>
          ) : (
            <div className="p-3 bg-emerald-950/40 border border-emerald-600/30 rounded-2xl text-center space-y-1">
              <span className="text-xs font-bold text-emerald-300">✔ التطبيق مهيأ بالكامل للتثبيت المباشر على هاتفك</span>
              <p className="text-[11px] text-slate-400">اتبع الخطوتين أدناه لإنزاله على شاشة الهاتف الرئيسية كأي تطبيق من المتجر:</p>
            </div>
          )}

          {/* Android Steps */}
          <div className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-2">
            <div className="text-xs font-bold text-slate-200 flex items-center gap-2">
              <span className="p-1 rounded bg-slate-800 text-slate-300 text-[10px]">Android</span>
              <span>خطوات التثبيت على أجهزة أندرويد (Chrome):</span>
            </div>
            <ol className="text-xs text-slate-300 space-y-1.5 list-decimal list-inside pr-1 leading-relaxed">
              <li>اضغط على زر النقاط الثلاث <strong className="text-white inline-flex items-center gap-1 font-mono">(⋮ خيارات)</strong> أعلى أو أسفل المتصفح.</li>
              <li>اختر <strong className="text-emerald-400 font-bold">"تثبيت التطبيق"</strong> أو <strong className="text-emerald-400 font-bold">"إضافة إلى الشاشة الرئيسية" (Add to Home screen)</strong>.</li>
              <li>اضغط "تثبيت" لتجد أيقونة التطبيق مستقلة تماماً في قائمة تطبيقات هاتفك!</li>
            </ol>
          </div>

          {/* iOS Steps */}
          <div className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-2">
            <div className="text-xs font-bold text-slate-200 flex items-center gap-2">
              <span className="p-1 rounded bg-slate-800 text-slate-300 text-[10px]">iPhone / iPad</span>
              <span>خطوات التثبيت على أجهزة آبل (Safari):</span>
            </div>
            <ol className="text-xs text-slate-300 space-y-1.5 list-decimal list-inside pr-1 leading-relaxed">
              <li>اضغط على زر المشاركة أسفل الشاشة <strong className="text-white inline-flex items-center gap-1">⎋ (Share)</strong>.</li>
              <li>مرر لأسفل واختر <strong className="text-emerald-400 font-bold">"إضافة إلى الصفحة الرئيسية" (Add to Home Screen)</strong>.</li>
              <li>اضغط على <strong className="text-emerald-400 font-bold">"إضافة" (Add)</strong> في أعلى الزاوية.</li>
            </ol>
          </div>

          {/* Advantages */}
          <div className="grid grid-cols-2 gap-2 text-[11px] text-slate-400">
            <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>يعمل بدون شريط عنوان المتصفح</span>
            </div>
            <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>سرعة استجابة فائقة وأوفلاين</span>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-800 bg-slate-900/90 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold transition-all cursor-pointer"
          >
            إغلاق
          </button>
        </div>
      </div>
    </div>
  );
};
