// src/components/ui/Input.tsx
import React, { InputHTMLAttributes, ReactNode, forwardRef } from 'react';
import { cn } from '../../lib/utils';

export interface InputProps extends InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  error?: string;
  hint?: string;
  prefixIcon?: ReactNode;
  suffixIcon?: ReactNode;
}

export const Input = forwardRef<HTMLInputElement, InputProps>(({
  label,
  error,
  hint,
  prefixIcon,
  suffixIcon,
  className,
  id,
  ...props
}, ref) => {
  const inputId = id || (label ? `inp-${label.replace(/\s+/g, '-').toLowerCase()}` : undefined);

  return (
    <div className="w-full text-right">
      {label && (
        <label htmlFor={inputId} className="block text-xs font-medium text-slate-300 mb-1.5">
          {label}
        </label>
      )}
      <div className="relative flex items-center">
        {prefixIcon && (
          <div className="absolute right-3 text-slate-400 pointer-events-none">
            {prefixIcon}
          </div>
        )}
        <input
          id={inputId}
          ref={ref}
          className={cn(
            'w-full bg-slate-900 border border-slate-700/80 rounded-xl px-3 py-2 text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition-colors',
            prefixIcon ? 'pr-9' : '',
            suffixIcon ? 'pl-9' : '',
            error ? 'border-red-500 focus:border-red-500 focus:ring-red-500' : '',
            className
          )}
          {...props}
        />
        {suffixIcon && (
          <div className="absolute left-3 text-slate-400">
            {suffixIcon}
          </div>
        )}
      </div>
      {error && <p className="text-[11px] text-red-400 mt-1">{error}</p>}
      {hint && !error && <p className="text-[11px] text-slate-500 mt-1">{hint}</p>}
    </div>
  );
});

Input.displayName = 'Input';
