// src/components/ui/Badge.tsx
import React, { ReactNode } from 'react';
import { cn } from '../../lib/utils';

export interface BadgeProps {
  variant?: 'success' | 'warning' | 'error' | 'info' | 'neutral' | 'gold';
  size?: 'sm' | 'md';
  children: ReactNode;
  icon?: ReactNode;
  className?: string;
}

export const Badge: React.FC<BadgeProps> = ({
  variant = 'neutral',
  size = 'sm',
  children,
  icon,
  className
}) => {
  const variantStyles = {
    success: 'bg-emerald-950/80 text-emerald-300 border-emerald-600/40',
    warning: 'bg-amber-950/80 text-amber-300 border-amber-600/40',
    error: 'bg-red-950/80 text-red-300 border-red-600/40',
    info: 'bg-blue-950/80 text-blue-300 border-blue-600/40',
    neutral: 'bg-slate-800 text-slate-300 border-slate-700',
    gold: 'bg-amber-500/20 text-amber-300 border-amber-500/40'
  };

  const sizeStyles = {
    sm: 'text-[11px] px-2 py-0.5 rounded-full gap-1',
    md: 'text-xs px-2.5 py-1 rounded-full gap-1.5 font-medium'
  };

  return (
    <span
      className={cn(
        'inline-flex items-center border font-mono tracking-tight shrink-0 select-none',
        variantStyles[variant],
        sizeStyles[size],
        className
      )}
    >
      {icon && <span className="shrink-0">{icon}</span>}
      <span>{children}</span>
    </span>
  );
};
