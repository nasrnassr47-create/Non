// src/components/ui/Card.tsx
import React, { HTMLAttributes, ReactNode } from 'react';
import { cn } from '../../lib/utils';

export interface CardProps extends HTMLAttributes<HTMLDivElement> {
  variant?: 'default' | 'glass' | 'emerald' | 'gold' | 'outline';
  children: ReactNode;
}

export const Card: React.FC<CardProps> = ({
  variant = 'default',
  children,
  className,
  ...props
}) => {
  const variantClasses = {
    default: 'bg-slate-900/90 border border-slate-800 text-slate-100 shadow-lg',
    glass: 'bg-slate-900/60 backdrop-blur-md border border-slate-800/80 text-slate-100 shadow-xl',
    emerald: 'bg-gradient-to-br from-emerald-900/80 via-teal-950/80 to-slate-950 border border-emerald-500/30 text-white shadow-emerald-950/40 shadow-xl',
    gold: 'bg-gradient-to-br from-amber-950/80 via-yellow-950/40 to-slate-950 border border-amber-500/30 text-amber-100 shadow-amber-950/40 shadow-xl',
    outline: 'bg-transparent border border-slate-800 text-slate-200'
  };

  return (
    <div
      className={cn('rounded-2xl p-4 transition-all', variantClasses[variant], className)}
      {...props}
    >
      {children}
    </div>
  );
};
