// src/components/ui/Drawer.tsx
import React, { ReactNode, useEffect } from 'react';
import { X } from 'lucide-react';
import { cn } from '../../lib/utils';

export interface DrawerProps {
  isOpen: boolean;
  onClose: () => void;
  title?: string;
  children: ReactNode;
  position?: 'right' | 'left' | 'bottom';
}

export const Drawer: React.FC<DrawerProps> = ({
  isOpen,
  onClose,
  title,
  children,
  position = 'right'
}) => {
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [isOpen]);

  if (!isOpen) return null;

  const positionClasses = {
    right: 'top-0 right-0 h-full w-full sm:w-96 border-l border-slate-800 animate-in slide-in-from-right duration-200',
    left: 'top-0 left-0 h-full w-full sm:w-96 border-r border-slate-800 animate-in slide-in-from-left duration-200',
    bottom: 'bottom-0 left-0 right-0 max-h-[85vh] rounded-t-3xl border-t border-slate-800 animate-in slide-in-from-bottom duration-200'
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" onClick={onClose} />
      <div
        className={cn(
          'absolute bg-slate-900 shadow-2xl flex flex-col z-10 text-slate-100',
          positionClasses[position]
        )}
      >
        <div className="px-5 py-4 border-b border-slate-800 flex items-center justify-between">
          <h3 className="font-bold text-base text-slate-100">{title || ''}</h3>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl hover:bg-slate-800 text-slate-400 hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
        <div className="flex-1 overflow-y-auto p-5">{children}</div>
      </div>
    </div>
  );
};
