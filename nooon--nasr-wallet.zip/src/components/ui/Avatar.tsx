// src/components/ui/Avatar.tsx
import React from 'react';
import { cn } from '../../lib/utils';

export interface AvatarProps {
  name: string;
  src?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  status?: 'online' | 'offline' | 'busy';
  className?: string;
}

export const Avatar: React.FC<AvatarProps> = ({
  name,
  src,
  size = 'md',
  status,
  className
}) => {
  const sizeClasses = {
    sm: 'w-7 h-7 text-[10px]',
    md: 'w-9 h-9 text-xs',
    lg: 'w-12 h-12 text-sm',
    xl: 'w-16 h-16 text-lg font-bold'
  };

  const getInitials = (n: string) => {
    const parts = n.trim().split(/\s+/);
    if (parts.length >= 2) {
      return `${parts[0][0]}${parts[1][0]}`;
    }
    return n.substring(0, 2);
  };

  return (
    <div className={cn('relative inline-block shrink-0', className)}>
      {src ? (
        <img
          src={src}
          alt={name}
          className={cn('rounded-full object-cover border border-slate-700/80', sizeClasses[size])}
        />
      ) : (
        <div
          className={cn(
            'rounded-full bg-emerald-950 text-emerald-300 border border-emerald-600/40 flex items-center justify-center font-bold font-sans',
            sizeClasses[size]
          )}
        >
          {getInitials(name)}
        </div>
      )}

      {status && (
        <span
          className={cn(
            'absolute bottom-0 right-0 rounded-full ring-2 ring-slate-950',
            size === 'sm' ? 'w-2 h-2' : 'w-2.5 h-2.5',
            status === 'online' ? 'bg-emerald-400' : status === 'busy' ? 'bg-red-400' : 'bg-slate-500'
          )}
        />
      )}
    </div>
  );
};
