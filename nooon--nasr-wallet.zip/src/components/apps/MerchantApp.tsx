import React, { useState } from 'react';
import { 
  Store, 
  QrCode, 
  Receipt, 
  MessageSquare, 
  CheckCircle2, 
  Volume2, 
  TrendingUp, 
  Share2, 
  ArrowRight,
  DollarSign
} from 'lucide-react';

interface Props {
  onNotifyAutoSave?: (action: string) => void;
}

export const MerchantApp: React.FC<Props> = ({ onNotifyAutoSave }) => {
  const [activeTab, setActiveTab] = useState<'pos' | 'invoices' | 'settlement'>('pos');
  const [invoiceAmount, setInvoiceAmount] = useState('');
  const [customerName, setCustomerName] = useState('');
  const [activeQrCode, setActiveQrCode] = useState<string | null>(null);
  const [recentSales, setRecentSales] = useState([
    { id: 's-1', ref: 'INV-8819', customer: 'عميل نقدي', amount: 8500, time: 'منذ 5 دقائق', status: 'مدفوع' },
    { id: 's-2', ref: 'INV-8818', customer: 'زبون واتساب', amount: 34000, time: 'منذ 22 دقيقة', status: 'مدفوع' },
    { id: 's-3', ref: 'INV-8817', customer: 'فاتورة نقاط البيع', amount: 12500, time: 'منذ 40 دقيقة', status: 'مدفوع' },
  ]);
  const [totalSalesToday, setTotalSalesToday] = useState(145000);

  const handleGenerateInvoice = (e: React.FormEvent) => {
    e.preventDefault();
    const amount = parseFloat(invoiceAmount);
    if (!amount || isNaN(amount)) return;

    const ref = `INV-${Math.floor(1000 + Math.random() * 9000)}`;
    setActiveQrCode(ref);

    // Simulate instant customer scan & audio alert after 2.5 seconds
    setTimeout(() => {
      const newSale = {
        id: `s-${Date.now()}`,
        ref,
        customer: customerName || 'زبون الكاشير',
        amount,
        time: 'الآن',
        status: 'مدفوع'
      };
      setRecentSales([newSale, ...recentSales]);
      setTotalSalesToday(prev => prev + amount);
      if (onNotifyAutoSave) {
        onNotifyAutoSave(`عملية بيع جديدة للمتجر #${ref} بقيمة ${amount.toLocaleString()} ر.ي`);
      }
    }, 2500);
  };

  return (
    <div id="merchant-app" className="bg-slate-950 text-slate-100 min-h-[580px] rounded-3xl overflow-hidden flex flex-col shadow-2xl border border-cyan-500/20">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-cyan-950 to-slate-900 p-4 border-b border-cyan-500/30 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-cyan-500/20 text-cyan-400 border border-cyan-500/30">
            <Store className="w-5 h-5" />
          </div>
          <div>
            <div className="text-sm font-bold text-white">تطبيق التاجر ونقاط البيع POS</div>
            <div className="text-xs text-cyan-200/80">متجر نصر للإلكترونيات #882</div>
          </div>
        </div>

        <div className="text-right">
          <div className="text-[10px] text-cyan-200">مبيعات اليوم</div>
          <div className="text-sm font-bold font-mono text-cyan-400">{totalSalesToday.toLocaleString()} ر.ي</div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-slate-800 bg-slate-900 text-xs">
        <button
          onClick={() => setActiveTab('pos')}
          className={`flex-1 py-3 font-semibold transition-all border-b-2 flex items-center justify-center gap-1.5 ${
            activeTab === 'pos' ? 'border-cyan-500 text-cyan-400 bg-slate-800/40' : 'border-transparent text-slate-400'
          }`}
        >
          <QrCode className="w-4 h-4" /> 1. كاشير سريع QR
        </button>

        <button
          onClick={() => setActiveTab('invoices')}
          className={`flex-1 py-3 font-semibold transition-all border-b-2 flex items-center justify-center gap-1.5 ${
            activeTab === 'invoices' ? 'border-cyan-500 text-cyan-400 bg-slate-800/40' : 'border-transparent text-slate-400'
          }`}
        >
          <Receipt className="w-4 h-4" /> 2. المبيعات الأخيرة
        </button>

        <button
          onClick={() => setActiveTab('settlement')}
          className={`flex-1 py-3 font-semibold transition-all border-b-2 flex items-center justify-center gap-1.5 ${
            activeTab === 'settlement' ? 'border-cyan-500 text-cyan-400 bg-slate-800/40' : 'border-transparent text-slate-400'
          }`}
        >
          <TrendingUp className="w-4 h-4" /> 3. التسوية اليومية
        </button>
      </div>

      {/* Content */}
      <div className="flex-1 p-4 overflow-y-auto space-y-4">
        {activeTab === 'pos' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <form onSubmit={handleGenerateInvoice} className="p-4 bg-slate-900 rounded-2xl border border-slate-800 space-y-3">
              <div className="text-xs font-bold text-cyan-400">إصدار فاتورة ودفع سريع:</div>

              <div>
                <label className="text-xs text-slate-400 block mb-1">قيمة الفاتورة (ر.ي)</label>
                <input
                  type="number"
                  placeholder="مثال: 15000"
                  value={invoiceAmount}
                  onChange={(e) => setInvoiceAmount(e.target.value)}
                  required
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-base text-white font-mono focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div>
                <label className="text-xs text-slate-400 block mb-1">اسم الزبون أو رقم الطاولة (اختياري)</label>
                <input
                  type="text"
                  placeholder="زبون الصالة"
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div className="flex gap-2 pt-1">
                <button
                  type="submit"
                  className="flex-1 py-2.5 bg-cyan-600 hover:bg-cyan-500 text-white rounded-xl text-xs font-bold shadow flex items-center justify-center gap-1.5"
                >
                  <QrCode className="w-4 h-4" /> توليد رمز QR للدفع
                </button>
                <button
                  type="button"
                  onClick={() => alert(`تم نسخ رابط دفع واتساب للفاتورة بقيمة ${invoiceAmount || 0} ر.ي`)}
                  className="px-3 py-2.5 bg-emerald-900/60 hover:bg-emerald-800 text-emerald-300 rounded-xl text-xs flex items-center gap-1 border border-emerald-700/40"
                >
                  <MessageSquare className="w-4 h-4" /> واتساب
                </button>
              </div>
            </form>

            {/* Live QR Output */}
            <div className="p-4 bg-slate-900 rounded-2xl border border-slate-800 flex flex-col items-center justify-center text-center space-y-3">
              {activeQrCode ? (
                <>
                  <span className="text-xs text-cyan-300 font-mono font-bold">فاتورة #{activeQrCode}</span>
                  <div className="p-3 bg-white rounded-xl shadow-inner">
                    <QrCode className="w-36 h-36 text-slate-900" />
                  </div>
                  <div className="flex items-center gap-1.5 text-xs text-emerald-400 animate-pulse">
                    <Volume2 className="w-4 h-4" />
                    <span>الكاشير بانتظار مسح الزبون للرمز...</span>
                  </div>
                </>
              ) : (
                <div className="text-slate-500 text-xs py-8">
                  أدخل قيمة الفاتورة لتوليد رمز QR السريع للزبون هنا.
                </div>
              )}
            </div>
          </div>
        )}

        {/* TAB 2: INVOICES */}
        {activeTab === 'invoices' && (
          <div className="space-y-2">
            <div className="text-xs text-slate-400">سجل فواتير اليوم:</div>
            {recentSales.map((s) => (
              <div key={s.id} className="p-3 bg-slate-900 rounded-xl border border-slate-800 flex justify-between items-center text-xs">
                <div>
                  <div className="font-bold text-slate-200">{s.customer}</div>
                  <div className="text-[10px] text-slate-400 font-mono">{s.ref} • {s.time}</div>
                </div>
                <div className="text-left">
                  <div className="font-bold text-emerald-400 font-mono">+{s.amount.toLocaleString()} ر.ي</div>
                  <div className="text-[10px] text-emerald-500">{s.status}</div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* TAB 3: SETTLEMENT */}
        {activeTab === 'settlement' && (
          <div className="p-4 bg-slate-900 rounded-2xl border border-slate-800 space-y-3 text-xs">
            <div className="flex justify-between items-center">
              <span className="font-bold text-slate-200">التسوية الآلية للمتجر</span>
              <span className="bg-emerald-950 text-emerald-300 px-2 py-0.5 rounded border border-emerald-800">
                تسوية يومية 12:00 منتصف الليل
              </span>
            </div>
            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
              <div className="flex justify-between text-slate-300">
                <span>المبيعات المستحقة للتحويل:</span>
                <span className="font-bold text-cyan-400">{totalSalesToday.toLocaleString()} ر.ي</span>
              </div>
              <div className="flex justify-between text-slate-300">
                <span>الحساب البنكي للتسوية:</span>
                <span className="font-mono text-slate-400">بنك التضامن •• 4910</span>
              </div>
            </div>
            <button
              onClick={() => alert('تم ترحيل المبيعات فورياً إلى حسابك البنكي')}
              className="w-full py-2 bg-cyan-600 hover:bg-cyan-500 text-white rounded-xl font-bold"
            >
              تسوية فورية الآن إلى البنك
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
