import React, { useState } from 'react';
import { 
  Headphones, 
  Search, 
  MessageSquare, 
  AlertCircle, 
  CheckCircle2, 
  Clock, 
  Send, 
  RefreshCw,
  User,
  ShieldCheck
} from 'lucide-react';

interface Props {
  onNotifyAutoSave?: (action: string) => void;
}

export const SupportApp: React.FC<Props> = ({ onNotifyAutoSave }) => {
  const [searchRef, setSearchRef] = useState('');
  const [activeTicket, setActiveTicket] = useState<string | null>('t-1');
  const [chatMessage, setChatMessage] = useState('');

  const [tickets] = useState([
    { id: 't-1', customer: 'عبد الرحمن الشامي (771920011)', issue: 'استفسار عن تأخر حوالة بنكية واردة', time: 'منذ 3 دقائق', status: 'جاري الحل', priority: 'متوسط' },
    { id: 't-2', customer: 'متجر البركة (770029188)', issue: 'طلب ربط كاشير POS ثاني مع المتجر', time: 'منذ 15 دقيقة', status: 'جديد', priority: 'عادي' },
    { id: 't-3', customer: 'فؤاد الوصابي (773491022)', issue: 'نسيان رمز المرور واستعادة الحساب KYC', time: 'منذ 30 دقيقة', status: 'معلق', priority: 'عاجل' },
  ]);

  const [messages, setMessages] = useState([
    { sender: 'customer', text: 'السلام عليكم، حولت مبلغ من حسابي في بنك الكريمي إلى محفظة نصر والت ولم يظهر بعد.', time: '14:20' },
    { sender: 'support', text: 'وعليكم السلام ورحمة الله أخي الكريم، مرحباً بك في دعم نصر والت. زودني برقم الحوالة المرجعي وسأفحص دفتر الأستاذ فوراً.', time: '14:21' },
    { sender: 'customer', text: 'الرقم المرجعي هو KRM-9948201', time: '14:22' },
  ]);

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatMessage.trim()) return;

    setMessages(prev => [...prev, { sender: 'support', text: chatMessage, time: 'الآن' }]);
    setChatMessage('');
    if (onNotifyAutoSave) {
      onNotifyAutoSave('إرسال رد في تذكرة الدعم الفني');
    }
  };

  return (
    <div id="support-app" className="bg-slate-950 text-slate-100 min-h-[580px] rounded-3xl overflow-hidden flex flex-col shadow-2xl border border-teal-500/20">
      {/* Top Banner */}
      <div className="bg-slate-900 p-4 border-b border-slate-800 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-teal-500/20 text-teal-400 border border-teal-500/30">
            <Headphones className="w-5 h-5" />
          </div>
          <div>
            <div className="text-sm font-bold text-white">تطبيق الدعم الفني وخدمة العملاء (Support App)</div>
            <div className="text-xs text-slate-400">فريق الدعم الفني الميداني 24/7</div>
          </div>
        </div>

        <span className="text-xs bg-emerald-950 text-emerald-300 px-2.5 py-1 rounded-full border border-emerald-800 flex items-center gap-1">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
          متصل للخدمة
        </span>
      </div>

      {/* Main Split Body */}
      <div className="flex-1 grid grid-cols-1 md:grid-cols-3 overflow-hidden">
        {/* Tickets Sidebar */}
        <div className="border-b md:border-b-0 md:border-l border-slate-800 p-3 space-y-2 bg-slate-900/40 overflow-y-auto">
          <div className="text-xs font-bold text-slate-400 px-1">التذاكر النشطة:</div>
          {tickets.map((t) => (
            <div
              key={t.id}
              onClick={() => setActiveTicket(t.id)}
              className={`p-3 rounded-xl border text-xs cursor-pointer transition-all ${
                activeTicket === t.id
                  ? 'bg-teal-950/50 border-teal-500/60 shadow'
                  : 'bg-slate-900 border-slate-800 hover:border-slate-700'
              }`}
            >
              <div className="font-bold text-slate-200">{t.customer}</div>
              <div className="text-[11px] text-slate-400 mt-1 line-clamp-1">{t.issue}</div>
              <div className="flex justify-between items-center mt-2 pt-1 border-t border-slate-800 text-[10px]">
                <span className="text-teal-400">{t.status}</span>
                <span className="text-slate-500">{t.time}</span>
              </div>
            </div>
          ))}
        </div>

        {/* Live Chat Area */}
        <div className="md:col-span-2 flex flex-col justify-between bg-slate-950 p-4">
          {/* Chat header */}
          <div className="pb-3 border-b border-slate-800 flex items-center justify-between text-xs">
            <div className="flex items-center gap-2">
              <User className="w-4 h-4 text-teal-400" />
              <span className="font-bold text-slate-200">عبد الرحمن الشامي (العميل)</span>
            </div>
            <button
              onClick={() => alert('تم فحص الحوالة في دفتر الأستاذ: مقيدة بنجاح وتم تحويلها لمحفظة العميل')}
              className="px-2 py-1 bg-emerald-950 text-emerald-300 rounded border border-emerald-800/40 text-[11px]"
            >
              فحص الحوالة في الدفتر المالي
            </button>
          </div>

          {/* Messages list */}
          <div className="flex-1 py-4 space-y-3 overflow-y-auto max-h-[340px]">
            {messages.map((m, idx) => (
              <div
                key={idx}
                className={`flex flex-col ${m.sender === 'support' ? 'items-start' : 'items-end'}`}
              >
                <div
                  className={`p-3 rounded-2xl max-w-[80%] text-xs leading-relaxed ${
                    m.sender === 'support'
                      ? 'bg-teal-900 text-teal-100 rounded-tr-none'
                      : 'bg-slate-800 text-slate-200 rounded-tl-none'
                  }`}
                >
                  {m.text}
                </div>
                <span className="text-[10px] text-slate-500 mt-0.5 px-1">{m.time}</span>
              </div>
            ))}
          </div>

          {/* Send Input */}
          <form onSubmit={handleSendMessage} className="pt-3 border-t border-slate-800 flex gap-2">
            <input
              type="text"
              placeholder="اكتب ردك للعميل هنا..."
              value={chatMessage}
              onChange={(e) => setChatMessage(e.target.value)}
              className="flex-1 bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-teal-500"
            />
            <button
              type="submit"
              className="px-4 py-2 bg-teal-600 hover:bg-teal-500 text-white rounded-xl text-xs font-bold flex items-center gap-1 shadow"
            >
              <Send className="w-3.5 h-3.5" /> إرسال
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
