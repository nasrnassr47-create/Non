import React, { useState } from 'react';
import { 
  ShieldAlert, 
  Users, 
  CheckCircle2, 
  XCircle, 
  AlertTriangle, 
  Search, 
  Lock, 
  Unlock, 
  Activity, 
  FileText
} from 'lucide-react';

interface Props {
  onNotifyAutoSave?: (action: string) => void;
}

export const AdminPanel: React.FC<Props> = ({ onNotifyAutoSave }) => {
  const [activeTab, setActiveTab] = useState<'kyc' | 'aml' | 'limits'>('kyc');

  // KYC Requests
  const [kycRequests, setKycRequests] = useState([
    { id: 'kyc-1', name: 'طارق عبد الله الحميري', phone: '772194821', docType: 'بطاقة شخصية ذكية', requestedTier: 'Tier 3', status: 'pending' },
    { id: 'kyc-2', name: 'صلاح أحمد الريمي', phone: '773910244', docType: 'جواز سفر إلكتروني', requestedTier: 'Tier 2', status: 'pending' },
  ]);

  // AML Alerts
  const [amlAlerts, setAmlAlerts] = useState([
    { id: 'aml-1', account: '771892011', reason: 'سحب متزامن سريع يتجاوز 10,000,000 ر.ي في 5 دقائق', risk: 'مرتفع', actionTaken: 'حجز مؤقت' },
    { id: 'aml-2', account: '774019283', reason: 'محاولات دخول متعددة من عناوين IP خارجية مختلفة', risk: 'متوسط', actionTaken: 'طلب 2FA' },
  ]);

  const handleApproveKyc = (id: string, name: string) => {
    setKycRequests(prev => prev.filter(k => k.id !== id));
    if (onNotifyAutoSave) {
      onNotifyAutoSave(`اعتماد توثيق KYC للمستخدم ${name}`);
    }
    alert(`تم اعتماد ترقية المستوى للمستخدم ${name} بنجاح`);
  };

  const handleRejectKyc = (id: string, name: string) => {
    setKycRequests(prev => prev.filter(k => k.id !== id));
    if (onNotifyAutoSave) {
      onNotifyAutoSave(`رفض طلب توثيق KYC للمستخدم ${name}`);
    }
  };

  return (
    <div id="admin-panel" className="bg-slate-950 text-slate-100 min-h-[580px] rounded-3xl overflow-hidden flex flex-col shadow-2xl border border-slate-700">
      {/* Top Banner */}
      <div className="bg-slate-900 p-4 border-b border-slate-800 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-blue-500/20 text-blue-400 border border-blue-500/30">
            <ShieldAlert className="w-5 h-5" />
          </div>
          <div>
            <div className="text-sm font-bold text-white">لوحة التحكم الإدارية والعمليات (Admin Panel)</div>
            <div className="text-xs text-slate-400">إدارة التوثيق KYC ومكافحة الاحتيال AML وضبط الحدود</div>
          </div>
        </div>

        <span className="text-xs bg-blue-950 text-blue-300 px-2.5 py-1 rounded-full border border-blue-800">
          مشرف العمليات النشط
        </span>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-slate-800 bg-slate-900/60 text-xs">
        <button
          onClick={() => setActiveTab('kyc')}
          className={`flex-1 py-3 font-semibold transition-all border-b-2 flex items-center justify-center gap-1.5 ${
            activeTab === 'kyc' ? 'border-blue-500 text-blue-400 bg-slate-800/40' : 'border-transparent text-slate-400'
          }`}
        >
          <Users className="w-4 h-4" /> طلبات التوثيق KYC ({kycRequests.length})
        </button>

        <button
          onClick={() => setActiveTab('aml')}
          className={`flex-1 py-3 font-semibold transition-all border-b-2 flex items-center justify-center gap-1.5 ${
            activeTab === 'aml' ? 'border-blue-500 text-blue-400 bg-slate-800/40' : 'border-transparent text-slate-400'
          }`}
        >
          <AlertTriangle className="w-4 h-4" /> مراقبة AML المشبوهة ({amlAlerts.length})
        </button>

        <button
          onClick={() => setActiveTab('limits')}
          className={`flex-1 py-3 font-semibold transition-all border-b-2 flex items-center justify-center gap-1.5 ${
            activeTab === 'limits' ? 'border-blue-500 text-blue-400 bg-slate-800/40' : 'border-transparent text-slate-400'
          }`}
        >
          <Lock className="w-4 h-4" /> سياسات الحدود والرسوم
        </button>
      </div>

      {/* Body */}
      <div className="flex-1 p-4 overflow-y-auto space-y-3">
        {activeTab === 'kyc' && (
          <div className="space-y-2.5">
            <div className="text-xs text-slate-400">طلبات الترقية للهويات بانتظار الفحص اليدوي:</div>
            {kycRequests.map((req) => (
              <div key={req.id} className="p-3.5 bg-slate-900 rounded-xl border border-slate-800 flex justify-between items-center text-xs">
                <div>
                  <div className="font-bold text-slate-200">{req.name}</div>
                  <div className="text-[11px] text-slate-400 font-mono">{req.phone} • {req.docType}</div>
                  <div className="text-[10px] text-blue-300 mt-1">المستوى المطلوب: {req.requestedTier}</div>
                </div>

                <div className="flex gap-2">
                  <button
                    onClick={() => handleApproveKyc(req.id, req.name)}
                    className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-semibold flex items-center gap-1"
                  >
                    <CheckCircle2 className="w-3.5 h-3.5" /> اعتماد
                  </button>
                  <button
                    onClick={() => handleRejectKyc(req.id, req.name)}
                    className="px-2 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs"
                  >
                    رفض
                  </button>
                </div>
              </div>
            ))}
            {kycRequests.length === 0 && (
              <div className="text-center py-8 text-xs text-slate-500">لا توجد طلبات معلقة حالياً.</div>
            )}
          </div>
        )}

        {activeTab === 'aml' && (
          <div className="space-y-2.5">
            <div className="text-xs text-slate-400">تنبيهات محرك الذكاء الاصطناعي لمكافحة غسل الأموال:</div>
            {amlAlerts.map((alertItem) => (
              <div key={alertItem.id} className="p-3.5 bg-slate-900 rounded-xl border border-red-900/40 space-y-2 text-xs">
                <div className="flex justify-between items-center">
                  <span className="font-mono font-bold text-slate-200">حساب #{alertItem.account}</span>
                  <span className="bg-red-950 text-red-300 px-2 py-0.5 rounded border border-red-800/40 text-[10px]">
                    مستوى الخطر: {alertItem.risk}
                  </span>
                </div>
                <div className="text-slate-300 text-[11px]">{alertItem.reason}</div>
                <div className="flex justify-between items-center pt-1 border-t border-slate-800 text-[11px]">
                  <span className="text-amber-400">الإجراء الآلي: {alertItem.actionTaken}</span>
                  <button 
                    onClick={() => alert(`تم تأكيد الحجز للحساب ${alertItem.account} وإرسال تقرير STR للبنك المركزي`)}
                    className="text-red-400 hover:underline"
                  >
                    تثبيت الحجز وإخطار الرقابة
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}

        {activeTab === 'limits' && (
          <div className="p-4 bg-slate-900 rounded-2xl border border-slate-800 space-y-3 text-xs">
            <div className="font-bold text-slate-200">الحدود التنظيمية المقررة:</div>
            <div className="space-y-2 text-slate-300">
              <div className="p-2.5 bg-slate-950 rounded-lg flex justify-between">
                <span>حد التحويل اليومي للأفراد (Tier 2):</span>
                <span className="font-bold text-blue-400">2,000,000 ر.ي</span>
              </div>
              <div className="p-2.5 bg-slate-950 rounded-lg flex justify-between">
                <span>حد التحويل اليومي للمشترك والتجار (Tier 3):</span>
                <span className="font-bold text-blue-400">50,000,000 ر.ي</span>
              </div>
              <div className="p-2.5 bg-slate-950 rounded-lg flex justify-between">
                <span>رسوم تحويل P2P:</span>
                <span className="font-bold text-emerald-400">0% مجاني</span>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
