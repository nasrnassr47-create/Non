import React, { useState } from 'react';
import { 
  Users, 
  Building2, 
  Landmark, 
  FileSpreadsheet, 
  Plus, 
  CheckCircle2, 
  AlertCircle, 
  DollarSign, 
  Calendar, 
  Shield, 
  ArrowRight, 
  TrendingUp, 
  Download, 
  Share2, 
  Send, 
  Sparkles, 
  Clock, 
  ShieldCheck, 
  Check,
  Smartphone
} from 'lucide-react';
import { FamilyMemberItem } from '../../types';
import { storage } from '../../lib/storage';
import { initialApprovals } from '../../data/centralData';
import { ApprovalItem } from '../../types/central';
import { InstallStandaloneModal } from '../common/InstallStandaloneModal';

interface Props {
  onNotifyAutoSave?: (action: string) => void;
}

export const SubscriberApp: React.FC<Props> = ({ onNotifyAutoSave }) => {
  const [activeTab, setActiveTab] = useState<'family' | 'payroll' | 'banking' | 'subscription_request' | 'reports'>('family');
  const [subTier, setSubTier] = useState<'business' | 'vip_corp' | 'family_plus'>('business');
  const [institutionName, setInstitutionName] = useState('مؤسسة نصر للتجارة والتقنية');
  const [contactPhone, setContactPhone] = useState('775223344');
  const [requestedDeposit, setRequestedDeposit] = useState('18,750,000');
  const [notes, setNotes] = useState('طلب اعتماد سقف مؤسسي وربط مصرفي بنك التضامن وبنك الكريمي');
  const [requestSent, setRequestSent] = useState(false);
  const [isInstallModalOpen, setIsInstallModalOpen] = useState(false);

  // Family members list
  const [familyMembers, setFamilyMembers] = useState<FamilyMemberItem[]>([
    { id: 'f-1', name: 'أم أحمد (الزوجة)', relation: 'زوجة', avatar: '👩', dailyLimit: 150000, spentToday: 35000, monthlyLimit: 1500000, balance: 240000, status: 'active', requiresApproval: false },
    { id: 'f-2', name: 'أحمد ناصر (الابن)', relation: 'ابن (جامعي)', avatar: '🧑', dailyLimit: 25000, spentToday: 12000, monthlyLimit: 300000, balance: 45000, status: 'active', requiresApproval: true },
    { id: 'f-3', name: 'سارة ناصر (الابنة)', relation: 'ابنة (مدرسة)', avatar: '👧', dailyLimit: 10000, spentToday: 3000, monthlyLimit: 120000, balance: 18000, status: 'active', requiresApproval: true },
  ]);

  // Payroll Batch state
  const [payrollStatus, setPayrollStatus] = useState<'idle' | 'processing' | 'completed'>('idle');
  const [employeesCount] = useState(18);
  const [payrollTotal] = useState(4850000); // 4.85 Million YER

  // Bank links
  const [bankAccounts] = useState([
    { id: 'b-1', bank: 'بنك التضامن الإسلامي', iban: 'YE92TIB0001827461928', balance: '12,500,000 YER', status: 'متصل وموثق' },
    { id: 'b-2', bank: 'بنك الكريمي للتمويل الأصغر', iban: 'YE41KRM0009283746192', balance: '25,400 SAR', status: 'متصل وموثق' },
    { id: 'b-3', bank: 'شبكة النجم للتحويلات', iban: 'NAJM-AGENT-9021', balance: 'جاهز للاستلام/التغذية', status: 'ربط مباشر' }
  ]);

  const handleDisbursePayroll = () => {
    setPayrollStatus('processing');
    setTimeout(() => {
      setPayrollStatus('completed');
      if (onNotifyAutoSave) {
        onNotifyAutoSave('صرف دفعة الرواتب لشهر مارس بنجاح لـ 18 موظفاً');
      }
    }, 1200);
  };

  const handleAddAllowance = (memberId: string, amount: number) => {
    setFamilyMembers(prev => prev.map(m => {
      if (m.id === memberId) {
        return { ...m, balance: m.balance + amount };
      }
      return m;
    }));
    if (onNotifyAutoSave) {
      onNotifyAutoSave(`تغذية محفظة تابعة بمبلغ ${amount.toLocaleString()} ر.ي`);
    }
  };

  const handleSubmitSubscriptionRequest = (e: React.FormEvent) => {
    e.preventDefault();
    const newApproval: ApprovalItem = {
      id: `appr-sub-${Date.now()}`,
      type: 'subscription_request',
      requesterName: institutionName,
      requesterPhone: contactPhone,
      amount: `${requestedDeposit} YER`,
      details: `طلب اشتراك باقة (${subTier === 'business' ? 'المشترك التجاري' : subTier === 'vip_corp' ? 'المؤسسات الكبرى VIP' : 'العائلة بلس'}). ملاحظات: ${notes}`,
      time: 'الآن',
      riskLevel: 'medium',
      status: 'pending'
    };

    const currentList = storage.get<ApprovalItem[]>('central_approvals_list', initialApprovals);
    const updated = [newApproval, ...currentList];
    storage.set('central_approvals_list', updated);

    setRequestSent(true);
    if (onNotifyAutoSave) {
      onNotifyAutoSave(`تم رفع طلب اشتراك ${institutionName} إلى النظام المركزي للموافقة والاعتماد`);
    }
  };

  return (
    <div id="subscriber-app" className="bg-slate-950 text-slate-100 min-h-[620px] rounded-3xl overflow-hidden flex flex-col shadow-2xl border border-emerald-500/20">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-emerald-900 to-teal-950 p-4 border-b border-emerald-500/30 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-emerald-500/20 text-emerald-300 border border-emerald-400/30">
            <Building2 className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-sm font-bold text-white">تطبيق المشترك (Subscriber App)</span>
              <span className="text-[10px] bg-emerald-950 text-emerald-300 px-2 py-0.5 rounded-full border border-emerald-700/50">
                باقة المشترك المؤسسي
              </span>
            </div>
            <p className="text-xs text-emerald-200/80">إدارة العائلة • صرف الرواتب • الربط البنكي الموحد</p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => setIsInstallModalOpen(true)}
            className="px-2.5 py-1.5 bg-emerald-600/30 hover:bg-emerald-500/40 border border-emerald-400/40 text-emerald-200 text-xs font-bold rounded-xl flex items-center gap-1.5 transition-all cursor-pointer shadow-sm active:scale-95"
            title="تثبيت تطبيق المشترك لحاله كتطبيق هاتف مستقل"
          >
            <Smartphone className="w-3.5 h-3.5 text-emerald-300" />
            <span className="hidden sm:inline">تثبيت كتطبيق مستقل</span>
            <span className="text-[10px] font-mono bg-emerald-950 px-1 rounded text-emerald-400">PWA</span>
          </button>

          <div className="text-right">
            <div className="text-[11px] text-emerald-200">الرصيد المؤسسي</div>
            <div className="text-sm font-bold font-mono text-emerald-300">18,750,000 YER</div>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-slate-800 bg-slate-900 text-xs">
        <button
          onClick={() => setActiveTab('family')}
          className={`flex-1 py-3 font-semibold transition-all border-b-2 flex items-center justify-center gap-1.5 ${
            activeTab === 'family' ? 'border-emerald-500 text-emerald-400 bg-slate-800/40' : 'border-transparent text-slate-400'
          }`}
        >
          <Users className="w-4 h-4" /> إدارة العائلة (3)
        </button>

        <button
          onClick={() => setActiveTab('payroll')}
          className={`flex-1 py-3 font-semibold transition-all border-b-2 flex items-center justify-center gap-1.5 ${
            activeTab === 'payroll' ? 'border-emerald-500 text-emerald-400 bg-slate-800/40' : 'border-transparent text-slate-400'
          }`}
        >
          <FileSpreadsheet className="w-4 h-4" /> كشوف الرواتب
        </button>

        <button
          onClick={() => setActiveTab('banking')}
          className={`flex-1 py-3 font-semibold transition-all border-b-2 flex items-center justify-center gap-1.5 ${
            activeTab === 'banking' ? 'border-emerald-500 text-emerald-400 bg-slate-800/40' : 'border-transparent text-slate-400'
          }`}
        >
          <Landmark className="w-4 h-4" /> الربط البنكي
        </button>

        <button
          onClick={() => {
            setActiveTab('subscription_request');
            setRequestSent(false);
          }}
          className={`flex-1 py-3 font-semibold transition-all border-b-2 flex items-center justify-center gap-1.5 ${
            activeTab === 'subscription_request' ? 'border-emerald-500 text-emerald-400 bg-slate-800/40' : 'border-transparent text-amber-400/90 hover:text-amber-300'
          }`}
        >
          <Sparkles className="w-4 h-4 text-amber-400" /> طلب اشتراك جديد ⚡
        </button>

        <button
          onClick={() => setActiveTab('reports')}
          className={`flex-1 py-3 font-semibold transition-all border-b-2 flex items-center justify-center gap-1.5 ${
            activeTab === 'reports' ? 'border-emerald-500 text-emerald-400 bg-slate-800/40' : 'border-transparent text-slate-400'
          }`}
        >
          <TrendingUp className="w-4 h-4" /> التقارير
        </button>
      </div>

      {/* Body */}
      <div className="flex-1 p-4 overflow-y-auto space-y-4">
        {/* TAB 1: FAMILY MANAGEMENT */}
        {activeTab === 'family' && (
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-slate-300">أفراد العائلة والمحافظ التابعة</span>
              <button 
                onClick={() => alert('إضافة فرد جديد عبر QR أو رقم الهاتف')}
                className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs flex items-center gap-1"
              >
                <Plus className="w-3.5 h-3.5" /> إضافة فرد
              </button>
            </div>

            <div className="space-y-2.5">
              {familyMembers.map((member) => (
                <div key={member.id} className="p-3.5 bg-slate-900 rounded-xl border border-slate-800 space-y-2.5">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2.5">
                      <span className="text-2xl">{member.avatar}</span>
                      <div>
                        <div className="text-xs font-bold text-slate-100">{member.name}</div>
                        <div className="text-[10px] text-slate-400">{member.relation}</div>
                      </div>
                    </div>
                    <div className="text-left">
                      <div className="text-xs font-bold text-emerald-400">
                        {member.balance.toLocaleString()} ر.ي
                      </div>
                      <div className="text-[10px] text-slate-400">الرصيد المتاح</div>
                    </div>
                  </div>

                  {/* Limits and Progress */}
                  <div className="bg-slate-950 p-2.5 rounded-lg text-xs space-y-1.5">
                    <div className="flex justify-between text-[11px] text-slate-400">
                      <span>مصروف اليوم: {member.spentToday.toLocaleString()} ر.ي</span>
                      <span>الحد اليومي: {member.dailyLimit.toLocaleString()} ر.ي</span>
                    </div>
                    <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                      <div 
                        className="bg-emerald-500 h-full rounded-full"
                        style={{ width: `${Math.min(100, (member.spentToday / member.dailyLimit) * 100)}%` }}
                      />
                    </div>
                  </div>

                  {/* Quick Allowance Actions */}
                  <div className="flex items-center justify-between pt-1 border-t border-slate-800/80 text-xs">
                    <span className="text-[11px] text-slate-400">
                      {member.requiresApproval ? '⚠️ يتطلب موافقة الوصي للمشتريات' : '✅ صرف مباشر دون استئذان'}
                    </span>
                    <div className="flex gap-1.5">
                      <button
                        onClick={() => handleAddAllowance(member.id, 10000)}
                        className="px-2 py-0.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded text-[11px]"
                      >
                        +10,000
                      </button>
                      <button
                        onClick={() => handleAddAllowance(member.id, 50000)}
                        className="px-2 py-0.5 bg-emerald-950 text-emerald-300 hover:bg-emerald-900 rounded border border-emerald-800/50 text-[11px]"
                      >
                        +50,000
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 2: PAYROLL ENGINE */}
        {activeTab === 'payroll' && (
          <div className="p-4 bg-slate-900 rounded-2xl border border-slate-800 space-y-4">
            <div className="flex justify-between items-start">
              <div>
                <h4 className="text-sm font-bold text-white">كشف رواتب شهر مارس 2026</h4>
                <p className="text-xs text-slate-400 mt-0.5">مؤسسة نصر للتجارة والتقنية (18 موظفاً)</p>
              </div>
              <span className="text-xs bg-emerald-950 text-emerald-300 px-2 py-0.5 rounded border border-emerald-800">
                جاهز للصرف
              </span>
            </div>

            <div className="grid grid-cols-2 gap-3 text-center">
              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
                <div className="text-[11px] text-slate-400">إجمالي الرواتب الصافية</div>
                <div className="text-base font-extrabold text-emerald-400 mt-1">
                  {payrollTotal.toLocaleString()} ر.ي
                </div>
              </div>
              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
                <div className="text-[11px] text-slate-400">المستفيدون المعتمدون</div>
                <div className="text-base font-extrabold text-slate-100 mt-1">
                  {employeesCount} موظف
                </div>
              </div>
            </div>

            {payrollStatus === 'completed' ? (
              <div className="p-3.5 bg-emerald-950/70 border border-emerald-600 rounded-xl text-center space-y-2">
                <CheckCircle2 className="w-8 h-8 text-emerald-400 mx-auto" />
                <div className="text-sm font-bold text-emerald-300">تم صرف الرواتب وتوزيع القسائم بنجاح!</div>
                <div className="text-xs text-emerald-200">
                  تم إيداع الرواتب في محافظ الـ 18 موظفاً مع إرسال إشعارات SMS وقسائم مشفرة.
                </div>
              </div>
            ) : (
              <button
                disabled={payrollStatus === 'processing'}
                onClick={handleDisbursePayroll}
                className="w-full py-3 bg-emerald-600 hover:bg-emerald-500 disabled:bg-slate-700 text-white rounded-xl font-bold text-sm shadow-lg flex items-center justify-center gap-2"
              >
                {payrollStatus === 'processing' ? 'جارٍ المعالجة بالقيد المزدوج...' : 'صرف الرواتب لجميع الموظفين بنقرة واحدة'}
              </button>
            )}
          </div>
        )}

        {/* TAB 3: BANK & EXCHANGE LINKING */}
        {activeTab === 'banking' && (
          <div className="space-y-3">
            <div className="text-xs text-slate-400">
              الحسابات المصرفية وشبكات الصرافة المرتبطة بمحفظتك المؤسسية:
            </div>

            <div className="space-y-2">
              {bankAccounts.map((b) => (
                <div key={b.id} className="p-3.5 bg-slate-900 rounded-xl border border-slate-800 space-y-1">
                  <div className="flex justify-between items-center">
                    <span className="text-xs font-bold text-slate-100">{b.bank}</span>
                    <span className="text-[10px] text-emerald-400 bg-emerald-950 px-1.5 py-0.5 rounded border border-emerald-800/40">
                      {b.status}
                    </span>
                  </div>
                  <div className="text-[11px] font-mono text-slate-400">{b.iban}</div>
                  <div className="text-xs font-semibold text-emerald-300 pt-1">
                    الرصيد المرتبط: {b.balance}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB: NEW SUBSCRIPTION REQUEST & CENTRAL APPROVAL */}
        {activeTab === 'subscription_request' && (
          <div className="p-4 bg-slate-900 rounded-2xl border border-slate-800 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="text-sm font-bold text-white flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4 text-amber-400" />
                  <span>طلب اشتراك مؤسسي جديد (رفع للنظام المركزي)</span>
                </h4>
                <p className="text-xs text-slate-400 mt-0.5">
                  عند إرسال الطلب سيظهر فورياً في طابور موافقات لوحة الإدارة المركزية للاعتماد
                </p>
              </div>
              <span className="text-[10px] bg-amber-950 text-amber-300 px-2 py-0.5 rounded border border-amber-800 font-bold">
                موافقة مركزية مطلوبة
              </span>
            </div>

            {requestSent ? (
              <div className="p-5 bg-emerald-950/60 border border-emerald-500 rounded-2xl text-center space-y-3">
                <CheckCircle2 className="w-12 h-12 text-emerald-400 mx-auto" />
                <div className="text-base font-bold text-emerald-300">
                  تم رفع طلب اشتراكك بنجاح إلى النظام المركزي!
                </div>
                <p className="text-xs text-slate-300 leading-relaxed max-w-md mx-auto">
                  الطلب الآن في حالة <strong className="text-amber-300 font-mono">قيد الانتظار (Pending)</strong> في شاشة الموافقات المركزية. بمجرد قيام مدير النظام بالضغط على زر <strong>"اعتماد وتمرير"</strong>، ستتم ترقية حسابك وتفعيل كافة الصلاحيات فورياً.
                </p>
                <div className="pt-2 flex justify-center gap-2">
                  <button
                    onClick={() => setRequestSent(false)}
                    className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-bold transition-all"
                  >
                    تقديم طلب اشتراك آخر
                  </button>
                  <button
                    onClick={() => setActiveTab('family')}
                    className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold transition-all"
                  >
                    الرجوع لإدارة المشترك
                  </button>
                </div>
              </div>
            ) : (
              <form onSubmit={handleSubmitSubscriptionRequest} className="space-y-3.5">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    اسم الشركة / المنشأة أو صاحب الاشتراك
                  </label>
                  <input
                    type="text"
                    required
                    value={institutionName}
                    onChange={e => setInstitutionName(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:border-emerald-500"
                    placeholder="مثال: مؤسسة النصر العالمية"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      رقم الهاتف المعتمد
                    </label>
                    <input
                      type="tel"
                      required
                      value={contactPhone}
                      onChange={e => setContactPhone(e.target.value)}
                      className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white font-mono focus:outline-none focus:border-emerald-500"
                      placeholder="770000000"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      سقف التغذية المطلوب (ر.ي)
                    </label>
                    <input
                      type="text"
                      required
                      value={requestedDeposit}
                      onChange={e => setRequestedDeposit(e.target.value)}
                      className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white font-mono focus:outline-none focus:border-emerald-500"
                      placeholder="10,000,000"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    نوع باقة المشترك
                  </label>
                  <div className="grid grid-cols-3 gap-2">
                    <button
                      type="button"
                      onClick={() => setSubTier('business')}
                      className={`p-2.5 rounded-xl border text-center transition-all cursor-pointer ${
                        subTier === 'business'
                          ? 'border-emerald-500 bg-emerald-950 text-emerald-300 font-bold'
                          : 'border-slate-800 bg-slate-950 text-slate-400'
                      }`}
                    >
                      <div className="text-xs">المشترك التجاري</div>
                      <div className="text-[10px] text-slate-500 mt-0.5">رواتب + عائلة</div>
                    </button>
                    <button
                      type="button"
                      onClick={() => setSubTier('vip_corp')}
                      className={`p-2.5 rounded-xl border text-center transition-all cursor-pointer ${
                        subTier === 'vip_corp'
                          ? 'border-amber-500 bg-amber-950 text-amber-300 font-bold'
                          : 'border-slate-800 bg-slate-950 text-slate-400'
                      }`}
                    >
                      <div className="text-xs">مؤسسات كبرى VIP</div>
                      <div className="text-[10px] text-slate-500 mt-0.5">ربط بنكي مباشر</div>
                    </button>
                    <button
                      type="button"
                      onClick={() => setSubTier('family_plus')}
                      className={`p-2.5 rounded-xl border text-center transition-all cursor-pointer ${
                        subTier === 'family_plus'
                          ? 'border-blue-500 bg-blue-950 text-blue-300 font-bold'
                          : 'border-slate-800 bg-slate-950 text-slate-400'
                      }`}
                    >
                      <div className="text-xs">عائلي بلس</div>
                      <div className="text-[10px] text-slate-500 mt-0.5">محافظ تابعة ممتدة</div>
                    </button>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    تفاصيل وملاحظات الطلب
                  </label>
                  <textarea
                    rows={2}
                    value={notes}
                    onChange={e => setNotes(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:border-emerald-500"
                    placeholder="اكتب أي متطلبات خاصة بالاشتراك..."
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-3 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white rounded-xl font-bold text-xs shadow-lg flex items-center justify-center gap-2 cursor-pointer transition-all"
                >
                  <Send className="w-4 h-4" />
                  <span>إرسال طلب الاشتراك للنظام المركزي للموافقة والقبول</span>
                </button>
              </form>
            )}
          </div>
        )}

        {/* TAB 4: ADVANCED REPORTS */}
        {activeTab === 'reports' && (
          <div className="p-4 bg-slate-900 rounded-2xl border border-slate-800 space-y-3 text-xs">
            <div className="flex justify-between items-center">
              <span className="font-bold text-slate-200">التقرير المالي الموسع (Q1 2026)</span>
              <button 
                onClick={() => alert('تم تصدير كشف الحساب بصيغة PDF')}
                className="text-emerald-400 hover:underline flex items-center gap-1"
              >
                <Download className="w-3.5 h-3.5" /> تحميل PDF
              </button>
            </div>

            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
              <div className="flex justify-between text-slate-300">
                <span>إجمالي المدفوعات التشغيلية:</span>
                <span className="font-bold text-emerald-400">8,950,000 ر.ي</span>
              </div>
              <div className="flex justify-between text-slate-300">
                <span>مصاريف العائلة والمحافظ الفرعية:</span>
                <span className="font-bold text-amber-400">1,240,000 ر.ي</span>
              </div>
              <div className="flex justify-between text-slate-300">
                <span>التحويلات المصرفية الواردة:</span>
                <span className="font-bold text-teal-400">15,000,000 ر.ي</span>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Standalone Install Modal */}
      <InstallStandaloneModal
        isOpen={isInstallModalOpen}
        onClose={() => setIsInstallModalOpen(false)}
        appName="تطبيق المشترك - نصر والت (Subscriber App)"
      />
    </div>
  );
};
