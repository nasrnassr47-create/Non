import React, { useState } from 'react';
import { 
  Crown, 
  ShieldAlert, 
  KeyRound, 
  Cpu, 
  FileLock2, 
  Flame, 
  CheckCircle2, 
  XCircle, 
  RefreshCw, 
  AlertOctagon, 
  Sliders, 
  Terminal,
  Lock,
  Unlock,
  Eye,
  EyeOff
} from 'lucide-react';
import { DevProposal, SecretItem } from '../../types';

interface Props {
  onNotifyAutoSave?: (action: string) => void;
  onSelectModule?: (moduleName: string) => void;
}

export const SovereignOwnerPanel: React.FC<Props> = ({ onNotifyAutoSave, onSelectModule }) => {
  const [godModeActive, setGodModeActive] = useState(true);
  const [emergencyFreezeActive, setEmergencyFreezeActive] = useState(false);
  const [showSecretKey, setShowSecretKey] = useState(false);
  const [activeTab, setActiveTab] = useState<'sovereign' | 'secrets' | 'proposals' | 'audit'>('sovereign');

  // AI Dev proposals awaiting owner approval
  const [proposals, setProposals] = useState<DevProposal[]>([
    {
      id: 'prop-101',
      title: 'تحسين سرعة قفل المحفظة التشاؤمي (Pessimistic Wallet Locking)',
      component: 'Wallet Core Engine (s-wallet)',
      category: 'optimization',
      description: 'استبدال فحص قاعدة البيانات المتكرر بـ Redis In-Memory Distributed Lock لخفض وقت المعالجة من 45ms إلى 12ms',
      diffPreview: '+ const lock = await redis.set(`lock:wallet:${id}`, 1, "NX", "EX", 5);\n- await db.wallets.selectForUpdate(id);',
      impactScore: 94,
      status: 'pending_review',
      createdAt: 'منذ 18 دقيقة'
    },
    {
      id: 'prop-102',
      title: 'إضافة تشفير إضافي لمعرفات عمليات الصرافة اليمنية',
      component: 'Bank & Exchange Gateway (s-link)',
      category: 'security',
      description: 'تطبيق توقيع HMAC-SHA256 على كافة الرسائل المرسلة لشبكات النجم والامتياز لمنع التعديل أثناء النقل',
      diffPreview: '+ const signature = crypto.createHmac("sha256", secretKey).update(payload).digest("hex");',
      impactScore: 98,
      status: 'pending_review',
      createdAt: 'اليوم 09:15 ص'
    }
  ]);

  // Master Secrets Vault
  const [secrets] = useState<SecretItem[]>([
    { id: 'sec-1', keyName: 'MASTER_ENCRYPTION_KEY_AES256', algorithm: 'AES-256-GCM', maskedValue: '••••••••••••••••••••••••••••••••', lastRotated: '2026-03-01', status: 'active', category: 'hsm_master' },
    { id: 'sec-2', keyName: 'CENTRAL_BANK_REPORTING_KEY', algorithm: 'RSA-4096 Private', maskedValue: '••••••••••••••••••••••••••••••••', lastRotated: '2026-02-15', status: 'active', category: 'bank_key' },
    { id: 'sec-3', keyName: 'SHAMIR_SECRET_SHARE_PART_A', algorithm: 'Shamir 2-of-3', maskedValue: '••••••••••••••••••••••••••••••••', lastRotated: '2026-01-20', status: 'active', category: 'hsm_master' }
  ]);

  const handleApproveProposal = (id: string, title: string) => {
    setProposals(prev => prev.map(p => p.id === id ? { ...p, status: 'owner_approved' } : p));
    if (onNotifyAutoSave) {
      onNotifyAutoSave(`اعتماد سيادي ونشر التحسين البرمجي: ${title}`);
    }
    alert(`تم توقيع ونشر التحسين البرمجي "${title}" بنجاح في بيئة الإنتاج.`);
  };

  const handleToggleEmergencyFreeze = () => {
    const nextState = !emergencyFreezeActive;
    setEmergencyFreezeActive(nextState);
    if (onNotifyAutoSave) {
      onNotifyAutoSave(nextState ? 'تفعيل مفتاح الطوارئ السيادي وتجميد الخدمات' : 'إلغاء تجميد الطوارئ واستئناف الخدمات');
    }
  };

  return (
    <div id="sovereign-owner-panel" className="bg-slate-950 text-slate-100 min-h-[620px] rounded-3xl overflow-hidden flex flex-col shadow-2xl border-2 border-amber-500/40">
      {/* Sovereign Header with Gold / Amber Accent */}
      <div className="bg-gradient-to-r from-amber-950 via-slate-900 to-black p-4 border-b border-amber-500/50 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-3 rounded-2xl bg-gradient-to-br from-amber-500 to-yellow-600 text-slate-950 shadow-lg shadow-amber-900/50">
            <Crown className="w-6 h-6 font-bold" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-base md:text-lg font-black text-amber-300">
                لوحة التحكم السيادية للمالك (Sovereign Owner - God Mode)
              </h3>
              <span className="text-[10px] bg-amber-500/20 text-amber-300 px-2.5 py-0.5 rounded-full border border-amber-500/40 font-bold uppercase tracking-wider">
                تحكم مطلق
              </span>
            </div>
            <p className="text-xs text-amber-200/70">
              صلاحيات سيادية لا يمكن تجاوزها • مخزن الأسرار • محرك التطوير الذاتي • مفتاح الطوارئ
            </p>
          </div>
        </div>

        {/* Emergency Kill Switch Button */}
        <button
          onClick={handleToggleEmergencyFreeze}
          className={`px-3 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 border shadow-lg ${
            emergencyFreezeActive 
              ? 'bg-red-600 text-white border-red-400 animate-pulse' 
              : 'bg-slate-900 hover:bg-red-950 text-red-400 border-red-800/60'
          }`}
        >
          <AlertOctagon className="w-4 h-4" />
          {emergencyFreezeActive ? 'النظام مجمد طارئاً (Kill-Switch Active)' : 'مفتاح الطوارئ (Emergency Lock)'}
        </button>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-slate-800 bg-slate-900 text-xs">
        <button
          onClick={() => setActiveTab('sovereign')}
          className={`flex-1 py-3 font-semibold transition-all border-b-2 flex items-center justify-center gap-1.5 ${
            activeTab === 'sovereign' ? 'border-amber-500 text-amber-400 bg-slate-800/40' : 'border-transparent text-slate-400'
          }`}
        >
          <Sliders className="w-4 h-4" /> 1. التجاوز السيادي
        </button>

        <button
          onClick={() => setActiveTab('secrets')}
          className={`flex-1 py-3 font-semibold transition-all border-b-2 flex items-center justify-center gap-1.5 ${
            activeTab === 'secrets' ? 'border-amber-500 text-amber-400 bg-slate-800/40' : 'border-transparent text-slate-400'
          }`}
        >
          <KeyRound className="w-4 h-4" /> 2. مخزن الأسرار (Secrets Vault)
        </button>

        <button
          onClick={() => setActiveTab('proposals')}
          className={`flex-1 py-3 font-semibold transition-all border-b-2 flex items-center justify-center gap-1.5 ${
            activeTab === 'proposals' ? 'border-amber-500 text-amber-400 bg-slate-800/40' : 'border-transparent text-slate-400'
          }`}
        >
          <Cpu className="w-4 h-4" /> 3. محرك التطوير وموافقة الكود ({proposals.filter(p => p.status === 'pending_review').length})
        </button>

        <button
          onClick={() => setActiveTab('audit')}
          className={`flex-1 py-3 font-semibold transition-all border-b-2 flex items-center justify-center gap-1.5 ${
            activeTab === 'audit' ? 'border-amber-500 text-amber-400 bg-slate-800/40' : 'border-transparent text-slate-400'
          }`}
        >
          <FileLock2 className="w-4 h-4" /> 4. السجل السيادي غير القابل للمسح
        </button>
      </div>

      {/* Content Body */}
      <div className="flex-1 p-4 overflow-y-auto space-y-4">
        {/* TAB 1: SOVEREIGN CONTROLS */}
        {activeTab === 'sovereign' && (
          <div className="space-y-3">
            <div className="p-4 bg-amber-950/20 border border-amber-800/40 rounded-2xl text-xs space-y-2">
              <div className="text-amber-300 font-bold flex items-center gap-2">
                <Crown className="w-4 h-4" /> مبادئ التحكم السيادي لنصر والت:
              </div>
              <p className="text-slate-300 leading-relaxed">
                المالك هو السلطة العليا السيادية الوحيدة للنظام. يمتلك حق التجاوز الفوري (Sovereign Override) في الحالات القاهرة كإلغاء قفل الحسابات المجمدة خطأ، أو التدخل لحل النزاعات المعقدة، مع تسجيل كل خطوة في السجل المشفر.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div className="p-3.5 bg-slate-900 rounded-xl border border-slate-800 space-y-2">
                <div className="font-bold text-slate-200">السيولة المركزية الإجمالية الحية</div>
                <div className="text-xl font-mono font-bold text-emerald-400">
                  482,900,000 YER <span className="text-xs text-slate-400">(482.9 مليون)</span>
                </div>
                <div className="text-[11px] text-slate-400">
                  موزعة على 3 عملات مع مطابقة كاملة لدفتر الأستاذ المزدوج 100%
                </div>
              </div>

              <div className="p-3.5 bg-slate-900 rounded-xl border border-slate-800 space-y-2">
                <div className="font-bold text-slate-200">إجراءات التدخل السريع للمالك</div>
                <div className="flex flex-wrap gap-2 pt-1">
                  <button
                    onClick={() => {
                      if (onNotifyAutoSave) onNotifyAutoSave('أمر سيادي: تدقيق القيد المالي الشامل');
                      alert('تم تنفيذ مطابقة ومراجعة القيد المزدوج لكافة المحافظ.');
                    }}
                    className="px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg"
                  >
                    مطابقة فورية للدفاتر
                  </button>
                  <button
                    onClick={() => {
                      if (onNotifyAutoSave) onNotifyAutoSave('أمر سيادي: تدوير مفاتيح الـ API');
                      alert('تم تدوير مفاتيح الـ API المشفرة بأمان.');
                    }}
                    className="px-2.5 py-1.5 bg-amber-950 text-amber-300 hover:bg-amber-900 rounded-lg border border-amber-700/50"
                  >
                    تدوير المفاتيح المشفرة
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: SECRETS VAULT */}
        {activeTab === 'secrets' && (
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-300">مخزن الأسرار المشفر (Secrets Vault - AES 256):</span>
              <button
                onClick={() => setShowSecretKey(!showSecretKey)}
                className="text-xs text-amber-400 hover:text-amber-300 flex items-center gap-1"
              >
                {showSecretKey ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                {showSecretKey ? 'إخفاء الأسرار' : 'إظهار التجزئة الحية'}
              </button>
            </div>

            <div className="space-y-2">
              {secrets.map((sec) => (
                <div key={sec.id} className="p-3.5 bg-slate-900 rounded-xl border border-slate-800 space-y-1.5 text-xs">
                  <div className="flex justify-between items-center">
                    <span className="font-mono font-bold text-amber-300">{sec.keyName}</span>
                    <span className="text-[10px] bg-slate-800 text-slate-400 px-2 py-0.5 rounded">
                      {sec.algorithm}
                    </span>
                  </div>
                  <div className="p-2 bg-slate-950 rounded font-mono text-[11px] text-slate-400 break-all">
                    {showSecretKey ? `nasr_sec_${sec.id}_${Math.random().toString(36).substring(2, 22)}_gcm` : sec.maskedValue}
                  </div>
                  <div className="flex justify-between text-[10px] text-slate-500 pt-1">
                    <span>آخر تدوير: {sec.lastRotated}</span>
                    <span className="text-emerald-400">محمي بـ Hardware Security Module (HSM)</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 3: AI DEV PROPOSALS */}
        {activeTab === 'proposals' && (
          <div className="space-y-3">
            <div className="p-3 bg-slate-900 rounded-xl border border-slate-800 text-xs text-slate-300 flex items-center gap-2">
              <Cpu className="w-4 h-4 text-amber-400 shrink-0" />
              <span>
                <strong>جدار حماية الكود:</strong> محرك الذكاء الاصطناعي يحلل النظام ويقترح التحسينات، لكن لا ينفذ أي سطر كود إلا بتوقيع المالك.
              </span>
            </div>

            <div className="space-y-3">
              {proposals.map((prop) => (
                <div key={prop.id} className="p-4 bg-slate-900 rounded-2xl border border-slate-800 space-y-3 text-xs">
                  <div className="flex justify-between items-start">
                    <div>
                      <div className="font-bold text-slate-100 text-sm">{prop.title}</div>
                      <div className="text-[11px] text-slate-400 mt-0.5">
                        المكون المستهدف: <span className="text-amber-300 font-mono">{prop.component}</span> • {prop.createdAt}
                      </div>
                    </div>
                    <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${
                      prop.status === 'owner_approved' 
                        ? 'bg-emerald-950 text-emerald-300 border border-emerald-800' 
                        : 'bg-amber-950 text-amber-300 border border-amber-800'
                    }`}>
                      {prop.status === 'owner_approved' ? 'معتمد ومنشور' : 'بانتظار موافقة المالك'}
                    </span>
                  </div>

                  <p className="text-slate-300 text-xs leading-relaxed">{prop.description}</p>

                  <div className="bg-slate-950 p-2.5 rounded-xl font-mono text-[11px] text-emerald-400 overflow-x-auto border border-slate-800/80">
                    <pre>{prop.diffPreview}</pre>
                  </div>

                  {prop.status === 'pending_review' && (
                    <div className="flex gap-2 pt-1">
                      <button
                        onClick={() => handleApproveProposal(prop.id, prop.title)}
                        className="px-4 py-2 bg-gradient-to-r from-amber-600 to-yellow-600 hover:from-amber-500 hover:to-yellow-500 text-slate-950 font-bold rounded-xl text-xs flex items-center gap-1.5 shadow"
                      >
                        <CheckCircle2 className="w-4 h-4" /> اعتماد سيادي ونشر فوري للكود
                      </button>
                      <button
                        onClick={() => alert('تم رفض المقترح وإعادته لمحرك الذكاء الاصطناعي لإعادة الصياغة')}
                        className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs"
                      >
                        رفض
                      </button>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 4: IMMUTABLE AUDIT LOG */}
        {activeTab === 'audit' && (
          <div className="p-4 bg-slate-900 rounded-2xl border border-slate-800 space-y-3 text-xs">
            <div className="flex justify-between items-center">
              <span className="font-bold text-slate-200">سجل التدقيق غير القابل للتعديل (Hash-Chained):</span>
              <span className="text-[10px] text-emerald-400 font-mono">Chain Verified ✓</span>
            </div>

            <div className="space-y-2 font-mono text-[11px]">
              <div className="p-2.5 bg-slate-950 rounded-lg border border-slate-800 text-slate-300">
                <div className="text-amber-400 font-bold">BLOCK #8401 • SOVEREIGN_VAULT_UNLOCK</div>
                <div className="text-slate-500">Prev: a981..3e • Hash: 4e91..1c • 2026-03-21 14:40:12</div>
              </div>
              <div className="p-2.5 bg-slate-950 rounded-lg border border-slate-800 text-slate-300">
                <div className="text-emerald-400 font-bold">BLOCK #8400 • LEDGER_RECONCILIATION_PASS</div>
                <div className="text-slate-500">Prev: 2b44..9d • Hash: a981..3e • 2026-03-21 14:35:00</div>
              </div>
              <div className="p-2.5 bg-slate-950 rounded-lg border border-slate-800 text-slate-300">
                <div className="text-teal-400 font-bold">BLOCK #8399 • BATCH_PAYROLL_EXECUTE</div>
                <div className="text-slate-500">Prev: 7f19..0a • Hash: 2b44..9d • 2026-03-21 14:20:41</div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
