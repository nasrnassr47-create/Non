import React, { useState } from 'react';
import { 
  Briefcase, 
  ArrowDownCircle, 
  ArrowUpCircle, 
  Coins, 
  CheckCircle2, 
  Search, 
  ShieldCheck, 
  Clock, 
  Printer
} from 'lucide-react';

interface Props {
  onNotifyAutoSave?: (action: string) => void;
}

export const AgentApp: React.FC<Props> = ({ onNotifyAutoSave }) => {
  const [activeMode, setActiveMode] = useState<'cash_in' | 'cash_out' | 'settlement'>('cash_in');
  const [agentFloat, setAgentFloat] = useState(25000000); // 25 Million YER
  const [commissionsEarned, setCommissionsEarned] = useState(145000);
  
  // Cash-in state
  const [clientPhone, setClientPhone] = useState('');
  const [cashInAmount, setCashInAmount] = useState('');
  const [cashInResult, setCashInResult] = useState<string | null>(null);

  // Cash-out state
  const [cashOutOtp, setCashOutOtp] = useState('');
  const [cashOutAmount, setCashOutAmount] = useState('');

  const handleCashIn = (e: React.FormEvent) => {
    e.preventDefault();
    const amount = parseFloat(cashInAmount);
    if (!amount || isNaN(amount)) return;
    if (amount > agentFloat) {
      alert('رصيد صندوق الوكيل غير كافٍ');
      return;
    }

    const comm = Math.round(amount * 0.005); // 0.5% commission
    setAgentFloat(prev => prev - amount);
    setCommissionsEarned(prev => prev + comm);
    setCashInResult(`تم إيداع ${amount.toLocaleString()} ر.ي بنجاح إلى حساب العميل ${clientPhone}. عمولتك الفورية: ${comm.toLocaleString()} ر.ي`);
    setClientPhone('');
    setCashInAmount('');

    if (onNotifyAutoSave) {
      onNotifyAutoSave(`إيداع نقدي للعميل بقيمة ${amount.toLocaleString()} ر.ي`);
    }
  };

  const handleCashOut = (e: React.FormEvent) => {
    e.preventDefault();
    const amount = parseFloat(cashOutAmount);
    if (!amount || !cashOutOtp) return;

    const comm = Math.round(amount * 0.005);
    setAgentFloat(prev => prev + amount);
    setCommissionsEarned(prev => prev + comm);
    alert(`تم تأكيد السحب برمز OTP ${cashOutOtp}. تم تسليم العميل ${amount.toLocaleString()} ر.ي نقداً. عمولتك: ${comm.toLocaleString()} ر.ي`);
    setCashOutOtp('');
    setCashOutAmount('');

    if (onNotifyAutoSave) {
      onNotifyAutoSave(`سحب نقدي مؤكد للعميل`);
    }
  };

  return (
    <div id="agent-app" className="bg-slate-950 text-slate-100 min-h-[580px] rounded-3xl overflow-hidden flex flex-col shadow-2xl border border-amber-500/20">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-amber-950 to-slate-900 p-4 border-b border-amber-500/30 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/30">
            <Briefcase className="w-5 h-5" />
          </div>
          <div>
            <div className="text-sm font-bold text-white">تطبيق الوكيل والصراف الميداني</div>
            <div className="text-xs text-amber-200/80">وكالة نصر المعتمدة رقم #419</div>
          </div>
        </div>

        <div className="text-right">
          <div className="text-[10px] text-amber-200">صندوق الوكيل (Float)</div>
          <div className="text-sm font-bold font-mono text-amber-400">{agentFloat.toLocaleString()} ر.ي</div>
        </div>
      </div>

      {/* Modes */}
      <div className="flex border-b border-slate-800 bg-slate-900 text-xs">
        <button
          onClick={() => setActiveMode('cash_in')}
          className={`flex-1 py-3 font-semibold transition-all border-b-2 flex items-center justify-center gap-1.5 ${
            activeMode === 'cash_in' ? 'border-amber-500 text-amber-400 bg-slate-800/40' : 'border-transparent text-slate-400'
          }`}
        >
          <ArrowDownCircle className="w-4 h-4" /> 1. إيداع نقدي للعميل
        </button>
        <button
          onClick={() => setActiveMode('cash_out')}
          className={`flex-1 py-3 font-semibold transition-all border-b-2 flex items-center justify-center gap-1.5 ${
            activeMode === 'cash_out' ? 'border-amber-500 text-amber-400 bg-slate-800/40' : 'border-transparent text-slate-400'
          }`}
        >
          <ArrowUpCircle className="w-4 h-4" /> 2. سحب نقدي
        </button>
        <button
          onClick={() => setActiveMode('settlement')}
          className={`flex-1 py-3 font-semibold transition-all border-b-2 flex items-center justify-center gap-1.5 ${
            activeMode === 'settlement' ? 'border-amber-500 text-amber-400 bg-slate-800/40' : 'border-transparent text-slate-400'
          }`}
        >
          <Coins className="w-4 h-4" /> 3. عمولاتي والصندوق
        </button>
      </div>

      {/* Content */}
      <div className="flex-1 p-4 overflow-y-auto space-y-4">
        {/* MODE 1: CASH-IN */}
        {activeMode === 'cash_in' && (
          <form onSubmit={handleCashIn} className="p-4 bg-slate-900 rounded-2xl border border-slate-800 space-y-3">
            <div className="text-xs font-bold text-amber-400">تنفيذ إيداع نقدي في محفظة العميل:</div>
            
            <div>
              <label className="text-xs text-slate-400 block mb-1">رقم هاتف العميل</label>
              <input
                type="text"
                placeholder="770112233"
                value={clientPhone}
                onChange={(e) => setClientPhone(e.target.value)}
                required
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-500"
              />
            </div>

            <div>
              <label className="text-xs text-slate-400 block mb-1">المبلغ المستلم نقداً (ر.ي)</label>
              <input
                type="number"
                placeholder="مثال: 100000"
                value={cashInAmount}
                onChange={(e) => setCashInAmount(e.target.value)}
                required
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-500"
              />
            </div>

            <button
              type="submit"
              className="w-full py-2.5 bg-amber-600 hover:bg-amber-500 text-white rounded-xl text-xs font-bold shadow"
            >
              استلام النقد وتغذية محفظة العميل فوراً
            </button>

            {cashInResult && (
              <div className="p-3 bg-emerald-950/70 border border-emerald-700 rounded-xl text-xs text-emerald-200">
                {cashInResult}
              </div>
            )}
          </form>
        )}

        {/* MODE 2: CASH-OUT */}
        {activeMode === 'cash_out' && (
          <form onSubmit={handleCashOut} className="p-4 bg-slate-900 rounded-2xl border border-slate-800 space-y-3">
            <div className="text-xs font-bold text-amber-400">تنفيذ سحب نقدي بطلب العميل:</div>

            <div>
              <label className="text-xs text-slate-400 block mb-1">رمز السحب الأمني (OTP) من تطبيق العميل</label>
              <input
                type="text"
                placeholder="6 أرقام سرية"
                value={cashOutOtp}
                onChange={(e) => setCashOutOtp(e.target.value)}
                required
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-500 font-mono tracking-widest text-center"
              />
            </div>

            <div>
              <label className="text-xs text-slate-400 block mb-1">المبلغ المراد سحبه (ر.ي)</label>
              <input
                type="number"
                placeholder="مثال: 50000"
                value={cashOutAmount}
                onChange={(e) => setCashOutAmount(e.target.value)}
                required
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-500"
              />
            </div>

            <button
              type="submit"
              className="w-full py-2.5 bg-gradient-to-r from-amber-600 to-teal-600 hover:from-amber-500 hover:to-teal-500 text-white rounded-xl text-xs font-bold shadow"
            >
              التحقق من الرمز وتسليم النقد للعميل
            </button>
          </form>
        )}

        {/* MODE 3: COMMISSIONS & SETTLEMENT */}
        {activeMode === 'settlement' && (
          <div className="space-y-3">
            <div className="p-4 bg-slate-900 rounded-2xl border border-slate-800 space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-xs text-slate-400">أرباح وعمولات الوكيل المتراكمة</span>
                <span className="text-xs bg-emerald-950 text-emerald-300 px-2 py-0.5 rounded border border-emerald-800">
                  تودع لحظياً
                </span>
              </div>
              <div className="text-2xl font-extrabold text-emerald-400 font-mono">
                {commissionsEarned.toLocaleString()} ر.ي
              </div>

              <div className="pt-2 border-t border-slate-800 flex gap-2">
                <button
                  onClick={() => alert('تم ترحيل العمولات إلى حسابك التجاري')}
                  className="flex-1 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs rounded-xl"
                >
                  سحب العمولات للحساب
                </button>
                <button
                  onClick={() => alert('تمت طباعة إيصال جرد الصندوق')}
                  className="px-3 py-2 bg-emerald-950 hover:bg-emerald-900 text-emerald-300 border border-emerald-800/40 text-xs rounded-xl flex items-center gap-1"
                >
                  <Printer className="w-3.5 h-3.5" /> جرد الصندوق
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
