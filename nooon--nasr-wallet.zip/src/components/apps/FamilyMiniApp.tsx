import React, { useState } from 'react';
import { 
  HeartHandshake, 
  Send, 
  QrCode, 
  Clock, 
  AlertCircle, 
  CheckCircle2, 
  Coffee, 
  BookOpen, 
  ShoppingBag, 
  Smartphone,
  ShieldAlert
} from 'lucide-react';

interface Props {
  onNotifyAutoSave?: (action: string) => void;
}

export const FamilyMiniApp: React.FC<Props> = ({ onNotifyAutoSave }) => {
  const [balance, setBalance] = useState(45000);
  const [dailyLimit] = useState(25000);
  const [spentToday, setSpentToday] = useState(12000);
  const [requestAmount, setRequestAmount] = useState('');
  const [requestReason, setRequestReason] = useState('');
  const [approvalStatus, setApprovalStatus] = useState<'idle' | 'pending' | 'approved'>('idle');

  const handleRequestAllowance = (e: React.FormEvent) => {
    e.preventDefault();
    const amountNum = parseFloat(requestAmount);
    if (!amountNum || isNaN(amountNum)) return;

    setApprovalStatus('pending');
    if (onNotifyAutoSave) {
      onNotifyAutoSave(`طلب مصروف استثنائي بقيمة ${amountNum.toLocaleString()} ر.ي`);
    }

    // Auto simulated parent response after 2 seconds
    setTimeout(() => {
      setApprovalStatus('approved');
      setBalance(prev => prev + amountNum);
      if (onNotifyAutoSave) {
        onNotifyAutoSave(`موافقة ولي الأمر على المصروف`);
      }
    }, 2000);
  };

  const handleQuickSpend = (category: string, amount: number) => {
    if (spentToday + amount > dailyLimit) {
      alert('عفواً، لقد تجاوزت الحد اليومي المسموح به من قِبل ولي الأمر (25,000 ر.ي)');
      return;
    }
    if (amount > balance) {
      alert('الرصيد في محفظتك غير كافٍ');
      return;
    }
    setBalance(prev => prev - amount);
    setSpentToday(prev => prev + amount);
    if (onNotifyAutoSave) {
      onNotifyAutoSave(`شراء ${category} بقيمة ${amount.toLocaleString()} ر.ي`);
    }
    alert(`تم الدفع بنجاح لـ ${category}`);
  };

  return (
    <div id="family-mini-app" className="bg-slate-950 text-slate-100 min-h-[580px] rounded-3xl overflow-hidden flex flex-col shadow-2xl border border-teal-500/20">
      {/* Header */}
      <div className="bg-slate-900 p-4 border-b border-slate-800 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-teal-500/20 text-teal-400 flex items-center justify-center text-lg border border-teal-500/40">
            🧑
          </div>
          <div>
            <div className="text-xs text-slate-400">محفظة الابن التابعة</div>
            <div className="text-sm font-bold text-white">أحمد ناصر اليماني</div>
          </div>
        </div>

        <span className="text-[10px] bg-teal-950 text-teal-300 px-2 py-0.5 rounded-full border border-teal-800/40">
          تحت إشراف ولي الأمر
        </span>
      </div>

      {/* Body */}
      <div className="flex-1 p-4 overflow-y-auto space-y-4">
        {/* Balance card */}
        <div className="p-4 rounded-2xl bg-gradient-to-br from-teal-900 via-slate-900 to-slate-950 border border-teal-500/30 text-center space-y-2">
          <div className="text-xs text-teal-200">الرصيد المتاح للمصروف</div>
          <div className="text-3xl font-extrabold text-white font-mono">
            {balance.toLocaleString()} <span className="text-teal-300 text-sm font-normal">ر.ي</span>
          </div>

          <div className="pt-2 border-t border-slate-800/80 flex justify-between text-xs text-slate-400">
            <span>مصروف اليوم: {spentToday.toLocaleString()} ر.ي</span>
            <span>الحد المتبقي: {(dailyLimit - spentToday).toLocaleString()} ر.ي</span>
          </div>
        </div>

        {/* Quick spending categories */}
        <div className="space-y-2">
          <div className="text-xs font-semibold text-slate-300">الدفع المباشر المصرح به:</div>
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={() => handleQuickSpend('كافتيريا الجامعة', 2500)}
              className="p-3 bg-slate-900 hover:bg-slate-800 rounded-xl border border-slate-800 text-right flex items-center gap-2 transition-all"
            >
              <Coffee className="w-5 h-5 text-amber-400 shrink-0" />
              <div>
                <div className="text-xs font-bold text-slate-200">وجبة / كافتيريا</div>
                <div className="text-[10px] text-slate-400">2,500 ر.ي</div>
              </div>
            </button>

            <button
              onClick={() => handleQuickSpend('مكتبة وكتب دراسية', 5000)}
              className="p-3 bg-slate-900 hover:bg-slate-800 rounded-xl border border-slate-800 text-right flex items-center gap-2 transition-all"
            >
              <BookOpen className="w-5 h-5 text-blue-400 shrink-0" />
              <div>
                <div className="text-xs font-bold text-slate-200">كتب ومستلزمات</div>
                <div className="text-[10px] text-slate-400">5,000 ر.ي</div>
              </div>
            </button>
          </div>
        </div>

        {/* Request Allowance from Parent */}
        <form onSubmit={handleRequestAllowance} className="p-4 bg-slate-900 rounded-2xl border border-slate-800 space-y-3">
          <div className="flex items-center gap-2 text-teal-400 text-xs font-bold">
            <HeartHandshake className="w-4 h-4" /> طلب مصروف أو إذن شراء من ولي الأمر
          </div>

          <div>
            <label className="text-[11px] text-slate-400 block mb-1">المبلغ المطلوب (ر.ي)</label>
            <input
              type="number"
              placeholder="مثال: 15000"
              value={requestAmount}
              onChange={(e) => setRequestAmount(e.target.value)}
              required
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-teal-500"
            />
          </div>

          <div>
            <label className="text-[11px] text-slate-400 block mb-1">سبب الطلب لولي الأمر</label>
            <input
              type="text"
              placeholder="مثال: شراء مراجع مقررات الهندسة"
              value={requestReason}
              onChange={(e) => setRequestReason(e.target.value)}
              required
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-teal-500"
            />
          </div>

          {approvalStatus === 'pending' && (
            <div className="p-3 bg-amber-950/60 border border-amber-800 rounded-xl text-xs text-amber-200 flex items-center gap-2">
              <Clock className="w-4 h-4 text-amber-400 shrink-0 animate-spin" />
              <span>تم إرسال الإشعار لهاتف ولي الأمر، بانتظار الموافقة باللمسة الواحدة...</span>
            </div>
          )}

          {approvalStatus === 'approved' && (
            <div className="p-3 bg-emerald-950/70 border border-emerald-600 rounded-xl text-xs text-emerald-200 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>وافق ولي الأمر! تم تحويل المبلغ فورياً إلى رصيدك.</span>
            </div>
          )}

          {approvalStatus === 'idle' && (
            <button
              type="submit"
              className="w-full py-2 bg-teal-600 hover:bg-teal-500 text-white rounded-xl text-xs font-bold shadow"
            >
              إرسال طلب الاستئذان لولي الأمر
            </button>
          )}
        </form>
      </div>
    </div>
  );
};
