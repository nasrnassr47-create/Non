import React, { useState } from 'react';
import { 
  Send, 
  Download, 
  QrCode, 
  Receipt, 
  CreditCard, 
  ShieldCheck, 
  ArrowUpRight, 
  ArrowDownLeft, 
  CheckCircle2, 
  Smartphone, 
  Wifi, 
  Zap, 
  Tv, 
  Gamepad2, 
  Lock, 
  RefreshCw,
  Copy,
  ChevronLeft,
  X
} from 'lucide-react';
import { WalletAccount, TransactionRecord } from '../../types';

interface Props {
  onNotifyAutoSave?: (action: string) => void;
}

export const UserClientApp: React.FC<Props> = ({ onNotifyAutoSave }) => {
  const [selectedCurrency, setSelectedCurrency] = useState<'YER' | 'SAR' | 'USD'>('YER');
  const [activeTab, setActiveTab] = useState<'home' | 'send' | 'bills' | 'cards' | 'history'>('home');
  const [activeModal, setActiveModal] = useState<'qr' | 'success' | null>(null);
  const [modalMessage, setModalMessage] = useState('');
  
  // Send form state
  const [sendPhone, setSendPhone] = useState('');
  const [sendAmount, setSendAmount] = useState('');
  const [sendNote, setSendNote] = useState('');

  // Wallets data
  const [wallets, setWallets] = useState<WalletAccount[]>([
    { id: 'w-yer', name: 'الريال اليمني', currency: 'YER', symbol: 'ر.ي', balance: 4850000, holdBalance: 0, accountNumber: '777-100-2491', isDefault: true },
    { id: 'w-sar', name: 'الريال السعودي', currency: 'SAR', symbol: 'ر.س', balance: 14200, holdBalance: 0, accountNumber: '777-100-2492' },
    { id: 'w-usd', name: 'الدولار الأمريكي', currency: 'USD', symbol: '$', balance: 3750, holdBalance: 0, accountNumber: '777-100-2493' },
  ]);

  // Transaction History
  const [transactions, setTransactions] = useState<TransactionRecord[]>([
    { id: 'tx-1', refNo: 'TXN-948102', type: 'P2P', title: 'تحويل إلى أحمد ناصر', amount: 50000, currency: 'YER', fee: 0, sender: 'أنت', receiver: '773001122', timestamp: 'منذ 15 دقيقة', status: 'completed', hash: 'sha256:4b21..9a1' },
    { id: 'tx-2', refNo: 'TXN-948101', type: 'BILL', title: 'سداد باقة يمن موبايل مزايا', amount: 4500, currency: 'YER', fee: 0, sender: 'أنت', receiver: 'يمن موبايل', timestamp: 'اليوم 10:30 ص', status: 'completed', hash: 'sha256:7c82..3e4' },
    { id: 'tx-3', refNo: 'TXN-948099', type: 'CASH_IN', title: 'إيداع نقدي عبر وكيل النصر', amount: 500000, currency: 'YER', fee: 0, sender: 'وكيل 104', receiver: 'أنت', timestamp: 'أمس 04:15 م', status: 'completed', hash: 'sha256:1a99..4f5' },
    { id: 'tx-4', refNo: 'TXN-948098', type: 'QR_PAY', title: 'مشتريات هايبر المستهلك', amount: 28400, currency: 'YER', fee: 0, sender: 'أنت', receiver: 'هايبر المستهلك', timestamp: 'أمس 01:20 م', status: 'completed', hash: 'sha256:3d21..8b9' }
  ]);

  const activeWallet = wallets.find(w => w.currency === selectedCurrency) || wallets[0];

  const handleExecuteSend = (e: React.FormEvent) => {
    e.preventDefault();
    const amountNum = parseFloat(sendAmount);
    if (!sendPhone || isNaN(amountNum) || amountNum <= 0) return;
    if (amountNum > activeWallet.balance) {
      alert('عفواً، الرصيد غير كافٍ في هذه المحفظة');
      return;
    }

    // Ledger double-entry simulated deduction
    setWallets(prev => prev.map(w => {
      if (w.currency === selectedCurrency) {
        return { ...w, balance: w.balance - amountNum };
      }
      return w;
    }));

    const newTx: TransactionRecord = {
      id: `tx-${Date.now()}`,
      refNo: `TXN-${Math.floor(100000 + Math.random() * 900000)}`,
      type: 'P2P',
      title: `تحويل إلى ${sendPhone}`,
      amount: amountNum,
      currency: selectedCurrency,
      fee: 0,
      sender: 'أنت',
      receiver: sendPhone,
      timestamp: 'الآن',
      status: 'completed',
      hash: `sha256:${Math.random().toString(36).substring(2, 10)}`
    };

    setTransactions([newTx, ...transactions]);
    setSendPhone('');
    setSendAmount('');
    setSendNote('');
    setModalMessage(`تم تحويل ${amountNum.toLocaleString()} ${activeWallet.symbol} بنجاح إلى ${sendPhone} مع قيد اليومية المزدوج.`);
    setActiveModal('success');

    if (onNotifyAutoSave) {
      onNotifyAutoSave(`معاملة تحويل جديدة #${newTx.refNo}`);
    }
  };

  const handlePayBill = (serviceName: string, amount: number) => {
    if (amount > activeWallet.balance) {
      alert('الرصيد غير كافٍ');
      return;
    }
    setWallets(prev => prev.map(w => w.currency === selectedCurrency ? { ...w, balance: w.balance - amount } : w));
    const newTx: TransactionRecord = {
      id: `tx-${Date.now()}`,
      refNo: `TXN-${Math.floor(100000 + Math.random() * 900000)}`,
      type: 'BILL',
      title: `سداد ${serviceName}`,
      amount: amount,
      currency: selectedCurrency,
      fee: 0,
      sender: 'أنت',
      receiver: serviceName,
      timestamp: 'الآن',
      status: 'completed',
      hash: `sha256:${Math.random().toString(36).substring(2, 10)}`
    };
    setTransactions([newTx, ...transactions]);
    setModalMessage(`تم سداد ${serviceName} بقيمة ${amount.toLocaleString()} ${activeWallet.symbol} فورياً.`);
    setActiveModal('success');

    if (onNotifyAutoSave) {
      onNotifyAutoSave(`سداد فاتورة ${serviceName}`);
    }
  };

  return (
    <div id="user-client-app" className="bg-slate-950 text-slate-100 min-h-[620px] rounded-3xl overflow-hidden flex flex-col shadow-2xl border border-slate-800">
      {/* App Top Bar */}
      <div className="bg-slate-900/90 px-4 py-3 border-b border-slate-800 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold text-xs border border-emerald-500/30">
            ن
          </div>
          <div>
            <div className="text-xs text-slate-400">مرحباً بك،</div>
            <div className="text-sm font-bold text-slate-100">محمد ناصر اليماني</div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-[11px] bg-emerald-950 text-emerald-300 px-2 py-0.5 rounded-full border border-emerald-600/30 flex items-center gap-1">
            <ShieldCheck className="w-3 h-3 text-emerald-400" />
            موثق KYC 3
          </span>
          <button 
            onClick={() => setActiveModal('qr')}
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors"
            title="رمز الاستلام QR الخاص بك"
          >
            <QrCode className="w-4 h-4 text-emerald-400" />
          </button>
        </div>
      </div>

      {/* Main Body */}
      <div className="flex-1 p-4 overflow-y-auto space-y-4">
        {/* Currency Switcher Chips */}
        <div className="flex items-center gap-1.5 p-1 bg-slate-900 rounded-xl border border-slate-800">
          {(['YER', 'SAR', 'USD'] as const).map((curr) => (
            <button
              key={curr}
              onClick={() => setSelectedCurrency(curr)}
              className={`flex-1 py-1.5 text-xs font-semibold rounded-lg transition-all ${
                selectedCurrency === curr
                  ? 'bg-emerald-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {curr === 'YER' ? 'الريال اليمني (YER)' : curr === 'SAR' ? 'الريال السعودي (SAR)' : 'الدولار ($ USD)'}
            </button>
          ))}
        </div>

        {/* Balance Card with Emerald Gradient */}
        <div className="relative overflow-hidden rounded-2xl p-5 bg-gradient-to-br from-emerald-800 via-teal-900 to-slate-900 border border-emerald-500/30 shadow-lg">
          <div className="flex justify-between items-start">
            <div>
              <div className="text-xs text-emerald-200 font-medium">الرصيد المتاح (القيد المزدوج)</div>
              <div className="text-2xl md:text-3xl font-extrabold text-white tracking-tight mt-1">
                {activeWallet.balance.toLocaleString()} <span className="text-emerald-300 text-base font-normal">{activeWallet.symbol}</span>
              </div>
            </div>
            <div className="bg-emerald-950/60 p-2 rounded-xl border border-emerald-600/30">
              <Lock className="w-4 h-4 text-emerald-300" />
            </div>
          </div>

          <div className="flex items-center justify-between mt-4 pt-3 border-t border-emerald-700/40 text-xs">
            <div className="text-emerald-200/80 font-mono">
              رقم الحساب: <span className="text-white font-semibold">{activeWallet.accountNumber}</span>
            </div>
            <button 
              onClick={() => {
                navigator.clipboard.writeText(activeWallet.accountNumber);
                alert('تم نسخ رقم الحساب');
              }}
              className="text-emerald-300 hover:text-white flex items-center gap-1 text-[11px]"
            >
              <Copy className="w-3 h-3" /> نسخ
            </button>
          </div>
        </div>

        {/* Quick Action Buttons */}
        <div className="grid grid-cols-4 gap-2 text-center">
          <button
            onClick={() => setActiveTab('send')}
            className="p-3 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 transition-all flex flex-col items-center gap-1.5 group"
          >
            <span className="p-2 rounded-lg bg-emerald-500/10 text-emerald-400 group-hover:bg-emerald-500 group-hover:text-white transition-all">
              <Send className="w-4 h-4" />
            </span>
            <span className="text-xs text-slate-300">تحويل سريع</span>
          </button>

          <button
            onClick={() => setActiveModal('qr')}
            className="p-3 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 transition-all flex flex-col items-center gap-1.5 group"
          >
            <span className="p-2 rounded-lg bg-teal-500/10 text-teal-400 group-hover:bg-teal-500 group-hover:text-white transition-all">
              <Download className="w-4 h-4" />
            </span>
            <span className="text-xs text-slate-300">استلام QR</span>
          </button>

          <button
            onClick={() => setActiveTab('bills')}
            className="p-3 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 transition-all flex flex-col items-center gap-1.5 group"
          >
            <span className="p-2 rounded-lg bg-amber-500/10 text-amber-400 group-hover:bg-amber-500 group-hover:text-white transition-all">
              <Receipt className="w-4 h-4" />
            </span>
            <span className="text-xs text-slate-300">سداد فواتير</span>
          </button>

          <button
            onClick={() => setActiveTab('cards')}
            className="p-3 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 transition-all flex flex-col items-center gap-1.5 group"
          >
            <span className="p-2 rounded-lg bg-cyan-500/10 text-cyan-400 group-hover:bg-cyan-500 group-hover:text-white transition-all">
              <CreditCard className="w-4 h-4" />
            </span>
            <span className="text-xs text-slate-300">بطاقاتي</span>
          </button>
        </div>

        {/* View Selection Content */}
        {activeTab === 'home' && (
          <div className="space-y-3">
            <div className="flex items-center justify-between text-xs text-slate-400 px-1">
              <span>آخر الحركات المالية</span>
              <button onClick={() => setActiveTab('history')} className="text-emerald-400 hover:underline">
                عرض الكل
              </button>
            </div>

            <div className="space-y-2">
              {transactions.slice(0, 4).map((tx) => (
                <div key={tx.id} className="p-3 rounded-xl bg-slate-900/80 border border-slate-800 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className={`p-2 rounded-lg ${
                      tx.type === 'CASH_IN' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-slate-800 text-slate-300'
                    }`}>
                      {tx.type === 'CASH_IN' ? <ArrowDownLeft className="w-4 h-4" /> : <ArrowUpRight className="w-4 h-4" />}
                    </div>
                    <div>
                      <div className="text-xs font-semibold text-slate-200">{tx.title}</div>
                      <div className="text-[10px] text-slate-500">{tx.timestamp} • {tx.refNo}</div>
                    </div>
                  </div>
                  <div className="text-left">
                    <div className={`text-xs font-bold ${tx.type === 'CASH_IN' ? 'text-emerald-400' : 'text-slate-200'}`}>
                      {tx.type === 'CASH_IN' ? '+' : '-'}{tx.amount.toLocaleString()} {tx.currency}
                    </div>
                    <div className="text-[10px] text-emerald-500">مكتمل</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB: SEND MONEY */}
        {activeTab === 'send' && (
          <form onSubmit={handleExecuteSend} className="p-4 bg-slate-900 rounded-2xl border border-slate-800 space-y-3">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <span className="text-sm font-bold text-emerald-400">تحويل فوري (P2P Transfer)</span>
              <button type="button" onClick={() => setActiveTab('home')} className="text-xs text-slate-400 hover:text-white">
                إلغاء
              </button>
            </div>

            <div>
              <label className="text-xs text-slate-400 block mb-1">رقم هاتف المستلم أو رقم المحفظة</label>
              <input
                type="text"
                placeholder="770000000"
                value={sendPhone}
                onChange={(e) => setSendPhone(e.target.value)}
                required
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-sm text-slate-100 focus:outline-none focus:border-emerald-500"
              />
            </div>

            <div>
              <label className="text-xs text-slate-400 block mb-1">المبلغ المطلوب ({activeWallet.currency})</label>
              <input
                type="number"
                placeholder="مثال: 10000"
                value={sendAmount}
                onChange={(e) => setSendAmount(e.target.value)}
                required
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-sm text-slate-100 focus:outline-none focus:border-emerald-500"
              />
            </div>

            <div>
              <label className="text-xs text-slate-400 block mb-1">ملاحظة التحويل (اختياري)</label>
              <input
                type="text"
                placeholder="مثال: حساب الأسبوع"
                value={sendNote}
                onChange={(e) => setSendNote(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-sm text-slate-100 focus:outline-none focus:border-emerald-500"
              />
            </div>

            <div className="pt-2">
              <button
                type="submit"
                className="w-full py-2.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white rounded-xl font-bold text-sm shadow-lg shadow-emerald-950 flex items-center justify-center gap-2"
              >
                <Send className="w-4 h-4" />
                تأكيد وقيد التحويل الفوري
              </button>
            </div>
          </form>
        )}

        {/* TAB: BILLS & RECHARGE */}
        {activeTab === 'bills' && (
          <div className="p-4 bg-slate-900 rounded-2xl border border-slate-800 space-y-3">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <span className="text-sm font-bold text-amber-400">سداد الفواتير وشحن الباقات</span>
              <button onClick={() => setActiveTab('home')} className="text-xs text-slate-400">إغلاق</button>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div 
                onClick={() => handlePayBill('باقة يمن موبايل مزايا', 4500)}
                className="p-3 bg-slate-950 rounded-xl border border-slate-800 hover:border-amber-500/40 cursor-pointer transition-all flex items-center gap-2.5"
              >
                <Smartphone className="w-5 h-5 text-red-400" />
                <div>
                  <div className="text-xs font-semibold text-slate-200">يمن موبايل</div>
                  <div className="text-[10px] text-amber-300">4,500 ر.ي</div>
                </div>
              </div>

              <div 
                onClick={() => handlePayBill('فاتورة سبأفون سوبر', 3000)}
                className="p-3 bg-slate-950 rounded-xl border border-slate-800 hover:border-amber-500/40 cursor-pointer transition-all flex items-center gap-2.5"
              >
                <Smartphone className="w-5 h-5 text-blue-400" />
                <div>
                  <div className="text-xs font-semibold text-slate-200">سبأفون</div>
                  <div className="text-[10px] text-amber-300">3,000 ر.ي</div>
                </div>
              </div>

              <div 
                onClick={() => handlePayBill('اشتراك إنترنت يمن نت ADSL', 12000)}
                className="p-3 bg-slate-950 rounded-xl border border-slate-800 hover:border-amber-500/40 cursor-pointer transition-all flex items-center gap-2.5"
              >
                <Wifi className="w-5 h-5 text-emerald-400" />
                <div>
                  <div className="text-xs font-semibold text-slate-200">يمن نت ADSL</div>
                  <div className="text-[10px] text-amber-300">12,000 ر.ي</div>
                </div>
              </div>

              <div 
                onClick={() => handlePayBill('فاتورة الكهرباء التجارية', 15000)}
                className="p-3 bg-slate-950 rounded-xl border border-slate-800 hover:border-amber-500/40 cursor-pointer transition-all flex items-center gap-2.5"
              >
                <Zap className="w-5 h-5 text-amber-400" />
                <div>
                  <div className="text-xs font-semibold text-slate-200">الكهرباء</div>
                  <div className="text-[10px] text-amber-300">15,000 ر.ي</div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB: VIRTUAL CARDS */}
        {activeTab === 'cards' && (
          <div className="space-y-3">
            <div className="flex items-center justify-between text-xs text-slate-400">
              <span>بطاقات نصر والت الرقمية</span>
              <button onClick={() => setActiveTab('home')} className="text-emerald-400">الرئيسية</button>
            </div>

            <div className="p-4 rounded-2xl bg-gradient-to-r from-blue-900 to-indigo-900 border border-indigo-500/30 text-white shadow-xl space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-xs font-mono font-bold tracking-widest text-indigo-300">NASR VIRTUAL PLATINUM</span>
                <CreditCard className="w-5 h-5 text-indigo-200" />
              </div>

              <div className="font-mono text-base md:text-lg tracking-wider">
                4291 •••• •••• 8840
              </div>

              <div className="flex justify-between items-end text-xs">
                <div>
                  <div className="text-[10px] text-indigo-300">حامل البطاقة</div>
                  <div className="font-semibold">MOHAMMED NASR</div>
                </div>
                <div>
                  <div className="text-[10px] text-indigo-300">الانتهاء</div>
                  <div className="font-semibold">12/28</div>
                </div>
                <div>
                  <div className="text-[10px] text-indigo-300">CVV الحركي</div>
                  <div className="font-semibold font-mono text-amber-300">381</div>
                </div>
              </div>
            </div>

            <div className="p-3 bg-slate-900 rounded-xl border border-slate-800 text-xs text-slate-300 flex items-center justify-between">
              <span>حالة البطاقة: نشطة للتسوق الدولي</span>
              <button 
                onClick={() => alert('تم تجميد البطاقة مؤقتاً')}
                className="px-2 py-1 bg-red-950 text-red-300 rounded border border-red-800/40 text-[11px]"
              >
                تجميد مؤقت
              </button>
            </div>
          </div>
        )}

        {/* TAB: TRANSACTIONS HISTORY */}
        {activeTab === 'history' && (
          <div className="p-4 bg-slate-900 rounded-2xl border border-slate-800 space-y-3">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <span className="text-sm font-bold text-slate-200">سجل المعاملات الموثق</span>
              <button onClick={() => setActiveTab('home')} className="text-xs text-emerald-400">رجوع</button>
            </div>

            <div className="space-y-2">
              {transactions.map((tx) => (
                <div key={tx.id} className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
                  <div>
                    <div className="text-xs font-semibold text-slate-200">{tx.title}</div>
                    <div className="text-[10px] text-slate-500 font-mono">
                      {tx.refNo} • {tx.timestamp}
                    </div>
                  </div>
                  <div className="text-left">
                    <div className="text-xs font-bold text-slate-100">
                      {tx.amount.toLocaleString()} {tx.currency}
                    </div>
                    <div className="text-[10px] font-mono text-slate-400 truncate max-w-[120px]">{tx.hash}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Modal: QR Receiver */}
      {activeModal === 'qr' && (
        <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-emerald-500/40 rounded-2xl p-5 max-w-xs w-full text-center space-y-4">
            <div className="flex justify-between items-center">
              <span className="text-sm font-bold text-emerald-400">رمز QR للاستلام الفوري</span>
              <button onClick={() => setActiveModal(null)} className="text-slate-400 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-4 bg-white rounded-xl mx-auto w-44 h-44 flex items-center justify-center shadow-inner">
              <QrCode className="w-36 h-36 text-slate-900" />
            </div>

            <div className="text-xs text-slate-300">
              الحساب: <span className="font-mono text-emerald-300 font-bold">{activeWallet.accountNumber}</span>
            </div>
            <p className="text-[11px] text-slate-400">امسح الرمز من أي تطبيق نصر والت لتحويل المبلغ لحظياً.</p>
          </div>
        </div>
      )}

      {/* Modal: Success Feedback */}
      {activeModal === 'success' && (
        <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-emerald-500/50 rounded-2xl p-5 max-w-xs w-full text-center space-y-3">
            <div className="w-12 h-12 rounded-full bg-emerald-500/20 text-emerald-400 mx-auto flex items-center justify-center border border-emerald-500/40">
              <CheckCircle2 className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-white">تمت العملية بنجاح!</h3>
            <p className="text-xs text-slate-300 leading-relaxed">{modalMessage}</p>
            <button
              onClick={() => setActiveModal(null)}
              className="w-full py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold"
            >
              تم
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
