import React, { useState } from 'react';
import { 
  ChevronDown, 
  ChevronRight, 
  CheckCircle2, 
  AlertCircle, 
  Sparkles, 
  FolderTree, 
  Layers,
  ArrowUpRight
} from 'lucide-react';

export interface TreeNode {
  id: string;
  name: string;
  description?: string;
  category?: string;
  status?: 'verified' | 'suggested' | 'warning';
  notes?: string;
  children?: TreeNode[];
}

interface TreeViewerProps {
  data: TreeNode[];
  onSelectNode?: (node: TreeNode) => void;
}

export const TreeViewer: React.FC<TreeViewerProps> = ({ data, onSelectNode }) => {
  const [expandedNodes, setExpandedNodes] = useState<Record<string, boolean>>({
    'root-1': true,
    'root-2': true,
    'root-3': true,
    'root-4': true,
  });

  const toggleNode = (id: string) => {
    setExpandedNodes(prev => ({ ...prev, [id]: !prev[id] }));
  };

  const renderNode = (node: TreeNode, depth: number = 0) => {
    const hasChildren = node.children && node.children.length > 0;
    const isExpanded = expandedNodes[node.id] ?? (depth < 2);

    return (
      <div key={node.id} className="select-none">
        <div
          onClick={() => {
            if (hasChildren) toggleNode(node.id);
            if (onSelectNode) onSelectNode(node);
          }}
          className={`group flex items-center justify-between py-2 px-3 my-1 rounded-xl transition-all cursor-pointer ${
            depth === 0
              ? 'bg-slate-900 text-white font-bold shadow-sm'
              : depth === 1
              ? 'bg-emerald-50/80 hover:bg-emerald-100/70 text-slate-800 font-semibold border border-emerald-100/80'
              : 'bg-white hover:bg-slate-50 text-slate-700 border border-slate-200/70 text-sm'
          }`}
          style={{ marginRight: `${depth * 18}px` }}
        >
          <div className="flex items-center gap-2.5 min-w-0">
            {hasChildren ? (
              <button
                type="button"
                className={`p-1 rounded-md transition-colors ${
                  depth === 0 ? 'text-emerald-400 hover:bg-slate-800' : 'text-emerald-600 hover:bg-emerald-200/50'
                }`}
                onClick={(e) => {
                  e.stopPropagation();
                  toggleNode(node.id);
                }}
              >
                {isExpanded ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
              </button>
            ) : (
              <span className="w-6 flex items-center justify-center text-slate-400">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
              </span>
            )}

            <div className="flex flex-col">
              <span className="truncate">{node.name}</span>
              {node.description && (
                <span className={`text-xs truncate ${depth === 0 ? 'text-slate-300' : 'text-slate-500'}`}>
                  {node.description}
                </span>
              )}
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            {node.status === 'verified' && (
              <span className="inline-flex items-center gap-1 text-[11px] font-semibold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                مكتمل
              </span>
            )}
            {node.status === 'suggested' && (
              <span className="inline-flex items-center gap-1 text-[11px] font-semibold px-2 py-0.5 rounded-full bg-amber-100 text-amber-900 border border-amber-200">
                <Sparkles className="w-3 h-3 text-amber-600" />
                تطوير مقترح
              </span>
            )}
            {node.status === 'warning' && (
              <span className="inline-flex items-center gap-1 text-[11px] font-semibold px-2 py-0.5 rounded-full bg-rose-100 text-rose-800">
                <AlertCircle className="w-3 h-3 text-rose-600" />
                بحاجة لمراجعة
              </span>
            )}
            {hasChildren && (
              <span className={`text-[11px] font-bold px-1.5 py-0.5 rounded-md ${
                depth === 0 ? 'bg-slate-800 text-slate-300' : 'bg-slate-100 text-slate-600'
              }`}>
                {node.children?.length}
              </span>
            )}
          </div>
        </div>

        {hasChildren && isExpanded && (
          <div className="border-r-2 border-emerald-500/20 mr-4 pr-1 my-0.5 space-y-0.5">
            {node.children!.map((child) => renderNode(child, depth + 1))}
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between px-2 pb-2 border-b border-slate-200 text-xs font-bold text-slate-500">
        <div className="flex items-center gap-1.5">
          <FolderTree className="w-4 h-4 text-emerald-600" />
          <span>المكونات والخدمات الفرعية</span>
        </div>
        <div className="flex items-center gap-1 text-slate-400">
          <Layers className="w-3.5 h-3.5" />
          <span>هيكل شجري ديناميكي</span>
        </div>
      </div>
      <div className="p-1 space-y-1">
        {data.map((node) => renderNode(node, 0))}
      </div>
    </div>
  );
};
