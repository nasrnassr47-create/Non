// src/components/layout/RoleSwitcher.tsx
import React, { useState } from 'react';
import { 
  Smartphone, 
  Users, 
  Briefcase, 
  Store, 
  ShieldCheck, 
  Crown, 
  Headphones, 
  ChevronDown,
  Check,
  Sparkles
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { UserRole } from '../../types/user';
import { cn } from '../../lib/utils';

export interface RoleConfig {
  role: UserRole;
  nameAr: string;
  nameEn: string;
  badge: string;
  icon: React.ComponentType<{ className?: string }>;
  color: string;
  gradient: string;
}

export const ROLE_CONFIGS: RoleConfig[] = [
  {
    role: 'client',
    nameAr: 'تطبيق العميل / المستخدم',
    nameEn: 'User App (25 Screens)',
    badge: 'P2P & QR',
    icon: Smartphone,
    color: 'text-emerald-400',
    gradient: 'from-emerald-600 to-teal-700'
  },
  {
    role: 'subscriber',
    nameAr: 'تطبيق المشترك ورب الأسرة',
    nameEn: 'Subscriber App',
    badge: 'رواتب وعائلة',
    icon: Users,
    color: 'text-blue-400',
    gradient: 'from-blue-600 to-indigo-700'
  },
  {
    role: 'family_mini',
    nameAr: 'تطبيق العائلة (محفظة التابع)',
    nameEn: 'Family Mini App',
    badge: 'إشراف أبوي',
    icon: Users,
    color: 'text-teal-400',
    gradient: 'from-teal-600 to-cyan-700'
  },
  {
    role: 'agent',
    nameAr: 'تطبيق الوكيل والصراف',
    nameEn: 'Agent App',
    badge: 'إيداع وسحب نقدي',
    icon: Briefcase,
    color: 'text-amber-400',
    gradient: 'from-amber-600 to-orange-700'
  },
  {
    role: 'merchant',
    nameAr: 'تطبيق التاجر ونقاط البيع',
    nameEn: 'Merchant App & POS',
    badge: 'فواتير وكاشير',
    icon: Store,
    color: 'text-cyan-400',
    gradient: 'from-cyan-600 to-blue-700'
  },
  {
    role: 'admin',
    nameAr: 'لوحة إدارة العمليات',
    nameEn: 'Admin Panel',
    badge: 'KYC & AML',
    icon: ShieldCheck,
    color: 'text-indigo-400',
    gradient: 'from-indigo-600 to-purple-700'
  },
  {
    role: 'owner',
    nameAr: 'لوحة المالك السيادية',
    nameEn: 'Owner Sovereign Panel (God Mode)',
    badge: 'تحكم مطلق',
    icon: Crown,
    color: 'text-amber-300',
    gradient: 'from-amber-500 to-yellow-600'
  },
  {
    role: 'support',
    nameAr: 'تطبيق الدعم وخدمة العملاء',
    nameEn: 'Support App 24/7',
    badge: 'دعم فني حي',
    icon: Headphones,
    color: 'text-emerald-300',
    gradient: 'from-emerald-700 to-slate-800'
  }
];

export const RoleSwitcher: React.FC = () => {
  const { activeRole, switchRole } = useAuth();
  const [isOpen, setIsOpen] = useState(false);

  const currentRole = ROLE_CONFIGS.find(r => r.role === activeRole) || 
    (activeRole === 'sovereign' ? ROLE_CONFIGS.find(r => r.role === 'owner') : null) || 
    ROLE_CONFIGS[0];

  const IconComp = currentRole.icon;

  return (
    <div className="relative z-40">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-2 px-3 py-1.5 rounded-2xl bg-slate-900 hover:bg-slate-800 border border-slate-700/80 transition-all shadow-md active:scale-[0.98] text-right"
      >
        <span className={cn('p-1.5 rounded-xl bg-slate-800 text-sm', currentRole.color)}>
          <IconComp className="w-4 h-4" />
        </span>
        <div className="hidden sm:block text-right">
          <div className="text-[10px] text-slate-400 leading-tight">الواجهة النشطة:</div>
          <div className="text-xs font-bold text-slate-100 flex items-center gap-1">
            <span>{currentRole.nameAr}</span>
            <span className="text-[9px] px-1.5 py-0.2 rounded-full bg-slate-800 text-emerald-400 font-mono border border-slate-700">
              {currentRole.badge}
            </span>
          </div>
        </div>
        <ChevronDown className="w-4 h-4 text-slate-400 ml-1 shrink-0" />
      </button>

      {isOpen && (
        <>
          <div className="fixed inset-0 z-30" onClick={() => setIsOpen(false)} />
          <div className="absolute right-0 mt-2 w-80 sm:w-96 bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl overflow-hidden z-40 p-2 text-slate-100 animate-in fade-in slide-in-from-top-2 duration-150">
            <div className="px-3 py-2 border-b border-slate-800 flex items-center justify-between text-xs text-slate-400">
              <span className="font-bold text-slate-200">اختر الواجهة / الدور للتجربة:</span>
              <span className="text-[10px] font-mono text-emerald-400 flex items-center gap-1">
                <Sparkles className="w-3 h-3" /> 7 تطبيقات متكاملة
              </span>
            </div>

            <div className="py-1 space-y-1 max-h-[70vh] overflow-y-auto">
              {ROLE_CONFIGS.map((cfg) => {
                const isSelected = activeRole === cfg.role || (cfg.role === 'owner' && activeRole === 'sovereign');
                const RoleIcon = cfg.icon;
                return (
                  <button
                    key={cfg.role}
                    onClick={() => {
                      switchRole(cfg.role);
                      setIsOpen(false);
                    }}
                    className={cn(
                      'w-full p-2.5 rounded-2xl flex items-center justify-between text-right transition-all cursor-pointer',
                      isSelected
                        ? 'bg-slate-800/90 border border-slate-700 text-white shadow-inner'
                        : 'hover:bg-slate-800/50 text-slate-300'
                    )}
                  >
                    <div className="flex items-center gap-2.5">
                      <div className={cn('p-2 rounded-xl bg-slate-950 border border-slate-800', cfg.color)}>
                        <RoleIcon className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="text-xs font-bold text-slate-100 flex items-center gap-1.5">
                          {cfg.nameAr}
                          {isSelected && <Check className="w-3.5 h-3.5 text-emerald-400" />}
                        </div>
                        <div className="text-[10px] text-slate-400 font-sans">{cfg.nameEn}</div>
                      </div>
                    </div>

                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-950/80 border border-slate-800 text-slate-300 font-mono">
                      {cfg.badge}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        </>
      )}
    </div>
  );
};
