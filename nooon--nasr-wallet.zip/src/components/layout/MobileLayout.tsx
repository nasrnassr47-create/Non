// src/components/layout/MobileLayout.tsx
import React, { ReactNode } from 'react';
import { MobileFrame } from '../MobileFrame';
import { BottomNav, BottomNavItem } from './BottomNav';

interface MobileLayoutProps {
  children: ReactNode;
  activeAppName?: string;
  activeTab?: string;
  onTabChange?: (tab: string) => void;
  navItems?: BottomNavItem[];
  showFrame?: boolean;
}

export const MobileLayout: React.FC<MobileLayoutProps> = ({
  children,
  activeAppName = 'نصر والت',
  activeTab = 'home',
  onTabChange,
  navItems,
  showFrame = true
}) => {
  const content = (
    <div className="flex flex-col min-h-[640px] bg-slate-950 text-slate-100 relative">
      <div className="flex-1 overflow-y-auto">{children}</div>
      {onTabChange && (
        <BottomNav items={navItems} activeId={activeTab} onChange={onTabChange} />
      )}
    </div>
  );

  if (!showFrame) {
    return (
      <div className="w-full max-w-md mx-auto rounded-3xl overflow-hidden border border-slate-800 shadow-2xl">
        {content}
      </div>
    );
  }

  return <MobileFrame activeAppName={activeAppName}>{content}</MobileFrame>;
};
