// src/components/layout/WebLayout.tsx
import React, { ReactNode, useState } from 'react';
import { TopBar } from './TopBar';
import { Sidebar, SidebarItem } from './Sidebar';
import { ToastContainer } from '../ui/Toast';

interface WebLayoutProps {
  children: ReactNode;
  sidebarItems?: SidebarItem[];
  activeSidebarId?: string;
  onSidebarChange?: (id: string) => void;
  onOpenNotifications?: () => void;
  onOpenSystemViewer?: () => void;
}

export const WebLayout: React.FC<WebLayoutProps> = ({
  children,
  sidebarItems,
  activeSidebarId,
  onSidebarChange,
  onOpenNotifications,
  onOpenSystemViewer
}) => {
  const [isSidebarOpenMobile, setIsSidebarOpenMobile] = useState(false);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-emerald-500 selection:text-white">
      {/* Top Bar */}
      <TopBar
        onToggleSidebar={() => setIsSidebarOpenMobile(!isSidebarOpenMobile)}
        onOpenNotifications={onOpenNotifications}
        onOpenSystemViewer={onOpenSystemViewer}
      />

      {/* Main Body Area */}
      <div className="flex-1 flex overflow-hidden max-w-7xl w-full mx-auto">
        {/* Desktop / Responsive Sidebar */}
        {sidebarItems && activeSidebarId && onSidebarChange && (
          <>
            {/* Desktop Sidebar */}
            <div className="hidden lg:block">
              <Sidebar
                items={sidebarItems}
                activeId={activeSidebarId}
                onChange={onSidebarChange}
                className="h-full"
              />
            </div>

            {/* Mobile Sidebar Overlay */}
            {isSidebarOpenMobile && (
              <div className="fixed inset-0 z-50 lg:hidden flex">
                <div
                  className="fixed inset-0 bg-black/75 backdrop-blur-sm"
                  onClick={() => setIsSidebarOpenMobile(false)}
                />
                <div className="relative z-10 w-72 h-full bg-slate-900 animate-in slide-in-from-right duration-200">
                  <Sidebar
                    items={sidebarItems}
                    activeId={activeSidebarId}
                    onChange={(id) => {
                      onSidebarChange(id);
                      setIsSidebarOpenMobile(false);
                    }}
                    className="h-full w-full"
                  />
                </div>
              </div>
            )}
          </>
        )}

        {/* Dynamic Main Workspace Content */}
        <main className="flex-1 overflow-y-auto p-3 sm:p-6">{children}</main>
      </div>

      {/* Global Toast Container */}
      <ToastContainer />
    </div>
  );
};
