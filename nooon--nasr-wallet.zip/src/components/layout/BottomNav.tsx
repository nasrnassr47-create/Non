// src/components/layout/BottomNav.tsx
import React, { ReactNode } from 'react';
import { Home, Send, QrCode, CreditCard, Clock } from 'lucide-react';
import { cn } from '../../lib/utils';

export interface BottomNavItem {
  id: string;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  badge?: number | string;
}

interface BottomNavProps {
  items?: BottomNavItem[];
  activeId: string;
  onChange: (id: string) => void;
  className?: string;
}

const defaultItems: BottomNavItem[] = [
  { id: 'dashboard', label: 'الرئيسية', icon: Home },
  { id: 'send', label: 'تحويل', icon: Send },
  { id: 'qr', label: 'مسح QR', icon: QrCode },
  { id: 'cards', label: 'بطاقاتي', icon: CreditCard },
  { id: 'transactions', label: 'السجل', icon: Clock },
];

export const BottomNav: React.FC<BottomNavProps> = ({
  items = defaultItems,
  activeId,
  onChange,
  className
}) => {
  return (
    <nav
      className={cn(
        'bg-slate-900/95 backdrop-blur-lg border-t border-slate-800 px-2 py-1.5 flex items-center justify-around z-30 shrink-0 select-none shadow-2xl',
        className
      )}
    >
      {items.map((item) => {
        const Icon = item.icon;
        const isActive = item.id === activeId;
        return (
          <button
            key={item.id}
            onClick={() => onChange(item.id)}
            className={cn(
              'flex flex-col items-center justify-center flex-1 py-1 px-1 rounded-2xl transition-all relative cursor-pointer',
              isActive
                ? 'text-emerald-400 font-bold'
                : 'text-slate-400 hover:text-slate-200'
            )}
          >
            {item.id === 'qr' ? (
              <div className="w-11 h-11 -mt-5 rounded-full bg-gradient-to-tr from-emerald-600 to-teal-500 text-white flex items-center justify-center shadow-lg shadow-emerald-950/60 border-2 border-slate-900">
                <Icon className="w-5 h-5" />
              </div>
            ) : (
              <div className="p-1 rounded-xl">
                <Icon className="w-5 h-5" />
              </div>
            )}
            <span className="text-[10px] mt-0.5 leading-none">{item.label}</span>
            {item.badge && (
              <span className="absolute top-1 right-3 px-1.5 py-0.2 text-[9px] font-bold bg-emerald-500 text-white rounded-full">
                {item.badge}
              </span>
            )}
          </button>
        );
      })}
    </nav>
  );
};
