// src/components/layout/Sidebar.tsx
import React from 'react';
import { 
  FolderTree, 
  Smartphone, 
  Database, 
  Server, 
  Terminal, 
  BookOpen, 
  Stethoscope, 
  Save, 
  Crown, 
  Layers,
  LogOut,
  Users,
  Briefcase,
  Store,
  ShieldCheck,
  Headphones
} from 'lucide-react';
import { cn } from '../../lib/utils';
import { useAuth } from '../../context/AuthContext';
import { Avatar } from '../ui/Avatar';

export interface SidebarItem {
  id: string;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  badge?: string | number;
  highlight?: boolean;
}

interface SidebarProps {
  items: SidebarItem[];
  activeId: string;
  onChange: (id: string) => void;
  className?: string;
}

export const Sidebar: React.FC<SidebarProps> = ({
  items,
  activeId,
  onChange,
  className
}) => {
  const { currentUser, logout, activeRole } = useAuth();

  return (
    <aside
      className={cn(
        'w-64 bg-slate-900 border-l border-slate-800 flex flex-col justify-between p-3 select-none shrink-0',
        className
      )}
    >
      {/* Upper Navigation Items */}
      <div 
        className="space-y-1 flex-1 min-h-0 overflow-y-auto overscroll-contain touch-scroll-container pr-0.5"
        style={{ WebkitOverflowScrolling: 'touch', touchAction: 'pan-y' }}
      >
        <div className="text-[11px] font-mono text-slate-500 px-3 py-1 font-semibold">
          قائمة التحكم والتنقل
        </div>
        {items.map((item) => {
          const Icon = item.icon;
          const isActive = item.id === activeId;
          return (
            <button
              key={item.id}
              style={{ touchAction: 'pan-y' }}
              onClick={() => onChange(item.id)}
              className={cn(
                'w-full flex items-center justify-between px-3 py-2.5 rounded-2xl text-xs font-semibold transition-all cursor-pointer text-right touch-pan-y',
                isActive
                  ? 'bg-emerald-600 text-white shadow-md shadow-emerald-950/40'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/70',
                item.highlight && !isActive ? 'border border-amber-500/30 text-amber-300 bg-amber-500/10' : ''
              )}
            >
              <div className="flex items-center gap-2.5 pointer-events-none">
                <Icon className={cn('w-4 h-4 shrink-0', isActive ? 'text-white' : 'text-slate-400')} />
                <span>{item.label}</span>
              </div>
              {item.badge && (
                <span
                  className={cn(
                    'text-[10px] px-1.5 py-0.2 rounded-full font-mono pointer-events-none',
                    isActive ? 'bg-emerald-800 text-white' : 'bg-slate-800 text-slate-400'
                  )}
                >
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* User Card & Session Footer */}
      <div className="pt-3 border-t border-slate-800 space-y-2 shrink-0">
        <div className="p-2.5 rounded-2xl bg-slate-950/80 border border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <Avatar name={currentUser.name} size="sm" status="online" />
            <div className="overflow-hidden">
              <div className="text-xs font-bold text-slate-100 truncate max-w-[110px]">
                {currentUser.name}
              </div>
              <div className="text-[10px] text-emerald-400 font-mono">
                {currentUser.phone}
              </div>
            </div>
          </div>
          <button
            onClick={logout}
            title="تسجيل الخروج"
            className="p-1.5 rounded-xl hover:bg-slate-800 text-slate-400 hover:text-red-400 transition-colors"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </div>
    </aside>
  );
};
