// src/components/layout/TopBar.tsx
import React from 'react';
import { 
  Bell, 
  Moon, 
  Sun, 
  Globe, 
  ShieldCheck, 
  DatabaseBackup,
  Menu
} from 'lucide-react';
import { Logo } from '../Logo';
import { RoleSwitcher } from './RoleSwitcher';
import { useTheme } from '../../context/ThemeContext';
import { useLanguage } from '../../context/LanguageContext';
import { useWallet } from '../../context/WalletContext';

interface TopBarProps {
  onToggleSidebar?: () => void;
  onOpenNotifications?: () => void;
  onOpenSystemViewer?: () => void;
}

export const TopBar: React.FC<TopBarProps> = ({
  onToggleSidebar,
  onOpenNotifications,
  onOpenSystemViewer
}) => {
  const { isDark, toggleTheme } = useTheme();
  const { language, toggleLanguage } = useLanguage();
  const { lastAutoSavedAction, createManualBackup } = useWallet();

  return (
    <header className="bg-slate-900/95 backdrop-blur-md border-b border-slate-800 sticky top-0 z-40 px-3 sm:px-6 py-2.5">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-3">
        {/* Left / Logo Section */}
        <div className="flex items-center gap-3">
          {onToggleSidebar && (
            <button
              onClick={onToggleSidebar}
              className="lg:hidden p-2 rounded-xl bg-slate-800 text-slate-300 hover:text-white"
            >
              <Menu className="w-5 h-5" />
            </button>
          )}

          <div className="flex items-center gap-2.5 cursor-pointer" onClick={onOpenSystemViewer}>
            <Logo size="sm" />
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-black text-sm sm:text-base text-white tracking-tight">نصر والت</span>
                <span className="text-[10px] font-mono text-emerald-400 font-bold bg-emerald-950 px-1.5 py-0.2 rounded border border-emerald-800/40">
                  V2
                </span>
              </div>
              <p className="text-[10px] text-slate-400 hidden sm:block">محفظتك أنت.. المنظومة المالية السيادية</p>
            </div>
          </div>
        </div>

        {/* Middle: Live Auto-save indicator */}
        <div className="hidden md:flex items-center gap-2 bg-slate-950 px-3 py-1.5 rounded-xl border border-slate-800 text-xs text-slate-300">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <span className="text-slate-400 text-[11px]">حفظ فوري:</span>
          <span className="text-emerald-300 font-mono text-[11px] truncate max-w-[200px]">
            {lastAutoSavedAction}
          </span>
        </div>

        {/* Right Action Tools */}
        <div className="flex items-center gap-2">
          <RoleSwitcher />

          {/* Backup Button */}
          <button
            onClick={createManualBackup}
            title="نسخ احتياطي الآن"
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-emerald-300 transition-colors hidden sm:flex items-center gap-1 text-xs"
          >
            <DatabaseBackup className="w-4 h-4 text-emerald-400" />
            <span className="hidden xl:inline text-[11px]">نسخ احتياطي</span>
          </button>

          {/* Theme Toggle */}
          <button
            onClick={toggleTheme}
            title={isDark ? 'التحويل للوضع النهاري' : 'التحويل للوضع الليلي'}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-amber-300 transition-colors"
          >
            {isDark ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-slate-200" />}
          </button>

          {/* Language Toggle */}
          <button
            onClick={toggleLanguage}
            title="تبديل اللغة (عربي / English)"
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-cyan-300 transition-colors flex items-center gap-1 text-xs font-mono font-bold"
          >
            <Globe className="w-4 h-4 text-cyan-400" />
            <span>{language.toUpperCase()}</span>
          </button>

          {/* Notifications bell */}
          {onOpenNotifications && (
            <button
              onClick={onOpenNotifications}
              title="التنبيهات والإشعارات"
              className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors relative"
            >
              <Bell className="w-4 h-4" />
              <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-emerald-400 ring-2 ring-slate-900" />
            </button>
          )}
        </div>
      </div>
    </header>
  );
};
