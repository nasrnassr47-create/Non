import React, { useState } from 'react';
import { 
  BookOpen, 
  Download, 
  FileText, 
  Search, 
  ChevronRight, 
  CheckCircle2, 
  Smartphone, 
  Shield, 
  Sparkles,
  ExternalLink
} from 'lucide-react';
import { SYSTEM_MANUALS, ManualGuide } from '../../data/documentationData';

interface Props {
  onNotifyAutoSave?: (action: string) => void;
}

export const DocumentationEngineView: React.FC<Props> = ({ onNotifyAutoSave }) => {
  const [selectedManual, setSelectedManual] = useState<ManualGuide>(SYSTEM_MANUALS[0]);
  const [searchQuery, setSearchQuery] = useState('');
  const [apkDownloadStarted, setApkDownloadStarted] = useState(false);

  const filteredManuals = SYSTEM_MANUALS.filter(m => 
    m.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    m.titleEn.toLowerCase().includes(searchQuery.toLowerCase()) ||
    m.targetRole.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleDownloadPdf = (manual: ManualGuide) => {
    // Generate text/markdown export formatted as an official document
    let content = `# ${manual.title} (${manual.titleEn})\n`;
    content += `الفئة المستهدفة: ${manual.targetRole}\n`;
    content += `التصنيف: ${manual.badge}\n`;
    content += `الملخص: ${manual.summary}\n\n`;
    content += `--------------------------------------------------\n\n`;
    manual.chapters.forEach((ch) => {
      content += `### ${ch.title}\n\n${ch.content}\n\n`;
    });
    content += `\nنظام نصر والت V2 - وثيقة رقمية معتمدة مشفرة\n`;

    const blob = new Blob([content], { type: 'text/markdown;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `دليل_نصر_والت_${manual.id}.md`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    if (onNotifyAutoSave) {
      onNotifyAutoSave(`تصدير وتحميل الدليل: ${manual.title}`);
    }
  };

  const handleDownloadApk = () => {
    setApkDownloadStarted(true);
    setTimeout(() => {
      setApkDownloadStarted(false);
      // Create a dummy APK manifest download for demonstration
      const blob = new Blob([
        JSON.stringify({
          app: "Nasr Wallet Sovereign Mobile",
          version: "2.0.4-sovereign",
          targetArchitecture: "ARM64-v8a / x86_64",
          signature: "SHA256:4a81..9b2e",
          timestamp: new Date().toISOString(),
          status: "Verified & Ready for Installation"
        }, null, 2)
      ], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'nasr-wallet-v2-sovereign.apk.json';
      a.click();
      URL.revokeObjectURL(url);

      if (onNotifyAutoSave) {
        onNotifyAutoSave('تحميل حزمة تثبيت تطبيق الموبايل APK');
      }
    }, 1500);
  };

  return (
    <div id="documentation-engine" className="bg-slate-900 text-slate-100 rounded-2xl border border-emerald-500/20 p-5 space-y-5">
      {/* Top Header */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-teal-500/20 text-teal-400 border border-teal-500/30">
            <BookOpen className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-lg font-bold text-white">محرك الدلائل وتوليد الـ PDF والـ APK</h3>
              <span className="text-xs bg-teal-950 text-teal-300 px-2 py-0.5 rounded-full border border-teal-700/50">
                الفرعان 34 و 35
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              12 دليلاً رقمياً مفصلاً لكل دور ووحدة، مع إمكانية القراءة والتنزيل الفوري
            </p>
          </div>
        </div>

        {/* APK Build Box */}
        <div className="flex items-center gap-2 bg-slate-950 p-2 rounded-xl border border-slate-800">
          <Smartphone className="w-5 h-5 text-emerald-400" />
          <div className="text-right">
            <div className="text-[10px] text-slate-400">حزمة الموبايل (APK)</div>
            <div className="text-xs font-bold text-emerald-300">Nasr-Wallet-v2.apk</div>
          </div>
          <button
            onClick={handleDownloadApk}
            className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold flex items-center gap-1 shadow"
          >
            <Download className="w-3.5 h-3.5" />
            {apkDownloadStarted ? 'جارٍ البناء...' : 'تنزيل APK'}
          </button>
        </div>
      </div>

      {/* Main Split Interface */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Sidebar: 12 Manuals List */}
        <div className="space-y-2 lg:border-l lg:border-slate-800 lg:pl-4">
          <div className="relative mb-3">
            <Search className="w-4 h-4 absolute right-3 top-3 text-slate-400" />
            <input
              type="text"
              placeholder="ابحث في الأدلة الـ 12..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl pr-9 pl-3 py-2 text-xs text-white focus:outline-none focus:border-teal-500"
            />
          </div>

          <div className="space-y-2 max-h-[480px] overflow-y-auto pr-1">
            {filteredManuals.map((m) => (
              <div
                key={m.id}
                onClick={() => setSelectedManual(m)}
                className={`p-3 rounded-xl border text-xs cursor-pointer transition-all ${
                  selectedManual.id === m.id
                    ? 'bg-teal-950/60 border-teal-500/70 shadow-md'
                    : 'bg-slate-950/60 border-slate-800 hover:border-slate-700'
                }`}
              >
                <div className="flex justify-between items-start">
                  <span className="font-bold text-slate-200">
                    {m.num}. {m.title}
                  </span>
                  <span className="text-[10px] text-teal-400 bg-teal-950 px-1.5 py-0.5 rounded border border-teal-800/40 shrink-0">
                    {m.badge}
                  </span>
                </div>
                <div className="text-[11px] text-slate-400 mt-1 line-clamp-1">{m.summary}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Reader & Viewer Area */}
        <div className="lg:col-span-2 bg-slate-950 rounded-2xl p-5 border border-slate-800 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
            <div>
              <div className="flex items-center gap-2">
                <h4 className="text-base font-bold text-white">{selectedManual.title}</h4>
                <span className="text-[11px] text-teal-300 font-mono">({selectedManual.titleEn})</span>
              </div>
              <div className="text-xs text-slate-400 mt-1">
                الفئة المستهدفة: <span className="text-emerald-400 font-semibold">{selectedManual.targetRole}</span>
              </div>
            </div>

            <button
              onClick={() => handleDownloadPdf(selectedManual)}
              className="px-3 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow self-start sm:self-auto"
            >
              <Download className="w-4 h-4" /> تحميل وثيقة الدليل
            </button>
          </div>

          <div className="p-3 bg-slate-900/60 rounded-xl text-xs text-slate-300 border border-slate-800/80">
            {selectedManual.summary}
          </div>

          {/* Chapters */}
          <div className="space-y-4 max-h-[380px] overflow-y-auto pr-2">
            {selectedManual.chapters.map((ch, idx) => (
              <div key={idx} className="p-4 bg-slate-900 rounded-xl border border-slate-800 space-y-2">
                <div className="text-xs font-bold text-emerald-400 flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  {ch.title}
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">{ch.content}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
