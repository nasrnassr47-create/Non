import React, { useState } from 'react';
import { 
  Terminal, 
  Send, 
  CheckCircle2, 
  Layers, 
  Code, 
  Copy, 
  ExternalLink,
  ChevronDown,
  ChevronRight
} from 'lucide-react';

export const ApiExplorerView: React.FC = () => {
  const [selectedEndpoint, setSelectedEndpoint] = useState<string>('post-transfer');
  const [apiResponse, setApiResponse] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const endpoints = [
    {
      id: 'post-transfer',
      method: 'POST',
      path: '/v1/txn/send',
      summary: 'تنفيذ تحويل فوري P2P مع القيد المزدوج وقفل الصرف',
      sampleBody: JSON.stringify({
        senderWalletId: "wal_yer_2491",
        receiverPhone: "773001122",
        amount: 50000,
        currency: "YER",
        idempotencyKey: "idem_89410294821",
        note: "دفعة حساب تجاري"
      }, null, 2),
      mockResponse: {
        statusCode: 200,
        success: true,
        data: {
          transactionId: "tx_9481029",
          referenceNo: "TXN-948102",
          status: "COMPLETED",
          ledger: {
            debitEntryId: "led_deb_1029",
            creditEntryId: "led_crd_1030",
            balanced: true
          },
          timestamp: new Date().toISOString()
        }
      }
    },
    {
      id: 'get-balance',
      method: 'GET',
      path: '/v1/wallets/balance?currency=YER',
      summary: 'الاستعلام عن رصيد المحفظة المتاح والمحجوز',
      sampleBody: null,
      mockResponse: {
        statusCode: 200,
        success: true,
        data: {
          accountNumber: "777-100-2491",
          currency: "YER",
          availableBalance: 4850000.00,
          heldBalance: 0.00,
          kycTier: 3
        }
      }
    },
    {
      id: 'post-batch-payroll',
      method: 'POST',
      path: '/v1/payroll/batch',
      summary: 'صرف دفعة رواتب جماعية لآلاف الموظفين',
      sampleBody: JSON.stringify({
        subscriberId: "sub_9921",
        monthYear: "2026-03",
        batchReference: "PAYROLL_MAR_2026",
        recipientsCount: 18,
        totalDisbursement: 4850000
      }, null, 2),
      mockResponse: {
        statusCode: 202,
        success: true,
        data: {
          batchId: "batch_48109",
          processedCount: 18,
          failedCount: 0,
          totalAmount: 4850000,
          slipsGenerated: true
        }
      }
    }
  ];

  const currentEp = endpoints.find(e => e.id === selectedEndpoint) || endpoints[0];

  const handleExecuteRequest = () => {
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      setApiResponse(JSON.stringify(currentEp.mockResponse, null, 2));
    }, 400);
  };

  return (
    <div id="api-explorer-view" className="bg-slate-900 text-slate-100 rounded-2xl border border-emerald-500/20 p-5 space-y-4">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-800">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-cyan-500/20 text-cyan-400 border border-cyan-500/30">
            <Terminal className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-lg font-bold text-white">مستكشف واجهات OpenAPI 3.0 التفاعلي</h3>
              <span className="text-xs bg-cyan-950 text-cyan-300 px-2 py-0.5 rounded-full border border-cyan-700/50">
                الفرع 25
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              اختبار حي لواجهات الـ REST و gRPC مع توثيق المدخلات والاستجابة اللحظية
            </p>
          </div>
        </div>

        <button 
          onClick={() => alert('تم تصدير ملف swagger.json الكامل للمنظومة')}
          className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs rounded-xl border border-slate-700 self-start sm:self-auto"
        >
          تحميل مواصفات Swagger
        </button>
      </div>

      {/* Explorer Body */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Endpoints List */}
        <div className="space-y-2 lg:border-l lg:border-slate-800 lg:pl-4">
          <div className="text-xs font-bold text-slate-400 mb-2">نقاط الاتصال المتاحة:</div>
          {endpoints.map((ep) => (
            <div
              key={ep.id}
              onClick={() => {
                setSelectedEndpoint(ep.id);
                setApiResponse(null);
              }}
              className={`p-3 rounded-xl border text-xs cursor-pointer transition-all ${
                selectedEndpoint === ep.id
                  ? 'bg-cyan-950/60 border-cyan-500/70 shadow'
                  : 'bg-slate-950/60 border-slate-800 hover:border-slate-700'
              }`}
            >
              <div className="flex items-center gap-2">
                <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold ${
                  ep.method === 'POST' ? 'bg-emerald-950 text-emerald-300 border border-emerald-800' : 'bg-blue-950 text-blue-300 border border-blue-800'
                }`}>
                  {ep.method}
                </span>
                <span className="font-mono text-[11px] text-slate-200">{ep.path}</span>
              </div>
              <p className="text-[11px] text-slate-400 mt-1 line-clamp-1">{ep.summary}</p>
            </div>
          ))}
        </div>

        {/* Live Runner & Response Pane */}
        <div className="lg:col-span-2 bg-slate-950 rounded-2xl p-4 border border-slate-800 space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-slate-800">
            <div className="flex items-center gap-2">
              <span className={`px-2 py-0.5 rounded text-xs font-mono font-bold ${
                currentEp.method === 'POST' ? 'bg-emerald-950 text-emerald-300' : 'bg-blue-950 text-blue-300'
              }`}>
                {currentEp.method}
              </span>
              <span className="font-mono text-xs text-white font-bold">{currentEp.path}</span>
            </div>

            <button
              onClick={handleExecuteRequest}
              disabled={loading}
              className="px-4 py-1.5 bg-cyan-600 hover:bg-cyan-500 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 shadow"
            >
              <Send className="w-3.5 h-3.5" />
              {loading ? 'جارٍ التنفيذ...' : 'إرسال الطلب'}
            </button>
          </div>

          <div className="text-xs text-slate-400">{currentEp.summary}</div>

          {currentEp.sampleBody && (
            <div className="space-y-1">
              <span className="text-[11px] font-bold text-slate-300">جسم الطلب (Request Body JSON):</span>
              <div className="bg-slate-900 p-3 rounded-xl font-mono text-[11px] text-emerald-400 overflow-x-auto border border-slate-800">
                <pre>{currentEp.sampleBody}</pre>
              </div>
            </div>
          )}

          {/* Response Box */}
          <div className="space-y-1">
            <span className="text-[11px] font-bold text-slate-300">الاستجابة الحية (Server Response):</span>
            <div className="bg-slate-900 p-3 rounded-xl font-mono text-[11px] text-cyan-300 overflow-x-auto min-h-[120px] border border-slate-800 flex flex-col justify-center">
              {apiResponse ? (
                <pre>{apiResponse}</pre>
              ) : (
                <div className="text-slate-500 text-center text-xs">
                  اضغط "إرسال الطلب" لاختبار نقطة الاتصال ومحاكاة الاستجابة المباشرة.
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
