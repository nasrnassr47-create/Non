import React, { useState } from 'react';
import { 
  Server, 
  Activity, 
  CheckCircle2, 
  Search, 
  Zap, 
  ShieldCheck, 
  Layers, 
  RefreshCw,
  ExternalLink
} from 'lucide-react';
import { BACKEND_SERVICES, Microservice } from '../../data/servicesData';

export const MicroservicesView: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedService, setSelectedService] = useState<Microservice>(BACKEND_SERVICES[0]);
  const [isPinging, setIsPinging] = useState(false);

  const filteredServices = BACKEND_SERVICES.filter(s =>
    s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    s.nameAr.toLowerCase().includes(searchQuery.toLowerCase()) ||
    s.endpoints.some(e => e.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  const handlePingAll = () => {
    setIsPinging(true);
    setTimeout(() => {
      setIsPinging(false);
      alert('تم فحص سلامة الـ 22 خدمة مصغرة: جميع الخدمات تعمل بكفاءة 100% وزمن الاستجابة مستقر.');
    }, 800);
  };

  return (
    <div id="microservices-view" className="bg-slate-900 text-slate-100 rounded-2xl border border-emerald-500/20 p-5 space-y-4">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-800">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/30">
            <Server className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-lg font-bold text-white">منظومة الخدمات المصغرة الـ 22 (Microservices Mesh)</h3>
              <span className="text-xs bg-amber-950 text-amber-300 px-2 py-0.5 rounded-full border border-amber-700/50">
                الفرع 10
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              شبكة الخدمات المعزولة عالية الاعتمادية مع بروتوكولات gRPC و Kafka و REST
            </p>
          </div>
        </div>

        <button
          disabled={isPinging}
          onClick={handlePingAll}
          className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl shadow flex items-center gap-1.5 self-start sm:self-auto"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${isPinging ? 'animate-spin' : ''}`} />
          {isPinging ? 'جارٍ الفحص...' : 'فحص صحة الـ 22 خدمة'}
        </button>
      </div>

      {/* Grid of services */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Services List */}
        <div className="space-y-2 lg:border-l lg:border-slate-800 lg:pl-4">
          <div className="relative mb-2">
            <Search className="w-4 h-4 absolute right-3 top-2.5 text-slate-400" />
            <input
              type="text"
              placeholder="ابحث في الخدمات الـ 22..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl pr-9 pl-3 py-1.5 text-xs text-white focus:outline-none focus:border-amber-500"
            />
          </div>

          <div className="space-y-1.5 max-h-[460px] overflow-y-auto pr-1">
            {filteredServices.map((svc) => (
              <div
                key={svc.id}
                onClick={() => setSelectedService(svc)}
                className={`p-2.5 rounded-xl border text-xs cursor-pointer transition-all ${
                  selectedService.id === svc.id
                    ? 'bg-amber-950/60 border-amber-500/70 shadow'
                    : 'bg-slate-950/60 border-slate-800 hover:border-slate-700'
                }`}
              >
                <div className="flex justify-between items-center">
                  <span className="font-bold text-slate-200">{svc.nameAr}</span>
                  <span className="font-mono text-[10px] text-amber-400 bg-amber-950 px-1.5 py-0.5 rounded border border-amber-800/40">
                    Port {svc.port}
                  </span>
                </div>
                <div className="flex justify-between items-center text-[10px] text-slate-400 mt-1">
                  <span>{svc.name}</span>
                  <span className="text-emerald-400 flex items-center gap-1 font-mono">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                    {svc.latencyMs}ms
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Selected Service Detail */}
        <div className="lg:col-span-2 bg-slate-950 rounded-2xl p-5 border border-slate-800 space-y-4">
          <div className="flex justify-between items-start pb-3 border-b border-slate-800">
            <div>
              <div className="flex items-center gap-2">
                <h4 className="text-base font-bold text-white">{selectedService.nameAr}</h4>
                <span className="text-xs text-amber-400 font-mono">({selectedService.name})</span>
              </div>
              <p className="text-xs text-slate-400 mt-1">{selectedService.description}</p>
            </div>
            <span className="px-2.5 py-1 rounded-lg text-xs font-mono font-bold bg-slate-800 text-teal-300 border border-slate-700">
              {selectedService.protocol}
            </span>
          </div>

          <div className="grid grid-cols-2 gap-3 text-xs">
            <div className="p-3 bg-slate-900 rounded-xl border border-slate-800">
              <div className="text-slate-400 text-[10px]">المنفذ الشبكي المخصص:</div>
              <div className="text-sm font-bold font-mono text-amber-300 mt-0.5">Port :{selectedService.port}</div>
            </div>
            <div className="p-3 bg-slate-900 rounded-xl border border-slate-800">
              <div className="text-slate-400 text-[10px]">زمن الاستجابة اللحظي (Latency):</div>
              <div className="text-sm font-bold font-mono text-emerald-400 mt-0.5">{selectedService.latencyMs} ms</div>
            </div>
          </div>

          {/* Endpoints */}
          <div className="space-y-2">
            <span className="text-xs font-bold text-slate-300">نقاط الاتصال (Endpoints):</span>
            <div className="space-y-1.5 font-mono text-[11px]">
              {selectedService.endpoints.map((ep, i) => (
                <div key={i} className="p-2 bg-slate-900 rounded-lg border border-slate-800 text-teal-300">
                  {ep}
                </div>
              ))}
            </div>
          </div>

          {/* Key Features */}
          <div className="space-y-2">
            <span className="text-xs font-bold text-slate-300">الميزات الأمنية والمعمارية:</span>
            <div className="flex flex-wrap gap-1.5">
              {selectedService.keyFeatures.map((feat, i) => (
                <span key={i} className="px-2.5 py-1 bg-slate-900 text-slate-300 rounded-lg border border-slate-800 text-xs">
                  ✓ {feat}
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
