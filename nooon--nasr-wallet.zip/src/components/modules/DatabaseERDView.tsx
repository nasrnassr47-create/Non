import React, { useState } from 'react';
import { 
  Database, 
  Search, 
  Table2, 
  Key, 
  Link2, 
  Layers, 
  CheckCircle2,
  FileSpreadsheet
} from 'lucide-react';
import { DATABASE_TABLES, DBTable } from '../../data/databaseSchema';

export const DatabaseERDView: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedTable, setSelectedTable] = useState<DBTable>(DATABASE_TABLES[0]);

  const filteredTables = DATABASE_TABLES.filter(t => {
    const matchesCat = selectedCategory === 'all' || t.category === selectedCategory;
    const matchesSearch = 
      t.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.nameAr.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.columns.some(c => c.name.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesCat && matchesSearch;
  });

  return (
    <div id="database-erd-view" className="bg-slate-900 text-slate-100 rounded-2xl border border-emerald-500/20 p-5 space-y-4">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-800">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-teal-500/20 text-teal-400 border border-teal-500/30">
            <Database className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-lg font-bold text-white">بنية قاعدة البيانات ومخطط العلاقات (ERD)</h3>
              <span className="text-xs bg-teal-950 text-teal-300 px-2 py-0.5 rounded-full border border-teal-700/50">
                50+ جدولاً مصرفياً
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              مخطط دفتر الأستاذ المزدوج والجداول العائلية والتجارية ومخزن الأسرار المشفر
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="bg-slate-950 border border-slate-700 rounded-xl px-3 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-teal-500"
          >
            <option value="all">كافة الفئات ({DATABASE_TABLES.length})</option>
            <option value="core">الحسابات والعملاء (Core)</option>
            <option value="finance">المالية ودفتر الأستاذ (Finance)</option>
            <option value="family">المحافظ العائلية (Family)</option>
            <option value="merchants">الوكلاء والتجار (Merchants)</option>
            <option value="security">التشفير والأسرار (Security)</option>
            <option value="dev_ops">النسخ والتطوير (DevOps)</option>
          </select>
        </div>
      </div>

      {/* Grid of Tables */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Table list */}
        <div className="space-y-2 lg:border-l lg:border-slate-800 lg:pl-4">
          <div className="relative mb-2">
            <Search className="w-4 h-4 absolute right-3 top-2.5 text-slate-400" />
            <input
              type="text"
              placeholder="ابحث في الجداول والحقول..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl pr-9 pl-3 py-1.5 text-xs text-white focus:outline-none focus:border-teal-500"
            />
          </div>

          <div className="space-y-1.5 max-h-[460px] overflow-y-auto pr-1">
            {filteredTables.map((tbl) => (
              <div
                key={tbl.id}
                onClick={() => setSelectedTable(tbl)}
                className={`p-2.5 rounded-xl border text-xs cursor-pointer transition-all ${
                  selectedTable.id === tbl.id
                    ? 'bg-teal-950/60 border-teal-500/70 shadow'
                    : 'bg-slate-950/60 border-slate-800 hover:border-slate-700'
                }`}
              >
                <div className="flex justify-between items-center">
                  <span className="font-mono font-bold text-slate-200">{tbl.name}</span>
                  <span className="text-[10px] text-teal-400 bg-teal-950 px-1.5 py-0.5 rounded border border-teal-800/40">
                    {tbl.nameAr}
                  </span>
                </div>
                <div className="text-[10px] text-slate-400 mt-1">{tbl.columns.length} أعمدة • {tbl.description}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Selected Table Fields Detail */}
        <div className="lg:col-span-2 bg-slate-950 rounded-2xl p-5 border border-slate-800 space-y-4">
          <div className="flex justify-between items-start pb-3 border-b border-slate-800">
            <div>
              <div className="flex items-center gap-2">
                <h4 className="text-base font-bold font-mono text-white">{selectedTable.name}</h4>
                <span className="text-xs text-teal-300 font-semibold">({selectedTable.nameAr})</span>
              </div>
              <p className="text-xs text-slate-400 mt-1">{selectedTable.description}</p>
            </div>
            <span className="text-xs bg-slate-800 text-slate-300 px-2.5 py-1 rounded-lg border border-slate-700">
              {selectedTable.category}
            </span>
          </div>

          {/* Columns Table */}
          <div className="overflow-x-auto">
            <table className="w-full text-right text-xs">
              <thead>
                <tr className="text-slate-400 border-b border-slate-800 pb-2">
                  <th className="pb-2 font-semibold">اسم الحقل (Column)</th>
                  <th className="pb-2 font-semibold">نوع البيانات (Type)</th>
                  <th className="pb-2 font-semibold">المفتاح والارتباط (Keys)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-mono text-[11px]">
                {selectedTable.columns.map((col, idx) => (
                  <tr key={idx} className="hover:bg-slate-900/50">
                    <td className="py-2.5 text-slate-200 font-semibold flex items-center gap-1.5">
                      {col.isPrimary && <Key className="w-3 h-3 text-amber-400" />}
                      {col.isForeign && <Link2 className="w-3 h-3 text-teal-400" />}
                      {col.name}
                    </td>
                    <td className="py-2.5 text-teal-300">{col.type}</td>
                    <td className="py-2.5 text-slate-400">
                      {col.isPrimary && <span className="text-amber-400 font-bold">PRIMARY KEY</span>}
                      {col.isForeign && <span className="text-teal-400 font-bold">FK → {col.ref}</span>}
                      {!col.isPrimary && !col.isForeign && (col.nullable ? 'NULLABLE' : 'NOT NULL')}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
