import React, { useState, useEffect } from 'react';
import { 
  Save, 
  Clock, 
  RotateCcw, 
  ShieldCheck, 
  FileText, 
  CheckCircle2, 
  Database,
  ArrowDownToLine,
  RefreshCw
} from 'lucide-react';

interface Props {
  lastAction?: string;
  onNotifyAutoSave?: (action: string) => void;
}

export const BackupAutoSaveView: React.FC<Props> = ({ lastAction, onNotifyAutoSave }) => {
  const [secondsUntilBackup, setSecondsUntilBackup] = useState(285); // 4 min 45 sec
  const [snapshots, setSnapshots] = useState([
    { id: 'snap-4', hash: 'sha256:9f81..2a0', sizeMb: '14.8 MB', records: 48920, time: 'منذ 5 دقائق', verified: true },
    { id: 'snap-3', hash: 'sha256:7c40..1b8', sizeMb: '14.6 MB', records: 48870, time: 'منذ 10 دقائق', verified: true },
    { id: 'snap-2', hash: 'sha256:1a89..9d2', sizeMb: '14.4 MB', records: 48810, time: 'منذ 15 دقيقة', verified: true },
    { id: 'snap-1', hash: 'sha256:3e10..4f1', sizeMb: '14.2 MB', records: 48750, time: 'منذ 20 دقيقة', verified: true }
  ]);

  const [walLogs, setWalLogs] = useState([
    { id: 'wal-1', event: 'TXN_POST_LEDGER_DEBIT', details: 'Wallet YE-2491 amount 50000', timestamp: '14:41:02.190' },
    { id: 'wal-2', event: 'TXN_POST_LEDGER_CREDIT', details: 'Wallet YE-1049 amount 50000', timestamp: '14:41:02.192' },
    { id: 'wal-3', event: 'VAULT_ACCESS_VERIFY', details: 'Owner Signature valid SHA256', timestamp: '14:40:15.012' },
    { id: 'wal-4', event: 'PAYROLL_BATCH_SIGN', details: '18 records batch signed', timestamp: '14:38:00.840' }
  ]);

  useEffect(() => {
    const timer = setInterval(() => {
      setSecondsUntilBackup(prev => {
        if (prev <= 1) {
          // Trigger automatic snapshot
          const newSnap = {
            id: `snap-${Date.now()}`,
            hash: `sha256:${Math.random().toString(36).substring(2, 10)}..${Math.random().toString(36).substring(2, 5)}`,
            sizeMb: '15.0 MB',
            records: 48990,
            time: 'الآن',
            verified: true
          };
          setSnapshots(curr => [newSnap, ...curr.slice(0, 5)]);
          return 300; // Reset to 5 min
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const handleManualSnapshot = () => {
    const newSnap = {
      id: `snap-${Date.now()}`,
      hash: `sha256:${Math.random().toString(36).substring(2, 10)}..manual`,
      sizeMb: '15.1 MB',
      records: 49010,
      time: 'الآن (يدوي)',
      verified: true
    };
    setSnapshots([newSnap, ...snapshots]);
    setSecondsUntilBackup(300);
    if (onNotifyAutoSave) {
      onNotifyAutoSave('أخذ لقطة نسخ احتياطي يدوي وفحص مطابقة البيانات');
    }
  };

  const minutes = Math.floor(secondsUntilBackup / 60);
  const seconds = secondsUntilBackup % 60;

  return (
    <div id="backup-autosave-view" className="bg-slate-900 text-slate-100 rounded-2xl border border-emerald-500/20 p-5 space-y-4">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-800">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
            <Save className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-lg font-bold text-white">محرك الحفظ اللحظي والنسخ الاحتياطي (Auto-Save WAL)</h3>
              <span className="text-xs bg-emerald-950 text-emerald-300 px-2 py-0.5 rounded-full border border-emerald-700/50">
                الفرع 32
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              كل تغيير يُحفظ فورياً عبر Write-Ahead Logging، مع لقطات Snapshot كل 5 دقائق
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <div className="text-right px-3 py-1.5 bg-slate-950 rounded-xl border border-slate-800 text-xs">
            <div className="text-[10px] text-slate-400">النسخ التلقائي القادم خلال</div>
            <div className="font-mono font-bold text-emerald-400">
              {minutes}:{seconds < 10 ? `0${seconds}` : seconds}
            </div>
          </div>
          <button
            onClick={handleManualSnapshot}
            className="px-3 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl shadow flex items-center gap-1.5"
          >
            <ArrowDownToLine className="w-3.5 h-3.5" />
            أخذ Snapshot الآن
          </button>
        </div>
      </div>

      {/* Real-time WAL status banner */}
      <div className="p-3.5 bg-emerald-950/30 border border-emerald-800/40 rounded-xl flex items-center justify-between text-xs">
        <div className="flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span className="text-emerald-200">
            <strong>الحفظ الفوري اللحظي نشط:</strong> آخر نشاط مسجل: {lastAction || 'استقرار المنظومة ومزامنة السجلات'}
          </span>
        </div>
        <span className="text-[11px] font-mono text-emerald-400 bg-emerald-950 px-2 py-0.5 rounded border border-emerald-700/40">
          Zero-Data-Loss Active
        </span>
      </div>

      {/* Split details: Snapshots vs WAL Stream */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
        {/* Snapshots list */}
        <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-3">
          <div className="font-bold text-slate-200 flex items-center justify-between">
            <span>سجل لقطات النسخ الاحتياطي (Snapshots):</span>
            <span className="text-[10px] text-slate-400">مشفرة AES-256</span>
          </div>

          <div className="space-y-2">
            {snapshots.map((snap) => (
              <div key={snap.id} className="p-2.5 bg-slate-900 rounded-lg border border-slate-800 flex justify-between items-center">
                <div>
                  <div className="font-mono font-semibold text-emerald-300">{snap.hash}</div>
                  <div className="text-[10px] text-slate-400">{snap.time} • {snap.records.toLocaleString()} سجل مالي</div>
                </div>
                <div className="text-left">
                  <div className="font-mono text-slate-200">{snap.sizeMb}</div>
                  <button 
                    onClick={() => alert(`تم التحقق من سلامة اللقطة ${snap.hash}: متطابقة 100% وجاهزة للاستعادة في 30 ثانية.`)}
                    className="text-[10px] text-teal-400 hover:underline"
                  >
                    فحص الاستعادة
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Live WAL Stream */}
        <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-3">
          <div className="font-bold text-slate-200 flex items-center justify-between">
            <span>شريط الـ Write-Ahead Logging (WAL) المباشر:</span>
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
          </div>

          <div className="space-y-2 font-mono text-[11px]">
            {walLogs.map((wal) => (
              <div key={wal.id} className="p-2 bg-slate-900 rounded border border-slate-800/80">
                <div className="flex justify-between text-slate-400 text-[10px]">
                  <span className="text-teal-400 font-bold">{wal.event}</span>
                  <span>{wal.timestamp}</span>
                </div>
                <div className="text-slate-300 mt-0.5 text-[10px] truncate">{wal.details}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
