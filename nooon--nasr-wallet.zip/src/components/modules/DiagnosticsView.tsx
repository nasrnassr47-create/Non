import React, { useState } from 'react';
import { 
  Stethoscope, 
  CheckCircle2, 
  AlertTriangle, 
  XCircle, 
  Wrench, 
  RefreshCw, 
  ShieldCheck, 
  Database, 
  Cpu, 
  Activity,
  Zap
} from 'lucide-react';
import { DiagnosticCheckItem } from '../../types';

interface Props {
  onNotifyAutoSave?: (action: string) => void;
}

export const DiagnosticsView: React.FC<Props> = ({ onNotifyAutoSave }) => {
  const [isRunningScan, setIsRunningScan] = useState(false);
  const [lastScanTime, setLastScanTime] = useState('اليوم 14:30');

  const [diagnostics, setDiagnostics] = useState<DiagnosticCheckItem[]>([
    {
      id: 'd-1',
      category: 'finance',
      title: 'تطابق دفتر الأستاذ المزدوج (Ledger Integrity)',
      description: 'فحص موازنة مجموع القيود الدائنة مع المدينة لكافة المعاملات',
      status: 'pass',
      detail: 'مجموع المدين يساوي مجموع الدائن بدقة 100.00% (توازن تام)',
      fixable: false
    },
    {
      id: 'd-2',
      category: 'finance',
      title: 'قفل الصرف المزدوج (Double-Spending Shield)',
      description: 'التحقق من عدم وجود أي سحب متزامن بنفس مفتاح التحقق',
      status: 'pass',
      detail: 'لا توجد أي محاولات صرف مزدوج معلقة',
      fixable: false
    },
    {
      id: 'd-3',
      category: 'security',
      title: 'شهادات الأمان والتشفير (TLS 1.3 & AES-256)',
      description: 'فحص صلاحية الشهادات وتشفير مخزن الأسرار',
      status: 'pass',
      detail: 'تشفير AES-256-GCM نشط وشهادة TLS صالحة لـ 320 يوماً',
      fixable: false
    },
    {
      id: 'd-4',
      category: 'database',
      title: 'محرك الـ Write-Ahead Logging (WAL)',
      description: 'التحقق من كتابة الأحداث قبل التثبيت في قاعدة البيانات',
      status: 'pass',
      detail: 'زمن استجابة الـ WAL أقل من 8ms وسجل الأحداث متطابق',
      fixable: false
    },
    {
      id: 'd-5',
      category: 'performance',
      title: 'زمن الاستجابة للخدمات الـ 22 (Microservices Latency)',
      description: 'قياس متوسط سرعة استجابة الـ gRPC و Kafka',
      status: 'pass',
      detail: 'متوسط الاستجابة 28ms (أقل بكثير من الحد الأقصى 200ms)',
      fixable: false
    },
    {
      id: 'd-6',
      category: 'security',
      title: 'سجل التدقيق السيادي (Immutable Hash Chain)',
      description: 'التحقق من صحة ترابط سلاسل الكتل الداخلية',
      status: 'pass',
      detail: 'جميع الكتل الـ 8,401 متسلسلة وخالية من أي تلاعب',
      fixable: false
    }
  ]);

  const handleRunFullDiagnostics = () => {
    setIsRunningScan(true);
    setTimeout(() => {
      setIsRunningScan(false);
      setLastScanTime('الآن');
      if (onNotifyAutoSave) {
        onNotifyAutoSave('تشغيل الفاحص الشامل للمنظومة: كل الأنظمة تعمل بكفاءة 100%');
      }
    }, 1500);
  };

  const handleAutoRepair = () => {
    alert('تم تشغيل بروتوكول الإصلاح الآلي: إعادة مزامنة الذاكرة المؤقتة وضبط مؤشرات قواعد البيانات.');
    if (onNotifyAutoSave) {
      onNotifyAutoSave('إجراء فحص وإصلاح آلي لمؤشرات النظام');
    }
  };

  return (
    <div id="diagnostics-view" className="bg-slate-900 text-slate-100 rounded-2xl border border-emerald-500/20 p-5 space-y-4">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-800">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
            <Stethoscope className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-lg font-bold text-white">محرك الفحص والإصلاح الذكي (Diagnostics)</h3>
              <span className="text-xs bg-emerald-950 text-emerald-300 px-2 py-0.5 rounded-full border border-emerald-700/50">
                الفرع 36
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              فحص التوازن المالي، كشف الثغرات الأمنية، والمطابقة التلقائية مع دفتر الأستاذ
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleAutoRepair}
            className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs rounded-xl border border-slate-700 flex items-center gap-1.5"
          >
            <Wrench className="w-3.5 h-3.5 text-amber-400" />
            إصلاح تلقائي
          </button>
          <button
            disabled={isRunningScan}
            onClick={handleRunFullDiagnostics}
            className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl shadow flex items-center gap-1.5"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isRunningScan ? 'animate-spin' : ''}`} />
            {isRunningScan ? 'جارٍ الفحص الشامل...' : 'فحص شامل الآن'}
          </button>
        </div>
      </div>

      {/* Score and Health Banner */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800 flex items-center justify-between">
          <div>
            <div className="text-xs text-slate-400">مؤشر السلامة المالية</div>
            <div className="text-xl font-bold text-emerald-400">100% متطابق</div>
          </div>
          <CheckCircle2 className="w-6 h-6 text-emerald-400" />
        </div>

        <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800 flex items-center justify-between">
          <div>
            <div className="text-xs text-slate-400">الامتثال الأمني (OWASP / PCI)</div>
            <div className="text-xl font-bold text-teal-300">Grade A+</div>
          </div>
          <ShieldCheck className="w-6 h-6 text-teal-400" />
        </div>

        <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800 flex items-center justify-between">
          <div>
            <div className="text-xs text-slate-400">آخر فحص تلقائي</div>
            <div className="text-base font-bold text-slate-200">{lastScanTime}</div>
          </div>
          <Activity className="w-6 h-6 text-emerald-400" />
        </div>
      </div>

      {/* Checks Grid */}
      <div className="space-y-2.5">
        <div className="text-xs font-semibold text-slate-300">نقاط الفحص الحرجة:</div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5">
          {diagnostics.map((chk) => (
            <div key={chk.id} className="p-3.5 bg-slate-950 rounded-xl border border-slate-800 space-y-1.5 text-xs">
              <div className="flex justify-between items-start">
                <span className="font-bold text-slate-200">{chk.title}</span>
                <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-emerald-950 text-emerald-300 border border-emerald-800/50 flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3 text-emerald-400" /> سليم
                </span>
              </div>
              <p className="text-[11px] text-slate-400">{chk.description}</p>
              <div className="p-2 bg-slate-900 rounded text-[11px] font-mono text-emerald-300">
                {chk.detail}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
