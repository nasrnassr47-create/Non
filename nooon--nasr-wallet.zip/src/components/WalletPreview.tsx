import React, { useState } from 'react';
import { 
  ArrowDownLeft, 
  ArrowUpRight, 
  CreditCard, 
  QrCode, 
  ReceiptText, 
  ShieldCheck, 
  Eye, 
  EyeOff, 
  Plus, 
  Smartphone, 
  Send, 
  TrendingUp, 
  Building2, 
  CheckCircle,
  Copy,
  ChevronLeft
} from 'lucide-react';
import { Logo } from './Logo';

export const WalletPreview: React.FC = () => {
  const [showBalance, setShowBalance] = useState(true);
  const [activeCurrency, setActiveCurrency] = useState<'YER' | 'SAR' | 'USD'>('YER');
  const [copied, setCopied] = useState(false);
  const [activeModal, setActiveModal] = useState<string | null>(null);

  const balances = {
    YER: { amount: 1450000, symbol: 'ر.ي', name: 'ريال يمني' },
    SAR: { amount: 8250, symbol: 'ر.س', name: 'ريال سعودي' },
    USD: { amount: 2200, symbol: '$', name: 'دولار أمريكي' },
  };

  const current = balances[activeCurrency];

  const handleCopyAcc = () => {
    navigator.clipboard?.writeText?.('NW-8920-4491-00');
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="bg-slate-100/90 rounded-3xl p-3 sm:p-5 border border-slate-200/80 shadow-inner space-y-4 max-w-md mx-auto">
      {/* Wallet App Bar */}
      <div className="flex items-center justify-between px-1">
        <Logo size="sm" variant="horizontal" showSubtitle={false} />
        <div className="flex items-center gap-2">
          <div className="flex bg-slate-200/80 p-0.5 rounded-xl text-xs font-bold text-slate-700">
            {(['YER', 'SAR', 'USD'] as const).map((curr) => (
              <button
                key={curr}
                onClick={() => setActiveCurrency(curr)}
                className={`px-2 py-1 rounded-lg transition-all ${
                  activeCurrency === curr
                    ? 'bg-emerald-600 text-white shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {curr}
              </button>
            ))}
          </div>
          <span className="relative flex h-3 w-3">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500"></span>
          </span>
        </div>
      </div>

      {/* Main Leather & Emerald Metallic Card */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-slate-900 via-emerald-950 to-slate-900 text-white p-5 shadow-xl border border-emerald-500/30">
        {/* Golden Tan Accent line reminiscent of the wallet stitching */}
        <div className="absolute top-0 right-0 left-0 h-1 bg-gradient-to-r from-amber-500 via-amber-300 to-emerald-400" />
        
        <div className="flex items-start justify-between relative z-10">
          <div>
            <span className="text-xs font-medium text-emerald-300/80 block mb-1">الرصيد الكلي المتاح</span>
            <div className="flex items-baseline gap-2">
              <h2 className="text-3xl font-black tracking-tight">
                {showBalance ? current.amount.toLocaleString('ar-YE') : '••••••••'}
              </h2>
              <span className="text-sm font-bold text-amber-300">{current.symbol}</span>
              <button
                onClick={() => setShowBalance(!showBalance)}
                className="p-1 text-slate-400 hover:text-emerald-300 transition-colors"
                title="إظهار/إخفاء الرصيد"
              >
                {showBalance ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-amber-500 to-amber-600 p-2 shadow-md flex items-center justify-center border border-amber-300/30">
            <span className="text-slate-900 font-extrabold text-xs">NW</span>
          </div>
        </div>

        <div className="mt-5 pt-3 border-t border-emerald-900/60 flex items-center justify-between text-xs text-slate-300 relative z-10">
          <div className="flex items-center gap-1.5 cursor-pointer hover:text-white" onClick={handleCopyAcc}>
            <span className="font-mono text-emerald-200">NW-8920-4491-00</span>
            {copied ? <CheckCircle className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 text-slate-400" />}
          </div>
          <span className="flex items-center gap-1 text-emerald-400 font-semibold">
            <ShieldCheck className="w-3.5 h-3.5" />
            محفظة موثقة (KYC)
          </span>
        </div>
      </div>

      {/* Quick Action Matrix */}
      <div className="grid grid-cols-4 gap-2 text-center">
        <button
          onClick={() => setActiveModal('transfer')}
          className="flex flex-col items-center gap-1.5 p-2.5 rounded-2xl bg-white hover:bg-emerald-50 text-slate-800 border border-slate-200/80 shadow-sm transition-all hover:scale-[1.02]"
        >
          <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center">
            <Send className="w-5 h-5" />
          </div>
          <span className="text-xs font-bold">تحويل</span>
        </button>

        <button
          onClick={() => setActiveModal('deposit')}
          className="flex flex-col items-center gap-1.5 p-2.5 rounded-2xl bg-white hover:bg-emerald-50 text-slate-800 border border-slate-200/80 shadow-sm transition-all hover:scale-[1.02]"
        >
          <div className="w-10 h-10 rounded-xl bg-amber-100 text-amber-700 flex items-center justify-center">
            <Plus className="w-5 h-5" />
          </div>
          <span className="text-xs font-bold">إيداع</span>
        </button>

        <button
          onClick={() => setActiveModal('qr')}
          className="flex flex-col items-center gap-1.5 p-2.5 rounded-2xl bg-white hover:bg-emerald-50 text-slate-800 border border-slate-200/80 shadow-sm transition-all hover:scale-[1.02]"
        >
          <div className="w-10 h-10 rounded-xl bg-slate-100 text-slate-700 flex items-center justify-center">
            <QrCode className="w-5 h-5" />
          </div>
          <span className="text-xs font-bold">مسح QR</span>
        </button>

        <button
          onClick={() => setActiveModal('bills')}
          className="flex flex-col items-center gap-1.5 p-2.5 rounded-2xl bg-white hover:bg-emerald-50 text-slate-800 border border-slate-200/80 shadow-sm transition-all hover:scale-[1.02]"
        >
          <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center">
            <Smartphone className="w-5 h-5" />
          </div>
          <span className="text-xs font-bold">سداد</span>
        </button>
      </div>

      {/* Services Grid Snapshot */}
      <div className="bg-white rounded-2xl p-3 border border-slate-200/80 shadow-sm space-y-2">
        <div className="flex items-center justify-between text-xs font-bold text-slate-600 px-1">
          <span>الخدمات المالية الرئيسية</span>
          <span className="text-emerald-600 cursor-pointer hover:underline">الكل (12)</span>
        </div>
        <div className="grid grid-cols-2 gap-2 text-xs">
          <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-100 flex items-center gap-2 hover:bg-emerald-50/50 cursor-pointer">
            <CreditCard className="w-4 h-4 text-emerald-600 shrink-0" />
            <div className="text-right">
              <span className="font-bold text-slate-800 block">بطاقة نصر مسبقة الدفع</span>
              <span className="text-[10px] text-slate-500">فيزا وماستركارد افتراضية</span>
            </div>
          </div>

          <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-100 flex items-center gap-2 hover:bg-emerald-50/50 cursor-pointer">
            <Building2 className="w-4 h-4 text-amber-600 shrink-0" />
            <div className="text-right">
              <span className="font-bold text-slate-800 block">حوالات بنكية ومصارف</span>
              <span className="text-[10px] text-slate-500">ربط مع شبكات الصرافة</span>
            </div>
          </div>
        </div>
      </div>

      {/* Recent Ledger History */}
      <div className="bg-white rounded-2xl p-3.5 border border-slate-200/80 shadow-sm space-y-3">
        <div className="flex items-center justify-between text-xs font-bold text-slate-700">
          <span>آخر العمليات المالية</span>
          <span className="text-emerald-600 text-[11px] font-semibold flex items-center gap-0.5">
            سجل التدقيق
            <ChevronLeft className="w-3 h-3" />
          </span>
        </div>

        <div className="space-y-2 text-xs">
          <div className="flex items-center justify-between p-2 rounded-xl bg-slate-50 hover:bg-slate-100/70 transition-colors">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center">
                <ArrowDownLeft className="w-4 h-4" />
              </div>
              <div>
                <p className="font-bold text-slate-800">إيداع نقدي عبر وكيل نصر</p>
                <p className="text-[10px] text-slate-400">اليوم 02:45 م • رقم السند #7712</p>
              </div>
            </div>
            <span className="font-bold text-emerald-600 dir-ltr">+ 50,000 ر.ي</span>
          </div>

          <div className="flex items-center justify-between p-2 rounded-xl bg-slate-50 hover:bg-slate-100/70 transition-colors">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-rose-100 text-rose-700 flex items-center justify-center">
                <ArrowUpRight className="w-4 h-4" />
              </div>
              <div>
                <p className="font-bold text-slate-800">سداد باقة اتصالات وإنترنت</p>
                <p className="text-[10px] text-slate-400">أمس 09:15 ص • يمن موبايل 4G</p>
              </div>
            </div>
            <span className="font-bold text-rose-600 dir-ltr">- 4,800 ر.ي</span>
          </div>
        </div>
      </div>

      {/* Modal / Action Notice */}
      {activeModal && (
        <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-800 flex items-center justify-between">
          <span>سيتم تفعيل بوابة [{activeModal}] فور اعتماد فروع الشجرة المعمارية!</span>
          <button onClick={() => setActiveModal(null)} className="font-bold underline text-emerald-900">
            إغلاق
          </button>
        </div>
      )}
    </div>
  );
};
