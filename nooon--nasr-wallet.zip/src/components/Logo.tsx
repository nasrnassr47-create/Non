import React from 'react';

interface LogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showSubtitle?: boolean;
  variant?: 'full' | 'icon-only' | 'horizontal';
  className?: string;
}

export const Logo: React.FC<LogoProps> = ({
  size = 'md',
  showSubtitle = true,
  variant = 'full',
  className = '',
}) => {
  const iconDimensions = {
    sm: { w: 36, h: 36 },
    md: { w: 56, h: 56 },
    lg: { w: 84, h: 84 },
    xl: { w: 120, h: 120 },
  }[size];

  const titleSizes = {
    sm: 'text-base font-black',
    md: 'text-2xl font-black',
    lg: 'text-3xl font-black',
    xl: 'text-4xl font-black',
  }[size];

  const subtitleSizes = {
    sm: 'text-[10px] font-medium tracking-tight',
    md: 'text-xs font-semibold tracking-normal',
    lg: 'text-sm font-semibold tracking-wide',
    xl: 'text-base font-semibold tracking-wider',
  }[size];

  return (
    <div
      id="nasr-wallet-brand-logo"
      className={`flex items-center select-none ${
        variant === 'full' ? 'flex-col text-center gap-2' : 'flex-row items-center gap-3.5'
      } ${className}`}
    >
      {/* Visual Logo Emblem */}
      <div
        className="relative flex items-center justify-center transition-transform hover:scale-105 duration-300"
        style={{ width: iconDimensions.w, height: iconDimensions.h }}
      >
        <svg
          viewBox="0 0 200 160"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="w-full h-full drop-shadow-md"
        >
          <defs>
            {/* Emerald 3D Gradient */}
            <linearGradient id="emeraldGrad" x1="20" y1="20" x2="110" y2="140" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#22c55e" />
              <stop offset="40%" stopColor="#16a34a" />
              <stop offset="85%" stopColor="#15803d" />
              <stop offset="100%" stopColor="#14532d" />
            </linearGradient>

            <linearGradient id="emeraldHighlight" x1="40" y1="20" x2="70" y2="70" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#86efac" stopOpacity="0.8" />
              <stop offset="100%" stopColor="#22c55e" stopOpacity="0" />
            </linearGradient>

            {/* Leather Wallet Gradient */}
            <linearGradient id="leatherGrad" x1="100" y1="30" x2="190" y2="130" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#f59e0b" />
              <stop offset="35%" stopColor="#d97706" />
              <stop offset="75%" stopColor="#b45309" />
              <stop offset="100%" stopColor="#78350f" />
            </linearGradient>

            {/* Leather Shadow */}
            <filter id="leatherShadow" x="90" y="25" width="105" height="115" filterUnits="userSpaceOnUse">
              <feDropShadow dx="2" dy="5" stdDeviation="4" floodColor="#451a03" floodOpacity="0.35" />
            </filter>

            {/* Subtle Texture */}
            <radialGradient id="sphereGrad" cx="30%" cy="30%" r="70%">
              <stop offset="0%" stopColor="#4ade80" />
              <stop offset="60%" stopColor="#16a34a" />
              <stop offset="100%" stopColor="#0f5132" />
            </radialGradient>
          </defs>

          {/* Tan Leather Wallet (Right Side) */}
          <g filter="url(#leatherShadow)">
            {/* Back Fold */}
            <rect x="110" y="32" width="70" height="74" rx="8" fill="#92400e" opacity="0.6" />
            
            {/* Main Bi-fold Body */}
            <rect x="114" y="36" width="72" height="74" rx="10" fill="url(#leatherGrad)" stroke="#78350f" strokeWidth="1.5" />
            
            {/* Leather Stitching lines around border */}
            <rect
              x="118"
              y="40"
              width="64"
              height="66"
              rx="7"
              fill="none"
              stroke="#fbbf24"
              strokeWidth="1.2"
              strokeDasharray="3 2"
              opacity="0.85"
            />

            {/* Wallet Clasp Strap */}
            <path
              d="M 160 67 L 194 67 C 196.5 67 198 69 198 73 L 198 77 C 198 81 196.5 83 194 83 L 160 83 Z"
              fill="#78350f"
            />
            <path
              d="M 160 69 L 192 69 C 194 69 195.5 70.5 195.5 73.5 L 195.5 76.5 C 195.5 79.5 194 81 192 81 L 160 81 Z"
              fill="#b45309"
            />
            {/* Clasp Stitching */}
            <line x1="163" y1="71" x2="191" y2="71" stroke="#fef08a" strokeWidth="1" strokeDasharray="2 1.5" />
            <line x1="163" y1="79" x2="191" y2="79" stroke="#fef08a" strokeWidth="1" strokeDasharray="2 1.5" />
            {/* Metallic Clasp Rivet/Stud */}
            <circle cx="188" cy="75" r="2.5" fill="#fef08a" stroke="#ca8a04" strokeWidth="0.8" />
          </g>

          {/* Stylized Emerald 3D Calligraphic Ribbon (نصر / NW) */}
          <g>
            {/* Left Noon arch */}
            <path
              d="M 38 108 C 22 108 14 94 14 74 C 14 46 32 30 54 30 C 74 30 84 46 84 70 C 84 94 72 108 58 108 C 50 108 44 102 44 94 C 44 86 50 82 56 82 C 64 82 68 88 68 93 C 68 96 66 98 63 98 C 61 98 60 97 60 96 C 60 88 48 88 48 68 C 48 50 40 42 32 60 C 27 70 26 84 34 94 C 38 98 42 99 46 99 Z"
              fill="url(#emeraldGrad)"
            />

            {/* 3D Sphere Dot in the center of Noon */}
            <circle cx="48" cy="62" r="11" fill="url(#sphereGrad)" filter="drop-shadow(1px 2px 2px rgba(0,0,0,0.3))" />
            <circle cx="45" cy="59" r="3.5" fill="#ffffff" opacity="0.5" />

            {/* Lower sphere accent */}
            <circle cx="72" cy="98" r="9" fill="url(#sphereGrad)" filter="drop-shadow(1px 2px 2px rgba(0,0,0,0.25))" />
            <circle cx="70" cy="96" r="2.5" fill="#ffffff" opacity="0.45" />

            {/* Flowing ribbon connecting to wallet forming 'W' & 'ص/ر' */}
            <path
              d="M 82 38 C 88 34 96 32 106 48 L 126 102 C 128 107 133 108 138 103 L 156 52 C 158 46 156 42 150 42 L 140 42 C 135 42 133 45 131 51 L 122 78 L 112 50 C 108 40 98 34 82 38 Z"
              fill="url(#emeraldGrad)"
              filter="drop-shadow(1px 3px 4px rgba(0,0,0,0.2))"
            />
            {/* Highlight edge on the ribbon */}
            <path
              d="M 84 40 C 92 36 98 40 106 50 L 125 100"
              stroke="url(#emeraldHighlight)"
              strokeWidth="2.5"
              strokeLinecap="round"
            />
          </g>
        </svg>
      </div>

      {/* Brand Typography */}
      {variant !== 'icon-only' && (
        <div className={`flex flex-col ${variant === 'horizontal' ? 'text-right' : 'text-center'}`}>
          <div className="flex items-center gap-1.5 justify-center">
            <span
              className={`${titleSizes} tracking-tight text-slate-800 font-extrabold transition-colors`}
              style={{ fontFamily: "'Cairo', sans-serif" }}
            >
              نصر والت
            </span>
          </div>
          {showSubtitle && (
            <span
              className={`${subtitleSizes} text-slate-500 font-bold -mt-0.5 tracking-wide`}
              style={{ fontFamily: "'Cairo', sans-serif" }}
            >
              محفظتك أنت..
            </span>
          )}
        </div>
      )}
    </div>
  );
};
