import React, { useState, useMemo } from 'react';
import { 
  GitBranch, 
  Layers, 
  Code, 
  Database, 
  Activity, 
  Search, 
  CheckCircle2, 
  Clock, 
  ChevronRight, 
  ChevronDown, 
  Download, 
  Filter, 
  Sparkles,
  Shield,
  Smartphone,
  Server,
  ArrowRight
} from 'lucide-react';
import { SYSTEM_BRANCHES, SystemBranch } from '../data/systemTree';

interface Props {
  onSelectBranch?: (branch: SystemBranch) => void;
  onRequestRoleApp?: (role: string) => void;
  onSelectService?: (serviceName: string) => void;
}

export const SystemVisualizer: React.FC<Props> = ({ onSelectBranch, onRequestRoleApp, onSelectService }) => {
  const [viewMode, setViewMode] = useState<'tree' | 'code' | 'structural' | 'erd' | 'flow'>('tree');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [expandedBranches, setExpandedBranches] = useState<Record<string, boolean>>({
    'b-0': true,
    'b-8': true,
    'b-9': true,
    'b-10': true,
    'b-12': true,
    'b-30': true,
    'b-31': true
  });
  const [copiedNotification, setCopiedNotification] = useState(false);

  const toggleBranch = (id: string) => {
    setExpandedBranches(prev => ({ ...prev, [id]: !prev[id] }));
  };

  const expandAll = () => {
    const allExpanded: Record<string, boolean> = {};
    SYSTEM_BRANCHES.forEach(b => { allExpanded[b.id] = true; });
    setExpandedBranches(allExpanded);
  };

  const collapseAll = () => {
    setExpandedBranches({});
  };

  const filteredBranches = useMemo(() => {
    return SYSTEM_BRANCHES.filter(b => {
      const matchesCat = selectedCategory === 'all' || b.category === selectedCategory;
      const matchesSearch = 
        b.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        b.titleEn.toLowerCase().includes(searchQuery.toLowerCase()) ||
        b.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        b.children.some(c => c.title.toLowerCase().includes(searchQuery.toLowerCase()) || c.description.toLowerCase().includes(searchQuery.toLowerCase()));
      return matchesCat && matchesSearch;
    });
  }, [searchQuery, selectedCategory]);

  const stats = useMemo(() => {
    const totalBranches = SYSTEM_BRANCHES.length;
    const totalSub = SYSTEM_BRANCHES.reduce((acc, b) => acc + b.children.length, 0);
    const completed = SYSTEM_BRANCHES.reduce((acc, b) => acc + b.children.filter(c => c.status === 'completed').length, 0);
    const percent = Math.round((completed / totalSub) * 100);
    return { totalBranches, totalSub, completed, percent };
  }, []);

  const handleExport = (format: 'json' | 'md') => {
    let content = '';
    let mime = 'text/plain';
    let filename = `nasr-wallet-system-tree.${format}`;

    if (format === 'json') {
      content = JSON.stringify(SYSTEM_BRANCHES, null, 2);
      mime = 'application/json';
    } else {
      content = `# شجرة النظام الشامل - نصر والت (Nasr Wallet V2)\n\n`;
      content += `إجمالي الفروع: ${SYSTEM_BRANCHES.length} فرعاً رئيسياً | نسبة الاكتمال: ${stats.percent}%\n\n`;
      SYSTEM_BRANCHES.forEach(b => {
        content += `## الفرع ${b.num}: ${b.title} (${b.titleEn})\n`;
        content += `*الوصف*: ${b.description}\n`;
        b.children.forEach(c => {
          content += `- [x] **${c.code} ${c.title}**: ${c.description}\n`;
        });
        content += `\n`;
      });
    }

    const blob = new Blob([content], { type: mime });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
    setCopiedNotification(true);
    setTimeout(() => setCopiedNotification(false), 3000);
  };

  return (
    <div id="system-visualizer" className="bg-slate-900 text-slate-100 rounded-2xl border border-emerald-500/20 shadow-2xl p-4 md:p-6 mb-8">
      {/* Header Bar */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-6 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-3">
            <span className="p-2.5 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-700 text-white shadow-lg shadow-emerald-900/40">
              <GitBranch className="w-6 h-6" />
            </span>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl md:text-2xl font-bold text-emerald-400">
                  لوحة "شكل النظام" التفاعلية
                </h2>
                <span className="text-xs bg-emerald-950 text-emerald-300 px-2.5 py-0.5 rounded-full border border-emerald-600/30">
                  الفرع 42 من 42
                </span>
              </div>
              <p className="text-sm text-slate-400 mt-0.5">
                مخطط الشجرة المتكامل لـ 42 فرعاً و 7 تطبيقات و 22 خدمة ومخزن الأسرار السيادي
              </p>
            </div>
          </div>
        </div>

        {/* View Mode Switcher */}
        <div className="flex items-center flex-wrap gap-1.5 bg-slate-800/80 p-1.5 rounded-xl border border-slate-700/60">
          <button
            onClick={() => setViewMode('tree')}
            className={`px-3 py-1.5 rounded-lg text-xs md:text-sm font-medium transition-all flex items-center gap-1.5 ${
              viewMode === 'tree' ? 'bg-emerald-600 text-white shadow' : 'text-slate-300 hover:text-white hover:bg-slate-700/50'
            }`}
          >
            <GitBranch className="w-4 h-4" />
            1. شجري (42 فرع)
          </button>
          <button
            onClick={() => setViewMode('structural')}
            className={`px-3 py-1.5 rounded-lg text-xs md:text-sm font-medium transition-all flex items-center gap-1.5 ${
              viewMode === 'structural' ? 'bg-emerald-600 text-white shadow' : 'text-slate-300 hover:text-white hover:bg-slate-700/50'
            }`}
          >
            <Layers className="w-4 h-4" />
            2. بنيوي (الطبقات)
          </button>
          <button
            onClick={() => setViewMode('code')}
            className={`px-3 py-1.5 rounded-lg text-xs md:text-sm font-medium transition-all flex items-center gap-1.5 ${
              viewMode === 'code' ? 'bg-emerald-600 text-white shadow' : 'text-slate-300 hover:text-white hover:bg-slate-700/50'
            }`}
          >
            <Code className="w-4 h-4" />
            3. برمجي (الخدمات والملفات)
          </button>
          <button
            onClick={() => setViewMode('erd')}
            className={`px-3 py-1.5 rounded-lg text-xs md:text-sm font-medium transition-all flex items-center gap-1.5 ${
              viewMode === 'erd' ? 'bg-emerald-600 text-white shadow' : 'text-slate-300 hover:text-white hover:bg-slate-700/50'
            }`}
          >
            <Database className="w-4 h-4" />
            4. بياناتي (ERD)
          </button>
          <button
            onClick={() => setViewMode('flow')}
            className={`px-3 py-1.5 rounded-lg text-xs md:text-sm font-medium transition-all flex items-center gap-1.5 ${
              viewMode === 'flow' ? 'bg-emerald-600 text-white shadow' : 'text-slate-300 hover:text-white hover:bg-slate-700/50'
            }`}
          >
            <Activity className="w-4 h-4" />
            5. تدفقات العمليات
          </button>
        </div>
      </div>

      {/* Progress & Quick Stats bar */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 my-4">
        <div className="bg-slate-800/60 p-3 rounded-xl border border-slate-700/50 flex items-center justify-between">
          <div>
            <div className="text-xs text-slate-400">إجمالي الفروع</div>
            <div className="text-lg font-bold text-white">42 فرعاً رئيسياً</div>
          </div>
          <div className="p-2 rounded-lg bg-emerald-500/10 text-emerald-400">
            <GitBranch className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-slate-800/60 p-3 rounded-xl border border-slate-700/50 flex items-center justify-between">
          <div>
            <div className="text-xs text-slate-400">العقد والخدمات المنجزة</div>
            <div className="text-lg font-bold text-emerald-400">{stats.completed} عنصر</div>
          </div>
          <div className="p-2 rounded-lg bg-emerald-500/10 text-emerald-400">
            <CheckCircle2 className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-slate-800/60 p-3 rounded-xl border border-slate-700/50 flex items-center justify-between">
          <div>
            <div className="text-xs text-slate-400">التطبيقات والخدمات</div>
            <div className="text-lg font-bold text-amber-300">7 تطبيقات + 22 خدمة</div>
          </div>
          <div className="p-2 rounded-lg bg-amber-500/10 text-amber-400">
            <Smartphone className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-slate-800/60 p-3 rounded-xl border border-slate-700/50 flex items-center justify-between">
          <div>
            <div className="text-xs text-slate-400">جاهزية المعمارية</div>
            <div className="text-lg font-bold text-teal-300">{stats.percent}% متكامل</div>
          </div>
          <div className="p-2 rounded-lg bg-teal-500/10 text-teal-400">
            <Shield className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* VIEW 1: TREE VIEW (42 Branches) */}
      {viewMode === 'tree' && (
        <div>
          {/* Filter & Action Toolbar */}
          <div className="flex flex-col md:flex-row items-center justify-between gap-3 mb-4 pt-2">
            <div className="flex items-center gap-2 w-full md:w-auto">
              <div className="relative flex-1 md:w-72">
                <Search className="w-4 h-4 absolute right-3 top-3 text-slate-400" />
                <input
                  type="text"
                  placeholder="ابحث في الـ 42 فرعاً والفروع الفرعية..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl pr-9 pl-3 py-2 text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-emerald-500 transition-colors"
                />
              </div>

              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-sm text-slate-200 focus:outline-none focus:border-emerald-500"
              >
                <option value="all">جميع الأقسام (All)</option>
                <option value="core">الأساس والأوامر (Core)</option>
                <option value="planning">التخطيط والجدوى (Planning)</option>
                <option value="architecture">المعمارية والتصميم (Architecture)</option>
                <option value="apps">التطبيقات الـ 7 (Apps)</option>
                <option value="services">الخدمات الـ 22 (Services)</option>
                <option value="security">الأمان ومخزن الأسرار (Security)</option>
                <option value="engines">المحركات الذكية (Engines)</option>
              </select>
            </div>

            <div className="flex items-center gap-2 w-full md:w-auto justify-end">
              <button
                onClick={expandAll}
                className="px-2.5 py-1.5 text-xs bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg border border-slate-700"
              >
                توسيع الكل
              </button>
              <button
                onClick={collapseAll}
                className="px-2.5 py-1.5 text-xs bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg border border-slate-700"
              >
                طي الكل
              </button>
              <button
                onClick={() => handleExport('json')}
                className="px-2.5 py-1.5 text-xs bg-emerald-900/40 hover:bg-emerald-800/60 text-emerald-300 rounded-lg border border-emerald-700/50 flex items-center gap-1"
                title="تصدير الشجرة بتنسيق JSON"
              >
                <Download className="w-3.5 h-3.5" />
                تصدير JSON
              </button>
              <button
                onClick={() => handleExport('md')}
                className="px-2.5 py-1.5 text-xs bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg border border-slate-700 flex items-center gap-1"
                title="تصدير الشجرة بتنسيق Markdown"
              >
                <Download className="w-3.5 h-3.5" />
                Markdown
              </button>
            </div>
          </div>

          {copiedNotification && (
            <div className="bg-emerald-900/80 border border-emerald-500 text-emerald-200 text-xs px-3 py-2 rounded-lg mb-3 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              تم تصدير ملف هيكل شجرة النظام بنجاح إلى جهازك!
            </div>
          )}

          {/* Tree Node Container */}
          <div className="space-y-2.5 max-h-[640px] overflow-y-auto pr-1">
            {filteredBranches.map((branch) => {
              const isExpanded = !!expandedBranches[branch.id];
              return (
                <div 
                  key={branch.id} 
                  className={`rounded-xl border transition-all ${
                    isExpanded 
                      ? 'bg-slate-800/90 border-emerald-500/40 shadow-md' 
                      : 'bg-slate-800/40 border-slate-700/50 hover:border-slate-600'
                  }`}
                >
                  <div
                    onClick={() => toggleBranch(branch.id)}
                    className="p-3.5 flex items-center justify-between cursor-pointer select-none"
                  >
                    <div className="flex items-center gap-3">
                      <div className="text-slate-400 hover:text-white">
                        {isExpanded ? <ChevronDown className="w-5 h-5 text-emerald-400" /> : <ChevronRight className="w-5 h-5" />}
                      </div>

                      <div className="w-7 h-7 rounded-lg bg-emerald-950 text-emerald-300 border border-emerald-700/40 flex items-center justify-center font-bold text-xs">
                        {branch.num}
                      </div>

                      <div>
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="font-semibold text-slate-100 text-sm md:text-base">
                            الفرع {branch.num}: {branch.title}
                          </span>
                          <span className="text-xs text-slate-400 font-mono hidden sm:inline">
                            ({branch.titleEn})
                          </span>
                          <span className="text-[10px] bg-slate-700 text-slate-300 px-2 py-0.5 rounded-full">
                            {branch.children.length} عنصر
                          </span>
                        </div>
                        <p className="text-xs text-slate-400 mt-0.5">{branch.description}</p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <span className="text-xs px-2 py-0.5 rounded-md bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 hidden md:inline-flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3" /> مكتمل
                      </span>
                    </div>
                  </div>

                  {/* Sub-branches list */}
                  {isExpanded && (
                    <div className="px-4 pb-4 pt-1 border-t border-slate-700/60 bg-slate-900/40 rounded-b-xl">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-2 mt-2">
                        {branch.children.map((sub) => (
                          <div 
                            key={sub.id}
                            className="bg-slate-800/80 p-2.5 rounded-lg border border-slate-700/40 hover:border-emerald-500/30 transition-all flex items-start justify-between gap-2"
                          >
                            <div>
                              <div className="flex items-center gap-1.5">
                                <span className="font-mono text-emerald-400 text-xs font-bold">{sub.code}</span>
                                <span className="text-xs font-medium text-slate-200">{sub.title}</span>
                              </div>
                              <p className="text-[11px] text-slate-400 mt-1 leading-relaxed">{sub.description}</p>
                            </div>
                            <span className="text-[10px] text-emerald-400 shrink-0 bg-emerald-950/80 px-1.5 py-0.5 rounded border border-emerald-700/30">
                              مفعّل
                            </span>
                          </div>
                        ))}
                      </div>

                      {/* Quick jump actions if branch is related to apps or services */}
                      {branch.num === 9 && (
                        <div className="mt-3 pt-2 border-t border-slate-800 flex items-center justify-between text-xs">
                          <span className="text-slate-400">انتقال سريع لتجربة التطبيقات:</span>
                          <div className="flex gap-2">
                            <button
                              onClick={() => onRequestRoleApp && onRequestRoleApp('client')}
                              className="text-emerald-400 hover:text-emerald-300 underline"
                            >
                              تطبيق العميل
                            </button>
                            <span className="text-slate-600">•</span>
                            <button
                              onClick={() => onRequestRoleApp && onRequestRoleApp('subscriber')}
                              className="text-emerald-400 hover:text-emerald-300 underline"
                            >
                              المشترك
                            </button>
                            <span className="text-slate-600">•</span>
                            <button
                              onClick={() => onRequestRoleApp && onRequestRoleApp('owner')}
                              className="text-amber-400 hover:text-amber-300 underline"
                            >
                              المالك السيادي
                            </button>
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* VIEW 2: STRUCTURAL VIEW (Layers Architecture) */}
      {viewMode === 'structural' && (
        <div className="space-y-4">
          <div className="p-3 bg-emerald-950/30 border border-emerald-800/40 rounded-xl text-xs text-emerald-300 flex items-center gap-2">
            <Layers className="w-4 h-4 text-emerald-400" />
            <span>الهندسة البنيوية متعددة الطبقات (Multi-Tier Sovereign Architecture) لنظام نصر والت V2:</span>
          </div>

          <div className="grid grid-cols-1 gap-3">
            {/* Tier 1: Clients & UI */}
            <div className="bg-slate-800/80 p-4 rounded-xl border border-slate-700">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-bold text-emerald-400 flex items-center gap-2">
                  <Smartphone className="w-4 h-4" /> 1. طبقة واجهات المستخدم والتطبيقات الـ 7 (Client Apps Layer)
                </span>
                <span className="text-xs bg-slate-700 text-slate-300 px-2 py-0.5 rounded">Flutter & React Mobile-First</span>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
                <div className="p-2 bg-slate-900/60 rounded border border-slate-700 text-slate-200">
                  <div className="font-semibold text-emerald-300">1. تطبيق العميل</div>
                  <div className="text-[10px] text-slate-400">45+ شاشة / P2P و QR وفواتير</div>
                </div>
                <div className="p-2 bg-slate-900/60 rounded border border-slate-700 text-slate-200">
                  <div className="font-semibold text-emerald-300">2. تطبيق المشترك</div>
                  <div className="text-[10px] text-slate-400">60+ شاشة / عائلة ورواتب وبنوك</div>
                </div>
                <div className="p-2 bg-slate-900/60 rounded border border-slate-700 text-slate-200">
                  <div className="font-semibold text-emerald-300">3. تطبيق العائلة المصغر</div>
                  <div className="text-[10px] text-slate-400">20+ شاشة / حدود وموافقة الوصي</div>
                </div>
                <div className="p-2 bg-slate-900/60 rounded border border-slate-700 text-slate-200">
                  <div className="font-semibold text-emerald-300">4. تطبيق الوكيل والصراف</div>
                  <div className="text-[10px] text-slate-400">25+ شاشة / إيداع وسحب وعمولات</div>
                </div>
                <div className="p-2 bg-slate-900/60 rounded border border-slate-700 text-slate-200">
                  <div className="font-semibold text-emerald-300">5. تطبيق التاجر و POS</div>
                  <div className="text-[10px] text-slate-400">20+ شاشة / كاشير و QR وروابط</div>
                </div>
                <div className="p-2 bg-slate-900/60 rounded border border-slate-700 text-slate-200">
                  <div className="font-semibold text-emerald-300">6. لوحة التحكم الإدارية</div>
                  <div className="text-[10px] text-slate-400">عمليات ومستخدمين و AML</div>
                </div>
                <div className="p-2 bg-amber-950/30 rounded border border-amber-800/40 text-slate-200">
                  <div className="font-semibold text-amber-300">7. لوحة المالك السيادية</div>
                  <div className="text-[10px] text-amber-200">God Mode / مخزن الأسرار</div>
                </div>
                <div className="p-2 bg-slate-900/60 rounded border border-slate-700 text-slate-200">
                  <div className="font-semibold text-emerald-300">8. تطبيق الدعم الفني</div>
                  <div className="text-[10px] text-slate-400">15+ شاشة / تذاكر ونزاعات حية</div>
                </div>
              </div>
            </div>

            {/* Tier 2: API Gateway & Security Shield */}
            <div className="bg-slate-800/80 p-4 rounded-xl border border-slate-700">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-bold text-teal-400 flex items-center gap-2">
                  <Shield className="w-4 h-4" /> 2. بوابة الـ API والدفاع السيبراني (Gateway & Security Shield)
                </span>
                <span className="text-xs bg-slate-700 text-slate-300 px-2 py-0.5 rounded">TLS 1.3 / mTLS / WAF</span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs">
                <div className="p-2 bg-slate-900/60 rounded border border-slate-700">
                  <div className="text-slate-200 font-medium">محدد السرعة وحماية الهجمات</div>
                  <div className="text-[10px] text-slate-400">Rate Limiting 100 req/s + DDoS Guard</div>
                </div>
                <div className="p-2 bg-slate-900/60 rounded border border-slate-700">
                  <div className="text-slate-200 font-medium">مخزن الأسرار السيادي (Secrets Vault)</div>
                  <div className="text-[10px] text-slate-400">تشفير AES-256-GCM وتقسيم Shamir</div>
                </div>
                <div className="p-2 bg-slate-900/60 rounded border border-slate-700">
                  <div className="text-slate-200 font-medium">حارس منع الصرف المزدوج</div>
                  <div className="text-[10px] text-slate-400">Idempotency Keys & Distributed Locks</div>
                </div>
              </div>
            </div>

            {/* Tier 3: 22 Microservices */}
            <div className="bg-slate-800/80 p-4 rounded-xl border border-slate-700">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-bold text-amber-400 flex items-center gap-2">
                  <Server className="w-4 h-4" /> 3. مصفوفة الخدمات المصغرة الـ 22 (Microservices Mesh)
                </span>
                <span className="text-xs bg-slate-700 text-slate-300 px-2 py-0.5 rounded">gRPC + Kafka + REST</span>
              </div>
              <p className="text-xs text-slate-400 mb-2">
                22 خدمة مستقلة تتواصل عبر ناقل الأحداث فائق السرعة مع دعم نمط Saga للمعاملات الموزعة.
              </p>
              <div className="flex flex-wrap gap-1.5 text-[11px]">
                {['Auth Service', 'Wallet Core', 'Transaction Engine', 'Family Sub-Wallets', 'Bank & Exchange Gateway', 'Payroll Engine', 'Secrets Vault', 'Auto-Save & WAL', 'AI Self-Dev', 'System Structure', 'Docs & PDF Engine', 'Cards Engine', 'Agent Float', 'Merchant POS', 'AML Shield', 'Immutable Audit', 'Notification Hub', 'Encrypted Files', 'Auto Diagnostics', 'APK Builder', 'Sovereign Override'].map((svc, i) => (
                  <span key={i} className="bg-slate-900 text-slate-300 px-2 py-0.5 rounded border border-slate-700">
                    {svc}
                  </span>
                ))}
              </div>
            </div>

            {/* Tier 4: Storage & Data Engine */}
            <div className="bg-slate-800/80 p-4 rounded-xl border border-slate-700">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-bold text-cyan-400 flex items-center gap-2">
                  <Database className="w-4 h-4" /> 4. طبقة التخزين ودفتر الأستاذ (Persistence & Double-Entry Ledger)
                </span>
                <span className="text-xs bg-slate-700 text-slate-300 px-2 py-0.5 rounded">Zero Data Loss</span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs">
                <div className="p-2 bg-slate-900/60 rounded border border-slate-700">
                  <div className="text-slate-200 font-medium">دفتر الأستاذ المزدوج (Ledger)</div>
                  <div className="text-[10px] text-slate-400">كل حركة تسجل مدين ودائن، لا تعديل يدوي</div>
                </div>
                <div className="p-2 bg-slate-900/60 rounded border border-slate-700">
                  <div className="text-slate-200 font-medium">محرك الـ WAL اللحظي</div>
                  <div className="text-[10px] text-slate-400">كتابة السجل قبل القرص لحماية كل نقرة</div>
                </div>
                <div className="p-2 bg-slate-900/60 rounded border border-slate-700">
                  <div className="text-slate-200 font-medium">النسخ التلقائي كل 5 دقائق</div>
                  <div className="text-[10px] text-slate-400">لقطات Snapshot مشفرة جاهزة للاستعادة</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* VIEW 3: CODE/SERVICES VIEW */}
      {viewMode === 'code' && (
        <div className="space-y-4">
          <div className="p-3 bg-slate-800 rounded-xl border border-slate-700 text-xs text-slate-300">
            ملفات ومكونات البنية البرمجية المتكاملة، موزعة ومجهزة للعمل وفق أفضل الممارسات:
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs font-mono">
            <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
              <div className="text-emerald-400 font-bold mb-2 flex items-center gap-1.5">
                <Code className="w-4 h-4" /> هيكل الواجهات الأمامية (Frontend Apps)
              </div>
              <ul className="space-y-1 text-slate-300">
                <li>📂 /src/components/apps/</li>
                <li className="pl-3 text-emerald-300">├── UserClientApp.tsx (تطبيق العميل - 45+ ميزة)</li>
                <li className="pl-3 text-emerald-300">├── SubscriberApp.tsx (تطبيق المشترك والرواتب)</li>
                <li className="pl-3 text-emerald-300">├── FamilyMiniApp.tsx (تطبيق العائلة والحدود)</li>
                <li className="pl-3 text-emerald-300">├── AgentApp.tsx (تطبيق الوكيل والصناديق)</li>
                <li className="pl-3 text-emerald-300">├── MerchantApp.tsx (تطبيق التاجر و POS)</li>
                <li className="pl-3 text-emerald-300">├── AdminPanel.tsx (لوحة التحكم الإدارية)</li>
                <li className="pl-3 text-amber-300 font-bold">└── SovereignOwnerPanel.tsx (لوحة المالك السيادي)</li>
              </ul>
            </div>

            <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
              <div className="text-teal-400 font-bold mb-2 flex items-center gap-1.5">
                <Server className="w-4 h-4" /> المحركات والخدمات المركزية (Engines)
              </div>
              <ul className="space-y-1 text-slate-300">
                <li>📂 /src/components/modules/</li>
                <li className="pl-3 text-teal-300">├── SecretsVaultView.tsx (مخزن الأسرار المشفر)</li>
                <li className="pl-3 text-teal-300">├── SelfDevEngineView.tsx (محرك التطوير الذاتي)</li>
                <li className="pl-3 text-teal-300">├── DiagnosticsView.tsx (الفحص والإصلاح الفوري)</li>
                <li className="pl-3 text-teal-300">├── BackupAutoSaveView.tsx (الحفظ اللحظي والنسخ 5 دقائق)</li>
                <li className="pl-3 text-teal-300">├── DocumentationEngineView.tsx (الدلائل الـ 12 والـ PDF)</li>
                <li className="pl-3 text-teal-300">└── ApiExplorerView.tsx (واجهات OpenAPI 3.0)</li>
              </ul>
            </div>
          </div>
        </div>
      )}

      {/* VIEW 4: ERD / DATABASE SCHEMA PREVIEW */}
      {viewMode === 'erd' && (
        <div className="space-y-3">
          <div className="flex items-center justify-between p-3 bg-slate-800 rounded-xl border border-slate-700">
            <span className="text-xs text-slate-300">
              مخطط العلاقات وقاعدة البيانات ERD - يدعم أكثر من 50 جدولاً مصرفياً مع القيد المزدوج:
            </span>
            <span className="text-xs text-emerald-400 font-semibold">
              Double-Entry Ledger + WAL Active
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
            <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
              <div className="text-emerald-400 font-bold mb-2">📋 الجداول المالية (Finance)</div>
              <div className="space-y-1 text-slate-300 font-mono">
                <div className="p-1.5 bg-slate-900 rounded">wallets (المحافظ والعملات)</div>
                <div className="p-1.5 bg-emerald-950/60 border border-emerald-800/40 rounded text-emerald-300 font-bold">
                  ledger_entries (دفتر الأستاذ المزدوج)
                </div>
                <div className="p-1.5 bg-slate-900 rounded">transactions (الحركات والتحويلات)</div>
                <div className="p-1.5 bg-slate-900 rounded">transaction_events (أحداث Saga)</div>
                <div className="p-1.5 bg-slate-900 rounded">payrolls (الرواتب الجماعية)</div>
              </div>
            </div>

            <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
              <div className="text-amber-400 font-bold mb-2">👨‍👩‍👧 جداول العائلة والشركاء</div>
              <div className="space-y-1 text-slate-300 font-mono">
                <div className="p-1.5 bg-slate-900 rounded">families (العائلات)</div>
                <div className="p-1.5 bg-slate-900 rounded">family_members (أعضاء العائلة والحدود)</div>
                <div className="p-1.5 bg-slate-900 rounded">family_wallets (المحافظ الفرعية)</div>
                <div className="p-1.5 bg-slate-900 rounded">agents (الوكلاء ونقاط الصرافة)</div>
                <div className="p-1.5 bg-slate-900 rounded">merchants (المتاجر و POS)</div>
              </div>
            </div>

            <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
              <div className="text-cyan-400 font-bold mb-2">🔐 الأمان والسيادة ومخزن الأسرار</div>
              <div className="space-y-1 text-slate-300 font-mono">
                <div className="p-1.5 bg-cyan-950/60 border border-cyan-800/40 rounded text-cyan-300 font-bold">
                  secrets_vault (مخزن الأسرار AES-256)
                </div>
                <div className="p-1.5 bg-slate-900 rounded">audit_logs (السجل غير القابل للتعديل)</div>
                <div className="p-1.5 bg-slate-900 rounded">system_backups (النسخ اللحظي 5 دقائق)</div>
                <div className="p-1.5 bg-slate-900 rounded">dev_requests (طلبات التطوير الذاتي)</div>
                <div className="p-1.5 bg-slate-900 rounded">bank_links (الربط المصرفي)</div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* VIEW 5: FLOW / TRANSACTIONS FLOW */}
      {viewMode === 'flow' && (
        <div className="space-y-4">
          <div className="p-3 bg-slate-850 bg-slate-800/80 rounded-xl border border-slate-700 text-xs text-slate-300">
            مخطط سير العمليات المالية وتطبيق القيد المزدوج وقفل الصرف المزدوج:
          </div>

          <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-4">
            <div className="flex flex-col md:flex-row items-center justify-between gap-3 text-xs">
              <div className="p-3 bg-slate-900 rounded-lg border border-slate-800 text-center w-full">
                <div className="font-bold text-slate-200">1. بدء المعاملة (Initiate)</div>
                <div className="text-[10px] text-slate-400 mt-1">توليد Idempotency Key وفحص الرصيد</div>
              </div>
              <ArrowRight className="w-5 h-5 text-emerald-500 hidden md:block shrink-0 rotate-180" />
              <div className="p-3 bg-slate-900 rounded-lg border border-slate-800 text-center w-full">
                <div className="font-bold text-slate-200">2. قفل المحفظة (Wallet Lock)</div>
                <div className="text-[10px] text-slate-400 mt-1">حجز المبلغ ومنع أي سحب متزامن</div>
              </div>
              <ArrowRight className="w-5 h-5 text-emerald-500 hidden md:block shrink-0 rotate-180" />
              <div className="p-3 bg-slate-900 rounded-lg border border-slate-800 text-center w-full">
                <div className="font-bold text-slate-200">3. كتابة WAL وقيد اليومية</div>
                <div className="text-[10px] text-slate-400 mt-1">مدين للمرسل ودائن للمستلم بالقيمة</div>
              </div>
              <ArrowRight className="w-5 h-5 text-emerald-500 hidden md:block shrink-0 rotate-180" />
              <div className="p-3 bg-emerald-950/70 border border-emerald-700 rounded-lg text-center w-full">
                <div className="font-bold text-emerald-300">4. التسوية اللحظية الفورية</div>
                <div className="text-[10px] text-emerald-400 mt-1">إشعار الطرفين والتنفيذ في أقل من 300ms</div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
