export type AppRole = 
  | 'client' 
  | 'subscriber' 
  | 'family' 
  | 'family_mini'
  | 'agent' 
  | 'merchant' 
  | 'admin' 
  | 'owner' 
  | 'sovereign'
  | 'support';

export type MainNavSection = 
  | 'visualizer' 
  | 'apps' 
  | 'services' 
  | 'database' 
  | 'vault' 
  | 'selfdev' 
  | 'diagnostics' 
  | 'docs' 
  | 'api';

export interface WalletAccount {
  id: string;
  name: string;
  currency: 'YER' | 'SAR' | 'USD';
  symbol: string;
  balance: number;
  holdBalance: number;
  accountNumber: string;
  isDefault?: boolean;
}

export interface WalletServiceNode {
  id: string;
  title: string;
  description: string;
  icon: string;
  category: 'transfer' | 'payment' | 'cards' | 'savings' | 'merchant' | 'settings';
  badge?: string;
  status: 'active' | 'coming_soon' | 'planned';
  subFeatures?: WalletServiceNode[];
}

export interface TransactionRecord {
  id: string;
  refNo: string;
  type: 'P2P' | 'QR_PAY' | 'BILL' | 'CASH_IN' | 'CASH_OUT' | 'PAYROLL' | 'FAMILY_ALLOWANCE';
  title: string;
  amount: number;
  currency: 'YER' | 'SAR' | 'USD';
  fee: number;
  sender: string;
  receiver: string;
  timestamp: string;
  status: 'completed' | 'pending' | 'reversed' | 'failed';
  hash: string;
}

export interface FamilyMemberItem {
  id: string;
  name: string;
  relation: string;
  avatar: string;
  dailyLimit: number;
  spentToday: number;
  monthlyLimit: number;
  balance: number;
  status: 'active' | 'paused';
  requiresApproval: boolean;
}

export interface DevProposal {
  id: string;
  title: string;
  component: string;
  category: 'optimization' | 'security' | 'feature' | 'refactor';
  description: string;
  diffPreview: string;
  impactScore: number;
  status: 'pending_review' | 'owner_approved' | 'rejected' | 'deployed';
  createdAt: string;
}

export interface SecretItem {
  id: string;
  keyName: string;
  algorithm: string;
  maskedValue: string;
  lastRotated: string;
  status: 'active' | 'scheduled_rotation';
  category: 'bank_key' | 'hsm_master' | 'tls_cert' | 'api_gateway';
}

export interface DiagnosticCheckItem {
  id: string;
  category: 'finance' | 'security' | 'database' | 'performance';
  title: string;
  description: string;
  status: 'pass' | 'warning' | 'fail';
  detail: string;
  fixable: boolean;
}
