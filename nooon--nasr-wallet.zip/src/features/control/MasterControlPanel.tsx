// src/features/control/MasterControlPanel.tsx
import React, { useState } from 'react';
import { 
  Sliders, 
  DollarSign, 
  ShieldCheck, 
  Palette, 
  Database, 
  AlertTriangle, 
  RefreshCw, 
  Smartphone, 
  Monitor, 
  Eye, 
  EyeOff, 
  CheckCircle2, 
  Flame, 
  Lock, 
  Unlock, 
  Wifi, 
  Radio, 
  Download, 
  Sparkles, 
  Crown,
  KeyRound,
  Fingerprint,
  RotateCcw,
  Zap,
  Users,
  Coins
} from 'lucide-react';
import { useWallet } from '../../context/WalletContext';
import { CurrencyCode } from '../../types/wallet';

interface Props {
  onClose?: () => void;
  onRequestRoleApp?: (role: string) => void;
}

export const MasterControlPanel: React.FC<Props> = ({ onClose, onRequestRoleApp }) => {
  const {
    wallets,
    activeCurrency,
    setActiveCurrency,
    systemControl,
    updateWalletBalance,
    addQuickFunds,
    updateExchangeRate,
    updateLimits,
    updateFees,
    updateSecurity,
    updateAppearance,
    updateNetwork,
    resetAllToFactoryDefaults,
    generateDemoTransactions,
    createManualBackup,
    showToast
  } = useWallet();

  const [activeTab, setActiveTab] = useState<'financial' | 'appearance' | 'security' | 'system' | 'roles'>('financial');
  const [customBalanceInput, setCustomBalanceInput] = useState<string>('');
  const [pinInput, setPinInput] = useState<string>(systemControl.security.masterPin);

  const selectedWallet = wallets.find(w => w.currency === activeCurrency) || wallets[0];

  const handleApplyCustomBalance = () => {
    const val = parseFloat(customBalanceInput);
    if (!isNaN(val) && val >= 0) {
      updateWalletBalance(activeCurrency, val);
      setCustomBalanceInput('');
    } else {
      showToast('يرجى إدخال مبلغ صحيح', 'error');
    }
  };

  return (
    <div className="w-full bg-slate-950 text-slate-100 rounded-3xl border border-emerald-500/30 shadow-2xl overflow-hidden select-none">
      {/* Top Banner Header */}
      <div className="bg-gradient-to-r from-emerald-950 via-slate-900 to-amber-950/70 p-5 border-b border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-3 rounded-2xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 shadow-lg shadow-emerald-950/50">
            <Sliders className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-lg sm:text-xl font-black text-white">مركز الإعدادات والتحكم السيادي الكامل</h2>
              <span className="bg-amber-500/20 text-amber-300 text-[10px] px-2.5 py-0.5 rounded-full border border-amber-500/30 font-bold">
                GOD MODE & SETTINGS
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              تحكم مطلق بالأرصدة الفورية، أسعار الصرف، سياسات الأمان، المظهر الفاخر، ومحاكي التشغيل
            </p>
          </div>
        </div>

        {/* Global Quick Status Badges */}
        <div className="flex flex-wrap items-center gap-2 text-xs">
          {systemControl.security.emergencyLockdown ? (
            <div className="px-3 py-1 rounded-xl bg-red-950/80 border border-red-500/60 text-red-300 flex items-center gap-1.5 font-bold animate-pulse">
              <AlertTriangle className="w-3.5 h-3.5" />
              <span>قفل الطوارئ نشط</span>
            </div>
          ) : (
            <div className="px-3 py-1 rounded-xl bg-emerald-950/60 border border-emerald-500/40 text-emerald-300 flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>المنظومة آمنة وتعمل بكفاءة</span>
            </div>
          )}

          <div className="px-2.5 py-1 rounded-xl bg-slate-900 border border-slate-800 text-slate-300 font-mono text-[11px] flex items-center gap-1">
            <Radio className="w-3 h-3 text-cyan-400" />
            <span>شبكة {systemControl.network.simulatedSpeed.toUpperCase()}</span>
          </div>

          {onClose && (
            <button
              onClick={onClose}
              className="px-3 py-1 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold transition-all"
            >
              إغلاق
            </button>
          )}
        </div>
      </div>

      {/* Internal Navigation Tabs */}
      <div className="flex items-center gap-1 px-4 pt-3 border-b border-slate-800/80 overflow-x-auto bg-slate-900/50">
        <button
          onClick={() => setActiveTab('financial')}
          className={`px-4 py-2.5 rounded-t-2xl font-bold text-xs transition-all flex items-center gap-2 whitespace-nowrap ${
            activeTab === 'financial'
              ? 'bg-slate-950 text-emerald-400 border-t-2 border-x border-slate-800 border-t-emerald-500 shadow-sm'
              : 'text-slate-400 hover:text-white hover:bg-slate-900'
          }`}
        >
          <Coins className="w-4 h-4" />
          <span>1. الأرصدة والأسعار والعمولات</span>
        </button>

        <button
          onClick={() => setActiveTab('appearance')}
          className={`px-4 py-2.5 rounded-t-2xl font-bold text-xs transition-all flex items-center gap-2 whitespace-nowrap ${
            activeTab === 'appearance'
              ? 'bg-slate-950 text-emerald-400 border-t-2 border-x border-slate-800 border-t-emerald-500 shadow-sm'
              : 'text-slate-400 hover:text-white hover:bg-slate-900'
          }`}
        >
          <Palette className="w-4 h-4" />
          <span>2. المظهر والواجهات والعرض</span>
        </button>

        <button
          onClick={() => setActiveTab('security')}
          className={`px-4 py-2.5 rounded-t-2xl font-bold text-xs transition-all flex items-center gap-2 whitespace-nowrap ${
            activeTab === 'security'
              ? 'bg-slate-950 text-emerald-400 border-t-2 border-x border-slate-800 border-t-emerald-500 shadow-sm'
              : 'text-slate-400 hover:text-white hover:bg-slate-900'
          }`}
        >
          <ShieldCheck className="w-4 h-4" />
          <span>3. الأمان وقفل الطوارئ والـ PIN</span>
        </button>

        <button
          onClick={() => setActiveTab('system')}
          className={`px-4 py-2.5 rounded-t-2xl font-bold text-xs transition-all flex items-center gap-2 whitespace-nowrap ${
            activeTab === 'system'
              ? 'bg-slate-950 text-emerald-400 border-t-2 border-x border-slate-800 border-t-emerald-500 shadow-sm'
              : 'text-slate-400 hover:text-white hover:bg-slate-900'
          }`}
        >
          <Database className="w-4 h-4" />
          <span>4. الذاكرة والبيانات والمحاكي</span>
        </button>

        <button
          onClick={() => setActiveTab('roles')}
          className={`px-4 py-2.5 rounded-t-2xl font-bold text-xs transition-all flex items-center gap-2 whitespace-nowrap ${
            activeTab === 'roles'
              ? 'bg-slate-950 text-emerald-400 border-t-2 border-x border-slate-800 border-t-emerald-500 shadow-sm'
              : 'text-slate-400 hover:text-white hover:bg-slate-900'
          }`}
        >
          <Users className="w-4 h-4" />
          <span>5. التبديل بين الأدوار الـ 7</span>
        </button>
      </div>

      {/* Panel Content Body */}
      <div className="p-5 sm:p-6 space-y-6">
        {/* TAB 1: FINANCIAL & BALANCES */}
        {activeTab === 'financial' && (
          <div className="space-y-6">
            {/* Live Balance Tuner Box */}
            <div className="p-5 rounded-3xl bg-slate-900/90 border border-slate-800 space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div>
                  <h3 className="text-sm font-bold text-white flex items-center gap-2">
                    <DollarSign className="w-4 h-4 text-emerald-400" />
                    <span>تعديل وتغذية رصيد المحفظة فورياً (Live Balance Injection)</span>
                  </h3>
                  <p className="text-xs text-slate-400 mt-0.5">
                    اختر العملة وقم بتعديل الرصيد مباشرة لتجربة العمليات الكبرى أو إعادة التعيين
                  </p>
                </div>

                {/* Currency Switcher */}
                <div className="flex bg-slate-950 p-1 rounded-2xl border border-slate-800">
                  {(['YER', 'SAR', 'USD', 'EUR'] as CurrencyCode[]).map((curr) => (
                    <button
                      key={curr}
                      onClick={() => setActiveCurrency(curr)}
                      className={`px-3 py-1 rounded-xl text-xs font-mono font-bold transition-all ${
                        activeCurrency === curr
                          ? 'bg-emerald-600 text-white shadow-md'
                          : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      {curr}
                    </button>
                  ))}
                </div>
              </div>

              {/* Current Active Currency Stat Card */}
              <div className="p-4 rounded-2xl bg-slate-950 border border-emerald-500/20 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <span className="text-xs text-slate-400">الرصيد الحالي لعملة ({activeCurrency}):</span>
                  <div className="text-2xl sm:text-3xl font-black text-emerald-400 font-mono mt-0.5">
                    {selectedWallet ? selectedWallet.balance.toLocaleString() : '0'}{' '}
                    <span className="text-sm text-slate-400 font-normal">{selectedWallet?.symbol}</span>
                  </div>
                </div>

                {/* Quick Add Fund Chips */}
                <div className="flex flex-wrap gap-1.5">
                  <button
                    onClick={() => addQuickFunds(activeCurrency, activeCurrency === 'YER' ? 50000 : 100)}
                    className="px-3 py-1.5 rounded-xl bg-emerald-950 text-emerald-300 border border-emerald-600/40 hover:bg-emerald-600 hover:text-white text-xs font-bold transition-all"
                  >
                    +{activeCurrency === 'YER' ? '50,000' : '100'} {selectedWallet?.symbol}
                  </button>
                  <button
                    onClick={() => addQuickFunds(activeCurrency, activeCurrency === 'YER' ? 250000 : 500)}
                    className="px-3 py-1.5 rounded-xl bg-emerald-950 text-emerald-300 border border-emerald-600/40 hover:bg-emerald-600 hover:text-white text-xs font-bold transition-all"
                  >
                    +{activeCurrency === 'YER' ? '250,000' : '500'} {selectedWallet?.symbol}
                  </button>
                  <button
                    onClick={() => addQuickFunds(activeCurrency, activeCurrency === 'YER' ? 1000000 : 2000)}
                    className="px-3 py-1.5 rounded-xl bg-amber-950/80 text-amber-300 border border-amber-600/40 hover:bg-amber-600 hover:text-slate-950 text-xs font-bold transition-all"
                  >
                    +{activeCurrency === 'YER' ? '1,000,000' : '2,000'} {selectedWallet?.symbol}
                  </button>
                </div>
              </div>

              {/* Exact Balance Input */}
              <div className="flex gap-2">
                <input
                  type="number"
                  value={customBalanceInput}
                  onChange={(e) => setCustomBalanceInput(e.target.value)}
                  placeholder={`اكتب المبلغ المطلوب لتثبيت رصيد الـ ${activeCurrency} مباشرة...`}
                  className="flex-1 bg-slate-950 border border-slate-700 rounded-2xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-emerald-500 font-mono"
                />
                <button
                  onClick={handleApplyCustomBalance}
                  className="px-5 py-2.5 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-all shadow-md shrink-0 cursor-pointer"
                >
                  تثبيت الرصيد
                </button>
              </div>
            </div>

            {/* Exchange Rates Customizer */}
            <div className="p-5 rounded-3xl bg-slate-900/90 border border-slate-800 space-y-4">
              <div>
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <Zap className="w-4 h-4 text-amber-400" />
                  <span>محرك أسعار الصرف الحية (Live Currency Exchange Rates)</span>
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  تعديل أسعار التحويل بين العملات مع إعادة احتساب لحظية في سائر المعاملات
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                {/* USD -> YER */}
                <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
                  <div className="flex justify-between items-center text-xs">
                    <span className="text-slate-300 font-bold">دولار مقابل ريال يمني (USD/YER)</span>
                    <span className="font-mono text-emerald-400 font-bold">{systemControl.exchangeRates.USD_YER} ر.ي</span>
                  </div>
                  <input
                    type="range"
                    min={1200}
                    max={2000}
                    step={10}
                    value={systemControl.exchangeRates.USD_YER}
                    onChange={(e) => updateExchangeRate('USD_YER', parseFloat(e.target.value))}
                    className="w-full accent-emerald-500 cursor-pointer"
                  />
                  <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                    <span>1,200</span>
                    <span>1,650 (افتراضي)</span>
                    <span>2,000</span>
                  </div>
                </div>

                {/* SAR -> YER */}
                <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
                  <div className="flex justify-between items-center text-xs">
                    <span className="text-slate-300 font-bold">ريال سعودي مقابل يمني (SAR/YER)</span>
                    <span className="font-mono text-amber-400 font-bold">{systemControl.exchangeRates.SAR_YER} ر.ي</span>
                  </div>
                  <input
                    type="range"
                    min={300}
                    max={600}
                    step={5}
                    value={systemControl.exchangeRates.SAR_YER}
                    onChange={(e) => updateExchangeRate('SAR_YER', parseFloat(e.target.value))}
                    className="w-full accent-amber-500 cursor-pointer"
                  />
                  <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                    <span>300</span>
                    <span>435 (افتراضي)</span>
                    <span>600</span>
                  </div>
                </div>

                {/* EUR -> USD */}
                <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
                  <div className="flex justify-between items-center text-xs">
                    <span className="text-slate-300 font-bold">يورو مقابل دولار (EUR/USD)</span>
                    <span className="font-mono text-cyan-400 font-bold">{systemControl.exchangeRates.EUR_USD} $</span>
                  </div>
                  <input
                    type="range"
                    min={0.9}
                    max={1.3}
                    step={0.01}
                    value={systemControl.exchangeRates.EUR_USD}
                    onChange={(e) => updateExchangeRate('EUR_USD', parseFloat(e.target.value))}
                    className="w-full accent-cyan-500 cursor-pointer"
                  />
                  <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                    <span>0.90</span>
                    <span>1.08</span>
                    <span>1.30</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Limits & Fees Section */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Transfer Limits */}
              <div className="p-5 rounded-3xl bg-slate-900/90 border border-slate-800 space-y-3">
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-cyan-400" />
                  <span>سقوف وحدود المعاملات المالية (YER)</span>
                </h3>
                <div className="space-y-2.5 text-xs">
                  <div>
                    <div className="flex justify-between mb-1">
                      <span className="text-slate-400">سقف العملية الواحدة:</span>
                      <span className="font-mono font-bold text-white">{systemControl.limits.singleTxLimitYER.toLocaleString()} ر.ي</span>
                    </div>
                    <input
                      type="range"
                      min={100000}
                      max={10000000}
                      step={100000}
                      value={systemControl.limits.singleTxLimitYER}
                      onChange={(e) => updateLimits({ singleTxLimitYER: parseFloat(e.target.value) })}
                      className="w-full accent-cyan-500 cursor-pointer"
                    />
                  </div>

                  <div>
                    <div className="flex justify-between mb-1">
                      <span className="text-slate-400">السقف اليومي الإجمالي:</span>
                      <span className="font-mono font-bold text-white">{systemControl.limits.dailyLimitYER.toLocaleString()} ر.ي</span>
                    </div>
                    <input
                      type="range"
                      min={500000}
                      max={20000000}
                      step={500000}
                      value={systemControl.limits.dailyLimitYER}
                      onChange={(e) => updateLimits({ dailyLimitYER: parseFloat(e.target.value) })}
                      className="w-full accent-emerald-500 cursor-pointer"
                    />
                  </div>
                </div>
              </div>

              {/* Commission & Fees */}
              <div className="p-5 rounded-3xl bg-slate-900/90 border border-slate-800 space-y-3">
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <Coins className="w-4 h-4 text-amber-400" />
                  <span>سياسة العمولات والرسوم</span>
                </h3>
                <div className="space-y-3 text-xs">
                  <div className="flex items-center justify-between p-3 rounded-2xl bg-slate-950 border border-slate-800">
                    <div>
                      <div className="font-bold text-white">التحويل المجاني السيادي (0% رسوم)</div>
                      <div className="text-[11px] text-slate-400">إعفاء كامل للمستخدمين من رسوم التحويل P2P</div>
                    </div>
                    <button
                      onClick={() => updateFees({ isFeeFree: !systemControl.fees.isFeeFree })}
                      className={`px-3 py-1.5 rounded-xl font-bold transition-all ${
                        systemControl.fees.isFeeFree
                          ? 'bg-emerald-600 text-white'
                          : 'bg-slate-800 text-slate-400'
                      }`}
                    >
                      {systemControl.fees.isFeeFree ? 'مفعّل (0%)' : 'معطّل'}
                    </button>
                  </div>

                  {!systemControl.fees.isFeeFree && (
                    <div>
                      <div className="flex justify-between mb-1">
                        <span className="text-slate-400">نسبة العمولة على التحويلات:</span>
                        <span className="font-mono font-bold text-white">{systemControl.fees.p2pFeePercent}%</span>
                      </div>
                      <input
                        type="range"
                        min={0.1}
                        max={3}
                        step={0.1}
                        value={systemControl.fees.p2pFeePercent}
                        onChange={(e) => updateFees({ p2pFeePercent: parseFloat(e.target.value) })}
                        className="w-full accent-amber-500 cursor-pointer"
                      />
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: APPEARANCE & DISPLAY MODES */}
        {activeTab === 'appearance' && (
          <div className="space-y-6">
            {/* Display Layout Modes */}
            <div className="p-5 rounded-3xl bg-slate-900/90 border border-slate-800 space-y-4">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Monitor className="w-4 h-4 text-emerald-400" />
                <span>وضع شاشة العرض (View Mode)</span>
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <button
                  onClick={() => updateAppearance({ viewMode: 'mobile' })}
                  className={`p-4 rounded-2xl border text-right transition-all flex items-start gap-3 ${
                    systemControl.appearance.viewMode === 'mobile'
                      ? 'bg-emerald-950/40 border-emerald-500 text-white shadow-lg'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  <Smartphone className="w-6 h-6 text-emerald-400 shrink-0 mt-0.5" />
                  <div>
                    <div className="text-sm font-bold text-white">إطار الهاتف الذكي التفاعلي (Mobile View)</div>
                    <div className="text-xs text-slate-400 mt-1">
                      محاكاة دقيقة وتجربة حية كأنك تحمل هاتفاً حقيقياً في يدك مع شريط الأزرار السفلي
                    </div>
                  </div>
                </button>

                <button
                  onClick={() => updateAppearance({ viewMode: 'desktop' })}
                  className={`p-4 rounded-2xl border text-right transition-all flex items-start gap-3 ${
                    systemControl.appearance.viewMode === 'desktop'
                      ? 'bg-emerald-950/40 border-emerald-500 text-white shadow-lg'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  <Monitor className="w-6 h-6 text-emerald-400 shrink-0 mt-0.5" />
                  <div>
                    <div className="text-sm font-bold text-white">وضع الشاشة الموسعة للمحترفين (Expanded Desktop)</div>
                    <div className="text-xs text-slate-400 mt-1">
                      واجهة كاملة فائقة الدقة والاتساع تستغل كامل شاشة سطح المكتب مع جداول تفصيلية
                    </div>
                  </div>
                </button>
              </div>
            </div>

            {/* Luxury Color Themes */}
            <div className="p-5 rounded-3xl bg-slate-900/90 border border-slate-800 space-y-4">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Palette className="w-4 h-4 text-amber-400" />
                <span>سمات الألوان الفاخرة (Color Themes)</span>
              </h3>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
                {[
                  { id: 'emerald', label: 'الزمرد السيادي', color: 'from-emerald-600 to-teal-800', desc: 'Sovereign Emerald' },
                  { id: 'gold', label: 'الذهب الملكي', color: 'from-amber-500 to-yellow-700', desc: 'Royal Gold' },
                  { id: 'cyber', label: 'التيتانيوم الليلي', color: 'from-blue-600 to-slate-900', desc: 'Cyber Titanium' },
                  { id: 'light', label: 'النهاري الناصع', color: 'from-slate-200 to-slate-400', desc: 'Crisp Luxury Light' },
                ].map((th) => (
                  <button
                    key={th.id}
                    onClick={() => updateAppearance({ themePreset: th.id as 'emerald' | 'gold' | 'cyber' | 'light' })}
                    className={`p-3.5 rounded-2xl border transition-all flex flex-col items-center gap-2 cursor-pointer ${
                      systemControl.appearance.themePreset === th.id
                        ? 'bg-slate-800 border-emerald-500 shadow-lg ring-1 ring-emerald-500'
                        : 'bg-slate-950 border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    <div className={`w-8 h-8 rounded-full bg-gradient-to-tr ${th.color} shadow-md`} />
                    <div className="text-xs font-bold text-white">{th.label}</div>
                    <div className="text-[10px] text-slate-400 font-mono">{th.desc}</div>
                  </button>
                ))}
              </div>
            </div>

            {/* Privacy and Density Toggles */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-xl bg-slate-950 text-slate-300">
                    {systemControl.appearance.hideBalances ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </div>
                  <div>
                    <div className="text-xs font-bold text-white">نمط الخصوصية (تعتيم الأرصدة)</div>
                    <div className="text-[11px] text-slate-400">إخفاء الأرقام في الأماكن العامة</div>
                  </div>
                </div>
                <button
                  onClick={() => updateAppearance({ hideBalances: !systemControl.appearance.hideBalances })}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                    systemControl.appearance.hideBalances ? 'bg-amber-600 text-slate-950' : 'bg-slate-800 text-slate-300'
                  }`}
                >
                  {systemControl.appearance.hideBalances ? 'مخفية' : 'ظاهرة'}
                </button>
              </div>

              <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-xl bg-slate-950 text-slate-300">
                    <Sparkles className="w-4 h-4 text-cyan-400" />
                  </div>
                  <div>
                    <div className="text-xs font-bold text-white">كثافة العناصر (Density)</div>
                    <div className="text-[11px] text-slate-400">مريح للمطالعة أو مدمج للمحترفين</div>
                  </div>
                </div>
                <button
                  onClick={() =>
                    updateAppearance({
                      density: systemControl.appearance.density === 'comfortable' ? 'compact' : 'comfortable'
                    })
                  }
                  className="px-3 py-1.5 rounded-xl bg-slate-800 text-xs font-bold text-white hover:bg-slate-700"
                >
                  {systemControl.appearance.density === 'comfortable' ? 'مريح (Spacious)' : 'مكثف (Compact)'}
                </button>
              </div>
            </div>
          </div>
        )}

        {/* TAB 3: SECURITY, PIN & EMERGENCY */}
        {activeTab === 'security' && (
          <div className="space-y-6">
            {/* Big Emergency Sovereign Lockdown Banner */}
            <div className={`p-6 rounded-3xl border transition-all ${
              systemControl.security.emergencyLockdown 
                ? 'bg-red-950/90 border-red-500 shadow-2xl shadow-red-950/80' 
                : 'bg-slate-900 border-slate-800'
            }`}>
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="flex items-center gap-3.5">
                  <div className={`p-3 rounded-2xl ${
                    systemControl.security.emergencyLockdown ? 'bg-red-500 text-white animate-bounce' : 'bg-slate-950 text-red-400'
                  }`}>
                    <Flame className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="text-base font-black text-white">
                      قفل الطوارئ السيادي الشامل (Emergency Sovereign Freeze)
                    </h3>
                    <p className="text-xs text-slate-300 mt-1 max-w-xl">
                      تجميد فوري وشامل لجميع العمليات المالية والسحب والتحويل عبر كافة الحسابات والوكلاء لحماية السيولة ومواجهة التهديدات.
                    </p>
                  </div>
                </div>

                <button
                  onClick={() => updateSecurity({ emergencyLockdown: !systemControl.security.emergencyLockdown })}
                  className={`px-6 py-3 rounded-2xl font-black text-xs transition-all shadow-xl cursor-pointer ${
                    systemControl.security.emergencyLockdown
                      ? 'bg-emerald-600 hover:bg-emerald-500 text-white'
                      : 'bg-red-600 hover:bg-red-500 text-white'
                  }`}
                >
                  {systemControl.security.emergencyLockdown ? 'إلغاء قفل الطوارئ واستئناف المنظومة' : 'تفعيل قفل الطوارئ فورياً'}
                </button>
              </div>
            </div>

            {/* PIN Settings & Fast Testing Mode */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Bypass PIN Switch */}
              <div className="p-5 rounded-3xl bg-slate-900/90 border border-slate-800 space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-sm font-bold text-white">
                    <KeyRound className="w-4 h-4 text-emerald-400" />
                    <span>نمط الاختبار السريع (تجاوز PIN)</span>
                  </div>
                  <button
                    onClick={() => updateSecurity({ bypassPin: !systemControl.security.bypassPin })}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                      systemControl.security.bypassPin ? 'bg-emerald-600 text-white' : 'bg-slate-800 text-slate-400'
                    }`}
                  >
                    {systemControl.security.bypassPin ? 'مفعّل (بدون PIN)' : 'معطّل (طلب PIN)'}
                  </button>
                </div>
                <p className="text-xs text-slate-400">
                  يتيح لك تجربة التحويلات وسداد الفواتير فورياً بنقرة واحدة لتسهيل الفحص دون الحاجة لكتابة رمز السري في كل خطوة.
                </p>
              </div>

              {/* Master PIN Customizer */}
              <div className="p-5 rounded-3xl bg-slate-900/90 border border-slate-800 space-y-2">
                <div className="text-sm font-bold text-white flex items-center gap-2">
                  <Lock className="w-4 h-4 text-amber-400" />
                  <span>رمز PIN السيادي الماستر</span>
                </div>
                <div className="flex gap-2">
                  <input
                    type="password"
                    maxLength={4}
                    value={pinInput}
                    onChange={(e) => setPinInput(e.target.value)}
                    className="w-32 bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-center text-sm font-mono tracking-widest text-white focus:outline-none focus:border-emerald-500"
                  />
                  <button
                    onClick={() => {
                      if (pinInput.length === 4) {
                        updateSecurity({ masterPin: pinInput });
                      } else {
                        showToast('يجب أن يتكون رمز PIN من 4 أرقام', 'error');
                      }
                    }}
                    className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-emerald-600 text-white text-xs font-bold transition-all"
                  >
                    حفظ الرمز
                  </button>
                </div>
                <p className="text-[11px] text-slate-500">الرمز الافتراضي الحالي: {systemControl.security.masterPin}</p>
              </div>
            </div>

            {/* AML & Biometrics */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="p-5 rounded-3xl bg-slate-900/90 border border-slate-800 space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-sm font-bold text-white">
                    <Fingerprint className="w-4 h-4 text-cyan-400" />
                    <span>المصادقة البايومترية (Face ID / البصمة)</span>
                  </div>
                  <button
                    onClick={() => updateSecurity({ biometricAuth: !systemControl.security.biometricAuth })}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                      systemControl.security.biometricAuth ? 'bg-cyan-600 text-white' : 'bg-slate-800 text-slate-400'
                    }`}
                  >
                    {systemControl.security.biometricAuth ? 'مفعّلة' : 'معطّلة'}
                  </button>
                </div>
                <p className="text-xs text-slate-400">تتيح تسجيل الدخول السريع وتأكيد العمليات بلمسة واحدة</p>
              </div>

              <div className="p-5 rounded-3xl bg-slate-900/90 border border-slate-800 space-y-2">
                <div className="text-sm font-bold text-white flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-indigo-400" />
                  <span>حساسية فحص مكافحة غسيل الأموال (AML Sensitivity)</span>
                </div>
                <div className="flex gap-2 text-xs">
                  {(['low', 'medium', 'strict'] as const).map((lvl) => (
                    <button
                      key={lvl}
                      onClick={() => updateSecurity({ amlSensitivity: lvl })}
                      className={`flex-1 py-1.5 rounded-xl font-bold transition-all ${
                        systemControl.security.amlSensitivity === lvl
                          ? 'bg-indigo-600 text-white'
                          : 'bg-slate-950 text-slate-400 hover:text-white'
                      }`}
                    >
                      {lvl === 'low' ? 'مرن (Low)' : lvl === 'medium' ? 'قياسي (Medium)' : 'مشدد (Strict)'}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 4: SYSTEM DATA, MEMORY & NETWORK SIMULATOR */}
        {activeTab === 'system' && (
          <div className="space-y-6">
            {/* Network Latency Simulator */}
            <div className="p-5 rounded-3xl bg-slate-900/90 border border-slate-800 space-y-3">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Wifi className="w-4 h-4 text-cyan-400" />
                <span>محاكي جودة وسرعة الاتصال (Network Simulation)</span>
              </h3>
              <div className="grid grid-cols-3 gap-2.5 text-center text-xs">
                {[
                  { id: '5g', label: 'اتصال فائق 5G', latency: 80, desc: 'استجابة فائقة السرعة' },
                  { id: '3g', label: 'شبكة 3G بطيئة', latency: 650, desc: 'اختبار مؤشرات التحميل' },
                  { id: 'offline', label: 'نمط بدون إنترنت', latency: 0, desc: 'اختبار التخزين المحلي WAL' },
                ].map((item) => (
                  <button
                    key={item.id}
                    onClick={() => updateNetwork({ simulatedSpeed: item.id as '5g' | '3g' | 'offline', latencyMs: item.latency })}
                    className={`p-3 rounded-2xl border transition-all ${
                      systemControl.network.simulatedSpeed === item.id
                        ? 'bg-cyan-950/60 border-cyan-500 text-cyan-300 font-bold'
                        : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    <div className="font-bold text-white">{item.label}</div>
                    <div className="text-[10px] text-slate-400 mt-1">{item.desc}</div>
                  </button>
                ))}
              </div>
            </div>

            {/* Quick Generator & Data Reset Operations */}
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3">
              {/* Generate Demo Tx */}
              <button
                onClick={generateDemoTransactions}
                className="p-4 rounded-2xl bg-slate-900 border border-slate-800 hover:border-emerald-500 transition-all text-right group cursor-pointer"
              >
                <div className="p-2.5 rounded-xl bg-emerald-950 text-emerald-400 w-fit mb-2 group-hover:scale-105 transition-transform">
                  <Sparkles className="w-4 h-4" />
                </div>
                <div className="text-xs font-bold text-white">توليد 3 حركات تجريبية</div>
                <div className="text-[10px] text-slate-400 mt-0.5">شراء، حوالة واردة، وسداد فاتورة</div>
              </button>

              {/* Manual Backup Download */}
              <button
                onClick={createManualBackup}
                className="p-4 rounded-2xl bg-slate-900 border border-slate-800 hover:border-cyan-500 transition-all text-right group cursor-pointer"
              >
                <div className="p-2.5 rounded-xl bg-cyan-950 text-cyan-400 w-fit mb-2 group-hover:scale-105 transition-transform">
                  <Download className="w-4 h-4" />
                </div>
                <div className="text-xs font-bold text-white">تصدير نسخة احتياطية</div>
                <div className="text-[10px] text-slate-400 mt-0.5">تنزيل ملف JSON مشفر للبيانات</div>
              </button>

              {/* Factory Reset */}
              <button
                onClick={() => {
                  if (window.confirm('هل أنت متأكد من استعادة الحالة المصنعية الافتراضية للمنظومة؟')) {
                    resetAllToFactoryDefaults();
                  }
                }}
                className="p-4 rounded-2xl bg-slate-900 border border-slate-800 hover:border-amber-500 transition-all text-right group cursor-pointer"
              >
                <div className="p-2.5 rounded-xl bg-amber-950 text-amber-400 w-fit mb-2 group-hover:scale-105 transition-transform">
                  <RotateCcw className="w-4 h-4" />
                </div>
                <div className="text-xs font-bold text-white">استعادة ضبط المصنع</div>
                <div className="text-[10px] text-slate-400 mt-0.5">إعادة ضبط الأرصدة والبيانات للأصل</div>
              </button>

              {/* Clear Cache */}
              <button
                onClick={() => {
                  showToast('تم تفريغ الذاكرة المؤقتة بنجاح', 'success');
                }}
                className="p-4 rounded-2xl bg-slate-900 border border-slate-800 hover:border-indigo-500 transition-all text-right group cursor-pointer"
              >
                <div className="p-2.5 rounded-xl bg-indigo-950 text-indigo-400 w-fit mb-2 group-hover:scale-105 transition-transform">
                  <RefreshCw className="w-4 h-4" />
                </div>
                <div className="text-xs font-bold text-white">تفريغ الكاش المؤقت</div>
                <div className="text-[10px] text-slate-400 mt-0.5">تحديث الجلسة وإعادة المزامنة</div>
              </button>
            </div>
          </div>
        )}

        {/* TAB 5: INSTANT MULTI-ROLE SWITCHER */}
        {activeTab === 'roles' && (
          <div className="space-y-4">
            <div>
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Users className="w-4 h-4 text-emerald-400" />
                <span>التبديل الفوري بين تطبيقات الأدوار الميدانية الـ 7</span>
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                انتقل فورياً لتجربة أي دور في المنظومة المالية بصلاحياته الكاملة
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
              {[
                { role: 'client', name: 'تطبيق العميل الأساسي (Client)', desc: 'تحويل P2P، مسح QR، شحن بطاقات وسداد فواتير', color: 'emerald' },
                { role: 'subscriber', name: 'تطبيق المشترك ورب الأسرة (Subscriber)', desc: 'إدارة أفراد العائلة والرواتب والمصروفات', color: 'blue' },
                { role: 'family_mini', name: 'محفظة التابع / الابن (Family Mini)', desc: 'مصروفات مقيدة وإشراف أبوي مباشر', color: 'teal' },
                { role: 'agent', name: 'تطبيق الوكيل والصراف (Agent)', desc: 'إيداع نقدي Cash-In وسحب Cash-Out وعمولات', color: 'amber' },
                { role: 'merchant', name: 'تطبيق التاجر ونقاط البيع (Merchant POS)', desc: 'كاشير فوري، إنشاء فواتير، وكود QR', color: 'cyan' },
                { role: 'admin', name: 'لوحة إدارة العمليات (Admin Panel)', desc: 'مراجعة طلبات التوثيق KYC وتنبيهات AML', color: 'indigo' },
                { role: 'sovereign', name: 'لوحة التحكم السيادية للمالك (God Mode)', desc: 'التحكم المطلق ومفاتيح التشفير وقفل الطوارئ', color: 'yellow' },
              ].map((item) => (
                <button
                  key={item.role}
                  onClick={() => {
                    if (onRequestRoleApp) {
                      onRequestRoleApp(item.role);
                    }
                    if (onClose) onClose();
                  }}
                  className="p-4 rounded-2xl bg-slate-900 border border-slate-800 hover:border-emerald-500 text-right transition-all flex flex-col justify-between group active:scale-[0.98] cursor-pointer"
                >
                  <div>
                    <div className="text-xs font-bold text-white group-hover:text-emerald-300 transition-colors">
                      {item.name}
                    </div>
                    <div className="text-[11px] text-slate-400 mt-1">{item.desc}</div>
                  </div>
                  <div className="mt-3 text-[10px] text-emerald-400 font-bold flex items-center gap-1">
                    <span>فتح هذا التطبيق ←</span>
                  </div>
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
