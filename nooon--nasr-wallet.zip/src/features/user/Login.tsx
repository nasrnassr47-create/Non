// src/features/user/Login.tsx
import React, { useState } from 'react';
import { Phone, Lock, ArrowLeft, ShieldCheck, Fingerprint } from 'lucide-react';
import { Button } from '../../components/ui/Button';
import { Input } from '../../components/ui/Input';
import { useAuth } from '../../context/AuthContext';
import { useWallet } from '../../context/WalletContext';

interface Props {
  onSuccess: () => void;
  onNavigateRegister: () => void;
  onForgotPassword?: () => void;
}

export const Login: React.FC<Props> = ({ onSuccess, onNavigateRegister, onForgotPassword }) => {
  const { login } = useAuth();
  const { showToast } = useWallet();
  const [phone, setPhone] = useState('777100249');
  const [pin, setPin] = useState('1234');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await login(phone, pin);
      showToast(res.message, 'success');
      onSuccess();
    } catch {
      showToast('خطأ في تسجيل الدخول', 'error');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-[580px] p-6 bg-slate-950 text-slate-100 flex flex-col justify-between">
      <div className="space-y-6">
        <div>
          <span className="text-[11px] font-mono text-emerald-400 bg-emerald-950 px-2 py-0.5 rounded-md border border-emerald-800/40">
            دخول آمن
          </span>
          <h2 className="text-2xl font-bold text-white mt-2">تسجيل الدخول</h2>
          <p className="text-xs text-slate-400 mt-1">أدخل رقم الهاتف ورمز المرور السري للدخول إلى محفظتك</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <Input
            label="رقم الهاتف (يمن موبايل / سبأفون / يو)"
            type="tel"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            placeholder="770000000"
            prefixIcon={<Phone className="w-4 h-4" />}
            required
          />

          <Input
            label="رمز المرور أو PIN السري (4-6 أرقام)"
            type="password"
            value={pin}
            onChange={(e) => setPin(e.target.value)}
            placeholder="••••"
            prefixIcon={<Lock className="w-4 h-4" />}
            required
          />

          <div className="flex justify-between items-center text-xs">
            <button
              type="button"
              onClick={() => {
                setPhone('777100249');
                setPin('1234');
              }}
              className="text-emerald-400 hover:underline"
            >
              استخدام بيانات تجريبية جاهزة
            </button>
            {onForgotPassword && (
              <button
                type="button"
                onClick={onForgotPassword}
                className="text-slate-400 hover:text-slate-200"
              >
                نسيت الرمز؟
              </button>
            )}
          </div>

          <Button
            type="submit"
            variant="primary"
            size="lg"
            className="w-full"
            isLoading={loading}
            icon={<ArrowLeft className="w-4 h-4" />}
            iconPosition="left"
          >
            دخول فوري للمحفظة
          </Button>

          <Button
            type="button"
            variant="secondary"
            size="md"
            className="w-full"
            icon={<Fingerprint className="w-4 h-4 text-emerald-400" />}
            onClick={() => {
              login('777100249', '1234');
              showToast('تم التحقق البايومتري بنجاح', 'success');
              onSuccess();
            }}
          >
            تسجيل الدخول بالبصمة / Face ID
          </Button>
        </form>
      </div>

      <div className="text-center pt-4 border-t border-slate-900 text-xs text-slate-400">
        ليس لديك حساب بعد؟{' '}
        <button
          onClick={onNavigateRegister}
          className="text-emerald-400 font-bold hover:underline ml-1"
        >
          إنشاء حساب جديد
        </button>
      </div>
    </div>
  );
};
