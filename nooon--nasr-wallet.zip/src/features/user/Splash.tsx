// src/features/user/Splash.tsx
import React, { useEffect } from 'react';
import { Logo } from '../../components/Logo';
import { Sparkles } from 'lucide-react';

interface Props {
  onFinish?: () => void;
}

export const Splash: React.FC<Props> = ({ onFinish }) => {
  return (
    <div className="min-h-[580px] flex flex-col items-center justify-between p-8 bg-gradient-to-b from-slate-950 via-slate-900 to-emerald-950 text-white select-none">
      <div className="w-full flex justify-end">
        <span className="text-[10px] font-mono text-emerald-400 border border-emerald-500/30 px-2 py-0.5 rounded-full bg-emerald-950/60">
          V2.0 السيادية
        </span>
      </div>

      <div className="flex flex-col items-center text-center space-y-4 my-auto">
        <div className="relative">
          <div className="absolute -inset-4 bg-emerald-500/20 rounded-full blur-xl animate-pulse" />
          <Logo size="lg" />
        </div>
        <div>
          <h1 className="text-3xl font-extrabold text-white tracking-tight mt-2">نصر والت</h1>
          <p className="text-sm font-semibold text-emerald-300 mt-1">«محفظتك أنت..»</p>
          <p className="text-xs text-slate-400 mt-2 max-w-xs leading-relaxed">
            المنظومة المالية السيادية المتطورة للمدفوعات الرقمية والقيد المزدوج المحاسبي
          </p>
        </div>
      </div>

      <div className="w-full space-y-3">
        <div className="flex items-center justify-center gap-2 text-xs text-slate-400">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
          <span>جاري تحميل المحفظة المشفرة محلياً...</span>
        </div>
        {onFinish && (
          <button
            onClick={onFinish}
            className="w-full py-3 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-2xl shadow-lg shadow-emerald-950 text-sm transition-all"
          >
            بدء الاستخدام
          </button>
        )}
      </div>
    </div>
  );
};
