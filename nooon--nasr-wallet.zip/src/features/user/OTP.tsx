// src/features/user/OTP.tsx
import React, { useState, useEffect } from 'react';
import { Smartphone, CheckCircle, RefreshCw, ArrowLeft } from 'lucide-react';
import { Button } from '../../components/ui/Button';
import { useAuth } from '../../context/AuthContext';
import { useWallet } from '../../context/WalletContext';

interface Props {
  phone?: string;
  onVerified: () => void;
  onBack?: () => void;
}

export const OTP: React.FC<Props> = ({ phone = '777100249', onVerified, onBack }) => {
  const { verifyOtp } = useAuth();
  const { showToast } = useWallet();
  const [digits, setDigits] = useState(['1', '2', '3', '4', '5', '6']);
  const [timer, setTimer] = useState(60);

  useEffect(() => {
    const t = setInterval(() => {
      setTimer((prev) => (prev > 0 ? prev - 1 : 0));
    }, 1000);
    return () => clearInterval(t);
  }, []);

  const handleDigitChange = (index: number, val: string) => {
    if (val.length > 1) val = val.slice(-1);
    const newDigits = [...digits];
    newDigits[index] = val;
    setDigits(newDigits);

    // Auto focus next input
    if (val && index < 5) {
      const nextInput = document.getElementById(`otp-input-${index + 1}`);
      nextInput?.focus();
    }
  };

  const handleVerify = () => {
    const code = digits.join('');
    if (verifyOtp(code)) {
      showToast('تم التحقق بنجاح من رمز OTP', 'success');
      onVerified();
    } else {
      showToast('رمز التحقق غير صحيح، يرجى المحاولة ثانية', 'error');
    }
  };

  return (
    <div className="min-h-[580px] p-6 bg-slate-950 text-slate-100 flex flex-col justify-between">
      <div className="space-y-6">
        <div>
          <span className="text-[11px] font-mono text-emerald-400 bg-emerald-950 px-2 py-0.5 rounded-md border border-emerald-800/40">
            التحقق من الهاتف
          </span>
          <h2 className="text-2xl font-bold text-white mt-2">أدخل رمز OTP</h2>
          <p className="text-xs text-slate-400 mt-1">
            أرسلنا رسالة نصية SMS برمز تحقق مكون من 6 أرقام إلى: <strong className="text-emerald-400 font-mono">{phone}</strong>
          </p>
        </div>

        {/* 6 Digit Input Boxes */}
        <div className="flex justify-center gap-2 dir-ltr">
          {digits.map((digit, i) => (
            <input
              key={i}
              id={`otp-input-${i}`}
              type="text"
              maxLength={1}
              value={digit}
              onChange={(e) => handleDigitChange(i, e.target.value)}
              className="w-11 h-13 text-center text-xl font-bold font-mono bg-slate-900 border-2 border-slate-700 focus:border-emerald-500 rounded-2xl text-white outline-none"
            />
          ))}
        </div>

        <div className="text-center text-xs text-slate-400">
          {timer > 0 ? (
            <span>يمكنك إعادة طلب الرمز خلال <strong className="text-emerald-400 font-mono">{timer} ثانية</strong></span>
          ) : (
            <button
              onClick={() => {
                setTimer(60);
                showToast('تم إعادة إرسال رمز OTP تجريبي', 'info');
              }}
              className="text-emerald-400 hover:underline flex items-center gap-1 mx-auto"
            >
              <RefreshCw className="w-3.5 h-3.5" /> إعادة إرسال الرمز
            </button>
          )}
        </div>

        <Button
          variant="primary"
          size="lg"
          className="w-full"
          onClick={handleVerify}
          icon={<CheckCircle className="w-4 h-4" />}
          iconPosition="left"
        >
          تأكيد الرمز والمتابعة
        </Button>
      </div>

      {onBack && (
        <div className="text-center pt-4 border-t border-slate-900">
          <button onClick={onBack} className="text-xs text-slate-400 hover:text-white">
            تغيير رقم الهاتف
          </button>
        </div>
      )}
    </div>
  );
};
