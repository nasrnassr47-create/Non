// src/features/user/SendMoney.tsx
import React, { useState } from 'react';
import { Send, ArrowRight, UserCheck, Phone, CheckCircle2, AlertCircle } from 'lucide-react';
import { Button } from '../../components/ui/Button';
import { Input } from '../../components/ui/Input';
import { useWallet } from '../../context/WalletContext';
import { useAuth } from '../../context/AuthContext';
import { CurrencyCode } from '../../types/wallet';

interface Props {
  onBack: () => void;
  onSuccessNavigate?: () => void;
}

export const SendMoney: React.FC<Props> = ({ onBack, onSuccessNavigate }) => {
  const { activeWallet, sendMoney, activeCurrency, setActiveCurrency } = useWallet();
  const { allUsers } = useAuth();

  const [receiverPhone, setReceiverPhone] = useState('771234567');
  const [amount, setAmount] = useState('5000');
  const [notes, setNotes] = useState('');
  const [pin, setPin] = useState('');
  const [step, setStep] = useState<'form' | 'confirm' | 'success'>('form');
  const [isLoading, setIsLoading] = useState(false);

  const numAmount = parseFloat(amount) || 0;
  const targetUser = allUsers.find(u => u.phone.includes(receiverPhone) || receiverPhone.includes(u.phone));

  const handleProceedToConfirm = (e: React.FormEvent) => {
    e.preventDefault();
    if (numAmount <= 0) return;
    setStep('confirm');
  };

  const handleExecuteSend = async () => {
    setIsLoading(true);
    try {
      const res = await sendMoney({
        receiverPhone,
        amount: numAmount,
        notes,
        currency: activeCurrency
      });
      if (res.success) {
        setStep('success');
      }
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="p-5 bg-slate-950 text-slate-100 min-h-[580px] flex flex-col justify-between select-none">
      {/* Top Header */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <button
              onClick={onBack}
              className="p-1.5 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 hover:text-white"
            >
              <ArrowRight className="w-5 h-5" />
            </button>
            <h2 className="text-lg font-bold text-white">تحويل مالي فوري P2P</h2>
          </div>
          <span className="text-xs font-mono text-emerald-400 bg-emerald-950 px-2 py-0.5 rounded-lg border border-emerald-800/40">
            بدون عمولة 0%
          </span>
        </div>

        {/* Current Balance Bar */}
        <div className="p-3 rounded-2xl bg-slate-900 border border-slate-800 flex justify-between items-center text-xs">
          <span className="text-slate-400">الرصيد المتاح للتحويل:</span>
          <span className="font-bold text-emerald-400 font-mono text-sm">
            {activeWallet.balance.toLocaleString()} {activeWallet.symbol}
          </span>
        </div>

        {step === 'form' && (
          <form onSubmit={handleProceedToConfirm} className="space-y-4">
            <Input
              label="رقم هاتف المستلم (يمن موبايل / سبأفون / يو)"
              type="tel"
              value={receiverPhone}
              onChange={(e) => setReceiverPhone(e.target.value)}
              placeholder="770000000"
              prefixIcon={<Phone className="w-4 h-4" />}
              hint={targetUser ? `الاسم المالي للمستلم: ${targetUser.name}` : 'سيتم التحويل مباشرة إلى محفظة المستلم'}
              required
            />

            <div className="text-right space-y-1">
              <label className="text-xs font-medium text-slate-300">مبلغ التحويل ({activeCurrency}):</label>
              <div className="relative flex items-center">
                <input
                  type="number"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  placeholder="0.00"
                  className="w-full text-2xl font-bold font-mono py-3 px-4 bg-slate-900 border border-slate-700 rounded-2xl text-white outline-none focus:border-emerald-500"
                  required
                />
                <span className="absolute left-4 font-bold text-slate-400 text-sm">{activeWallet.symbol}</span>
              </div>
            </div>

            {/* Quick amount chips */}
            <div className="flex gap-2">
              {[1000, 3000, 5000, 10000, 20000].map((val) => (
                <button
                  key={val}
                  type="button"
                  onClick={() => setAmount(val.toString())}
                  className="flex-1 py-1.5 rounded-xl text-xs bg-slate-900 border border-slate-800 hover:border-emerald-500/50 text-slate-300 font-mono transition-colors"
                >
                  {val.toLocaleString()}
                </button>
              ))}
            </div>

            <Input
              label="ملاحظات التحويل (اختياري)"
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="سداد حساب / مصروف شخصي / هدية..."
            />

            <Button
              type="submit"
              variant="primary"
              size="lg"
              className="w-full mt-2"
              icon={<Send className="w-4 h-4" />}
            >
              مراجعة وتأكيد التحويل
            </Button>
          </form>
        )}

        {step === 'confirm' && (
          <div className="space-y-4 animate-in fade-in duration-200">
            <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
              <h3 className="text-xs font-bold text-slate-300 border-b border-slate-800 pb-2">
                تفاصيل العملية قبل الإرسال
              </h3>
              <div className="flex justify-between text-xs">
                <span className="text-slate-400">إلى:</span>
                <span className="font-bold text-white">{targetUser?.name || receiverPhone}</span>
              </div>
              <div className="flex justify-between text-xs">
                <span className="text-slate-400">رقم الهاتف:</span>
                <span className="font-mono text-slate-300">{receiverPhone}</span>
              </div>
              <div className="flex justify-between text-xs">
                <span className="text-slate-400">المبلغ الإجمالي:</span>
                <span className="font-bold text-emerald-400 font-mono text-sm">
                  {numAmount.toLocaleString()} {activeCurrency}
                </span>
              </div>
              <div className="flex justify-between text-xs">
                <span className="text-slate-400">رسوم التحويل:</span>
                <span className="text-emerald-400 font-bold">مجاناً (0.00)</span>
              </div>
              {notes && (
                <div className="flex justify-between text-xs">
                  <span className="text-slate-400">البيان:</span>
                  <span className="text-slate-300">{notes}</span>
                </div>
              )}
            </div>

            <div className="space-y-1 text-right">
              <label className="text-xs font-medium text-slate-300">أدخل رمز PIN لتأكيد الصرف:</label>
              <input
                type="password"
                maxLength={4}
                value={pin}
                onChange={(e) => setPin(e.target.value)}
                placeholder="••••"
                className="w-full text-center tracking-[1em] text-2xl font-mono py-2.5 bg-slate-900 border border-slate-700 rounded-2xl text-white outline-none focus:border-emerald-500"
              />
            </div>

            <div className="flex gap-2">
              <Button
                variant="secondary"
                size="lg"
                className="flex-1"
                onClick={() => setStep('form')}
              >
                تعديل
              </Button>
              <Button
                variant="primary"
                size="lg"
                className="flex-2"
                isLoading={isLoading}
                onClick={handleExecuteSend}
              >
                تنفيذ التحويل الآن
              </Button>
            </div>
          </div>
        )}

        {step === 'success' && (
          <div className="text-center space-y-4 py-8 animate-in zoom-in-95 duration-200">
            <div className="w-16 h-16 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto border-2 border-emerald-500">
              <CheckCircle2 className="w-10 h-10" />
            </div>
            <div>
              <h3 className="text-xl font-bold text-white">تم التحويل بنجاح!</h3>
              <p className="text-xs text-slate-400 mt-1">
                تم قيد العملية بنجاح في سجل الحركات، وتم إرسال إشعار للمستلم
              </p>
              <div className="mt-3 text-2xl font-bold text-emerald-400 font-mono">
                {numAmount.toLocaleString()} {activeCurrency}
              </div>
            </div>

            <Button
              variant="primary"
              size="lg"
              className="w-full mt-6"
              onClick={onBack}
            >
              العودة للرئيسية
            </Button>
          </div>
        )}
      </div>

      <div className="text-center text-[10px] text-slate-500 font-mono">
        حماية القيد المزدوج المحاسبي • تشفير سيادي محلي
      </div>
    </div>
  );
};
