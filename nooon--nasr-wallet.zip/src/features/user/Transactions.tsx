// src/features/user/Transactions.tsx
import React, { useState } from 'react';
import { ArrowRight, Search, Filter, Download, Calendar } from 'lucide-react';
import { TransactionItem } from '../../components/shared/TransactionItem';
import { useWallet } from '../../context/WalletContext';
import { TransactionType } from '../../types/transaction';

interface Props {
  onBack: () => void;
  onSelectTx?: (txId: string) => void;
}

export const Transactions: React.FC<Props> = ({ onBack, onSelectTx }) => {
  const { transactions, showToast } = useWallet();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedType, setSelectedType] = useState<string>('all');

  const filtered = transactions.filter((tx) => {
    const matchSearch =
      tx.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      tx.refNo.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (tx.receiverPhone && tx.receiverPhone.includes(searchTerm));

    if (selectedType === 'all') return matchSearch;
    return matchSearch && tx.type === selectedType;
  });

  const filterTabs = [
    { id: 'all', label: 'الكل' },
    { id: 'P2P', label: 'تحويلات' },
    { id: 'BILL', label: 'فواتير' },
    { id: 'CASH_IN', label: 'إيداعات' },
    { id: 'QR_PAY', label: 'مدفوعات QR' }
  ];

  return (
    <div className="p-5 bg-slate-950 text-slate-100 min-h-[580px] flex flex-col justify-between select-none">
      <div className="space-y-4">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <button
              onClick={onBack}
              className="p-1.5 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 hover:text-white"
            >
              <ArrowRight className="w-5 h-5" />
            </button>
            <h2 className="text-lg font-bold text-white">سجل العمليات المالية (WAL)</h2>
          </div>
          <button
            onClick={() => showToast('تم تصدير كشف الحساب بصيغة PDF المشفرة', 'info')}
            className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-emerald-400 hover:text-emerald-300 flex items-center gap-1 text-xs"
          >
            <Download className="w-4 h-4" />
            <span className="hidden sm:inline">تصدير PDF</span>
          </button>
        </div>

        {/* Search Bar */}
        <div className="relative">
          <Search className="w-4 h-4 text-slate-500 absolute right-3 top-3" />
          <input
            type="text"
            placeholder="بحث برقم المرجع، الاسم، أو الهاتف..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-slate-900 border border-slate-800 rounded-2xl pr-9 pl-4 py-2.5 text-xs text-white placeholder-slate-500 outline-none focus:border-emerald-500"
          />
        </div>

        {/* Filter Chips */}
        <div className="flex gap-1.5 overflow-x-auto no-scrollbar pb-1">
          {filterTabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setSelectedType(tab.id)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                selectedType === tab.id
                  ? 'bg-emerald-600 text-white shadow-md'
                  : 'bg-slate-900 text-slate-400 border border-slate-800 hover:text-white'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Transactions List */}
        <div className="space-y-2 max-h-[380px] overflow-y-auto pr-1">
          {filtered.length > 0 ? (
            filtered.map((tx) => (
              <TransactionItem
                key={tx.id}
                transaction={tx}
                onClick={() => onSelectTx && onSelectTx(tx.id)}
              />
            ))
          ) : (
            <div className="text-center py-12 text-slate-500 text-xs">
              لا توجد عمليات مطابقة لخيارات البحث المحددة
            </div>
          )}
        </div>
      </div>

      <div className="text-center text-[10px] text-slate-500 font-mono">
        جميع القيود مسجلة وموثقة في سجل التدقيق الأمني المشفر WAL
      </div>
    </div>
  );
};
