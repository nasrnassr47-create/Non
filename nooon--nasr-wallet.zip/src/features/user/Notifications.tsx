// src/features/user/Notifications.tsx
import React from 'react';
import { ArrowRight, Bell, CheckCircle2, ArrowDownLeft, ArrowUpRight, ShieldCheck, CheckCheck } from 'lucide-react';
import { useWallet } from '../../context/WalletContext';

interface Props {
  onBack: () => void;
}

export const Notifications: React.FC<Props> = ({ onBack }) => {
  const { showToast } = useWallet();

  const notifications = [
    {
      id: 'n1',
      title: 'استلام حوالة مالية فورية',
      body: 'تم إضافة مبلغ 5,000 ر.ي إلى محفظتك بنجاح من رقم 771234567',
      time: 'منذ 5 دقائق',
      unread: true,
      icon: ArrowDownLeft,
      color: 'text-emerald-400 bg-emerald-500/10'
    },
    {
      id: 'n2',
      title: 'سداد فاتورة هاتف ناجح',
      body: 'تم سداد رصيد يمن موبايل بقيمة 2,000 ر.ي للمشترك 777100249',
      time: 'منذ ساعتين',
      unread: false,
      icon: CheckCircle2,
      color: 'text-blue-400 bg-blue-500/10'
    },
    {
      id: 'n3',
      title: 'تنبيه أمني: دخول جديد للمحفظة',
      body: 'تم تسجيل الدخول من جهاز محمول متوافق، IP: 185.190.x.x',
      time: 'منذ يوم',
      unread: false,
      icon: ShieldCheck,
      color: 'text-amber-400 bg-amber-500/10'
    }
  ];

  return (
    <div className="p-5 bg-slate-950 text-slate-100 min-h-[580px] flex flex-col justify-between select-none">
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <button
              onClick={onBack}
              className="p-1.5 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 hover:text-white"
            >
              <ArrowRight className="w-5 h-5" />
            </button>
            <h2 className="text-lg font-bold text-white">مركز الإشعارات والتنبيهات</h2>
          </div>
          <button
            onClick={() => showToast('تم تعيين جميع الإشعارات كمقروءة', 'info')}
            className="text-xs text-emerald-400 hover:underline flex items-center gap-1"
          >
            <CheckCheck className="w-4 h-4" /> تحديد كمقروء
          </button>
        </div>

        <div className="space-y-2.5">
          {notifications.map((n) => {
            const Icon = n.icon;
            return (
              <div
                key={n.id}
                className={`p-3.5 rounded-2xl border transition-all ${
                  n.unread
                    ? 'bg-slate-900 border-emerald-500/40 shadow-md'
                    : 'bg-slate-900/60 border-slate-800'
                }`}
              >
                <div className="flex items-start gap-3">
                  <div className={`p-2.5 rounded-xl ${n.color} shrink-0`}>
                    <Icon className="w-4 h-4" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-white">{n.title}</span>
                      <span className="text-[10px] text-slate-400 font-mono">{n.time}</span>
                    </div>
                    <p className="text-[11px] text-slate-300 mt-1 leading-relaxed">{n.body}</p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <div className="text-center text-[10px] text-slate-500 font-mono">
        إشعارات مشفرة عبر قنوات الاتصال الآمنة
      </div>
    </div>
  );
};
