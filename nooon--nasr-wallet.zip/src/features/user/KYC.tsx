// src/features/user/KYC.tsx
import React, { useState } from 'react';
import { ShieldCheck, Upload, FileText, CheckCircle2, ArrowLeft } from 'lucide-react';
import { Button } from '../../components/ui/Button';
import { Input } from '../../components/ui/Input';
import { useAuth } from '../../context/AuthContext';
import { useWallet } from '../../context/WalletContext';

interface Props {
  onDone: () => void;
  onSkip?: () => void;
}

export const KYC: React.FC<Props> = ({ onDone, onSkip }) => {
  const { updateKyc } = useAuth();
  const { showToast } = useWallet();
  const [nationalId, setNationalId] = useState('01019948201');
  const [docType, setDocType] = useState<'id_card' | 'passport'>('id_card');
  const [frontUploaded, setFrontUploaded] = useState(true);
  const [backUploaded, setBackUploaded] = useState(true);
  const [selfieUploaded, setSelfieUploaded] = useState(true);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateKyc('level_3');
    showToast('تم رفع وثائق الهوية وتوثيق الحساب إلى KYC المستوى 3 بنجاح', 'success');
    onDone();
  };

  return (
    <div className="min-h-[580px] p-6 bg-slate-950 text-slate-100 flex flex-col justify-between">
      <div className="space-y-5">
        <div>
          <span className="text-[11px] font-mono text-emerald-400 bg-emerald-950 px-2 py-0.5 rounded-md border border-emerald-800/40">
            الامتثال المصرفي KYC
          </span>
          <h2 className="text-2xl font-bold text-white mt-2">توثيق الهوية الوطنية</h2>
          <p className="text-xs text-slate-400 mt-1">
            لرفع حدود التحويل والسحب إلى أعلى سقف قانوني، يرجى استكمال بيانات إثبات الشخصية
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="flex gap-2">
            <button
              type="button"
              onClick={() => setDocType('id_card')}
              className={`flex-1 py-2 rounded-xl text-xs font-bold border transition-all ${
                docType === 'id_card'
                  ? 'bg-emerald-600/20 border-emerald-500 text-emerald-400'
                  : 'bg-slate-900 border-slate-800 text-slate-400'
              }`}
            >
              بطاقة شخصية ذكية
            </button>
            <button
              type="button"
              onClick={() => setDocType('passport')}
              className={`flex-1 py-2 rounded-xl text-xs font-bold border transition-all ${
                docType === 'passport'
                  ? 'bg-emerald-600/20 border-emerald-500 text-emerald-400'
                  : 'bg-slate-900 border-slate-800 text-slate-400'
              }`}
            >
              جواز سفر يمني
            </button>
          </div>

          <Input
            label="الرقم الوطني الموحد (11 رقم)"
            type="text"
            value={nationalId}
            onChange={(e) => setNationalId(e.target.value)}
            placeholder="0101XXXXXXXX"
            prefixIcon={<FileText className="w-4 h-4" />}
            required
          />

          <div className="space-y-2">
            <label className="block text-xs font-medium text-slate-300">مرفقات الهوية الرقمية</label>
            
            <div className="p-3 bg-slate-900 rounded-xl border border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span className="text-xs text-slate-200">صورة الوجه الأمامي للهوية</span>
              </div>
              <span className="text-[10px] text-emerald-400 font-mono">تم الإرفاق (بطاقة.jpg)</span>
            </div>

            <div className="p-3 bg-slate-900 rounded-xl border border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span className="text-xs text-slate-200">صورة الوجه الخلفي للهوية</span>
              </div>
              <span className="text-[10px] text-emerald-400 font-mono">تم الإرفاق (خلفي.jpg)</span>
            </div>

            <div className="p-3 bg-slate-900 rounded-xl border border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span className="text-xs text-slate-200">صورة سيلفي حية للتحقق من الحيوية</span>
              </div>
              <span className="text-[10px] text-emerald-400 font-mono">تم التحقق Liveness OK</span>
            </div>
          </div>

          <Button
            type="submit"
            variant="primary"
            size="lg"
            className="w-full"
            icon={<ShieldCheck className="w-4 h-4" />}
            iconPosition="left"
          >
            اعتماد التوثيق المالي
          </Button>
        </form>
      </div>

      {onSkip && (
        <div className="text-center pt-4 border-t border-slate-900">
          <button onClick={onSkip} className="text-xs text-slate-400 hover:text-white">
            تخطي التوثيق الآن (حدود أساسية فقط)
          </button>
        </div>
      )}
    </div>
  );
};
