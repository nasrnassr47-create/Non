// src/features/user/Settings.tsx
import React, { useState } from 'react';
import { 
  ArrowRight, 
  Moon, 
  Sun, 
  Globe, 
  Bell, 
  DatabaseBackup, 
  ShieldAlert, 
  Sliders, 
  Lock, 
  Sparkles, 
  RotateCcw, 
  Monitor, 
  Smartphone,
  Coins,
  Zap
} from 'lucide-react';
import { useTheme } from '../../context/ThemeContext';
import { useLanguage } from '../../context/LanguageContext';
import { useWallet } from '../../context/WalletContext';
import { MasterControlPanel } from '../control/MasterControlPanel';

interface Props {
  onBack: () => void;
  onNavigateSecurity?: () => void;
}

export const Settings: React.FC<Props> = ({ onBack, onNavigateSecurity }) => {
  const { isDark, toggleTheme } = useTheme();
  const { language, toggleLanguage } = useLanguage();
  const { 
    createManualBackup, 
    systemControl, 
    updateAppearance, 
    updateFees, 
    updateSecurity, 
    generateDemoTransactions,
    resetAllToFactoryDefaults,
    activeCurrency,
    addQuickFunds
  } = useWallet();

  const [showGodModeModal, setShowGodModeModal] = useState(false);

  if (showGodModeModal) {
    return (
      <div className="p-3 sm:p-5 bg-slate-950 text-slate-100 min-h-[600px] select-none">
        <MasterControlPanel onClose={() => setShowGodModeModal(false)} />
      </div>
    );
  }

  return (
    <div className="p-5 bg-slate-950 text-slate-100 min-h-[580px] flex flex-col justify-between select-none">
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <button
              onClick={onBack}
              className="p-1.5 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 hover:text-white"
            >
              <ArrowRight className="w-5 h-5" />
            </button>
            <h2 className="text-lg font-bold text-white">إعدادات المحفظة والتحكم الكامل</h2>
          </div>

          <button
            onClick={() => setShowGodModeModal(true)}
            className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-emerald-600 to-amber-600 hover:from-emerald-500 hover:to-amber-500 text-white text-xs font-bold shadow-lg shadow-emerald-950/50 flex items-center gap-1.5 transition-all"
          >
            <Sliders className="w-3.5 h-3.5" />
            <span>لوحة التحكم السيادية</span>
          </button>
        </div>

        {/* Highlight Banner for Sovereign Control */}
        <div 
          onClick={() => setShowGodModeModal(true)}
          className="p-4 rounded-2xl bg-gradient-to-br from-emerald-950/80 via-slate-900 to-amber-950/50 border border-emerald-500/30 cursor-pointer hover:border-emerald-400 transition-all group"
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-xl bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 group-hover:scale-105 transition-transform">
                <Sliders className="w-5 h-5" />
              </div>
              <div>
                <div className="text-xs font-black text-white flex items-center gap-2">
                  <span>مركز التحكم السيادي الكامل (God Mode)</span>
                  <span className="text-[10px] bg-amber-500/20 text-amber-300 px-2 py-0.5 rounded-full border border-amber-500/30 font-bold">تحكم فوري</span>
                </div>
                <div className="text-[11px] text-slate-300 mt-0.5">
                  تعديل وتغذية الأرصدة، أسعار الصرف الحية، قفل الطوارئ، وسقوف التحويل
                </div>
              </div>
            </div>
            <ArrowRight className="w-4 h-4 text-emerald-400 group-hover:translate-x-[-2px] transition-transform" />
          </div>
        </div>

        <div className="space-y-2.5">
          {/* Quick Balance Injection */}
          <div className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800 flex justify-between items-center">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-slate-800 text-emerald-400">
                <Coins className="w-4 h-4" />
              </div>
              <div>
                <div className="text-xs font-bold text-white">تغذية المحفظة برصيد سريع ({activeCurrency})</div>
                <div className="text-[11px] text-slate-400">إضافة فورية لرصيد العملة النشطة للتجربة</div>
              </div>
            </div>
            <button
              onClick={() => addQuickFunds(activeCurrency, activeCurrency === 'YER' ? 100000 : 200)}
              className="px-3 py-1.5 rounded-xl bg-emerald-600 text-white text-xs font-bold hover:bg-emerald-500 transition-all"
            >
              + {activeCurrency === 'YER' ? '100,000' : '200'}
            </button>
          </div>

          {/* View Mode Toggle */}
          <div className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800 flex justify-between items-center">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-slate-800 text-cyan-400">
                {systemControl.appearance.viewMode === 'desktop' ? <Monitor className="w-4 h-4" /> : <Smartphone className="w-4 h-4" />}
              </div>
              <div>
                <div className="text-xs font-bold text-white">وضع شاشة العرض</div>
                <div className="text-[11px] text-slate-400">
                  {systemControl.appearance.viewMode === 'desktop' ? 'شاشة سطح المكتب الموسعة' : 'إطار الهاتف الذكي التفاعلي'}
                </div>
              </div>
            </div>
            <button
              onClick={() => updateAppearance({
                viewMode: systemControl.appearance.viewMode === 'desktop' ? 'mobile' : 'desktop'
              })}
              className="px-3 py-1.5 rounded-xl bg-slate-800 text-xs font-bold text-slate-200 hover:bg-slate-700"
            >
              تبديل الشاشة
            </button>
          </div>

          {/* Rapid PIN Bypass */}
          <div className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800 flex justify-between items-center">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-slate-800 text-amber-400">
                <Lock className="w-4 h-4" />
              </div>
              <div>
                <div className="text-xs font-bold text-white">تجاوز رمز PIN للاختبار السريع</div>
                <div className="text-[11px] text-slate-400">تنفيذ التحويلات بنقرة مباشرة دون إدخال الرمز</div>
              </div>
            </div>
            <button
              onClick={() => updateSecurity({ bypassPin: !systemControl.security.bypassPin })}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                systemControl.security.bypassPin ? 'bg-emerald-600 text-white' : 'bg-slate-800 text-slate-400'
              }`}
            >
              {systemControl.security.bypassPin ? 'مفعّل' : 'معطّل'}
            </button>
          </div>

          {/* Zero Fee Toggle */}
          <div className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800 flex justify-between items-center">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-slate-800 text-teal-400">
                <Zap className="w-4 h-4" />
              </div>
              <div>
                <div className="text-xs font-bold text-white">سياسة التحويل المجاني 0% عمولة</div>
                <div className="text-[11px] text-slate-400">إعفاء تام من رسوم التحويلات بين الأفراد</div>
              </div>
            </div>
            <button
              onClick={() => updateFees({ isFeeFree: !systemControl.fees.isFeeFree })}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                systemControl.fees.isFeeFree ? 'bg-emerald-600 text-white' : 'bg-slate-800 text-slate-400'
              }`}
            >
              {systemControl.fees.isFeeFree ? '0% رسوم' : 'معطّل'}
            </button>
          </div>

          {/* Demo Tx Generator */}
          <div className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800 flex justify-between items-center">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-slate-800 text-indigo-400">
                <Sparkles className="w-4 h-4" />
              </div>
              <div>
                <div className="text-xs font-bold text-white">توليد حركات مالية تجريبية</div>
                <div className="text-[11px] text-slate-400">إضافة 3 حركات فورية لاختبار الواجهة وسجل العمليات</div>
              </div>
            </div>
            <button
              onClick={generateDemoTransactions}
              className="px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold transition-all"
            >
              توليد الآن
            </button>
          </div>

          {/* Theme Switch */}
          <div className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800 flex justify-between items-center">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-slate-800 text-amber-400">
                {isDark ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
              </div>
              <div>
                <div className="text-xs font-bold text-white">المظهر اللوني (ليلي / نهاري)</div>
                <div className="text-[11px] text-slate-400">{isDark ? 'الوضع الليلي الفاخر' : 'الوضع النهاري'}</div>
              </div>
            </div>
            <button
              onClick={toggleTheme}
              className="px-3 py-1.5 rounded-xl bg-slate-800 text-xs font-bold text-slate-200 hover:bg-slate-700"
            >
              تبديل
            </button>
          </div>

          {/* Language Switch */}
          <div className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800 flex justify-between items-center">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-slate-800 text-cyan-400">
                <Globe className="w-4 h-4" />
              </div>
              <div>
                <div className="text-xs font-bold text-white">لغة واجهة التطبيق</div>
                <div className="text-[11px] text-slate-400">{language === 'ar' ? 'العربية (RTL)' : 'English (LTR)'}</div>
              </div>
            </div>
            <button
              onClick={toggleLanguage}
              className="px-3 py-1.5 rounded-xl bg-slate-800 text-xs font-mono font-bold text-slate-200 hover:bg-slate-700"
            >
              {language === 'ar' ? 'English' : 'عربي'}
            </button>
          </div>

          {/* Backup */}
          <div className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800 flex justify-between items-center">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-slate-800 text-emerald-400">
                <DatabaseBackup className="w-4 h-4" />
              </div>
              <div>
                <div className="text-xs font-bold text-white">النسخ الاحتياطي اليدوي والتشفير</div>
                <div className="text-[11px] text-slate-400">تنزيل نسخة مشفرة من بيانات المحفظة محلياً</div>
              </div>
            </div>
            <button
              onClick={createManualBackup}
              className="px-3 py-1.5 rounded-xl bg-emerald-600 text-white text-xs font-bold hover:bg-emerald-500"
            >
              حفظ نسخة
            </button>
          </div>

          {/* Factory Reset */}
          <div className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800 flex justify-between items-center">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-slate-800 text-red-400">
                <RotateCcw className="w-4 h-4" />
              </div>
              <div>
                <div className="text-xs font-bold text-white">استعادة ضبط المصنع</div>
                <div className="text-[11px] text-slate-400">إعادة تعيين المحفظة والحسابات للوضع الأصلي</div>
              </div>
            </div>
            <button
              onClick={() => {
                if (window.confirm('هل تود إعادة تعيين المحفظة والبيانات للوضع المصنعي الأصلي؟')) {
                  resetAllToFactoryDefaults();
                }
              }}
              className="px-3 py-1.5 rounded-xl bg-red-950/80 text-red-300 border border-red-800 hover:bg-red-800 hover:text-white text-xs font-bold transition-all"
            >
              إعادة ضبط
            </button>
          </div>
        </div>
      </div>

      <div className="text-center text-[10px] text-slate-500 font-mono mt-4 pt-3 border-t border-slate-900">
        نظام نصر السيادي الفائق V2.5 • كامل الصلاحيات والتحكم اللحظي
      </div>
    </div>
  );
};

