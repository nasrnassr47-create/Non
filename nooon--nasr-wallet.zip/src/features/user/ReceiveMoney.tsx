// src/features/user/ReceiveMoney.tsx
import React, { useState } from 'react';
import { ArrowRight, Copy, Share2, Check, QrCode, Sparkles } from 'lucide-react';
import { Button } from '../../components/ui/Button';
import { useAuth } from '../../context/AuthContext';
import { useWallet } from '../../context/WalletContext';
import { copyToClipboard } from '../../lib/utils';

interface Props {
  onBack: () => void;
}

export const ReceiveMoney: React.FC<Props> = ({ onBack }) => {
  const { currentUser } = useAuth();
  const { activeWallet, showToast, activeCurrency } = useWallet();
  const [copied, setCopied] = useState(false);
  const [requestedAmount, setRequestedAmount] = useState('');

  const qrPayload = JSON.stringify({
    wallet: activeWallet.accountNumber,
    phone: currentUser.phone,
    name: currentUser.name,
    currency: activeCurrency,
    amount: requestedAmount ? parseFloat(requestedAmount) : undefined
  });

  const handleCopy = async () => {
    const ok = await copyToClipboard(currentUser.phone);
    if (ok) {
      setCopied(true);
      showToast('تم نسخ رقم الهاتف لمشاركته للاستلام', 'success');
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div className="p-5 bg-slate-950 text-slate-100 min-h-[580px] flex flex-col justify-between select-none">
      <div className="space-y-4">
        <div className="flex items-center gap-2">
          <button
            onClick={onBack}
            className="p-1.5 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 hover:text-white"
          >
            <ArrowRight className="w-5 h-5" />
          </button>
          <h2 className="text-lg font-bold text-white">استلام أموال عبر QR</h2>
        </div>

        {/* QR Code Container */}
        <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 flex flex-col items-center text-center space-y-4 shadow-xl">
          {/* Visual QR Simulator */}
          <div className="p-4 bg-white rounded-2xl shadow-inner flex flex-col items-center justify-center">
            {/* SVG QR Pattern */}
            <svg viewBox="0 0 100 100" className="w-44 h-44">
              <rect x="0" y="0" width="30" height="30" fill="#022c22" />
              <rect x="5" y="5" width="20" height="20" fill="white" />
              <rect x="9" y="9" width="12" height="12" fill="#059669" />

              <rect x="70" y="0" width="30" height="30" fill="#022c22" />
              <rect x="75" y="5" width="20" height="20" fill="white" />
              <rect x="79" y="9" width="12" height="12" fill="#059669" />

              <rect x="0" y="70" width="30" height="30" fill="#022c22" />
              <rect x="5" y="75" width="20" height="20" fill="white" />
              <rect x="9" y="79" width="12" height="12" fill="#059669" />

              {/* Data matrix dots */}
              <rect x="35" y="10" width="8" height="8" fill="#0f172a" />
              <rect x="50" y="15" width="10" height="6" fill="#0f172a" />
              <rect x="40" y="35" width="20" height="20" fill="#047857" rx="3" />
              <rect x="15" y="45" width="8" height="12" fill="#0f172a" />
              <rect x="75" y="45" width="10" height="10" fill="#0f172a" />
              <rect x="45" y="65" width="15" height="12" fill="#0f172a" />
              <rect x="70" y="75" width="12" height="12" fill="#0f172a" />
            </svg>
            <span className="text-[10px] text-slate-800 font-mono font-bold mt-1">نصر والت QR المعتمد</span>
          </div>

          <div>
            <h3 className="font-bold text-white text-base">{currentUser.name}</h3>
            <p className="text-xs text-emerald-400 font-mono mt-0.5">{currentUser.phone}</p>
            <p className="text-[11px] text-slate-400 font-mono mt-0.5">
              حساب المحفظة: {activeWallet.accountNumber}
            </p>
          </div>

          {/* Amount input to embed in QR */}
          <div className="w-full text-right pt-2 border-t border-slate-800">
            <label className="text-[11px] text-slate-400">تحديد مبلغ مطلوب (اختياري):</label>
            <div className="flex gap-2 mt-1">
              <input
                type="number"
                placeholder="أدخل المبلغ..."
                value={requestedAmount}
                onChange={(e) => setRequestedAmount(e.target.value)}
                className="flex-1 bg-slate-950 border border-slate-700 rounded-xl px-3 py-1.5 text-xs text-white font-mono outline-none"
              />
              <span className="p-2 bg-slate-950 rounded-xl text-xs font-mono text-emerald-400 border border-slate-800">
                {activeCurrency}
              </span>
            </div>
          </div>
        </div>

        <div className="flex gap-2">
          <Button
            variant="secondary"
            className="flex-1"
            icon={copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
            onClick={handleCopy}
          >
            {copied ? 'تم النسخ' : 'نسخ رقم الهاتف'}
          </Button>

          <Button
            variant="primary"
            className="flex-1"
            icon={<Share2 className="w-4 h-4" />}
            onClick={() => showToast('تم تجهيز رابط الدفع للمشاركة', 'info')}
          >
            مشاركة الباركود
          </Button>
        </div>
      </div>

      <div className="text-center text-[10px] text-slate-500 font-mono">
        متوافق مع شبكات المدفوعات والتبادل المالي عبر QR في اليمن
      </div>
    </div>
  );
};
