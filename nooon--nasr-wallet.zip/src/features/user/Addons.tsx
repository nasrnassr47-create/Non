// src/features/user/Addons.tsx
import React, { useState } from 'react';
import { ArrowRight, Gamepad2, Shield, PiggyBank, Briefcase, Sparkles, CheckCircle2 } from 'lucide-react';
import { Button } from '../../components/ui/Button';
import { useWallet } from '../../context/WalletContext';

interface Props {
  onBack: () => void;
}

export const Addons: React.FC<Props> = ({ onBack }) => {
  const { showToast, activeWallet } = useWallet();

  const addons = [
    {
      id: 'gaming',
      title: 'بطاقات الألعاب والتطبيقات',
      desc: 'ببجي، فري فاير، بلايستيشن، آيتونز، شاهد VIP، نتفليكس',
      icon: Gamepad2,
      color: 'text-purple-400 bg-purple-500/10 border-purple-500/30'
    },
    {
      id: 'savings',
      title: 'حصالة التوفير الذكية (صندوق ادخار)',
      desc: 'ادخار تلقائي عند كل عملية شرائية بعائد سيادي محفوظ',
      icon: PiggyBank,
      color: 'text-amber-400 bg-amber-500/10 border-amber-500/30'
    },
    {
      id: 'microfinance',
      title: 'تمويل المشاريع الصغيرة والأصغر',
      desc: 'تمويل إسلامي مرابحة بضمان المحفظة وسجل المعاملات',
      icon: Briefcase,
      color: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/30'
    },
    {
      id: 'takaful',
      title: 'التأمين التكافلي الصحي',
      desc: 'تغطية طبية فورية للأسرة بالاشتراك مع كبرى المستشفيات',
      icon: Shield,
      color: 'text-cyan-400 bg-cyan-500/10 border-cyan-500/30'
    }
  ];

  return (
    <div className="p-5 bg-slate-950 text-slate-100 min-h-[580px] flex flex-col justify-between select-none">
      <div className="space-y-4">
        <div className="flex items-center gap-2">
          <button
            onClick={onBack}
            className="p-1.5 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 hover:text-white"
          >
            <ArrowRight className="w-5 h-5" />
          </button>
          <h2 className="text-lg font-bold text-white">الخدمات الإضافية والادخار</h2>
        </div>

        <div className="space-y-3">
          {addons.map((a) => {
            const Icon = a.icon;
            return (
              <div
                key={a.id}
                className="p-4 rounded-3xl bg-slate-900 border border-slate-800 space-y-3 shadow-md hover:border-slate-700 transition-all"
              >
                <div className="flex items-start gap-3">
                  <div className={`p-3 rounded-2xl border ${a.color} shrink-0`}>
                    <Icon className="w-5 h-5" />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-xs sm:text-sm font-bold text-white">{a.title}</h3>
                    <p className="text-xs text-slate-400 mt-1 leading-relaxed">{a.desc}</p>
                  </div>
                </div>

                <Button
                  size="sm"
                  variant="secondary"
                  className="w-full"
                  onClick={() => showToast(`تم فتح خدمة: ${a.title}`, 'info')}
                >
                  استكشاف الخدمة وتفعيلها
                </Button>
              </div>
            );
          })}
        </div>
      </div>

      <div className="text-center text-[10px] text-slate-500 font-mono">
        خدمات إلكترونية متوافقة مع ضوابط التمويل الإسلامي
      </div>
    </div>
  );
};
