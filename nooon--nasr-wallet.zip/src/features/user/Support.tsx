// src/features/user/Support.tsx
import React, { useState } from 'react';
import { ArrowRight, Headphones, MessageSquare, Phone, Send, CheckCircle2, HelpCircle } from 'lucide-react';
import { Button } from '../../components/ui/Button';
import { Input } from '../../components/ui/Input';
import { useWallet } from '../../context/WalletContext';

interface Props {
  onBack: () => void;
}

export const Support: React.FC<Props> = ({ onBack }) => {
  const { showToast } = useWallet();
  const [ticketSubject, setTicketSubject] = useState('');
  const [ticketMsg, setTicketMsg] = useState('');
  const [sent, setSent] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    showToast('تم فتح تذكرة دعم فني جديدة برقم #T-88291', 'success');
    setSent(true);
  };

  return (
    <div className="p-5 bg-slate-950 text-slate-100 min-h-[580px] flex flex-col justify-between select-none">
      <div className="space-y-4">
        <div className="flex items-center gap-2">
          <button
            onClick={onBack}
            className="p-1.5 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 hover:text-white"
          >
            <ArrowRight className="w-5 h-5" />
          </button>
          <h2 className="text-lg font-bold text-white">الدعم الفني وخدمة العملاء 24/7</h2>
        </div>

        {/* Quick Contact Buttons */}
        <div className="grid grid-cols-2 gap-2">
          <div className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800 text-center space-y-1">
            <Phone className="w-5 h-5 text-emerald-400 mx-auto" />
            <div className="text-xs font-bold text-white">الرقم المجاني الموحد</div>
            <div className="text-xs text-emerald-400 font-mono font-bold">800-0080</div>
          </div>

          <div className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800 text-center space-y-1">
            <MessageSquare className="w-5 h-5 text-cyan-400 mx-auto" />
            <div className="text-xs font-bold text-white">دردشة واتساب حية</div>
            <div className="text-xs text-cyan-400 font-mono font-bold">+967 777 000 000</div>
          </div>
        </div>

        {/* Ticket Box */}
        {!sent ? (
          <form onSubmit={handleSubmit} className="p-4 rounded-3xl bg-slate-900 border border-slate-800 space-y-3">
            <h3 className="text-xs font-bold text-white flex items-center gap-1.5">
              <Headphones className="w-4 h-4 text-emerald-400" /> فتح بلاغ أو استفسار مالي
            </h3>

            <Input
              label="موضوع البلاغ / التذكرة"
              type="text"
              value={ticketSubject}
              onChange={(e) => setTicketSubject(e.target.value)}
              placeholder="مثال: استفسار عن حوالة معلقة"
              required
            />

            <div className="space-y-1 text-right">
              <label className="text-xs font-medium text-slate-300">تفاصيل المشكلة أو الطلب:</label>
              <textarea
                value={ticketMsg}
                onChange={(e) => setTicketMsg(e.target.value)}
                placeholder="اكتب تفاصيل طلبك هنا وسيقوم الفريق بالرد فوراً..."
                className="w-full bg-slate-950 border border-slate-700 rounded-xl p-3 text-xs text-white outline-none focus:border-emerald-500 h-24"
                required
              />
            </div>

            <Button
              type="submit"
              variant="primary"
              size="md"
              className="w-full"
              icon={<Send className="w-4 h-4" />}
            >
              إرسال التذكرة لفريق الدعم
            </Button>
          </form>
        ) : (
          <div className="p-6 text-center space-y-3 bg-slate-900 rounded-3xl border border-slate-800 animate-in zoom-in-95">
            <CheckCircle2 className="w-12 h-12 text-emerald-400 mx-auto" />
            <h3 className="text-base font-bold text-white">تم استلام طلبك بنجاح</h3>
            <p className="text-xs text-slate-400">
              تذكرة رقم <strong className="text-emerald-400 font-mono">#T-88291</strong> قيد المتابعة من المشرف المالي
            </p>
            <Button variant="secondary" size="sm" onClick={() => setSent(false)}>
              إرسال استفسار آخر
            </Button>
          </div>
        )}
      </div>

      <div className="text-center text-[10px] text-slate-500 font-mono">
        فريق الدعم الفني جاهز لخدمتكم على مدار الساعة 24/7/365
      </div>
    </div>
  );
};
