// src/features/user/BillPayment.tsx
import React, { useState } from 'react';
import { ArrowRight, Wifi, Zap, Phone, CheckCircle2, ChevronDown, Check } from 'lucide-react';
import { Button } from '../../components/ui/Button';
import { Input } from '../../components/ui/Input';
import { useWallet } from '../../context/WalletContext';

interface Props {
  onBack: () => void;
  defaultCategory?: string;
}

export const BillPayment: React.FC<Props> = ({ onBack, defaultCategory = 'telecom' }) => {
  const { payBill, activeWallet, showToast } = useWallet();

  const services = [
    { id: 'ym', name: 'يمن موبايل (رصيد وباقات)', category: 'telecom', icon: Phone },
    { id: 'sabafon', name: 'سبأفون (دفع مسبق وفوترة)', category: 'telecom', icon: Phone },
    { id: 'you', name: 'شركة يو YOU (إم تي إن سابقاً)', category: 'telecom', icon: Phone },
    { id: 'yemen_net', name: 'سوبر يمن نت (ADSL & FTTH)', category: 'internet', icon: Wifi },
    { id: 'aden_net', name: 'عدن نت (Aden Net 4G)', category: 'internet', icon: Wifi },
    { id: 'elec', name: 'فواتير وشحن كروت الكهرباء', category: 'utilities', icon: Zap },
    { id: 'water', name: 'المؤسسة العامة للمياه والصرف', category: 'utilities', icon: Zap }
  ];

  const [selectedService, setSelectedService] = useState(services[0]);
  const [billNumber, setBillNumber] = useState('777100249');
  const [amount, setAmount] = useState('2000');
  const [isProcessing, setIsProcessing] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsProcessing(true);
    try {
      const res = await payBill({
        serviceName: selectedService.name,
        amount: parseFloat(amount) || 0,
        billNumber
      });
      if (res.success) {
        setIsSuccess(true);
      }
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="p-5 bg-slate-950 text-slate-100 min-h-[580px] flex flex-col justify-between select-none">
      <div className="space-y-4">
        <div className="flex items-center gap-2">
          <button
            onClick={onBack}
            className="p-1.5 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 hover:text-white"
          >
            <ArrowRight className="w-5 h-5" />
          </button>
          <h2 className="text-lg font-bold text-white">سداد الفواتير والخدمات</h2>
        </div>

        {/* Balance preview */}
        <div className="p-3 rounded-2xl bg-slate-900 border border-slate-800 flex justify-between items-center text-xs">
          <span className="text-slate-400">الرصيد المتاح للسداد:</span>
          <span className="font-bold text-emerald-400 font-mono">
            {activeWallet.balance.toLocaleString()} {activeWallet.symbol}
          </span>
        </div>

        {!isSuccess ? (
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-1 text-right">
              <label className="text-xs font-medium text-slate-300">اختر الخدمة أو المزود:</label>
              <div className="grid grid-cols-1 gap-2 max-h-44 overflow-y-auto pr-1">
                {services.map((srv) => {
                  const SrvIcon = srv.icon;
                  const isSelected = selectedService.id === srv.id;
                  return (
                    <button
                      key={srv.id}
                      type="button"
                      onClick={() => setSelectedService(srv)}
                      className={`p-2.5 rounded-xl border flex items-center justify-between text-right text-xs transition-all ${
                        isSelected
                          ? 'bg-emerald-950/80 border-emerald-500 text-white font-bold'
                          : 'bg-slate-900 border-slate-800 text-slate-300 hover:bg-slate-850'
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <SrvIcon className="w-4 h-4 text-emerald-400" />
                        <span>{srv.name}</span>
                      </div>
                      {isSelected && <Check className="w-4 h-4 text-emerald-400" />}
                    </button>
                  );
                })}
              </div>
            </div>

            <Input
              label="رقم الهاتف / رقم الحساب أو المشترك"
              type="text"
              value={billNumber}
              onChange={(e) => setBillNumber(e.target.value)}
              placeholder="77XXXXXXX / 01XXXXXX"
              required
            />

            <div className="space-y-1 text-right">
              <label className="text-xs font-medium text-slate-300">مبلغ السداد (ريال يمني):</label>
              <input
                type="number"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="2000"
                className="w-full text-xl font-bold font-mono py-2.5 px-3 bg-slate-900 border border-slate-700 rounded-xl text-white outline-none focus:border-emerald-500"
                required
              />
            </div>

            <div className="flex gap-2">
              {[500, 1000, 2000, 5000, 10000].map((val) => (
                <button
                  key={val}
                  type="button"
                  onClick={() => setAmount(val.toString())}
                  className="flex-1 py-1.5 rounded-xl text-xs bg-slate-900 border border-slate-800 hover:border-emerald-500 text-slate-300 font-mono"
                >
                  {val.toLocaleString()}
                </button>
              ))}
            </div>

            <Button
              type="submit"
              variant="primary"
              size="lg"
              className="w-full mt-2"
              isLoading={isProcessing}
              icon={<CheckCircle2 className="w-4 h-4" />}
            >
              تأكيد سداد الفاتورة فورا
            </Button>
          </form>
        ) : (
          <div className="p-6 text-center space-y-4 py-8 animate-in zoom-in-95">
            <div className="w-16 h-16 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto border-2 border-emerald-500">
              <CheckCircle2 className="w-10 h-10" />
            </div>
            <div>
              <h3 className="text-xl font-bold text-white">تم سداد الفاتورة بنجاح!</h3>
              <p className="text-xs text-slate-400 mt-1">
                تم شحن وتسديد {selectedService.name} بمبلغ {amount} ريال بنجاح
              </p>
            </div>
            <Button variant="primary" size="lg" className="w-full" onClick={() => setIsSuccess(false)}>
              سداد فاتورة أخرى
            </Button>
          </div>
        )}
      </div>

      <div className="text-center text-[10px] text-slate-500 font-mono">
        ربط مباشر مع بوابات شركات الاتصالات ومؤسسات الخدمة العامة
      </div>
    </div>
  );
};
