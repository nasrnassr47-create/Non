// src/features/user/Dashboard.tsx
import React, { useState } from 'react';
import { 
  Send, 
  ArrowDownLeft, 
  QrCode, 
  PlusCircle, 
  Receipt, 
  Zap, 
  Wifi, 
  Users, 
  CreditCard, 
  Store, 
  FileText, 
  ShieldCheck, 
  Sparkles,
  ChevronLeft,
  Search,
  Sliders,
  TrendingUp,
  AlertTriangle,
  Lock,
  ArrowUpRight,
  Smartphone,
  Download
} from 'lucide-react';
import { WalletCard } from '../../components/shared/WalletCard';
import { TransactionItem } from '../../components/shared/TransactionItem';
import { useAuth } from '../../context/AuthContext';
import { useWallet } from '../../context/WalletContext';
import { CurrencyCode } from '../../types/wallet';
import { InstallStandaloneModal } from '../../components/common/InstallStandaloneModal';

interface Props {
  onNavigate: (screen: string) => void;
  onOpenSystemViewer?: () => void;
}

export const Dashboard: React.FC<Props> = ({ onNavigate, onOpenSystemViewer }) => {
  const { currentUser } = useAuth();
  const { activeCurrency, setActiveCurrency, transactions, systemControl } = useWallet();
  const [isInstallModalOpen, setIsInstallModalOpen] = useState(false);

  const currencies: CurrencyCode[] = ['YER', 'SAR', 'USD', 'EUR'];

  const quickActions = [
    { id: 'send', label: 'تحويل فوري', icon: Send, color: 'from-emerald-600 to-teal-600' },
    { id: 'receive', label: 'طلب استلام', icon: ArrowDownLeft, color: 'from-blue-600 to-indigo-600' },
    { id: 'scan_qr', label: 'مسح QR', icon: QrCode, color: 'from-cyan-600 to-teal-700' },
    { id: 'topup', label: 'تغذية المحفظة', icon: PlusCircle, color: 'from-amber-600 to-orange-600' },
  ];

  const services = [
    { id: 'bills', label: 'اتصالات وإنترنت', icon: Wifi, desc: 'يمن موبايل، سبأفون، يو، يمن نت' },
    { id: 'electricity', label: 'كهرباء ومياه', icon: Zap, desc: 'سداد فواتير وشحن كروت العداد' },
    { id: 'cards', label: 'بطاقات رقمية', icon: CreditCard, desc: 'إصدار فيزا افتراضية وماستركارد' },
    { id: 'family', label: 'محفظة العائلة', icon: Users, desc: 'مصروف الأبناء والحدود الشهرية' },
    { id: 'merchants', label: 'دفع للمتاجر', icon: Store, desc: 'سوبرماركت وصيدليات ومطاعم' },
    { id: 'reports', label: 'كشوف الحساب', icon: FileText, desc: 'تقارير WAL غير قابلة للتعديل' },
  ];

  const recentTx = transactions.slice(0, 4);

  return (
    <div className="p-4 sm:p-5 space-y-5 bg-slate-950 text-slate-100 pb-20 select-none">
      {/* Emergency Lockdown Warning Alert if active */}
      {systemControl.security.emergencyLockdown && (
        <div className="p-3.5 rounded-2xl bg-red-950 border border-red-500/80 text-red-200 flex items-center justify-between animate-pulse shadow-lg shadow-red-950/50">
          <div className="flex items-center gap-2.5">
            <AlertTriangle className="w-5 h-5 text-red-400 shrink-0" />
            <div>
              <div className="text-xs font-black text-white">قفل الطوارئ السيادي نشط</div>
              <div className="text-[10px] text-red-300">تم تجميد العمليات مؤقتاً لحماية السيولة</div>
            </div>
          </div>
          <button
            onClick={() => onNavigate('settings')}
            className="px-2.5 py-1 rounded-xl bg-red-600 hover:bg-red-500 text-white text-[11px] font-bold"
          >
            إدارة القفل
          </button>
        </div>
      )}

      {/* User Greeting & Status Bar */}
      <div className="flex items-center justify-between">
        <div>
          <div className="text-xs text-slate-400 flex items-center gap-1">
            <span>مرحباً بك مجدداً</span>
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping inline-block" />
          </div>
          <h2 className="text-base sm:text-lg font-bold text-white flex items-center gap-1.5">
            <span>{currentUser.name}</span>
            <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-300 border border-emerald-600/40 font-mono">
              KYC موثق
            </span>
          </h2>
        </div>

        {/* Currency Switcher */}
        <div className="flex bg-slate-900 p-1 rounded-2xl border border-slate-800 shadow-inner">
          {currencies.map((curr) => (
            <button
              key={curr}
              onClick={() => setActiveCurrency(curr)}
              className={`px-2.5 py-1 rounded-xl text-xs font-mono font-bold transition-all cursor-pointer ${
                activeCurrency === curr
                  ? 'bg-emerald-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {curr}
            </button>
          ))}
        </div>
      </div>

      {/* Main Luxury Metallic Wallet Card */}
      <WalletCard onQuickTopUp={() => onNavigate('topup')} />

      {/* Primary 4 Quick Action Circles */}
      <div className="grid grid-cols-4 gap-2 text-center">
        {quickActions.map((action) => {
          const Icon = action.icon;
          return (
            <button
              key={action.id}
              onClick={() => onNavigate(action.id)}
              className="flex flex-col items-center gap-1.5 p-2.5 rounded-2xl bg-slate-900 hover:bg-slate-850 border border-slate-800/90 hover:border-emerald-500/40 transition-all active:scale-95 group cursor-pointer shadow-sm"
            >
              <div
                className={`w-11 h-11 rounded-2xl bg-gradient-to-tr ${action.color} text-white flex items-center justify-center shadow-md shadow-emerald-950/40 group-hover:scale-105 transition-transform`}
              >
                <Icon className="w-5 h-5" />
              </div>
              <span className="text-[11px] font-semibold text-slate-200">{action.label}</span>
            </button>
          );
        })}
      </div>

      {/* Master Control & Sovereign System Banner */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
        {/* Full Settings & God Mode Quick Tile */}
        <div
          onClick={() => onNavigate('settings')}
          className="p-3.5 rounded-2xl bg-gradient-to-br from-amber-950/40 via-slate-900 to-slate-900 border border-amber-500/30 flex items-center justify-between cursor-pointer hover:border-amber-400 transition-all shadow-md group"
        >
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-amber-500/20 text-amber-300 group-hover:rotate-12 transition-transform">
              <Sliders className="w-4 h-4" />
            </div>
            <div>
              <div className="text-xs font-bold text-white flex items-center gap-1.5">
                <span>الإعدادات والتحكم السيادي</span>
                <span className="text-[9px] px-1.5 py-0.2 bg-amber-500/20 text-amber-300 rounded-full font-mono font-bold">FULL</span>
              </div>
              <div className="text-[10px] text-slate-400">تعديل الأرصدة، الصرف، والأمان</div>
            </div>
          </div>
          <ChevronLeft className="w-4 h-4 text-amber-400 group-hover:translate-x-[-2px] transition-transform" />
        </div>

        {/* System Architecture Tree */}
        <div
          onClick={onOpenSystemViewer}
          className="p-3.5 rounded-2xl bg-gradient-to-br from-emerald-950/40 via-slate-900 to-slate-900 border border-emerald-500/30 flex items-center justify-between cursor-pointer hover:border-emerald-400 transition-all shadow-md group"
        >
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-emerald-500/20 text-emerald-300 group-hover:scale-105 transition-transform">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <div className="text-xs font-bold text-white flex items-center gap-1.5">
                <span>معمارية المنظومة (42 فرعاً)</span>
                <span className="text-[9px] px-1.5 py-0.2 bg-emerald-600 text-white rounded-full">جاهزة</span>
              </div>
              <div className="text-[10px] text-slate-400">استكشف الشجرة الكاملة للملفات</div>
            </div>
          </div>
          <ChevronLeft className="w-4 h-4 text-emerald-400 group-hover:translate-x-[-2px] transition-transform" />
        </div>
      </div>

      {/* Standalone Mobile App Install Banner */}
      <div 
        onClick={() => setIsInstallModalOpen(true)}
        className="p-3.5 rounded-2xl bg-gradient-to-r from-blue-950/70 via-slate-900 to-emerald-950/60 border border-blue-500/30 hover:border-emerald-400/50 flex items-center justify-between cursor-pointer transition-all shadow-lg active:scale-98 group"
      >
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-xl bg-blue-600/20 text-blue-400 border border-blue-500/30 group-hover:bg-emerald-500/20 group-hover:text-emerald-400 transition-colors">
            <Smartphone className="w-4 h-4" />
          </div>
          <div>
            <div className="text-xs font-bold text-white flex items-center gap-1.5">
              <span>تثبيت تطبيق المحفظة على هاتفك</span>
              <span className="text-[9px] px-1.5 py-0.2 bg-blue-500/20 text-blue-300 border border-blue-500/30 rounded-full font-bold">
                مستقل كالآب ستور
              </span>
            </div>
            <div className="text-[10px] text-slate-400">يعمل بدون متصفح وبدون إنترنت على أي جهاز محمول</div>
          </div>
        </div>
        <div className="flex items-center gap-1 text-xs font-bold text-emerald-400">
          <span>تثبيت</span>
          <Download className="w-3.5 h-3.5 group-hover:translate-y-0.5 transition-transform" />
        </div>
      </div>

      {/* Services Grid (6 Core Cards) */}
      <div className="space-y-2.5">
        <div className="flex justify-between items-center text-xs">
          <h3 className="font-bold text-slate-200">الخدمات المصرفية والمدفوعات</h3>
          <span className="text-[10px] text-emerald-400 font-mono">سداد لحظي</span>
        </div>

        <div className="grid grid-cols-2 gap-2.5">
          {services.map((srv) => {
            const SrvIcon = srv.icon;
            return (
              <button
                key={srv.id}
                onClick={() => onNavigate(srv.id)}
                className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800/80 hover:border-emerald-500/40 text-right transition-all flex flex-col justify-between group active:scale-[0.98] cursor-pointer"
              >
                <div className="flex items-center justify-between mb-2">
                  <div className="p-2 rounded-xl bg-slate-950 border border-slate-800 text-emerald-400 group-hover:text-emerald-300">
                    <SrvIcon className="w-4 h-4" />
                  </div>
                  <ChevronLeft className="w-3.5 h-3.5 text-slate-600 group-hover:text-slate-400" />
                </div>
                <div>
                  <div className="text-xs font-bold text-slate-100">{srv.label}</div>
                  <div className="text-[10px] text-slate-400 mt-0.5 line-clamp-1">{srv.desc}</div>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Recent Activity / Transactions Section */}
      <div className="space-y-2.5">
        <div className="flex justify-between items-center text-xs">
          <h3 className="font-bold text-slate-200">أحدث العمليات المالية</h3>
          <button
            onClick={() => onNavigate('transactions')}
            className="text-emerald-400 hover:underline text-[11px] font-semibold cursor-pointer"
          >
            عرض الكل ({transactions.length})
          </button>
        </div>

        <div className="space-y-2">
          {recentTx.map((tx) => (
            <TransactionItem
              key={tx.id}
              transaction={tx}
              onClick={() => onNavigate('transaction_details')}
            />
          ))}
        </div>
      </div>

      {/* Standalone Install Modal */}
      <InstallStandaloneModal
        isOpen={isInstallModalOpen}
        onClose={() => setIsInstallModalOpen(false)}
        appName="تطبيق العميل - نصر والت (User Client App)"
      />
    </div>
  );
};

