// src/features/user/Register.tsx
import React, { useState } from 'react';
import { User, Phone, Mail, Lock, ArrowLeft } from 'lucide-react';
import { Button } from '../../components/ui/Button';
import { Input } from '../../components/ui/Input';
import { useAuth } from '../../context/AuthContext';
import { useWallet } from '../../context/WalletContext';

interface Props {
  onNextOtp: (phone: string) => void;
  onNavigateLogin: () => void;
}

export const Register: React.FC<Props> = ({ onNextOtp, onNavigateLogin }) => {
  const { register } = useAuth();
  const { showToast } = useWallet();
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [pin, setPin] = useState('');
  const [agreeTerms, setAgreeTerms] = useState(true);

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!agreeTerms) {
      showToast('يرجى الموافقة على الشروط والأحكام المصرفية', 'warning');
      return;
    }
    await register({ name, phone, email, pin });
    onNextOtp(phone);
  };

  return (
    <div className="min-h-[580px] p-6 bg-slate-950 text-slate-100 flex flex-col justify-between">
      <div className="space-y-5">
        <div>
          <span className="text-[11px] font-mono text-emerald-400 bg-emerald-950 px-2 py-0.5 rounded-md border border-emerald-800/40">
            حساب نصر والت جديد
          </span>
          <h2 className="text-2xl font-bold text-white mt-2">إنشاء محفظة إلكترونية</h2>
          <p className="text-xs text-slate-400 mt-1">سجل بياناتك للبدء في إدارة أموالك بحرية وسيادية</p>
          <div className="mt-2 p-2 bg-blue-950/40 border border-blue-500/30 rounded-xl text-[11px] text-blue-300 flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-blue-400 shrink-0" />
            <span>يتم إرسال طلب تسجيل العميل تلقائياً للنظام المركزي للموافقة والاعتماد الفوري</span>
          </div>
        </div>

        <form onSubmit={handleRegister} className="space-y-3.5">
          <Input
            label="الاسم الكامل (رباعي حسب الهوية)"
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="محمد ناصر اليماني"
            prefixIcon={<User className="w-4 h-4" />}
            required
          />

          <Input
            label="رقم الهاتف الأساسي"
            type="tel"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            placeholder="770000000"
            prefixIcon={<Phone className="w-4 h-4" />}
            required
          />

          <Input
            label="البريد الإلكتروني (اختياري)"
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="name@example.com"
            prefixIcon={<Mail className="w-4 h-4" />}
          />

          <Input
            label="رمز السري للمحفظة (PIN - 4 أرقام)"
            type="password"
            maxLength={4}
            value={pin}
            onChange={(e) => setPin(e.target.value)}
            placeholder="••••"
            prefixIcon={<Lock className="w-4 h-4" />}
            required
          />

          <label className="flex items-center gap-2 text-xs text-slate-300 cursor-pointer pt-1">
            <input
              type="checkbox"
              checked={agreeTerms}
              onChange={(e) => setAgreeTerms(e.target.checked)}
              className="accent-emerald-500 rounded"
            />
            <span>أوافق على الشروط والسياسات المالية لمحفظة نصر والت</span>
          </label>

          <Button
            type="submit"
            variant="primary"
            size="lg"
            className="w-full mt-2"
            icon={<ArrowLeft className="w-4 h-4" />}
            iconPosition="left"
          >
            متابعة التحقق برمز OTP
          </Button>
        </form>
      </div>

      <div className="text-center pt-4 border-t border-slate-900 text-xs text-slate-400">
        لديك حساب بالفعل؟{' '}
        <button
          onClick={onNavigateLogin}
          className="text-emerald-400 font-bold hover:underline ml-1"
        >
          تسجيل الدخول
        </button>
      </div>
    </div>
  );
};
