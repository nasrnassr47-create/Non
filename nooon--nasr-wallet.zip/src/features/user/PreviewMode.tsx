// src/features/user/PreviewMode.tsx
import React, { useState } from 'react';
import { ArrowRight, Smartphone, Eye, Check, Sparkles, Layers } from 'lucide-react';
import { Button } from '../../components/ui/Button';

interface Props {
  onBack: () => void;
  onSelectScreen: (screenId: string) => void;
  activeScreen: string;
}

export const USER_SCREENS = [
  { id: 'splash', name: '1. شاشة البداية (Splash)', cat: 'auth' },
  { id: 'onboarding', name: '2. شاشات الترحيب والتعريف (Onboarding)', cat: 'auth' },
  { id: 'login', name: '3. تسجيل الدخول (Login)', cat: 'auth' },
  { id: 'register', name: '4. إنشاء حساب جديد (Register)', cat: 'auth' },
  { id: 'otp', name: '5. التحقق برمز OTP', cat: 'auth' },
  { id: 'kyc', name: '6. توثيق الهوية (KYC Level 3)', cat: 'auth' },
  { id: 'set_pin', name: '7. تعيين رمز PIN السري', cat: 'auth' },
  { id: 'dashboard', name: '8. لوحة التحكم الرئيسية (Dashboard)', cat: 'main' },
  { id: 'send', name: '9. تحويل مالي فوري (Send P2P)', cat: 'money' },
  { id: 'receive', name: '10. طلب واستلام أموال (Receive QR)', cat: 'money' },
  { id: 'scan_qr', name: '11. مسح كود QR للدفع (Scan & Pay)', cat: 'money' },
  { id: 'transactions', name: '12. سجل العمليات والقيود (Transactions)', cat: 'money' },
  { id: 'transaction_details', name: '13. إيصال وتفاصيل العملية (Receipt)', cat: 'money' },
  { id: 'cards', name: '14. إدارة البطاقات المصرفية (Cards Stack)', cat: 'cards' },
  { id: 'add_card', name: '15. إصدار بطاقة جديدة (Add Card)', cat: 'cards' },
  { id: 'bills', name: '16. سداد الفواتير والاتصالات (Bill Payment)', cat: 'services' },
  { id: 'topup', name: '17. تغذية رصيد المحفظة (Top-Up)', cat: 'services' },
  { id: 'profile', name: '18. الملف الشخصي والبيانات (Profile)', cat: 'settings' },
  { id: 'settings', name: '19. إعدادات المحفظة والتطبيق (Settings)', cat: 'settings' },
  { id: 'security', name: '20. إعدادات الأمان والـ PIN (Security)', cat: 'settings' },
  { id: 'notifications', name: '21. مركز التنبيهات والإشعارات (Notifications)', cat: 'settings' },
  { id: 'support', name: '22. الدعم الفني وخدمة العملاء (Support 24/7)', cat: 'services' },
  { id: 'addons', name: '23. الخدمات الإضافية والادخار (Addons)', cat: 'services' },
  { id: 'preview', name: '24. استعراض كافة الشاشات (Preview Mode)', cat: 'system' },
  { id: 'system_viewer', name: '25. عارض النظام السيادي (42 فرعاً)', cat: 'system' }
];

export const PreviewMode: React.FC<Props> = ({ onBack, onSelectScreen, activeScreen }) => {
  return (
    <div className="p-5 bg-slate-950 text-slate-100 min-h-[580px] flex flex-col justify-between select-none">
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <button
              onClick={onBack}
              className="p-1.5 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 hover:text-white"
            >
              <ArrowRight className="w-5 h-5" />
            </button>
            <h2 className="text-lg font-bold text-white">معاينة جميع شاشات المستخدم</h2>
          </div>
          <span className="text-[11px] font-mono text-emerald-400 bg-emerald-950 px-2 py-0.5 rounded-lg border border-emerald-800/40">
            25 شاشة مكتملة
          </span>
        </div>

        <p className="text-xs text-slate-400">
          انقر فوق أي شاشة للانتقال إليها وتجربتها فوراً ببيانات تفاعلية حية:
        </p>

        {/* Screens Grid */}
        <div className="space-y-1.5 max-h-[430px] overflow-y-auto pr-1">
          {USER_SCREENS.map((sc) => {
            const isActive = activeScreen === sc.id;
            return (
              <button
                key={sc.id}
                onClick={() => onSelectScreen(sc.id)}
                className={`w-full p-2.5 rounded-2xl flex items-center justify-between text-right text-xs transition-all cursor-pointer ${
                  isActive
                    ? 'bg-emerald-600 text-white font-bold shadow-md shadow-emerald-950'
                    : 'bg-slate-900 border border-slate-800 text-slate-300 hover:bg-slate-850 hover:text-white'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <Smartphone className="w-4 h-4 shrink-0" />
                  <span>{sc.name}</span>
                </div>
                {isActive && <Check className="w-4 h-4 text-emerald-200" />}
              </button>
            );
          })}
        </div>
      </div>

      <div className="text-center text-[10px] text-slate-500 font-mono">
        نظام محفظة نصر والت V2 • 25 شاشة متكاملة للمستخدم
      </div>
    </div>
  );
};
