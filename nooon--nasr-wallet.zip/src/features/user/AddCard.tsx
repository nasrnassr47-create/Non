// src/features/user/AddCard.tsx
import React, { useState } from 'react';
import { ArrowRight, CreditCard, CheckCircle2, ShieldCheck } from 'lucide-react';
import { Button } from '../../components/ui/Button';
import { Input } from '../../components/ui/Input';
import { useWallet } from '../../context/WalletContext';
import { useAuth } from '../../context/AuthContext';

interface Props {
  onBack: () => void;
  onSuccess: () => void;
}

export const AddCard: React.FC<Props> = ({ onBack, onSuccess }) => {
  const { addCard, showToast, activeWallet } = useWallet();
  const { currentUser } = useAuth();

  const [cardType, setCardType] = useState<'virtual' | 'physical'>('virtual');
  const [brand, setBrand] = useState<'visa' | 'mastercard' | 'humyar'>('visa');
  const [label, setLabel] = useState('بطاقتي للشراء عبر الإنترنت');
  const [dailyLimit, setDailyLimit] = useState('500');

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    const randomSuffix = Math.floor(1000 + Math.random() * 9000);
    const newCardNumber = `4284 8920 1192 ${randomSuffix}`;

    addCard({
      walletId: activeWallet.id,
      cardNumber: newCardNumber,
      cardHolder: currentUser.name,
      cardholderName: currentUser.name,
      expiryMonth: '12',
      expiryYear: '28',
      expiryDate: '12/28',
      cvv: `${Math.floor(100 + Math.random() * 900)}`,
      brand,
      cardType: brand === 'mastercard' ? 'virtual_mastercard' : 'virtual_visa',
      isFrozen: false,
      dailyLimit: parseFloat(dailyLimit) || 500,
      monthlyLimit: (parseFloat(dailyLimit) || 500) * 15,
      currency: 'USD',
      colorTheme: 'emerald'
    });

    onSuccess();
  };

  return (
    <div className="p-5 bg-slate-950 text-slate-100 min-h-[580px] flex flex-col justify-between select-none">
      <div className="space-y-4">
        <div className="flex items-center gap-2">
          <button
            onClick={onBack}
            className="p-1.5 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 hover:text-white"
          >
            <ArrowRight className="w-5 h-5" />
          </button>
          <h2 className="text-lg font-bold text-white">إصدار بطاقة مصرفية فورية</h2>
        </div>

        <form onSubmit={handleCreate} className="space-y-4">
          <div className="space-y-1 text-right">
            <label className="text-xs font-medium text-slate-300">نوع البطاقة:</label>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => setCardType('virtual')}
                className={`flex-1 py-2.5 rounded-xl text-xs font-bold border transition-all ${
                  cardType === 'virtual'
                    ? 'bg-emerald-600/20 border-emerald-500 text-emerald-400'
                    : 'bg-slate-900 border-slate-800 text-slate-400'
                }`}
              >
                افتراضية فورية (Virtual)
              </button>
              <button
                type="button"
                onClick={() => setCardType('physical')}
                className={`flex-1 py-2.5 rounded-xl text-xs font-bold border transition-all ${
                  cardType === 'physical'
                    ? 'bg-emerald-600/20 border-emerald-500 text-emerald-400'
                    : 'bg-slate-900 border-slate-800 text-slate-400'
                }`}
              >
                بلاستيكية مع توصيل (Physical)
              </button>
            </div>
          </div>

          <div className="space-y-1 text-right">
            <label className="text-xs font-medium text-slate-300">الشبكة المصرفية:</label>
            <div className="flex gap-2">
              {[
                { id: 'visa', label: 'Visa الدولية' },
                { id: 'mastercard', label: 'Mastercard' },
                { id: 'humyar', label: 'حمير الوطنية (محلي)' }
              ].map((b) => (
                <button
                  key={b.id}
                  type="button"
                  onClick={() => setBrand(b.id as any)}
                  className={`flex-1 py-2 rounded-xl text-xs font-semibold border transition-all ${
                    brand === b.id
                      ? 'bg-indigo-600/20 border-indigo-500 text-indigo-300'
                      : 'bg-slate-900 border-slate-800 text-slate-400'
                  }`}
                >
                  {b.label}
                </button>
              ))}
            </div>
          </div>

          <Input
            label="اسم حامل البطاقة (يطبع على البطاقة)"
            type="text"
            value={currentUser.name}
            disabled
            className="bg-slate-900/50 text-slate-400"
          />

          <Input
            label="تسمية البطاقة للتفرقة"
            type="text"
            value={label}
            onChange={(e) => setLabel(e.target.value)}
            placeholder="مثال: بطاقة الإعلانات أو السفر"
          />

          <Input
            label="الحد اليومي للإنفاق (دولار USD)"
            type="number"
            value={dailyLimit}
            onChange={(e) => setDailyLimit(e.target.value)}
            placeholder="500"
          />

          <Button
            type="submit"
            variant="primary"
            size="lg"
            className="w-full mt-3"
            icon={<CheckCircle2 className="w-4 h-4" />}
          >
            إصدار وتنشيط البطاقة الآن
          </Button>
        </form>
      </div>

      <div className="text-center text-[10px] text-slate-500 font-mono">
        إصدار فوري بدون رسوم فتح حساب • قبول دولي في جميع المواقع
      </div>
    </div>
  );
};
