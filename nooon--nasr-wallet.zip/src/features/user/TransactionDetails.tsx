// src/features/user/TransactionDetails.tsx
import React from 'react';
import { ArrowRight, CheckCircle2, Share2, Copy, Shield, FileText, Download } from 'lucide-react';
import { Button } from '../../components/ui/Button';
import { useWallet } from '../../context/WalletContext';
import { formatDate } from '../../lib/format';
import { copyToClipboard } from '../../lib/utils';

interface Props {
  txId?: string;
  onBack: () => void;
}

export const TransactionDetails: React.FC<Props> = ({ txId, onBack }) => {
  const { transactions, showToast } = useWallet();
  const tx = transactions.find(t => t.id === txId) || transactions[0];

  const handleCopyRef = async () => {
    await copyToClipboard(tx.refNo);
    showToast('تم نسخ الرقم المرجعي للعملية', 'success');
  };

  return (
    <div className="p-5 bg-slate-950 text-slate-100 min-h-[580px] flex flex-col justify-between select-none">
      <div className="space-y-4">
        <div className="flex items-center gap-2">
          <button
            onClick={onBack}
            className="p-1.5 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 hover:text-white"
          >
            <ArrowRight className="w-5 h-5" />
          </button>
          <h2 className="text-lg font-bold text-white">إيصال العملية الإلكتروني</h2>
        </div>

        {/* Receipt Container */}
        <div className="p-5 rounded-3xl bg-slate-900 border border-slate-800 space-y-4 shadow-xl relative overflow-hidden">
          {/* Header Status */}
          <div className="text-center pb-3 border-b border-slate-800">
            <div className="w-12 h-12 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto mb-2 border border-emerald-500/40">
              <CheckCircle2 className="w-7 h-7" />
            </div>
            <div className="text-xs text-slate-400">عملية ناجحة ومكتملة</div>
            <div className="text-2xl font-bold text-white font-mono mt-1">
              {tx.amount.toLocaleString()} {tx.currency}
            </div>
            <div className="text-xs text-emerald-400 font-semibold mt-0.5">{tx.title}</div>
          </div>

          {/* Details Table */}
          <div className="space-y-2.5 text-xs">
            <div className="flex justify-between items-center">
              <span className="text-slate-400">الرقم المرجعي (Ref):</span>
              <button
                onClick={handleCopyRef}
                className="flex items-center gap-1 font-mono text-emerald-400 hover:underline font-bold"
              >
                <span>{tx.refNo}</span>
                <Copy className="w-3 h-3" />
              </button>
            </div>

            <div className="flex justify-between">
              <span className="text-slate-400">تاريخ ووقت القيد:</span>
              <span className="font-mono text-slate-300">{formatDate(tx.timestamp)}</span>
            </div>

            <div className="flex justify-between">
              <span className="text-slate-400">المرسل:</span>
              <span className="text-slate-200">{tx.senderName}</span>
            </div>

            <div className="flex justify-between">
              <span className="text-slate-400">المستلم:</span>
              <span className="text-slate-200">{tx.receiverName || tx.receiverPhone}</span>
            </div>

            <div className="flex justify-between">
              <span className="text-slate-400">العمولة المصرفية:</span>
              <span className="text-emerald-400 font-bold">0.00 (مجاناً)</span>
            </div>

            {tx.notes && (
              <div className="flex justify-between">
                <span className="text-slate-400">البيان / الملاحظة:</span>
                <span className="text-slate-300">{tx.notes}</span>
              </div>
            )}

            {/* Cryptographic Hash */}
            <div className="pt-2 border-t border-slate-800 text-[10px]">
              <span className="text-slate-500 block mb-1 flex items-center gap-1">
                <Shield className="w-3 h-3 text-emerald-500" /> البصمة الرقمية للعملية (SHA-256):
              </span>
              <div className="font-mono text-slate-400 break-all bg-slate-950 p-2 rounded-xl border border-slate-800/80">
                {tx.hash || 'sha256:e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'}
              </div>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex gap-2">
          <Button
            variant="secondary"
            className="flex-1"
            icon={<Download className="w-4 h-4" />}
            onClick={() => showToast('تم تنزيل إيصال العملية PDF', 'success')}
          >
            تنزيل الإيصال
          </Button>
          <Button
            variant="primary"
            className="flex-1"
            icon={<Share2 className="w-4 h-4" />}
            onClick={() => showToast('تمت مشاركة الإيصال عبر الواتساب', 'info')}
          >
            مشاركة الإيصال
          </Button>
        </div>
      </div>

      <div className="text-center text-[10px] text-slate-500 font-mono">
        إيصال إلكتروني معتمد رسمياً بموجب قانون المعاملات والمدفوعات الإلكترونية
      </div>
    </div>
  );
};
