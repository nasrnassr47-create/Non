// src/features/user/SetPin.tsx
import React, { useState } from 'react';
import { Lock, CheckCircle2 } from 'lucide-react';
import { Button } from '../../components/ui/Button';
import { useAuth } from '../../context/AuthContext';
import { useWallet } from '../../context/WalletContext';

interface Props {
  onSuccess: () => void;
}

export const SetPin: React.FC<Props> = ({ onSuccess }) => {
  const { setPin } = useAuth();
  const { showToast } = useWallet();
  const [pin, setPinValue] = useState('');
  const [confirmPin, setConfirmPin] = useState('');

  const handleSetPin = (e: React.FormEvent) => {
    e.preventDefault();
    if (pin.length < 4) {
      showToast('يجب أن يتكون الرمز السري من 4 أرقام على الأقل', 'warning');
      return;
    }
    if (pin !== confirmPin) {
      showToast('الرمز السري غير متطابق', 'error');
      return;
    }
    setPin(pin);
    showToast('تم تعيين الرمز السري للمحفظة بنجاح', 'success');
    onSuccess();
  };

  return (
    <div className="min-h-[580px] p-6 bg-slate-950 text-slate-100 flex flex-col justify-between">
      <div className="space-y-6">
        <div>
          <span className="text-[11px] font-mono text-emerald-400 bg-emerald-950 px-2 py-0.5 rounded-md border border-emerald-800/40">
            الحماية والسرية
          </span>
          <h2 className="text-2xl font-bold text-white mt-2">تعيين رمز PIN السري</h2>
          <p className="text-xs text-slate-400 mt-1">
            سيُطلب منك هذا الرمز لتأكيد أي تحويل مالي أو سداد فاتورة أو سحب نقدي
          </p>
        </div>

        <form onSubmit={handleSetPin} className="space-y-4">
          <div className="space-y-1 text-right">
            <label className="text-xs text-slate-300 font-medium">أدخل الرمز السري الجديد (4 أرقام):</label>
            <input
              type="password"
              maxLength={4}
              value={pin}
              onChange={(e) => setPinValue(e.target.value)}
              placeholder="••••"
              className="w-full text-center tracking-[1em] text-2xl font-mono py-3 bg-slate-900 border border-slate-700 rounded-2xl text-white outline-none focus:border-emerald-500"
              required
            />
          </div>

          <div className="space-y-1 text-right">
            <label className="text-xs text-slate-300 font-medium">أعد كتابة الرمز السري للتأكيد:</label>
            <input
              type="password"
              maxLength={4}
              value={confirmPin}
              onChange={(e) => setConfirmPin(e.target.value)}
              placeholder="••••"
              className="w-full text-center tracking-[1em] text-2xl font-mono py-3 bg-slate-900 border border-slate-700 rounded-2xl text-white outline-none focus:border-emerald-500"
              required
            />
          </div>

          <Button
            type="submit"
            variant="primary"
            size="lg"
            className="w-full mt-4"
            icon={<CheckCircle2 className="w-4 h-4" />}
            iconPosition="left"
          >
            تثبيت رمز الحماية والدخول
          </Button>
        </form>
      </div>

      <div className="text-center text-xs text-slate-500">
        تنبيه: لا تشارك رمز PIN الخاص بك مطلقاً مع أي شخص، حتى موظفي خدمة العملاء.
      </div>
    </div>
  );
};
