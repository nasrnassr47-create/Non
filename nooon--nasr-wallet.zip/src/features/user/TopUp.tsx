// src/features/user/TopUp.tsx
import React, { useState } from 'react';
import { ArrowRight, PlusCircle, Building2, MapPin, CreditCard, CheckCircle2 } from 'lucide-react';
import { Button } from '../../components/ui/Button';
import { Input } from '../../components/ui/Input';
import { useWallet } from '../../context/WalletContext';

interface Props {
  onBack: () => void;
  onNavigateAgent?: () => void;
}

export const TopUp: React.FC<Props> = ({ onBack, onNavigateAgent }) => {
  const { activeWallet, showToast, activeCurrency } = useWallet();
  const [method, setMethod] = useState<'agent' | 'bank' | 'card'>('agent');
  const [amount, setAmount] = useState('10000');

  const methods = [
    {
      id: 'agent',
      title: 'إيداع نقدي عبر أقرب وكيل / صراف',
      desc: 'أكثر من 15,000 نقطة وكيل معتمد في عموم محافظات اليمن',
      icon: MapPin,
      badge: 'فوري ونقدي'
    },
    {
      id: 'bank',
      title: 'تحويل بنكي مباشر (سويفت محلي)',
      desc: 'بنك الكريمي، بنك التضامن، بنك اليمن والكويت، كاك بنك',
      icon: Building2,
      badge: 'حساب إلى حساب'
    },
    {
      id: 'card',
      title: 'بطاقة بنكية دولية / محلية',
      desc: 'Visa, Mastercard أو بطاقات الدفع المباشر',
      icon: CreditCard,
      badge: 'شحن فوري'
    }
  ];

  return (
    <div className="p-5 bg-slate-950 text-slate-100 min-h-[580px] flex flex-col justify-between select-none">
      <div className="space-y-4">
        <div className="flex items-center gap-2">
          <button
            onClick={onBack}
            className="p-1.5 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 hover:text-white"
          >
            <ArrowRight className="w-5 h-5" />
          </button>
          <h2 className="text-lg font-bold text-white">تغذية رصيد المحفظة</h2>
        </div>

        <div className="p-3.5 rounded-2xl bg-gradient-to-r from-emerald-950 to-slate-900 border border-emerald-500/30 flex justify-between items-center text-xs">
          <div>
            <span className="text-slate-400 block text-[11px]">حسابك للإيداع:</span>
            <span className="font-bold text-white font-mono">{activeWallet.accountNumber}</span>
          </div>
          <div className="text-left">
            <span className="text-slate-400 block text-[11px]">الرصيد الحالي:</span>
            <span className="font-bold text-emerald-400 font-mono">
              {activeWallet.balance.toLocaleString()} {activeWallet.symbol}
            </span>
          </div>
        </div>

        {/* Methods */}
        <div className="space-y-2">
          <label className="text-xs font-medium text-slate-300">اختر طريقة التغذية:</label>
          {methods.map((m) => {
            const Icon = m.icon;
            const isSelected = method === m.id;
            return (
              <div
                key={m.id}
                onClick={() => setMethod(m.id as any)}
                className={`p-3 rounded-2xl border cursor-pointer transition-all ${
                  isSelected
                    ? 'bg-emerald-950/60 border-emerald-500 shadow-md'
                    : 'bg-slate-900 border-slate-800 hover:border-slate-700'
                }`}
              >
                <div className="flex items-start gap-3">
                  <div className={`p-2.5 rounded-xl ${isSelected ? 'bg-emerald-500 text-white' : 'bg-slate-800 text-slate-400'}`}>
                    <Icon className="w-4 h-4" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-white">{m.title}</span>
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-950 font-mono text-emerald-400 border border-slate-800">
                        {m.badge}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-400 mt-1">{m.desc}</p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {method === 'agent' && (
          <div className="p-3 bg-slate-900 rounded-2xl border border-slate-800 text-xs space-y-2">
            <div className="text-slate-300">
              توجه لأي وكيل صرافة وأعطه رقم حساب محفظتك: <strong className="text-emerald-400 font-mono">{activeWallet.accountNumber}</strong> أو رقم هاتفك.
            </div>
            {onNavigateAgent && (
              <Button
                variant="secondary"
                size="sm"
                className="w-full"
                onClick={onNavigateAgent}
              >
                البحث عن أقرب وكيل على الخريطة
              </Button>
            )}
          </div>
        )}

        {method !== 'agent' && (
          <div className="space-y-3">
            <Input
              label="المبلغ المطلوب إيداعه"
              type="number"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="10000"
            />
            <Button
              variant="primary"
              size="lg"
              className="w-full"
              onClick={() => showToast('تم بدء طلب التغذية المصرفية بنجاح', 'success')}
            >
              متابعة الشحن الآن
            </Button>
          </div>
        )}
      </div>

      <div className="text-center text-[10px] text-slate-500 font-mono">
        إيداعات فورية مدعومة بأنظمة التحويل المالي السريع
      </div>
    </div>
  );
};
