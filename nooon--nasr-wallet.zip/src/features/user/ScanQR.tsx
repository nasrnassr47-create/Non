// src/features/user/ScanQR.tsx
import React, { useState } from 'react';
import { ArrowRight, Camera, Flashlight, Image, CheckCircle, Store, Send } from 'lucide-react';
import { Button } from '../../components/ui/Button';
import { useWallet } from '../../context/WalletContext';

interface Props {
  onBack: () => void;
  onScannedSuccess?: (payload: string) => void;
}

export const ScanQR: React.FC<Props> = ({ onBack, onScannedSuccess }) => {
  const { showToast, sendMoney, activeCurrency } = useWallet();
  const [torchOn, setTorchOn] = useState(false);
  const [scannedTarget, setScannedTarget] = useState<{
    name: string;
    phone: string;
    amount?: number;
  } | null>(null);
  const [amount, setAmount] = useState('2500');
  const [isProcessing, setIsProcessing] = useState(false);

  const handleSimulateScan = (type: 'merchant' | 'user') => {
    if (type === 'merchant') {
      setScannedTarget({
        name: 'سوبرماركت الجندول المركزي',
        phone: '778900112',
        amount: 3200
      });
      setAmount('3200');
    } else {
      setScannedTarget({
        name: 'أحمد علي الحميري',
        phone: '771234567'
      });
    }
    showToast('تم التقاط وقراءة كود QR بنجاح!', 'success');
  };

  const handlePay = async () => {
    if (!scannedTarget) return;
    setIsProcessing(true);
    try {
      const res = await sendMoney({
        receiverPhone: scannedTarget.phone,
        amount: parseFloat(amount) || 0,
        notes: `سداد مشتريات QR - ${scannedTarget.name}`
      });
      if (res.success) {
        setScannedTarget(null);
        onBack();
      }
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="p-5 bg-slate-950 text-slate-100 min-h-[580px] flex flex-col justify-between select-none">
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <button
              onClick={onBack}
              className="p-1.5 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 hover:text-white"
            >
              <ArrowRight className="w-5 h-5" />
            </button>
            <h2 className="text-lg font-bold text-white">مسح كود QR للدفع</h2>
          </div>
          <button
            onClick={() => setTorchOn(!torchOn)}
            className={`p-2 rounded-xl border transition-colors ${
              torchOn ? 'bg-amber-500/20 text-amber-400 border-amber-500/40' : 'bg-slate-900 text-slate-400 border-slate-800'
            }`}
          >
            <Flashlight className="w-4 h-4" />
          </button>
        </div>

        {!scannedTarget ? (
          <div className="space-y-4">
            {/* Viewfinder simulation box */}
            <div className="relative aspect-square max-w-[280px] mx-auto rounded-3xl overflow-hidden bg-slate-900 border-2 border-emerald-500/50 flex flex-col items-center justify-center p-4">
              {/* Corner markers */}
              <div className="absolute top-4 right-4 w-7 h-7 border-t-2 border-r-2 border-emerald-400 rounded-tr-lg" />
              <div className="absolute top-4 left-4 w-7 h-7 border-t-2 border-l-2 border-emerald-400 rounded-tl-lg" />
              <div className="absolute bottom-4 right-4 w-7 h-7 border-b-2 border-r-2 border-emerald-400 rounded-br-lg" />
              <div className="absolute bottom-4 left-4 w-7 h-7 border-b-2 border-l-2 border-emerald-400 rounded-bl-lg" />

              {/* Laser scanline animation */}
              <div className="absolute left-4 right-4 h-0.5 bg-emerald-400 shadow-lg shadow-emerald-400 animate-bounce duration-1000" />

              <Camera className="w-12 h-12 text-slate-600 mb-2" />
              <span className="text-xs text-slate-400 text-center">وجّه الكاميرا نحو باركود التاجر أو العميل</span>
            </div>

            {/* Simulation test triggers */}
            <div className="p-3 bg-slate-900 rounded-2xl border border-slate-800 space-y-2 text-right">
              <span className="text-[11px] font-bold text-slate-300 block">تجربة قراءة فورية (محاكاة):</span>
              <div className="flex gap-2">
                <Button
                  size="sm"
                  variant="secondary"
                  className="flex-1 text-[11px]"
                  icon={<Store className="w-3.5 h-3.5" />}
                  onClick={() => handleSimulateScan('merchant')}
                >
                  كود تاجر (سوبرماركت)
                </Button>
                <Button
                  size="sm"
                  variant="secondary"
                  className="flex-1 text-[11px]"
                  icon={<Send className="w-3.5 h-3.5" />}
                  onClick={() => handleSimulateScan('user')}
                >
                  كود عميل فردي
                </Button>
              </div>
            </div>
          </div>
        ) : (
          /* Scanned Result & Payment Screen */
          <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-4 animate-in fade-in duration-200">
            <div className="flex items-center gap-3 border-b border-slate-800 pb-3">
              <div className="p-2.5 rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                <Store className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-white text-sm">{scannedTarget.name}</h3>
                <p className="text-xs text-slate-400 font-mono mt-0.5">{scannedTarget.phone}</p>
              </div>
            </div>

            <div className="space-y-1 text-right">
              <label className="text-xs font-medium text-slate-300">مبلغ السداد ({activeCurrency}):</label>
              <input
                type="number"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="w-full text-2xl font-bold font-mono py-2.5 px-3 bg-slate-950 border border-slate-700 rounded-xl text-white outline-none focus:border-emerald-500"
              />
            </div>

            <div className="flex gap-2">
              <Button
                variant="secondary"
                className="flex-1"
                onClick={() => setScannedTarget(null)}
              >
                إلغاء
              </Button>
              <Button
                variant="primary"
                className="flex-2"
                isLoading={isProcessing}
                onClick={handlePay}
                icon={<CheckCircle className="w-4 h-4" />}
              >
                تأكيد الدفع الفوري
              </Button>
            </div>
          </div>
        )}
      </div>

      <div className="text-center text-[10px] text-slate-500 font-mono">
        يدعم قارئ الباركود معايير EMVCo و ISO 20022 العالمية
      </div>
    </div>
  );
};
