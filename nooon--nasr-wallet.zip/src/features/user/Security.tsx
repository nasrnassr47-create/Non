// src/features/user/Security.tsx
import React, { useState } from 'react';
import { ArrowRight, Lock, Fingerprint, Key, ShieldCheck, CheckCircle2 } from 'lucide-react';
import { Button } from '../../components/ui/Button';
import { Input } from '../../components/ui/Input';
import { useAuth } from '../../context/AuthContext';
import { useWallet } from '../../context/WalletContext';

interface Props {
  onBack: () => void;
}

export const Security: React.FC<Props> = ({ onBack }) => {
  const { setPin } = useAuth();
  const { showToast } = useWallet();
  const [currentPin, setCurrentPin] = useState('');
  const [newPin, setNewPin] = useState('');
  const [biometricEnabled, setBiometricEnabled] = useState(true);
  const [twoFactorEnabled, setTwoFactorEnabled] = useState(true);

  const handleUpdatePin = (e: React.FormEvent) => {
    e.preventDefault();
    if (newPin.length < 4) {
      showToast('رمز PIN يجب أن يكون 4 أرقام على الأقل', 'warning');
      return;
    }
    setPin(newPin);
    showToast('تم تحديث رمز PIN السري بنجاح', 'success');
    setCurrentPin('');
    setNewPin('');
  };

  return (
    <div className="p-5 bg-slate-950 text-slate-100 min-h-[580px] flex flex-col justify-between select-none">
      <div className="space-y-4">
        <div className="flex items-center gap-2">
          <button
            onClick={onBack}
            className="p-1.5 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 hover:text-white"
          >
            <ArrowRight className="w-5 h-5" />
          </button>
          <h2 className="text-lg font-bold text-white">إعدادات الأمان والتشفير</h2>
        </div>

        {/* Security Toggles */}
        <div className="space-y-3">
          <div className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800 flex justify-between items-center">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-slate-800 text-emerald-400">
                <Fingerprint className="w-4 h-4" />
              </div>
              <div>
                <div className="text-xs font-bold text-white">الدخول بالبصمة / Face ID</div>
                <div className="text-[11px] text-slate-400">تأكيد فوري للعمليات المصرفية</div>
              </div>
            </div>
            <input
              type="checkbox"
              checked={biometricEnabled}
              onChange={(e) => {
                setBiometricEnabled(e.target.checked);
                showToast(e.target.checked ? 'تم تفعيل المصادقة البايومترية' : 'تم تعطيل المصادقة البايومترية', 'info');
              }}
              className="w-5 h-5 accent-emerald-500 rounded"
            />
          </div>

          <div className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800 flex justify-between items-center">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-slate-800 text-cyan-400">
                <ShieldCheck className="w-4 h-4" />
              </div>
              <div>
                <div className="text-xs font-bold text-white">المصادقة الثنائية (2FA) عبر OTP</div>
                <div className="text-[11px] text-slate-400">طلب رمز إضافي عند التحويل بمبالغ كبيرة</div>
              </div>
            </div>
            <input
              type="checkbox"
              checked={twoFactorEnabled}
              onChange={(e) => {
                setTwoFactorEnabled(e.target.checked);
                showToast(e.target.checked ? 'تم تفعيل المصادقة الثنائية' : 'تم تعطيل المصادقة الثنائية', 'info');
              }}
              className="w-5 h-5 accent-emerald-500 rounded"
            />
          </div>
        </div>

        {/* Change PIN form */}
        <form onSubmit={handleUpdatePin} className="p-4 rounded-3xl bg-slate-900 border border-slate-800 space-y-3">
          <h3 className="text-xs font-bold text-white flex items-center gap-1.5">
            <Lock className="w-3.5 h-3.5 text-emerald-400" /> تغيير رمز PIN السري للمحفظة
          </h3>

          <Input
            label="رمز PIN الحالي"
            type="password"
            maxLength={4}
            value={currentPin}
            onChange={(e) => setCurrentPin(e.target.value)}
            placeholder="••••"
            required
          />

          <Input
            label="رمز PIN الجديد"
            type="password"
            maxLength={4}
            value={newPin}
            onChange={(e) => setNewPin(e.target.value)}
            placeholder="••••"
            required
          />

          <Button type="submit" variant="primary" size="md" className="w-full">
            حفظ الرمز السري الجديد
          </Button>
        </form>
      </div>

      <div className="text-center text-[10px] text-slate-500 font-mono">
        حماية ضد هجمات إعادة التشغيل Replay Attacks وتشفير AES-GCM 256
      </div>
    </div>
  );
};
