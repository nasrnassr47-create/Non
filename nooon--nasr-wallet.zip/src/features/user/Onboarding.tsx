// src/features/user/Onboarding.tsx
import React, { useState } from 'react';
import { Smartphone, ShieldCheck, Zap, ArrowLeft, ArrowRight, Check } from 'lucide-react';
import { Button } from '../../components/ui/Button';

interface Props {
  onDone: () => void;
  onSkip?: () => void;
}

const slides = [
  {
    title: 'تحويلات P2P فورية بدون رسوم',
    desc: 'حوّل أموالك لأي رقم هاتف في اليمن بثوانٍ معدودة عبر القيد المزدوج المحاسبي الفوري.',
    icon: Zap,
    color: 'text-amber-400 bg-amber-500/10 border-amber-500/30'
  },
  {
    title: 'أمان سيادي وتشفير عالي',
    desc: 'حماية أموالك بتشفير متعدد الطبقات، ومصادقة بايومترية، وسجل تدقيق غير قابل للتعديل.',
    icon: ShieldCheck,
    color: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/30'
  },
  {
    title: 'كل خدماتك المالية بمكان واحد',
    desc: 'سداد فواتير الاتصالات، المياه، الكهرباء، البطاقات الرقمية، وإدارة ميزانية العائلة.',
    icon: Smartphone,
    color: 'text-cyan-400 bg-cyan-500/10 border-cyan-500/30'
  }
];

export const Onboarding: React.FC<Props> = ({ onDone, onSkip }) => {
  const [currentSlide, setCurrentSlide] = useState(0);

  const handleNext = () => {
    if (currentSlide < slides.length - 1) {
      setCurrentSlide(currentSlide + 1);
    } else {
      onDone();
    }
  };

  const slide = slides[currentSlide];
  const Icon = slide.icon;

  return (
    <div className="min-h-[580px] flex flex-col justify-between p-6 bg-slate-950 text-slate-100">
      <div className="flex justify-between items-center text-xs">
        <span className="font-mono text-slate-500">{currentSlide + 1} من {slides.length}</span>
        {onSkip && (
          <button onClick={onSkip} className="text-slate-400 hover:text-white">
            تخطي
          </button>
        )}
      </div>

      <div className="flex flex-col items-center text-center space-y-6 my-auto max-w-xs mx-auto">
        <div className={`p-6 rounded-3xl border shadow-xl ${slide.color}`}>
          <Icon className="w-14 h-14" />
        </div>
        <div className="space-y-2">
          <h2 className="text-xl font-bold text-white">{slide.title}</h2>
          <p className="text-xs text-slate-400 leading-relaxed">{slide.desc}</p>
        </div>

        {/* Indicators */}
        <div className="flex gap-2">
          {slides.map((_, i) => (
            <span
              key={i}
              className={`h-2 rounded-full transition-all ${
                i === currentSlide ? 'w-6 bg-emerald-500' : 'w-2 bg-slate-800'
              }`}
            />
          ))}
        </div>
      </div>

      <div className="w-full">
        <Button
          variant="primary"
          size="lg"
          className="w-full"
          onClick={handleNext}
          icon={currentSlide === slides.length - 1 ? <Check className="w-4 h-4" /> : <ArrowLeft className="w-4 h-4" />}
          iconPosition="left"
        >
          {currentSlide === slides.length - 1 ? 'ابدأ الآن' : 'التالي'}
        </Button>
      </div>
    </div>
  );
};
