// src/features/user/UserApp.tsx
import React, { useState } from 'react';
import { Splash } from './Splash';
import { Onboarding } from './Onboarding';
import { Login } from './Login';
import { Register } from './Register';
import { OTP } from './OTP';
import { KYC } from './KYC';
import { SetPin } from './SetPin';
import { Dashboard } from './Dashboard';
import { SendMoney } from './SendMoney';
import { ReceiveMoney } from './ReceiveMoney';
import { ScanQR } from './ScanQR';
import { Transactions } from './Transactions';
import { TransactionDetails } from './TransactionDetails';
import { Cards } from './Cards';
import { AddCard } from './AddCard';
import { BillPayment } from './BillPayment';
import { TopUp } from './TopUp';
import { Profile } from './Profile';
import { Settings } from './Settings';
import { Security } from './Security';
import { Notifications } from './Notifications';
import { Support } from './Support';
import { Addons } from './Addons';
import { PreviewMode } from './PreviewMode';
import { SystemViewer } from './SystemViewer';
import { MobileFrame } from '../../components/MobileFrame';
import { BottomNav, BottomNavItem } from '../../components/layout/BottomNav';
import { Home, Send, QrCode, CreditCard, Clock, Layers, Smartphone } from 'lucide-react';

interface UserAppProps {
  initialScreen?: string;
  onRequestRoleApp?: (role: string) => void;
  showFrame?: boolean;
}

export const UserApp: React.FC<UserAppProps> = ({
  initialScreen = 'dashboard',
  onRequestRoleApp,
  showFrame = true
}) => {
  const [currentScreen, setCurrentScreen] = useState<string>(initialScreen);
  const [activeTxId, setActiveTxId] = useState<string | undefined>(undefined);
  const [registrationPhone, setRegistrationPhone] = useState<string>('777100249');

  const navItems: BottomNavItem[] = [
    { id: 'dashboard', label: 'الرئيسية', icon: Home },
    { id: 'send', label: 'تحويل', icon: Send },
    { id: 'scan_qr', label: 'مسح QR', icon: QrCode },
    { id: 'cards', label: 'بطاقاتي', icon: CreditCard },
    { id: 'transactions', label: 'السجل', icon: Clock },
  ];

  const renderScreen = () => {
    switch (currentScreen) {
      case 'splash':
        return <Splash onFinish={() => setCurrentScreen('dashboard')} />;
      case 'onboarding':
        return <Onboarding onDone={() => setCurrentScreen('dashboard')} onSkip={() => setCurrentScreen('dashboard')} />;
      case 'login':
        return (
          <Login
            onSuccess={() => setCurrentScreen('dashboard')}
            onNavigateRegister={() => setCurrentScreen('register')}
          />
        );
      case 'register':
        return (
          <Register
            onNextOtp={(phone) => {
              setRegistrationPhone(phone);
              setCurrentScreen('otp');
            }}
            onNavigateLogin={() => setCurrentScreen('login')}
          />
        );
      case 'otp':
        return (
          <OTP
            phone={registrationPhone}
            onVerified={() => setCurrentScreen('kyc')}
            onBack={() => setCurrentScreen('register')}
          />
        );
      case 'kyc':
        return <KYC onDone={() => setCurrentScreen('set_pin')} onSkip={() => setCurrentScreen('set_pin')} />;
      case 'set_pin':
        return <SetPin onSuccess={() => setCurrentScreen('dashboard')} />;
      case 'send':
        return <SendMoney onBack={() => setCurrentScreen('dashboard')} />;
      case 'receive':
        return <ReceiveMoney onBack={() => setCurrentScreen('dashboard')} />;
      case 'scan_qr':
        return <ScanQR onBack={() => setCurrentScreen('dashboard')} />;
      case 'transactions':
        return (
          <Transactions
            onBack={() => setCurrentScreen('dashboard')}
            onSelectTx={(id) => {
              setActiveTxId(id);
              setCurrentScreen('transaction_details');
            }}
          />
        );
      case 'transaction_details':
        return <TransactionDetails txId={activeTxId} onBack={() => setCurrentScreen('transactions')} />;
      case 'cards':
        return (
          <Cards
            onBack={() => setCurrentScreen('dashboard')}
            onAddCard={() => setCurrentScreen('add_card')}
          />
        );
      case 'add_card':
        return (
          <AddCard
            onBack={() => setCurrentScreen('cards')}
            onSuccess={() => setCurrentScreen('cards')}
          />
        );
      case 'bills':
      case 'electricity':
        return <BillPayment onBack={() => setCurrentScreen('dashboard')} />;
      case 'topup':
        return (
          <TopUp
            onBack={() => setCurrentScreen('dashboard')}
            onNavigateAgent={() => onRequestRoleApp && onRequestRoleApp('agent')}
          />
        );
      case 'profile':
        return (
          <Profile
            onBack={() => setCurrentScreen('dashboard')}
            onNavigateSettings={() => setCurrentScreen('settings')}
            onNavigateSecurity={() => setCurrentScreen('security')}
          />
        );
      case 'settings':
        return (
          <Settings
            onBack={() => setCurrentScreen('dashboard')}
            onNavigateSecurity={() => setCurrentScreen('security')}
          />
        );
      case 'security':
        return <Security onBack={() => setCurrentScreen('settings')} />;
      case 'notifications':
        return <Notifications onBack={() => setCurrentScreen('dashboard')} />;
      case 'support':
        return <Support onBack={() => setCurrentScreen('dashboard')} />;
      case 'addons':
        return <Addons onBack={() => setCurrentScreen('dashboard')} />;
      case 'preview':
        return (
          <PreviewMode
            onBack={() => setCurrentScreen('dashboard')}
            onSelectScreen={(sc) => setCurrentScreen(sc)}
            activeScreen={currentScreen}
          />
        );
      case 'system_viewer':
        return (
          <SystemViewer
            onBack={() => setCurrentScreen('dashboard')}
            onRequestRoleApp={onRequestRoleApp}
          />
        );
      case 'dashboard':
      default:
        return (
          <Dashboard
            onNavigate={(screen) => setCurrentScreen(screen)}
            onOpenSystemViewer={() => setCurrentScreen('system_viewer')}
          />
        );
    }
  };

  const showBottomBar = ['dashboard', 'send', 'scan_qr', 'cards', 'transactions'].includes(currentScreen);

  return (
    <div className="flex flex-col items-center w-full">
      {/* Quick Screen Switcher Ribbon for Developer & Evaluator */}
      <div className="w-full max-w-lg mb-2 flex flex-wrap items-center justify-between gap-1.5 px-3 py-1.5 rounded-2xl bg-slate-900/90 border border-slate-800 text-xs">
        <div className="flex items-center gap-1.5 text-slate-300">
          <Smartphone className="w-4 h-4 text-emerald-400" />
          <span className="font-bold text-white text-[11px]">العميل:</span>
          <span className="text-emerald-400 font-mono text-[11px]">{currentScreen}</span>
        </div>
        <div className="flex items-center gap-1">
          <button
            onClick={() => setCurrentScreen('login')}
            className={`text-[10px] px-2 py-0.5 rounded-lg border font-semibold transition-all ${
              currentScreen === 'login'
                ? 'bg-blue-600 text-white border-blue-500'
                : 'bg-slate-800 text-slate-300 border-slate-700 hover:text-white'
            }`}
          >
            تسجيل دخول
          </button>
          <button
            onClick={() => setCurrentScreen('register')}
            className={`text-[10px] px-2 py-0.5 rounded-lg border font-semibold transition-all ${
              currentScreen === 'register'
                ? 'bg-emerald-600 text-white border-emerald-500'
                : 'bg-slate-800 text-slate-300 border-slate-700 hover:text-white'
            }`}
          >
            إنشاء حساب
          </button>
          <button
            onClick={() => setCurrentScreen('preview')}
            className="flex items-center gap-1 text-[10px] px-2 py-0.5 rounded-lg bg-emerald-600/20 text-emerald-300 border border-emerald-500/40 hover:bg-emerald-600 hover:text-white transition-all font-semibold"
          >
            <Layers className="w-3 h-3" />
            <span>25 شاشة</span>
          </button>
        </div>
      </div>

      {/* Main Mobile Screen */}
      {showFrame ? (
        <MobileFrame activeAppName="نصر والت V2">
          <div className="flex flex-col min-h-[640px] bg-slate-950 text-slate-100">
            <div className="flex-1 overflow-y-auto">{renderScreen()}</div>
            {showBottomBar && (
              <BottomNav
                items={navItems}
                activeId={currentScreen}
                onChange={(id) => setCurrentScreen(id)}
              />
            )}
          </div>
        </MobileFrame>
      ) : (
        <div className="w-full max-w-2xl bg-slate-950 border border-slate-800 rounded-3xl overflow-hidden shadow-2xl flex flex-col min-h-[640px]">
          <div className="flex-1 overflow-y-auto">{renderScreen()}</div>
          {showBottomBar && (
            <BottomNav
              items={navItems}
              activeId={currentScreen}
              onChange={(id) => setCurrentScreen(id)}
            />
          )}
        </div>
      )}
    </div>
  );
};
