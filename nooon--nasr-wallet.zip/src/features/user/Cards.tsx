// src/features/user/Cards.tsx
import React, { useState } from 'react';
import { ArrowRight, Plus, CreditCard, Lock, Unlock, Eye, EyeOff, ShieldCheck } from 'lucide-react';
import { Button } from '../../components/ui/Button';
import { useWallet } from '../../context/WalletContext';

interface Props {
  onBack: () => void;
  onAddCard: () => void;
}

export const Cards: React.FC<Props> = ({ onBack, onAddCard }) => {
  const { cards, toggleFreezeCard, showToast } = useWallet();
  const [showCvv, setShowCvv] = useState<Record<string, boolean>>({});

  const toggleCvv = (id: string) => {
    setShowCvv(prev => ({ ...prev, [id]: !prev[id] }));
  };

  return (
    <div className="p-5 bg-slate-950 text-slate-100 min-h-[580px] flex flex-col justify-between select-none">
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <button
              onClick={onBack}
              className="p-1.5 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 hover:text-white"
            >
              <ArrowRight className="w-5 h-5" />
            </button>
            <h2 className="text-lg font-bold text-white">البطاقات المصرفية والرقمية</h2>
          </div>
          <Button
            size="sm"
            variant="primary"
            icon={<Plus className="w-4 h-4" />}
            onClick={onAddCard}
          >
            بطاقة جديدة
          </Button>
        </div>

        {/* Cards Stack */}
        <div className="space-y-4 max-h-[440px] overflow-y-auto pr-1">
          {cards.map((card) => {
            const isFrozen = card.isFrozen;
            const isVisible = showCvv[card.id];

            return (
              <div
                key={card.id}
                className={`relative overflow-hidden rounded-3xl p-5 border transition-all ${
                  isFrozen
                    ? 'bg-slate-900/80 border-slate-700 opacity-75'
                    : 'bg-gradient-to-tr from-slate-900 via-indigo-950 to-slate-900 border-indigo-500/40 shadow-xl'
                }`}
              >
                {/* Brand & Chip */}
                <div className="flex justify-between items-start">
                  <div>
                    <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded-full bg-slate-800 text-indigo-300 border border-indigo-500/30">
                      {card.brand || 'VISA'} {card.cardType === 'virtual' || card.cardType === 'virtual_visa' || card.cardType === 'virtual_mastercard' ? 'رقمية' : 'بلاستيكية'}
                    </span>
                    <div className="text-sm font-bold text-white mt-1">{card.cardholderName || card.cardHolder}</div>
                  </div>
                  <div className="w-9 h-7 rounded-md bg-amber-400/80 border border-amber-300 flex items-center justify-center">
                    <div className="w-5 h-4 border border-amber-600/50 rounded-xs" />
                  </div>
                </div>

                {/* Card Number */}
                <div className="my-5">
                  <div className="text-lg sm:text-xl font-mono tracking-widest text-white font-bold text-center">
                    {isVisible ? card.cardNumber : `${card.cardNumber.slice(0, 4)} •••• •••• ${card.cardNumber.slice(-4)}`}
                  </div>
                </div>

                {/* Expiry & CVV */}
                <div className="flex justify-between items-end text-xs border-t border-slate-800/80 pt-3">
                  <div>
                    <span className="text-[10px] text-slate-400 block">تاريخ الانتهاء:</span>
                    <span className="font-mono text-white font-semibold">
                      {card.expiryDate || `${card.expiryMonth}/${card.expiryYear}`}
                    </span>
                  </div>

                  <div className="text-center">
                    <span className="text-[10px] text-slate-400 block">رمز الأمان CVV:</span>
                    <span className="font-mono text-emerald-400 font-bold">
                      {isVisible ? card.cvv : '•••'}
                    </span>
                  </div>

                  {/* Actions */}
                  <div className="flex gap-2">
                    <button
                      onClick={() => toggleCvv(card.id)}
                      className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300"
                      title="إظهار / إخفاء بيانات البطاقة"
                    >
                      {isVisible ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                    <button
                      onClick={() => toggleFreezeCard(card.id)}
                      className={`p-1.5 rounded-xl border transition-colors ${
                        isFrozen ? 'bg-red-500/20 text-red-400 border-red-500/40' : 'bg-slate-800 text-slate-300 border-slate-700'
                      }`}
                      title={isFrozen ? 'إلغاء التجميد' : 'تجميد البطاقة'}
                    >
                      {isFrozen ? <Unlock className="w-4 h-4" /> : <Lock className="w-4 h-4" />}
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <div className="text-center text-[10px] text-slate-500 font-mono">
        حماية 3D Secure ومعايير PCI-DSS للمدفوعات العالمية
      </div>
    </div>
  );
};
