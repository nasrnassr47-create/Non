// src/features/user/Profile.tsx
import React from 'react';
import { ArrowRight, User, Phone, Mail, ShieldCheck, MapPin, Edit3, LogOut } from 'lucide-react';
import { Avatar } from '../../components/ui/Avatar';
import { Badge } from '../../components/ui/Badge';
import { Button } from '../../components/ui/Button';
import { useAuth } from '../../context/AuthContext';

interface Props {
  onBack: () => void;
  onNavigateSettings?: () => void;
  onNavigateSecurity?: () => void;
}

export const Profile: React.FC<Props> = ({ onBack, onNavigateSettings, onNavigateSecurity }) => {
  const { currentUser, logout } = useAuth();

  return (
    <div className="p-5 bg-slate-950 text-slate-100 min-h-[580px] flex flex-col justify-between select-none">
      <div className="space-y-5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <button
              onClick={onBack}
              className="p-1.5 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 hover:text-white"
            >
              <ArrowRight className="w-5 h-5" />
            </button>
            <h2 className="text-lg font-bold text-white">الملف الشخصي</h2>
          </div>
          <Badge variant="success">حساب موثق رسمي</Badge>
        </div>

        {/* User Card */}
        <div className="p-5 rounded-3xl bg-slate-900 border border-slate-800 flex flex-col items-center text-center space-y-3">
          <Avatar name={currentUser.name} size="xl" status="online" />
          <div>
            <h3 className="text-base font-bold text-white">{currentUser.name}</h3>
            <p className="text-xs text-emerald-400 font-mono mt-0.5">{currentUser.phone}</p>
            <p className="text-[11px] text-slate-400 mt-1">الرقم الوطني: {currentUser.nationalId || '01019842109'}</p>
          </div>
        </div>

        {/* Info Rows */}
        <div className="p-4 rounded-3xl bg-slate-900 border border-slate-800 space-y-3 text-xs">
          <div className="flex justify-between items-center py-1 border-b border-slate-800/80">
            <span className="text-slate-400 flex items-center gap-1.5">
              <Mail className="w-4 h-4 text-emerald-400" /> البريد الإلكتروني:
            </span>
            <span className="text-white font-mono">{currentUser.email}</span>
          </div>

          <div className="flex justify-between items-center py-1 border-b border-slate-800/80">
            <span className="text-slate-400 flex items-center gap-1.5">
              <MapPin className="w-4 h-4 text-emerald-400" /> العنوان والمدينة:
            </span>
            <span className="text-white">{currentUser.address?.city || 'صنعاء'} - {currentUser.address?.street || 'شارع حدة'}</span>
          </div>

          <div className="flex justify-between items-center py-1">
            <span className="text-slate-400 flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-emerald-400" /> مستوى الامتثال (KYC):
            </span>
            <Badge variant="gold">المستوى 3 (أعلى سقف مالي)</Badge>
          </div>
        </div>

        {/* Quick actions */}
        <div className="grid grid-cols-2 gap-2">
          {onNavigateSecurity && (
            <Button variant="secondary" size="md" onClick={onNavigateSecurity}>
              إعدادات الأمان والـ PIN
            </Button>
          )}
          {onNavigateSettings && (
            <Button variant="secondary" size="md" onClick={onNavigateSettings}>
              تفضيلات النظام
            </Button>
          )}
        </div>
      </div>

      <Button
        variant="danger"
        size="md"
        className="w-full mt-4"
        icon={<LogOut className="w-4 h-4" />}
        onClick={logout}
      >
        تسجيل الخروج من الحساب
      </Button>
    </div>
  );
};
