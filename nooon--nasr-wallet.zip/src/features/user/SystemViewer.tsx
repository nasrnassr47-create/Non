// src/features/user/SystemViewer.tsx
import React from 'react';
import { ArrowRight, Sparkles } from 'lucide-react';
import { SystemVisualizer } from '../../components/SystemVisualizer';

interface Props {
  onBack: () => void;
  onRequestRoleApp?: (role: string) => void;
}

export const SystemViewer: React.FC<Props> = ({ onBack, onRequestRoleApp }) => {
  return (
    <div className="p-3 bg-slate-950 text-slate-100 min-h-[580px] flex flex-col justify-between select-none">
      <div className="space-y-3 flex-1 flex flex-col">
        <div className="flex items-center justify-between px-2 pt-2">
          <div className="flex items-center gap-2">
            <button
              onClick={onBack}
              className="p-1.5 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 hover:text-white"
            >
              <ArrowRight className="w-5 h-5" />
            </button>
            <div>
              <h2 className="text-base font-bold text-white flex items-center gap-1.5">
                <span>عارض النظام السيادي</span>
                <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950 px-2 py-0.5 rounded border border-emerald-800/40">
                  42 فرعاً
                </span>
              </h2>
            </div>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto">
          <SystemVisualizer onRequestRoleApp={onRequestRoleApp} />
        </div>
      </div>
    </div>
  );
};
